-- =============================================================================
-- Ecoskiller PostgreSQL Schema
-- Based on: PostgreSQL_Relational_Database_Technical_Specification.docx §9, §11
-- Run once against a fresh database before starting the MCP server.
-- =============================================================================

-- Extensions (spec §12 — trigram + FTS indexes)
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;  -- spec §16 monitoring

-- =============================================================================
-- ENUMS
-- =============================================================================

DO $$ BEGIN
    CREATE TYPE assessment_type AS ENUM ('technical', 'behavioral', 'group_discussion');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE assessment_status AS ENUM ('pending', 'in_progress', 'completed', 'graded');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE audit_action AS ENUM ('insert', 'update', 'delete');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- =============================================================================
-- TABLES
-- =============================================================================

-- candidates (spec §9 Schema — table 1)
CREATE TABLE IF NOT EXISTS candidates (
    id           UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
    email        TEXT         NOT NULL UNIQUE,
    name         TEXT         NOT NULL CHECK (char_length(name) BETWEEN 1 AND 200),
    phone        TEXT,
    organization TEXT,
    location     TEXT,
    skills       TEXT[]       DEFAULT '{}',
    resume_url   TEXT,
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ  NOT NULL DEFAULT now(),
    deleted_at   TIMESTAMPTZ  -- NULL = active; SET = soft-deleted (spec §6)
);

-- assessments (spec §9 Schema — table 2)
CREATE TABLE IF NOT EXISTS assessments (
    id               UUID              PRIMARY KEY DEFAULT uuid_generate_v4(),
    title            TEXT              NOT NULL,
    description      TEXT              DEFAULT '',
    type             assessment_type   NOT NULL,
    questions        JSONB             NOT NULL DEFAULT '{}',
    duration_minutes INTEGER           NOT NULL CHECK (duration_minutes BETWEEN 1 AND 480),
    pass_score       INTEGER           NOT NULL CHECK (pass_score BETWEEN 0 AND 100),
    status           assessment_status NOT NULL DEFAULT 'pending',
    created_at       TIMESTAMPTZ       NOT NULL DEFAULT now(),
    updated_at       TIMESTAMPTZ       NOT NULL DEFAULT now(),
    completed_at     TIMESTAMPTZ,
    created_by       UUID,
    deleted_at       TIMESTAMPTZ
);

-- assessment_results (spec §9 Schema — table 3)
CREATE TABLE IF NOT EXISTS assessment_results (
    id             UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    assessment_id  UUID        NOT NULL REFERENCES assessments(id) ON DELETE RESTRICT,
    candidate_id   UUID        NOT NULL REFERENCES candidates(id)  ON DELETE CASCADE,
    answers        JSONB       NOT NULL DEFAULT '{}',
    duration_ms    BIGINT,
    submitted_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (assessment_id, candidate_id)  -- one result per candidate per assessment (spec §11)
);

-- scores (spec §9 Schema — table 4)
CREATE TABLE IF NOT EXISTS scores (
    id             UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
    assessment_id  UUID         NOT NULL REFERENCES assessments(id) ON DELETE RESTRICT,
    candidate_id   UUID         NOT NULL REFERENCES candidates(id)  ON DELETE CASCADE,
    score          NUMERIC(5,2) NOT NULL CHECK (score BETWEEN 0 AND 100),
    breakdown      JSONB        DEFAULT '{}',
    calculated_at  TIMESTAMPTZ  NOT NULL DEFAULT now(),
    calculated_by  TEXT         DEFAULT 'ml-model-v1',
    created_at     TIMESTAMPTZ  NOT NULL DEFAULT now(),
    UNIQUE (assessment_id, candidate_id)  -- atomic upsert target (spec §6)
);

-- audit_logs (spec §9 Schema — table 5, spec §15 DPDP Act 2023)
CREATE TABLE IF NOT EXISTS audit_logs (
    id          BIGSERIAL    PRIMARY KEY,
    action      TEXT         NOT NULL CHECK (action IN ('insert','update','delete')),
    table_name  TEXT         NOT NULL,
    record_id   UUID,
    old_data    JSONB,
    new_data    JSONB,
    user_id     UUID,
    timestamp   TIMESTAMPTZ  NOT NULL DEFAULT now()
);

-- hiring_decisions
CREATE TABLE IF NOT EXISTS hiring_decisions (
    id            UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    candidate_id  UUID        NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
    assessment_id UUID        REFERENCES assessments(id),
    decision      TEXT        NOT NULL CHECK (decision IN ('offer','reject','hold','shortlist')),
    decided_by    UUID,
    notes         TEXT,
    decided_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- background_jobs (Kafka event queue fallback — spec §3)
CREATE TABLE IF NOT EXISTS background_jobs (
    id          UUID        PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_type    TEXT        NOT NULL,
    payload     JSONB       NOT NULL DEFAULT '{}',
    status      TEXT        NOT NULL DEFAULT 'pending'
                            CHECK (status IN ('pending','running','done','failed')),
    attempts    INTEGER     NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    scheduled_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =============================================================================
-- INDEXES (spec §12 Indexing Strategy)
-- =============================================================================

-- candidates
CREATE INDEX IF NOT EXISTS idx_candidates_email       ON candidates(email);
CREATE INDEX IF NOT EXISTS idx_candidates_org         ON candidates(organization);
CREATE INDEX IF NOT EXISTS idx_candidates_created_at  ON candidates(created_at);
CREATE INDEX IF NOT EXISTS idx_candidates_deleted_at  ON candidates(deleted_at);
-- Partial index: only active records (spec §12 partial indexes)
CREATE INDEX IF NOT EXISTS idx_candidates_active      ON candidates(id) WHERE deleted_at IS NULL;
-- Full-text search index (spec §12 GiST FTS)
CREATE INDEX IF NOT EXISTS idx_candidates_fts         ON candidates
    USING GIN(to_tsvector('english',
              coalesce(name,'') || ' ' || coalesce(email,'') || ' ' ||
              coalesce(organization,'') || ' ' || coalesce(array_to_string(skills,' '),'')));
-- Trigram index for fuzzy name search (spec §12)
CREATE INDEX IF NOT EXISTS idx_candidates_name_trgm   ON candidates USING GIN(name gin_trgm_ops);

-- assessments
CREATE INDEX IF NOT EXISTS idx_assessments_type       ON assessments(type);
CREATE INDEX IF NOT EXISTS idx_assessments_created_at ON assessments(created_at);
CREATE INDEX IF NOT EXISTS idx_assessments_active     ON assessments(id) WHERE deleted_at IS NULL;

-- assessment_results (spec §12 FK indexes)
CREATE INDEX IF NOT EXISTS idx_ar_candidate_id        ON assessment_results(candidate_id);
CREATE INDEX IF NOT EXISTS idx_ar_assessment_id       ON assessment_results(assessment_id);
CREATE INDEX IF NOT EXISTS idx_ar_submitted_at        ON assessment_results(submitted_at);
-- JSONB GIN index for answer search (spec §12)
CREATE INDEX IF NOT EXISTS idx_ar_answers_gin         ON assessment_results USING GIN(answers);

-- scores
CREATE INDEX IF NOT EXISTS idx_scores_candidate_id    ON scores(candidate_id);
CREATE INDEX IF NOT EXISTS idx_scores_score_desc      ON scores(score DESC);

-- audit_logs (spec §12 / §15)
CREATE INDEX IF NOT EXISTS idx_audit_record_id        ON audit_logs(record_id);
CREATE INDEX IF NOT EXISTS idx_audit_user_id          ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp        ON audit_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_table_name       ON audit_logs(table_name);

-- =============================================================================
-- TRIGGERS — updated_at auto-stamp
-- =============================================================================

CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

DO $$ BEGIN
    CREATE TRIGGER trg_candidates_updated_at
        BEFORE UPDATE ON candidates
        FOR EACH ROW EXECUTE FUNCTION update_timestamp();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TRIGGER trg_assessments_updated_at
        BEFORE UPDATE ON assessments
        FOR EACH ROW EXECUTE FUNCTION update_timestamp();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- =============================================================================
-- AUDIT TRIGGER — captures all INSERT/UPDATE/DELETE into audit_logs
-- Spec §15: "Trigger: captures all INSERT, UPDATE, DELETE; Logged: old_data, new_data"
-- =============================================================================

CREATE OR REPLACE FUNCTION audit_log_trigger()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
    INSERT INTO audit_logs (action, table_name, record_id, old_data, new_data, timestamp)
    VALUES (
        lower(TG_OP),
        TG_TABLE_NAME,
        COALESCE(
            CASE TG_OP WHEN 'DELETE' THEN (OLD.id)::uuid ELSE (NEW.id)::uuid END,
            NULL
        ),
        CASE TG_OP WHEN 'INSERT' THEN NULL ELSE to_jsonb(OLD) END,
        CASE TG_OP WHEN 'DELETE' THEN NULL ELSE to_jsonb(NEW) END,
        now()
    );
    RETURN COALESCE(NEW, OLD);
END;
$$;

DO $$ BEGIN
    CREATE TRIGGER trg_audit_candidates
        AFTER INSERT OR UPDATE OR DELETE ON candidates
        FOR EACH ROW EXECUTE FUNCTION audit_log_trigger();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TRIGGER trg_audit_assessments
        AFTER INSERT OR UPDATE OR DELETE ON assessments
        FOR EACH ROW EXECUTE FUNCTION audit_log_trigger();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TRIGGER trg_audit_scores
        AFTER INSERT OR UPDATE OR DELETE ON scores
        FOR EACH ROW EXECUTE FUNCTION audit_log_trigger();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TRIGGER trg_audit_hiring_decisions
        AFTER INSERT OR UPDATE OR DELETE ON hiring_decisions
        FOR EACH ROW EXECUTE FUNCTION audit_log_trigger();
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- =============================================================================
-- ROW-LEVEL SECURITY (spec §15: "Row-Level Security")
-- =============================================================================

-- Enable RLS on sensitive tables
ALTER TABLE candidates        ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessment_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE scores             ENABLE ROW LEVEL SECURITY;

-- Policy: app_user sees all rows (application enforces tenant scoping)
-- In production: replace current_user check with JWT claim function
CREATE POLICY IF NOT EXISTS allow_app_user_candidates
    ON candidates
    FOR ALL
    TO app_user
    USING (true);  -- app_user sees all — service-level RLS applied in application

-- Policy: read_only role can only SELECT
CREATE POLICY IF NOT EXISTS allow_readonly_candidates
    ON candidates
    FOR SELECT
    TO readonly_user
    USING (deleted_at IS NULL);  -- read_only sees only active candidates

-- =============================================================================
-- ROLES (spec §15: "Role: application user / read-only / admin")
-- =============================================================================

DO $$ BEGIN
    CREATE ROLE app_user WITH LOGIN;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE ROLE readonly_user WITH LOGIN;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- app_user: full CRUD on business tables, SELECT only on audit_logs
GRANT SELECT, INSERT, UPDATE, DELETE ON candidates, assessments,
      assessment_results, scores, hiring_decisions, background_jobs TO app_user;
GRANT SELECT ON audit_logs TO app_user;
-- No DELETE on audit_logs — spec §15: "prevent accidental deletion"

-- read_only: SELECT only
GRANT SELECT ON ALL TABLES IN SCHEMA public TO readonly_user;

-- Sequence access for BIGSERIAL
GRANT USAGE, SELECT ON SEQUENCE audit_logs_id_seq TO app_user;

-- =============================================================================
-- Comments (documentation in-database)
-- =============================================================================

COMMENT ON TABLE candidates         IS 'Candidate profiles — source of truth (spec §9)';
COMMENT ON TABLE assessments        IS 'Assessment definitions and question banks (spec §9)';
COMMENT ON TABLE assessment_results IS 'Candidate assessment submissions (spec §9)';
COMMENT ON TABLE scores             IS 'ML-computed scores per assessment per candidate (spec §9)';
COMMENT ON TABLE audit_logs         IS 'Immutable audit trail — DPDP Act 2023, GDPR, SOC2 (spec §15). Retain 7 years.';
COMMENT ON TABLE hiring_decisions   IS 'Final hiring decisions per candidate';

-- =============================================================================
-- Done
-- =============================================================================
SELECT 'Schema initialised successfully' AS status;
