# ecoskiller-postgres-mcp

**Ecoskiller | CAT-01 — PostgreSQL Primary Database**  
MCP Server in **Java 17** | **18 Tools** | Priority: **CRITICAL**

> Built from: `PostgreSQL_Relational_Database_Technical_Specification.docx` v2.0 (March 2026)  
> Architecture: Kubernetes Multi-Cloud (GCP Cloud SQL + AWS RDS)

---

## Overview

Secure Java MCP server that exposes the Ecoskiller PostgreSQL database to Claude via the Model Context Protocol (JSON-RPC 2.0, stdio transport).

Implements every security control from the spec §15:
- ✅ TLS in transit (`sslmode=require` enforced)
- ✅ Prepared statements only (SQL injection prevention)
- ✅ Input sanitisation + injection pattern detection
- ✅ Table & column allowlists
- ✅ Role-based access (`app_user` / `read_only` / `admin`)
- ✅ Rate limiting (120 calls/min per tool)
- ✅ DPDP Act 2023 audit logging on every write
- ✅ Soft-delete only (preserves audit trail)
- ✅ HikariCP connection pool (mirrors pgBouncer config)

---

## Tools (18)

| # | Tool | Category | Description |
|---|------|----------|-------------|
| 1 | `pg_list_tables` | Schema | All tables with size & row estimates |
| 2 | `pg_describe_table` | Schema | Columns, types, constraints, FK |
| 3 | `pg_list_indexes` | Schema | Index type, size, columns, definition |
| 4 | `pg_explain_query` | Schema | EXPLAIN ANALYZE on SELECT queries |
| 5 | `pg_search_candidates` | Candidate | Full-text + trigram search (FTS spec §5) |
| 6 | `pg_insert_candidate` | Candidate | Register new candidate + audit log |
| 7 | `pg_update_candidate` | Candidate | Update fields + audit log |
| 8 | `pg_soft_delete_candidate` | Candidate | Soft-delete (spec §6 "soft delete preferred") |
| 9 | `pg_get_assessment_results` | Assessment | Results + joined scores |
| 10 | `pg_insert_assessment` | Assessment | Create assessment definition |
| 11 | `pg_upsert_score` | Assessment | Atomic INSERT ON CONFLICT upsert |
| 12 | `pg_audit_log_query` | Audit | Query audit_logs by record/user/table/time |
| 13 | `pg_audit_record_history` | Audit | Full before/after change history |
| 14 | `pg_compliance_report` | Audit | DPDP/GDPR/SOC2 compliance summary |
| 15 | `pg_execute_transaction` | Transaction | Atomic multi-statement transaction |
| 16 | `pg_health_check` | Monitoring | Connections, cache hit, replication lag, disk |
| 17 | `pg_vacuum_analyze` | Maintenance | VACUUM ANALYZE (spec §16) |
| 18 | `pg_reindex_table` | Maintenance | REINDEX CONCURRENTLY (spec §16) |

---

## Requirements

- Java 17+
- Maven 3.8+
- PostgreSQL 15.x (GCP Cloud SQL or AWS RDS)
- Schema applied: `psql -f schema.sql`

---

## Quick Start

### 1 — Apply schema
```bash
psql -h your-host -U postgres -d ecoskiller -f schema.sql
```

### 2 — Build fat JAR
```bash
mvn clean package -q
# Output: target/ecoskiller-postgres-mcp-1.0.0.jar
```

### 3 — Set environment variables
```bash
export PG_HOST=your-postgres-host
export PG_PORT=5432
export PG_DATABASE=ecoskiller
export PG_USER=app_user
export PG_PASSWORD=your_strong_20char_password
export PG_SSL_MODE=require                       # ALWAYS require in production
export PG_SSL_ROOT_CERT=/path/to/server-ca.pem  # GCP/AWS CA cert
export MCP_DB_ROLE=app_user
```

### 4 — Run
```bash
java -jar target/ecoskiller-postgres-mcp-1.0.0.jar
```
The server reads JSON-RPC from **stdin** and writes to **stdout**.  
All logs go to **stderr** (stdout stays clean for MCP protocol).

### 5 — Test
```bash
python3 test_mcp_server.py           # quick pass/fail
python3 test_mcp_server.py --verbose # full JSON output
python3 test_mcp_server.py pg_health_check  # single tool
```

---

## Connect to Claude Desktop

Edit `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "ecoskiller-postgres-mcp": {
      "command": "java",
      "args": ["-jar", "/absolute/path/to/target/ecoskiller-postgres-mcp-1.0.0.jar"],
      "env": {
        "PG_HOST":         "your-postgres-host",
        "PG_PORT":         "5432",
        "PG_DATABASE":     "ecoskiller",
        "PG_USER":         "app_user",
        "PG_PASSWORD":     "YOUR_STRONG_PASSWORD",
        "PG_SSL_MODE":     "require",
        "MCP_DB_ROLE":     "app_user"
      }
    }
  }
}
```

---

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PG_HOST` | No | `localhost` | PostgreSQL hostname |
| `PG_PORT` | No | `5432` | PostgreSQL port |
| `PG_DATABASE` | **Yes** | — | Database name |
| `PG_USER` | **Yes** | — | Database username |
| `PG_PASSWORD` | **Yes** | — | Password (20+ chars, rotate every 90 days per spec §15) |
| `PG_SSL_MODE` | No | `require` | `require` / `verify-full` / `disable` (disable = dev only) |
| `PG_SSL_ROOT_CERT` | No | — | Path to server CA cert (for `verify-full`) |
| `PG_SSL_CERT` | No | — | Client certificate path (mTLS) |
| `PG_SSL_KEY` | No | — | Client key path (mTLS) |
| `PG_POOL_SIZE` | No | `20` | Max HikariCP pool size |
| `PG_POOL_MIN_IDLE` | No | `5` | Min idle connections |
| `PG_POOL_TIMEOUT` | No | `30000` | Connection timeout (ms) |
| `MCP_DB_ROLE` | No | `app_user` | Role for RBAC checks: `app_user` / `read_only` / `admin` |

---

## File Structure

```
ecoskiller-postgres-mcp/
├── pom.xml                                         ← Maven build (Java 17, fat JAR)
├── schema.sql                                      ← DB schema, indexes, RLS, triggers
├── claude_desktop_config.json                      ← Claude Desktop config snippet
├── test_mcp_server.py                              ← Integration test (Python 3)
├── README.md
└── src/main/java/com/ecoskiller/mcp/
    ├── server/
    │   ├── McpServer.java                          ← Main — stdio JSON-RPC loop
    │   └── McpException.java                       ← Typed exception with error codes
    ├── config/
    │   └── DatabaseConfig.java                     ← Env vars → HikariCP DataSource
    ├── security/
    │   └── SecurityManager.java                    ← Injection guard, allowlists, rate limit
    └── tools/
        ├── ToolRegistry.java                       ← Tool registration & dispatch
        ├── BaseTools.java                          ← Shared JDBC utilities
        ├── SchemaTools.java                        ← pg_list_tables … pg_explain_query
        ├── CandidateTools.java                     ← pg_search_candidates … pg_soft_delete
        ├── AssessmentTools.java                    ← pg_get_assessment_results … pg_upsert_score
        ├── AuditTools.java                         ← pg_audit_log_query … pg_compliance_report
        ├── TransactionTools.java                   ← pg_execute_transaction
        └── MaintenanceTools.java                   ← pg_health_check, pg_vacuum_analyze, pg_reindex_table
```

---

## Protocol

| Property | Value |
|----------|-------|
| Transport | **stdio** (stdin/stdout) |
| Format | **JSON-RPC 2.0** |
| MCP Version | **2024-11-05** |
| Methods | `initialize`, `ping`, `tools/list`, `tools/call` |

---

## Security Notes

1. **Never hard-code credentials** — always use environment variables
2. **Always use `PG_SSL_MODE=require`** in production (spec §15: "No unencrypted traffic allowed")
3. **Rotate PG_PASSWORD every 90 days** (spec §15: "Password: rotated every 90 days")
4. **`read_only` role** cannot call write tools — set `MCP_DB_ROLE=read_only` for reporting agents
5. **Audit logs** are written for every INSERT/UPDATE/DELETE — retained 7 years (DPDP Act 2023)
6. The `pg_execute_transaction` tool rejects all DDL (`DROP`, `TRUNCATE`, `ALTER`, `CREATE`, etc.)
7. `pg_shadow`, `pg_authid`, `information_schema` access is blocked via table allowlist

---

## Spec Compliance Mapping

| Spec Section | Implemented By |
|---|---|
| §5 Full-text + trigram search | `pg_search_candidates` (GIN + pg_trgm) |
| §6 Prepared statements | All tools use `PreparedStatement` |
| §6 Soft delete preferred | `pg_soft_delete_candidate` |
| §6 Upsert ON CONFLICT | `pg_upsert_score` |
| §6 Connection pooling 20 | `DatabaseConfig` HikariCP |
| §9 Schema (5 core tables) | `schema.sql` |
| §12 Indexes (B-tree, GIN, GiST, partial) | `schema.sql` |
| §15 TLS sslmode=require | `DatabaseConfig` |
| §15 RBAC app_user/read_only | `SecurityManager` + `schema.sql` |
| §15 RLS policies | `schema.sql` |
| §15 Audit logging DPDP | `CandidateTools.insertAuditLog()` |
| §15 SQL injection prevention | `SecurityManager.checkForInjection()` |
| §16 Connection count metric | `pg_health_check` |
| §16 Cache hit ratio metric | `pg_health_check` |
| §16 Replication lag metric | `pg_health_check` |
| §16 Slow query tracking | `pg_health_check` (pg_stat_statements) |
| §16 VACUUM ANALYZE | `pg_vacuum_analyze` |
| §16 REINDEX CONCURRENTLY | `pg_reindex_table` |
