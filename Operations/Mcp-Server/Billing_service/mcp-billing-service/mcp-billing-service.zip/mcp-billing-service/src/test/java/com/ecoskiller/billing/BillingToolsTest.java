package com.ecoskiller.billing;

import com.ecoskiller.billing.security.RequestValidator;
import com.ecoskiller.billing.server.ValidationException;
import com.ecoskiller.billing.tools.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.*;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for all 18 EcoSkiller Billing MCP tools.
 *
 * Tests cover:
 *  - Happy-path execution
 *  - Required-field validation
 *  - Invalid UUID rejection
 *  - Invalid enum value rejection
 *  - Negative / zero amount rejection
 *  - Over-length string rejection
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class BillingToolsTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static RequestValidator validator;

    private static final String TENANT_ID  = UUID.randomUUID().toString();
    private static final String SUB_ID     = UUID.randomUUID().toString();
    private static final String INV_ID     = UUID.randomUUID().toString();
    private static final String PAY_ID     = UUID.randomUUID().toString();
    private static final String IDEM_KEY   = UUID.randomUUID().toString();
    private static final String RES_ID     = UUID.randomUUID().toString();

    @BeforeAll
    static void setUp() {
        validator = new RequestValidator();
    }

    // ── Helper ─────────────────────────────────────────────────────────────

    private ObjectNode args(String... kv) {
        ObjectNode node = MAPPER.createObjectNode();
        for (int i = 0; i < kv.length - 1; i += 2) node.put(kv[i], kv[i + 1]);
        return node;
    }

    private void assertSuccess(JsonNode result) {
        assertNotNull(result, "result must not be null");
        assertEquals("success", result.path("status").asText(), "Expected status=success");
    }

    private void assertError(JsonNode result) {
        assertNotNull(result);
        assertEquals("error", result.path("status").asText(), "Expected status=error");
    }

    // ── Tool 1: List Plans ─────────────────────────────────────────────────

    @Test @Order(1)
    void listPlans_noArgs_returns3Plans() {
        var tool   = new SubscriptionListPlansTool(validator);
        var result = tool.execute(MAPPER.createObjectNode());
        assertSuccess(result);
        assertEquals(3, result.path("plans").size(), "Should return 3 plans");
    }

    // ── Tool 2: Create Subscription ────────────────────────────────────────

    @Test @Order(2)
    void createSubscription_happyPath() {
        var tool   = new SubscriptionCreateTool(validator);
        var result = tool.execute(args(
            "tenant_id",       TENANT_ID,
            "plan_id",         "professional",
            "billing_email",   "billing@test.com",
            "idempotency_key", IDEM_KEY
        ));
        assertSuccess(result);
        assertEquals("professional", result.path("plan_id").asText());
        assertEquals("active",       result.path("status").asText());
        assertNotNull(result.path("subscription_id").asText());
    }

    @Test @Order(3)
    void createSubscription_missingTenantId_throws() {
        var tool = new SubscriptionCreateTool(validator);
        assertThrows(ValidationException.class, () -> tool.execute(args(
            "plan_id",         "professional",
            "billing_email",   "x@x.com",
            "idempotency_key", IDEM_KEY
        )));
    }

    @Test @Order(4)
    void createSubscription_invalidUuid_throws() {
        var tool = new SubscriptionCreateTool(validator);
        assertThrows(ValidationException.class, () -> tool.execute(args(
            "tenant_id",       "not-a-uuid",
            "plan_id",         "professional",
            "billing_email",   "x@x.com",
            "idempotency_key", IDEM_KEY
        )));
    }

    @Test @Order(5)
    void createSubscription_invalidPlan_throws() {
        var tool = new SubscriptionCreateTool(validator);
        assertThrows(ValidationException.class, () -> tool.execute(args(
            "tenant_id",       TENANT_ID,
            "plan_id",         "premium-gold", // invalid
            "billing_email",   "x@x.com",
            "idempotency_key", IDEM_KEY
        )));
    }

    @Test @Order(6)
    void createSubscription_trialFlag_setsTrialStatus() {
        var tool   = new SubscriptionCreateTool(validator);
        ObjectNode a = args(
            "tenant_id",       TENANT_ID,
            "plan_id",         "enterprise",
            "billing_email",   "cto@corp.com",
            "idempotency_key", UUID.randomUUID().toString()
        );
        a.put("start_trial", true);
        var result = tool.execute(a);
        assertSuccess(result);
        assertEquals("trial", result.path("status").asText());
    }

    // ── Tool 3: Get Subscription ────────────────────────────────────────────

    @Test @Order(7)
    void getSubscription_happyPath() {
        var result = new SubscriptionGetTool(validator).execute(args(
            "tenant_id",       TENANT_ID,
            "subscription_id", SUB_ID
        ));
        assertSuccess(result);
        assertEquals(SUB_ID, result.path("subscription_id").asText());
    }

    // ── Tool 4: Upgrade Subscription ───────────────────────────────────────

    @Test @Order(8)
    void upgradeSubscription_professionalToEnterprise() {
        var result = new SubscriptionUpgradeTool(validator).execute(args(
            "tenant_id",       TENANT_ID,
            "subscription_id", SUB_ID,
            "new_plan_id",     "enterprise",
            "idempotency_key", UUID.randomUUID().toString()
        ));
        assertSuccess(result);
        assertEquals("enterprise", result.path("new_plan_id").asText());
    }

    @Test @Order(9)
    void upgradeSubscription_invalidPlan_throws() {
        assertThrows(ValidationException.class, () ->
            new SubscriptionUpgradeTool(validator).execute(args(
                "tenant_id",       TENANT_ID,
                "subscription_id", SUB_ID,
                "new_plan_id",     "ultra",   // invalid
                "idempotency_key", UUID.randomUUID().toString()
            ))
        );
    }

    // ── Tool 5: Cancel Subscription ────────────────────────────────────────

    @Test @Order(10)
    void cancelSubscription_atPeriodEnd() {
        var result = new SubscriptionCancelTool(validator).execute(args(
            "tenant_id",       TENANT_ID,
            "subscription_id", SUB_ID,
            "reason",          "Budget reduction"
        ));
        assertSuccess(result);
        assertTrue(result.path("cancel_at_period_end").asBoolean());
        assertEquals("active", result.path("status").asText());
    }

    @Test @Order(11)
    void cancelSubscription_immediate() {
        ObjectNode a = args(
            "tenant_id",       TENANT_ID,
            "subscription_id", SUB_ID
        );
        a.put("cancel_immediately", true);
        var result = new SubscriptionCancelTool(validator).execute(a);
        assertSuccess(result);
        assertEquals("cancelled", result.path("status").asText());
    }

    // ── Tool 6: Check Entitlement ───────────────────────────────────────────

    @Test @Order(12)
    void checkEntitlement_aiScoring_allowed() {
        var result = new SubscriptionCheckEntitlementTool(validator).execute(args(
            "tenant_id", TENANT_ID,
            "feature",   "ai_scoring"
        ));
        assertSuccess(result);
        assertTrue(result.path("allowed").asBoolean());
    }

    @Test @Order(13)
    void checkEntitlement_customBranding_denied() {
        var result = new SubscriptionCheckEntitlementTool(validator).execute(args(
            "tenant_id", TENANT_ID,
            "feature",   "custom_branding"
        ));
        assertSuccess(result);
        assertFalse(result.path("allowed").asBoolean());
        assertTrue(result.path("upgrade_required").asBoolean());
    }

    @Test @Order(14)
    void checkEntitlement_unknownFeature_returnsError() {
        var result = new SubscriptionCheckEntitlementTool(validator).execute(args(
            "tenant_id", TENANT_ID,
            "feature",   "teleport_access"
        ));
        assertError(result);
    }

    // ── Tool 7: Record Usage ────────────────────────────────────────────────

    @Test @Order(15)
    void recordUsage_gdSession_success() {
        var result = new UsageRecordTool(validator).execute(args(
            "tenant_id",       TENANT_ID,
            "resource_type",   "gd_session",
            "resource_id",     RES_ID,
            "idempotency_key", UUID.randomUUID().toString()
        ));
        assertSuccess(result);
        assertNotNull(result.path("usage_record_id").asText());
    }

    @Test @Order(16)
    void recordUsage_invalidResourceType_returnsError() {
        var result = new UsageRecordTool(validator).execute(args(
            "tenant_id",       TENANT_ID,
            "resource_type",   "unknown_resource",
            "resource_id",     RES_ID,
            "idempotency_key", UUID.randomUUID().toString()
        ));
        assertError(result);
    }

    // ── Tool 8: Get Usage ───────────────────────────────────────────────────

    @Test @Order(17)
    void getUsage_withHistory() {
        ObjectNode a = args("tenant_id", TENANT_ID);
        a.put("include_history", true);
        var result = new UsageGetTool(validator).execute(a);
        assertSuccess(result);
        assertTrue(result.has("billing_history"));
        assertEquals(3, result.path("billing_history").size());
    }

    // ── Tool 9: Generate Invoice ────────────────────────────────────────────

    @Test @Order(18)
    void generateInvoice_happyPath() {
        var result = new InvoiceGenerateTool(validator).execute(args(
            "tenant_id",       TENANT_ID,
            "subscription_id", SUB_ID,
            "period_start",    "2025-01-01T00:00:00Z",
            "period_end",      "2025-01-31T23:59:59Z",
            "idempotency_key", UUID.randomUUID().toString()
        ));
        assertSuccess(result);
        assertTrue(result.path("invoice_number").asText().startsWith("INV-"));
        assertEquals("issued",  result.path("status").asText());
        assertEquals("5898.82", result.path("total_amount").asText());
        assertTrue(result.path("gst_invoice").asBoolean());
    }

    // ── Tool 10: List Invoices ──────────────────────────────────────────────

    @Test @Order(19)
    void listInvoices_allStatuses() {
        var result = new InvoiceListTool(validator).execute(args("tenant_id", TENANT_ID));
        assertSuccess(result);
        assertEquals(6, result.path("invoices").size());
    }

    @Test @Order(20)
    void listInvoices_invalidStatus_throws() {
        assertThrows(ValidationException.class, () ->
            new InvoiceListTool(validator).execute(args(
                "tenant_id", TENANT_ID,
                "status",    "pending"  // not a valid invoice status
            ))
        );
    }

    // ── Tool 11: Get Invoice ────────────────────────────────────────────────

    @Test @Order(21)
    void getInvoice_happyPath() {
        var result = new InvoiceGetTool(validator).execute(args(
            "tenant_id",  TENANT_ID,
            "invoice_id", INV_ID
        ));
        assertSuccess(result);
        assertTrue(result.has("line_items"));
        assertTrue(result.path("gst_invoice").asBoolean());
    }

    // ── Tool 12: Invoice Download URL ──────────────────────────────────────

    @Test @Order(22)
    void invoiceDownloadUrl_returnsSignedUrl() {
        var result = new InvoiceDownloadUrlTool(validator).execute(args(
            "tenant_id",  TENANT_ID,
            "invoice_id", INV_ID
        ));
        assertSuccess(result);
        assertTrue(result.path("download_url").asText().contains("X-Amz-Expires"));
        assertEquals(86400, result.path("expires_in_secs").asInt());
    }

    // ── Tool 13: Initiate Payment ───────────────────────────────────────────

    @Test @Order(23)
    void initiatePayment_upi_createsIntent() {
        var result = new PaymentInitiateTool(validator).execute(args(
            "tenant_id",       TENANT_ID,
            "invoice_id",      INV_ID,
            "amount",          "5898.82",
            "currency",        "INR",
            "payment_method",  "upi",
            "idempotency_key", UUID.randomUUID().toString()
        ));
        assertSuccess(result);
        assertEquals("pending", result.path("status").asText());
        assertTrue(result.path("gateway_url").asText().contains("checkout"));
    }

    @Test @Order(24)
    void initiatePayment_zeroAmount_throws() {
        assertThrows(ValidationException.class, () ->
            new PaymentInitiateTool(validator).execute(args(
                "tenant_id",       TENANT_ID,
                "invoice_id",      INV_ID,
                "amount",          "0.00",        // invalid
                "currency",        "INR",
                "payment_method",  "upi",
                "idempotency_key", UUID.randomUUID().toString()
            ))
        );
    }

    @Test @Order(25)
    void initiatePayment_negativAmount_throws() {
        assertThrows(ValidationException.class, () ->
            new PaymentInitiateTool(validator).execute(args(
                "tenant_id",       TENANT_ID,
                "invoice_id",      INV_ID,
                "amount",          "-100.00",     // invalid
                "currency",        "INR",
                "payment_method",  "upi",
                "idempotency_key", UUID.randomUUID().toString()
            ))
        );
    }

    @Test @Order(26)
    void initiatePayment_invalidCurrency_throws() {
        assertThrows(ValidationException.class, () ->
            new PaymentInitiateTool(validator).execute(args(
                "tenant_id",       TENANT_ID,
                "invoice_id",      INV_ID,
                "amount",          "100.00",
                "currency",        "BTC",         // invalid
                "payment_method",  "upi",
                "idempotency_key", UUID.randomUUID().toString()
            ))
        );
    }

    // ── Tool 14: Confirm Payment ────────────────────────────────────────────

    @Test @Order(27)
    void confirmPayment_validSignature_success() {
        var result = new PaymentConfirmTool(validator).execute(args(
            "payment_intent_id",       UUID.randomUUID().toString(),
            "gateway_transaction_id",  "TXN_12345",
            "amount_received",         "5898.82",
            "currency",                "INR",
            "webhook_signature",       "sha256-abc123",
            "idempotency_key",         UUID.randomUUID().toString()
        ));
        assertSuccess(result);
        assertEquals("completed", result.path("status").asText());
        assertEquals("paid",      result.path("invoice_status").asText());
        assertTrue(result.path("signature_verified").asBoolean());
    }

    // ── Tool 15: Refund Payment ─────────────────────────────────────────────

    @Test @Order(28)
    void refundPayment_partialRefund() {
        var result = new PaymentRefundTool(validator).execute(args(
            "tenant_id",       TENANT_ID,
            "payment_id",      PAY_ID,
            "refund_amount",   "2500.00",
            "currency",        "INR",
            "reason",          "Duplicate charge",
            "idempotency_key", UUID.randomUUID().toString()
        ));
        assertSuccess(result);
        assertEquals("processing", result.path("status").asText());
        assertEquals("2500.00",    result.path("refund_amount").asText());
    }

    @Test @Order(29)
    void refundPayment_missingReason_throws() {
        assertThrows(ValidationException.class, () ->
            new PaymentRefundTool(validator).execute(args(
                "tenant_id",       TENANT_ID,
                "payment_id",      PAY_ID,
                "refund_amount",   "100.00",
                "currency",        "INR",
                "idempotency_key", UUID.randomUUID().toString()
                // reason intentionally missing
            ))
        );
    }

    // ── Tool 16: Get Payment Status ─────────────────────────────────────────

    @Test @Order(30)
    void getPaymentStatus_includesAuditChain() {
        var result = new PaymentGetStatusTool(validator).execute(args(
            "tenant_id",  TENANT_ID,
            "payment_id", PAY_ID
        ));
        assertSuccess(result);
        assertEquals("completed", result.path("status").asText());
        assertTrue(result.path("audit").path("immutable").asBoolean());
    }

    // ── Tool 17: Audit Log ──────────────────────────────────────────────────

    @Test @Order(31)
    void auditLog_noFilter_returns7Records() {
        var result = new AuditLogTool(validator).execute(args("tenant_id", TENANT_ID));
        assertSuccess(result);
        assertEquals(7, result.path("records").size());
        assertTrue(result.path("immutable").asBoolean());
    }

    @Test @Order(32)
    void auditLog_invalidEventType_returnsError() {
        var result = new AuditLogTool(validator).execute(args(
            "tenant_id",  TENANT_ID,
            "event_type", "hack.attempt"
        ));
        assertError(result);
    }

    // ── Tool 18: Health ─────────────────────────────────────────────────────

    @Test @Order(33)
    void health_allDependenciesUp() {
        var result = new BillingHealthTool(validator).execute(MAPPER.createObjectNode());
        assertEquals("UP",      result.path("status").asText());
        assertEquals(5,         result.path("dependency_checks").size());
        assertTrue(result.path("slo_status").path("within_slo").asBoolean());
    }

    // ── Validator — Extra Security Tests ────────────────────────────────────

    @Test @Order(34)
    void validator_sqlInjectionInString_throws() {
        assertThrows(ValidationException.class, () ->
            validator.optionalSafeString(
                args("notes", "'; DROP TABLE subscriptions; --"),
                "notes", 500
            )
        );
    }

    @Test @Order(35)
    void validator_oversizeString_throws() {
        String huge = "A".repeat(501);
        assertThrows(ValidationException.class, () ->
            validator.optionalSafeString(args("notes", huge), "notes", 500)
        );
    }

    @Test @Order(36)
    void validator_amountWithMoreThan2Decimals_throws() {
        assertThrows(ValidationException.class, () ->
            validator.requireAmount(args("amount", "99.999"), "amount")
        );
    }

    @Test @Order(37)
    void validator_validAmounts_pass() {
        assertDoesNotThrow(() -> {
            validator.requireAmount(args("a", "1"),         "a");
            validator.requireAmount(args("a", "9999.99"),   "a");
            validator.requireAmount(args("a", "0.01"),      "a");
            validator.requireAmount(args("a", "100"),       "a");
        });
    }
}
