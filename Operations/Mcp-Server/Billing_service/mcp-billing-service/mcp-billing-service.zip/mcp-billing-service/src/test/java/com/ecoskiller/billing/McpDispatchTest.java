package com.ecoskiller.billing;

import com.ecoskiller.billing.server.BillingMcpServer;
import com.ecoskiller.billing.tools.ToolRegistry;
import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for the JSON-RPC dispatch layer.
 * Tests the full request → dispatch → response pipeline.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class McpDispatchTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private ToolRegistry registry;

    @BeforeEach
    void setUp() {
        registry = new ToolRegistry(new RequestValidator());
    }

    @Test @Order(1)
    void toolsList_returns18Tools() {
        var tools = registry.listTools();
        assertEquals(18, tools.size(), "Registry must expose exactly 18 billing tools");
    }

    @Test @Order(2)
    void allTools_haveRequiredSchemaFields() {
        registry.listTools().forEach(toolNode -> {
            assertNotNull(toolNode.get("name"),        "Tool must have name");
            assertNotNull(toolNode.get("description"), "Tool must have description");
            assertNotNull(toolNode.get("inputSchema"), "Tool must have inputSchema");
        });
    }

    @Test @Order(3)
    void allToolNames_areUnique() {
        var names = new java.util.HashSet<String>();
        registry.listTools().forEach(t -> {
            String name = t.path("name").asText();
            assertTrue(names.add(name), "Duplicate tool name: " + name);
        });
    }

    @Test @Order(4)
    void allToolNames_startWithBillingPrefix() {
        registry.listTools().forEach(t -> {
            String name = t.path("name").asText();
            assertTrue(name.startsWith("billing_"),
                "Tool name must start with 'billing_': " + name);
        });
    }

    @Test @Order(5)
    void unknownTool_throwsToolNotFoundException() {
        assertThrows(
            com.ecoskiller.billing.server.ToolNotFoundException.class,
            () -> registry.call("non_existent_tool", MAPPER.createObjectNode())
        );
    }

    @Test @Order(6)
    void billingHealth_noArgs_returnsUpStatus() {
        JsonNode result = registry.call("billing_health", MAPPER.createObjectNode());
        assertEquals("UP", result.path("status").asText());
    }

    @Test @Order(7)
    void billingListPlans_noArgs_returnsPlans() {
        JsonNode result = registry.call("billing_list_plans", MAPPER.createObjectNode());
        assertEquals("success", result.path("status").asText());
        assertEquals(3, result.path("plans").size());
    }
}
