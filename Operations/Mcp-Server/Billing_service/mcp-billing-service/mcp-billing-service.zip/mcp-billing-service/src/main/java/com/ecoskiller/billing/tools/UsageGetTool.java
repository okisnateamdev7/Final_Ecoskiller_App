package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** billing_get_usage — Retrieve usage metrics for the current billing period */
public class UsageGetTool extends AbstractBillingTool {

    public UsageGetTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_get_usage"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "Retrieve current billing period usage summary for a tenant. " +
            "Returns per-resource breakdown and percentage of quota consumed.");
        addStringProp(schema, "tenant_id", "UUID of the tenant (from JWT claim)", true);
        addBoolProp  (schema, "include_history", "Include last 3 billing periods");
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String  tenantId       = validator.requireUuid(args, "tenant_id");
        boolean includeHistory = validator.optionalBoolean(args, "include_history", false);

        ObjectNode result = success("Usage summary retrieved");
        result.put("tenant_id",     tenantId);
        result.put("plan_id",       "professional");
        result.put("period_start",  nowIso());
        result.put("period_end",    futureIso(30));
        result.put("days_remaining", 22);

        ObjectNode current = result.putObject("current_period");
        current.put("total_units_used", 47);
        current.put("total_units_limit", 200);
        current.put("utilization_pct", 23.5);

        ArrayNode breakdown = current.putArray("breakdown");
        addUsageRow(breakdown, "gd_session",         12, 100, 12.0);
        addUsageRow(breakdown, "interview_session",    8,  60,  13.3);
        addUsageRow(breakdown, "dojo_match",           3,  20,  15.0);
        addUsageRow(breakdown, "ai_scoring_call",     23, 200, 11.5);
        addUsageRow(breakdown, "analytics_export",     1,  10,  10.0);

        if (includeHistory) {
            ArrayNode history = result.putArray("billing_history");
            addHistoryRow(history, futureIso(-60), futureIso(-30), 89, 200);
            addHistoryRow(history, futureIso(-90), futureIso(-60), 134, 200);
            addHistoryRow(history, futureIso(-120), futureIso(-90), 67, 200);
        }

        return result;
    }

    private void addUsageRow(ArrayNode arr, String type, int used, int limit, double pct) {
        ObjectNode row = arr.addObject();
        row.put("resource_type", type);
        row.put("used",  used);
        row.put("limit", limit);
        row.put("utilization_pct", pct);
    }

    private void addHistoryRow(ArrayNode arr, String start, String end, int used, int limit) {
        ObjectNode row = arr.addObject();
        row.put("period_start", start);
        row.put("period_end",   end);
        row.put("total_used",   used);
        row.put("limit",        limit);
    }
}
