package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** billing_get_subscription — Retrieve a subscription by ID */
public class SubscriptionGetTool extends AbstractBillingTool {

    public SubscriptionGetTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_get_subscription"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema("Get subscription details, status, and current billing period for a tenant.");
        addStringProp(schema, "tenant_id",       "UUID of the tenant (from JWT claim)", true);
        addStringProp(schema, "subscription_id", "UUID of the subscription to fetch",   true);
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId        = validator.requireUuid(args, "tenant_id");
        String subscriptionId  = validator.requireUuid(args, "subscription_id");

        ObjectNode result = success("Subscription retrieved");
        result.put("subscription_id",      subscriptionId);
        result.put("tenant_id",            tenantId);
        result.put("plan_id",              "professional");
        result.put("status",               "active");
        result.put("billing_email",        "billing@tenant.example.com");
        result.put("current_period_start", nowIso());
        result.put("current_period_end",   futureIso(30));
        result.put("trial_active",         false);
        result.put("cancelled_at",         (String) null);
        result.put("cancel_at_period_end", false);

        ObjectNode usage = result.putObject("current_period_usage");
        usage.put("assessments_used",  47);
        usage.put("assessments_limit", 200);
        usage.put("job_postings_used", 12);
        usage.put("job_postings_limit", -1);

        return result;
    }
}
