package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** billing_generate_invoice — Trigger invoice generation for a billing period */
public class InvoiceGenerateTool extends AbstractBillingTool {

    public InvoiceGenerateTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_generate_invoice"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "Generate a GST-compliant invoice for a completed billing period. " +
            "Stores PDF in MinIO (ecoskiller-invoices-{tenant_id} bucket). " +
            "Emits invoice.generated Kafka event → notification-service sends email.");
        addStringProp(schema, "tenant_id",       "UUID of the tenant",                       true);
        addStringProp(schema, "subscription_id", "UUID of the subscription",                 true);
        addStringProp(schema, "period_start",    "ISO-8601 billing period start (UTC)",       true);
        addStringProp(schema, "period_end",      "ISO-8601 billing period end (UTC)",         true);
        addStringProp(schema, "idempotency_key", "UUID — prevents duplicate invoice on retry", true);
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId       = validator.requireUuid(args, "tenant_id");
        String subscriptionId = validator.requireUuid(args, "subscription_id");
        String periodStart    = validator.requireString(args, "period_start");
        String periodEnd      = validator.requireString(args, "period_end");
        String idempotencyKey = validator.requireUuid(args, "idempotency_key");

        String invoiceId = newId();
        String invoiceNumber = "INV-" + System.currentTimeMillis();

        ObjectNode result = success("Invoice generated successfully");
        result.put("invoice_id",        invoiceId);
        result.put("invoice_number",    invoiceNumber);
        result.put("tenant_id",         tenantId);
        result.put("subscription_id",   subscriptionId);
        result.put("period_start",      periodStart);
        result.put("period_end",        periodEnd);
        result.put("status",            "issued");
        result.put("due_date",          futureIso(15));
        result.put("idempotency_key",   idempotencyKey);

        // Line items
        ArrayNode lineItems = result.putArray("line_items");
        addLineItem(lineItems, "Subscription — Professional Plan",     "4999.00");
        addLineItem(lineItems, "GD Sessions (12 sessions)",            "0.00");
        addLineItem(lineItems, "Interview Sessions (8 sessions)",      "0.00");

        // Totals with GST (18%)
        result.put("subtotal",          "4999.00");
        result.put("gst_rate",          "18");
        result.put("cgst_amount",        "449.91");
        result.put("sgst_amount",        "449.91");
        result.put("total_amount",       "5898.82");
        result.put("currency",           "INR");

        result.put("minio_bucket",      "ecoskiller-invoices-" + tenantId);
        result.put("minio_object_key",  "invoices/" + invoiceNumber + ".pdf");
        result.put("kafka_event",       "invoice.generated");
        result.put("audit_record_id",   newId());
        return result;
    }

    private void addLineItem(ArrayNode arr, String description, String amount) {
        ObjectNode item = arr.addObject();
        item.put("description", description);
        item.put("amount", amount);
        item.put("currency", "INR");
    }
}
