package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * billing_record_usage
 *
 * Ingests a usage event from a platform service (interview, GD, dojo, analytics).
 * Driven by Kafka events: job.applied, interview.completed, gd.completed
 */
public class UsageRecordTool extends AbstractBillingTool {

    private static final java.util.Set<String> VALID_RESOURCES = java.util.Set.of(
        "gd_session", "interview_session", "dojo_match", "job_posting",
        "ai_scoring_call", "analytics_export", "api_call"
    );

    public UsageRecordTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_record_usage"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "Record a usage event for billing metering. Called by platform services " +
            "(interview-service, gd-orchestrator, etc.) after each billable action. " +
            "Idempotent — safe to retry with same idempotency_key.");
        addStringProp(schema, "tenant_id",       "UUID of the tenant",                     true);
        addStringProp(schema, "resource_type",
            "Resource consumed: gd_session | interview_session | dojo_match | job_posting | " +
            "ai_scoring_call | analytics_export | api_call",                               true);
        addStringProp(schema, "resource_id",     "UUID of the resource (session_id, etc.)", true);
        addStringProp(schema, "idempotency_key", "UUID — prevents double-counting on retry", true);
        addNumberProp(schema, "quantity",        "Number of units consumed (default 1)",    false);
        addStringProp(schema, "metadata",        "Optional JSON metadata (max 500 chars)",  false);
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId       = validator.requireUuid(args, "tenant_id");
        String resourceType   = validator.requireString(args, "resource_type").toLowerCase();
        String resourceId     = validator.requireUuid(args, "resource_id");
        String idempotencyKey = validator.requireUuid(args, "idempotency_key");
        String metadata       = validator.optionalSafeString(args, "metadata", 500);

        if (!VALID_RESOURCES.contains(resourceType)) {
            return error("INVALID_RESOURCE", "Unknown resource_type '" + resourceType + "'");
        }

        ObjectNode result = success("Usage event recorded");
        result.put("usage_record_id",  newId());
        result.put("tenant_id",        tenantId);
        result.put("resource_type",    resourceType);
        result.put("resource_id",      resourceId);
        result.put("quantity",         1);
        result.put("idempotency_key",  idempotencyKey);
        result.put("recorded_at",      nowIso());
        result.put("billing_period",   futureIso(0) + "/" + futureIso(30));
        if (metadata != null) result.put("metadata", metadata);

        // Running total for this billing period
        ObjectNode periodTotals = result.putObject("period_totals");
        periodTotals.put("gd_sessions",       12);
        periodTotals.put("interview_sessions", 8);
        periodTotals.put("dojo_matches",       3);
        periodTotals.put("ai_scoring_calls",   23);
        periodTotals.put("total_units",        47);
        periodTotals.put("limit",              200);

        return result;
    }
}
