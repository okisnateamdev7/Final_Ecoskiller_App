package com.ecoskiller.billing.tools;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Contract that every Billing MCP tool must implement.
 *
 * - name()    : unique tool identifier (snake_case)
 * - schema()  : JSON Schema describing the tool for the MCP tools/list response
 * - execute() : business logic; receives validated args, returns a JSON result node
 */
public interface BillingTool {
    String   name();
    JsonNode schema();
    JsonNode execute(JsonNode args);
}
