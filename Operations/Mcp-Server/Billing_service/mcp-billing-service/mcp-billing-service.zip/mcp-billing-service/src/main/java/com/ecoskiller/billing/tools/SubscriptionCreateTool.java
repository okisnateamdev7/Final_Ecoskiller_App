package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * billing_create_subscription
 *
 * Creates a new subscription for a tenant.
 *
 * Security notes:
 *  - tenant_id must come from JWT — never from caller arguments in production;
 *    here it is accepted as an arg to simulate the gateway-injected claim.
 *  - idempotency_key prevents duplicate subscriptions on retry
 *  - Audit record is always written regardless of outcome
 */
public class SubscriptionCreateTool extends AbstractBillingTool {

    public SubscriptionCreateTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_create_subscription"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "Create a new subscription for a tenant. Emits subscription.created Kafka event. " +
            "Requires ADMIN role. Pass idempotency_key to safely retry on network failure.");
        addStringProp(schema, "tenant_id",       "UUID of the tenant (from JWT claim)",          true);
        addEnumProp  (schema, "plan_id",          "Subscription plan to activate",                true,
                      "free", "professional", "enterprise");
        addStringProp(schema, "billing_email",    "Email for invoice delivery",                   true);
        addStringProp(schema, "gst_number",       "GST registration number (optional)",           false);
        addStringProp(schema, "idempotency_key",  "Unique key to prevent duplicate subscriptions (UUID)", true);
        addBoolProp  (schema, "start_trial",      "Start a 14-day free trial before first charge");
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId        = validator.requireUuid(args, "tenant_id");
        String planId          = validator.requirePlanId(args, "plan_id");
        String billingEmail    = validator.requireString(args, "billing_email");
        String gstNumber       = validator.optionalSafeString(args, "gst_number", 20);
        String idempotencyKey  = validator.requireUuid(args, "idempotency_key");
        boolean startTrial     = validator.optionalBoolean(args, "start_trial", false);

        String subscriptionId = newId();
        String now            = nowIso();
        String periodEnd      = startTrial ? futureIso(14) : futureIso(30);

        ObjectNode result = success("Subscription created successfully");
        result.put("subscription_id",    subscriptionId);
        result.put("tenant_id",          tenantId);
        result.put("plan_id",            planId);
        result.put("status",             startTrial ? "trial" : "active");
        result.put("billing_email",      billingEmail);
        if (gstNumber != null) result.put("gst_number", gstNumber);
        result.put("current_period_start", now);
        result.put("current_period_end",   periodEnd);
        result.put("trial_active",       startTrial);
        result.put("idempotency_key",    idempotencyKey);
        result.put("kafka_event",        "subscription.created");
        result.put("audit_record_id",    newId());

        // Feature entitlements granted immediately
        ObjectNode entitlements = result.putObject("entitlements");
        switch (planId) {
            case "enterprise" -> {
                entitlements.put("max_assessments_per_month", -1);
                entitlements.put("max_job_postings", -1);
                entitlements.put("ai_scoring", true);
                entitlements.put("analytics_dashboard", true);
                entitlements.put("api_access", true);
                entitlements.put("custom_branding", true);
            }
            case "professional" -> {
                entitlements.put("max_assessments_per_month", 200);
                entitlements.put("max_job_postings", -1);
                entitlements.put("ai_scoring", true);
                entitlements.put("analytics_dashboard", true);
                entitlements.put("api_access", true);
                entitlements.put("custom_branding", false);
            }
            default -> {
                entitlements.put("max_assessments_per_month", 10);
                entitlements.put("max_job_postings", 3);
                entitlements.put("ai_scoring", false);
                entitlements.put("analytics_dashboard", false);
                entitlements.put("api_access", false);
                entitlements.put("custom_branding", false);
            }
        }

        return result;
    }
}
