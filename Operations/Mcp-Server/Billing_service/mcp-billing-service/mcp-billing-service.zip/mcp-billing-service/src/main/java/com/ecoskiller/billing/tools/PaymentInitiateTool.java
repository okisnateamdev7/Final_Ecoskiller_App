package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * billing_initiate_payment
 *
 * Creates a payment intent for an invoice. Integrates with Kill Bill
 * (open-source payment orchestration) as per the Ecoskiller PCI-DSS
 * compliance decision — card data is NEVER stored directly.
 *
 * Supported payment methods: upi, net_banking, card, wallet
 */
public class PaymentInitiateTool extends AbstractBillingTool {

    public PaymentInitiateTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_initiate_payment"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "Initiate a payment for an invoice. Returns a payment_intent_id and " +
            "gateway redirect URL. Card data flows directly to the payment processor " +
            "— never through EcoSkiller servers (PCI-DSS compliance). " +
            "Uses Kill Bill as the payment orchestration layer.");
        addStringProp(schema, "tenant_id",       "UUID of the tenant (from JWT claim)",    true);
        addStringProp(schema, "invoice_id",      "UUID of the invoice to pay",             true);
        addStringProp(schema, "amount",          "Payment amount (must match invoice total)", true);
        addEnumProp  (schema, "currency",        "Payment currency",                       true,
                      "INR", "USD", "EUR");
        addEnumProp  (schema, "payment_method",  "Payment method",                         true,
                      "upi", "net_banking", "card", "wallet");
        addStringProp(schema, "idempotency_key", "UUID — prevents duplicate payment intent", true);
        addStringProp(schema, "return_url",      "URL to redirect after payment gateway",  false);
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId       = validator.requireUuid(args, "tenant_id");
        String invoiceId      = validator.requireUuid(args, "invoice_id");
        String amount         = validator.requireAmount(args, "amount");
        String currency       = validator.requireCurrency(args, "currency");
        String method         = validator.requireString(args, "payment_method").toLowerCase();
        String idempotencyKey = validator.requireUuid(args, "idempotency_key");
        String returnUrl      = validator.optionalSafeString(args, "return_url", 500);

        // Validate payment method is in allowed set
        java.util.Set<String> validMethods = java.util.Set.of("upi", "net_banking", "card", "wallet");
        if (!validMethods.contains(method)) {
            return error("INVALID_PAYMENT_METHOD", "Unsupported payment method: " + method);
        }

        String paymentIntentId = newId();

        ObjectNode result = success("Payment intent created. Redirect customer to gateway_url.");
        result.put("payment_intent_id",  paymentIntentId);
        result.put("invoice_id",         invoiceId);
        result.put("tenant_id",          tenantId);
        result.put("amount",             amount);
        result.put("currency",           currency);
        result.put("payment_method",     method);
        result.put("status",             "pending");
        result.put("idempotency_key",    idempotencyKey);
        result.put("expires_at",         futureIso(0) + " (30 minutes)");

        // Gateway redirect — in production this is the Kill Bill / Razorpay / Stripe URL
        String gatewayUrl = "https://payments.ecoskiller.com/checkout/" + paymentIntentId
                          + "?method=" + method
                          + (returnUrl != null ? "&return_url=" + returnUrl : "");
        result.put("gateway_url",        gatewayUrl);

        // Webhook that payment gateway will call on completion
        result.put("webhook_endpoint",   "https://api.ecoskiller.com/api/v1/billing/webhooks/payment");
        result.put("kill_bill_account",  "kb-account-" + tenantId.substring(0, 8));
        result.put("audit_record_id",    newId());
        return result;
    }
}
