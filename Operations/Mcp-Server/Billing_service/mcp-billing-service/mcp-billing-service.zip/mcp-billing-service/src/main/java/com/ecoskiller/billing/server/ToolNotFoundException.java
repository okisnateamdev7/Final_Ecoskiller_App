package com.ecoskiller.billing.server;

public class ToolNotFoundException extends RuntimeException {
    public ToolNotFoundException(String toolName) {
        super("Tool not found: " + toolName);
    }
}
