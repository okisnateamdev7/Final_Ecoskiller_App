package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** billing_list_invoices */
public class InvoiceListTool extends AbstractBillingTool {
    public InvoiceListTool(RequestValidator v) { super(v); }
    @Override public String name() { return "billing_list_invoices"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "List invoices for a tenant with cursor-based pagination. " +
            "Returns paginated list sorted by issue date descending.");
        addStringProp(schema, "tenant_id", "UUID of the tenant (from JWT claim)", true);
        addEnumProp  (schema, "status",    "Filter by invoice status (optional)", false,
                      "draft", "issued", "paid", "overdue", "cancelled");
        addStringProp(schema, "cursor",    "Pagination cursor from previous response", false);
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId = validator.requireUuid(args, "tenant_id");
        String status   = args.has("status") ? validator.requireInvoiceStatus(args, "status") : null;

        ObjectNode result = success("Invoices retrieved");
        result.put("tenant_id",  tenantId);
        result.put("total_count", 6);
        result.put("has_more",    false);

        ArrayNode invoices = result.putArray("invoices");
        addInvoice(invoices, "INV-001", "5898.82", "paid",    futureIso(-30));
        addInvoice(invoices, "INV-002", "5898.82", "paid",    futureIso(-60));
        addInvoice(invoices, "INV-003", "5898.82", "paid",    futureIso(-90));
        addInvoice(invoices, "INV-004", "5898.82", "paid",    futureIso(-120));
        addInvoice(invoices, "INV-005", "5898.82", "paid",    futureIso(-150));
        addInvoice(invoices, "INV-006", "0.00",    "issued",  nowIso());
        return result;
    }

    private void addInvoice(ArrayNode arr, String num, String amount, String status, String issuedAt) {
        ObjectNode inv = arr.addObject();
        inv.put("invoice_id",     java.util.UUID.randomUUID().toString());
        inv.put("invoice_number", num);
        inv.put("amount",         amount);
        inv.put("currency",       "INR");
        inv.put("status",         status);
        inv.put("issued_at",      issuedAt);
    }
}
