package com.ecoskiller.billing.server;

public class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super(message);
    }
}
