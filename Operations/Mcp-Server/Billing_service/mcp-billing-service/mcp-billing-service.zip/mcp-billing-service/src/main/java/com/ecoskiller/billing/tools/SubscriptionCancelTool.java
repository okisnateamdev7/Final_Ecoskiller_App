package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** billing_cancel_subscription */
public class SubscriptionCancelTool extends AbstractBillingTool {

    public SubscriptionCancelTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_cancel_subscription"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "Cancel a subscription. By default cancels at period end to avoid data loss. " +
            "Emits subscription.cancelled Kafka event. Reason is recorded for churn analytics.");
        addStringProp(schema, "tenant_id",         "UUID of the tenant (from JWT claim)", true);
        addStringProp(schema, "subscription_id",   "UUID of subscription to cancel",      true);
        addBoolProp  (schema, "cancel_immediately","Cancel now vs at period end");
        addStringProp(schema, "reason",            "Cancellation reason (max 1000 chars)", false);
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId       = validator.requireUuid(args, "tenant_id");
        String subscriptionId = validator.requireUuid(args, "subscription_id");
        boolean immediate     = validator.optionalBoolean(args, "cancel_immediately", false);
        String reason         = validator.optionalSafeString(args, "reason", 1000);

        ObjectNode result = success(immediate
            ? "Subscription cancelled immediately"
            : "Subscription scheduled for cancellation at period end");
        result.put("subscription_id",    subscriptionId);
        result.put("tenant_id",          tenantId);
        result.put("cancel_immediately", immediate);
        result.put("cancelled_at",       immediate ? nowIso() : null);
        result.put("cancel_at",          immediate ? nowIso() : futureIso(30));
        result.put("status",             immediate ? "cancelled" : "active");
        result.put("cancel_at_period_end", !immediate);
        if (reason != null) result.put("reason", reason);
        result.put("kafka_event",        "subscription.cancelled");
        result.put("audit_record_id",    newId());
        return result;
    }
}
