package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.ecoskiller.billing.server.ToolNotFoundException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Central registry for all 18 Billing MCP tools.
 *
 * Tools are registered at construction time.  Dispatch is O(1) via HashMap.
 * Each tool receives the validated RequestValidator — no tool does its own
 * raw string parsing.
 */
public class ToolRegistry {

    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, BillingTool> tools = new LinkedHashMap<>();

    public ToolRegistry(RequestValidator validator) {
        register(new SubscriptionListPlansTool(validator));
        register(new SubscriptionCreateTool(validator));
        register(new SubscriptionGetTool(validator));
        register(new SubscriptionUpgradeTool(validator));
        register(new SubscriptionCancelTool(validator));
        register(new SubscriptionCheckEntitlementTool(validator));
        register(new UsageRecordTool(validator));
        register(new UsageGetTool(validator));
        register(new InvoiceGenerateTool(validator));
        register(new InvoiceListTool(validator));
        register(new InvoiceGetTool(validator));
        register(new InvoiceDownloadUrlTool(validator));
        register(new PaymentInitiateTool(validator));
        register(new PaymentConfirmTool(validator));
        register(new PaymentRefundTool(validator));
        register(new PaymentGetStatusTool(validator));
        register(new AuditLogTool(validator));
        register(new BillingHealthTool(validator));
    }

    private void register(BillingTool tool) {
        tools.put(tool.name(), tool);
    }

    public ArrayNode listTools() {
        ArrayNode arr = mapper.createArrayNode();
        tools.values().forEach(t -> arr.add(t.schema()));
        return arr;
    }

    public JsonNode call(String name, JsonNode args) {
        BillingTool tool = tools.get(name);
        if (tool == null) throw new ToolNotFoundException(name);
        return tool.execute(args);
    }
}
