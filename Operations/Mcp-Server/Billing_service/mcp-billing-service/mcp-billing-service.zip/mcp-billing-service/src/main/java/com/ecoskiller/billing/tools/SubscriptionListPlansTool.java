package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * billing_list_plans
 *
 * Returns all available subscription plans with feature entitlements.
 * No arguments required — publicly accessible metadata.
 *
 * Ecoskiller plans:
 *   free         — basic job posting, limited assessments
 *   professional — full assessment suite, analytics dashboard
 *   enterprise   — unlimited usage, multi-tenant, dedicated support
 */
public class SubscriptionListPlansTool extends AbstractBillingTool {

    public SubscriptionListPlansTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_list_plans"; }

    @Override
    public JsonNode schema() {
        return buildSchema(
            "List all available EcoSkiller subscription plans with pricing, features, " +
            "and entitlement details. No authentication required.");
    }

    @Override
    public JsonNode execute(JsonNode args) {
        ObjectNode result = success("Retrieved subscription plans");
        ArrayNode plans   = result.putArray("plans");

        plans.add(buildPlan(
            "free",
            "Free",
            "0.00",
            "INR",
            "monthly",
            new String[]{
                "3 active job postings",
                "10 candidate assessments / month",
                "Basic GD sessions (no AI scoring)",
                "Email notifications",
                "Community support"
            },
            new String[]{"ai_scoring", "analytics_dashboard", "api_access", "custom_branding"},
            10, 3
        ));

        plans.add(buildPlan(
            "professional",
            "Professional",
            "4999.00",
            "INR",
            "monthly",
            new String[]{
                "Unlimited job postings",
                "200 candidate assessments / month",
                "Full AI-scored GD + interview sessions",
                "Analytics dashboard with ClickHouse reports",
                "Invoice PDF generation (GST-compliant)",
                "Email + SMS + push notifications",
                "REST API access",
                "Priority support (SLA 8h)"
            },
            new String[]{"custom_branding", "dedicated_account_manager"},
            200, -1
        ));

        plans.add(buildPlan(
            "enterprise",
            "Enterprise",
            "24999.00",
            "INR",
            "monthly",
            new String[]{
                "Unlimited everything",
                "Multi-tenant isolation (separate Keycloak realm)",
                "Custom AI scoring rubrics",
                "Full ClickHouse analytics export",
                "Custom branding & white-label",
                "Dedicated account manager",
                "REST API + Webhook access",
                "SLA 1h — 24/7 support",
                "GST e-invoicing above threshold",
                "DPDPA 2023 data processing agreement"
            },
            new String[]{},
            -1, -1
        ));

        result.put("currency", "INR");
        result.put("gst_applicable", true);
        result.put("gst_rate_percent", 18);
        result.put("trial_days", 14);
        return result;
    }

    private ObjectNode buildPlan(
        String id, String name, String price, String currency, String billing,
        String[] features, String[] unavailableFeatures,
        int maxAssessmentsPerMonth, int maxJobPostings
    ) {
        ObjectNode plan = MAPPER.createObjectNode();
        plan.put("plan_id", id);
        plan.put("name", name);
        plan.put("price", price);
        plan.put("currency", currency);
        plan.put("billing_cycle", billing);

        ArrayNode featArr = plan.putArray("features");
        for (String f : features) featArr.add(f);

        ArrayNode unavail = plan.putArray("unavailable_features");
        for (String f : unavailableFeatures) unavail.add(f);

        plan.put("max_assessments_per_month", maxAssessmentsPerMonth);
        plan.put("max_job_postings", maxJobPostings);
        return plan;
    }
}
