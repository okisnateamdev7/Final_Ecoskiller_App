package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * billing_check_entitlement
 *
 * Gate-check whether a tenant is allowed to use a specific feature.
 * Called by every service before granting access (interview, GD, analytics, etc.).
 *
 * This is the plan-based feature gating middleware described in the Billing Service doc.
 */
public class SubscriptionCheckEntitlementTool extends AbstractBillingTool {

    private static final java.util.Set<String> VALID_FEATURES = java.util.Set.of(
        "ai_scoring", "analytics_dashboard", "api_access", "custom_branding",
        "gd_session", "interview_session", "dojo_match", "invoice_download",
        "bulk_assessments", "webhook_access"
    );

    public SubscriptionCheckEntitlementTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_check_entitlement"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "Check whether a tenant's active subscription grants access to a specific feature. " +
            "Returns allowed=true/false and remaining quota. Used as a middleware gate by all services.");
        addStringProp(schema, "tenant_id", "UUID of the tenant (from JWT claim)", true);
        addStringProp(schema, "feature",
            "Feature to check: ai_scoring, analytics_dashboard, api_access, custom_branding, " +
            "gd_session, interview_session, dojo_match, invoice_download, bulk_assessments, webhook_access",
            true);
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId = validator.requireUuid(args, "tenant_id");
        String feature  = validator.requireString(args, "feature").toLowerCase();

        if (!VALID_FEATURES.contains(feature)) {
            return error("INVALID_FEATURE",
                "Unknown feature '" + feature + "'. Valid features: " + VALID_FEATURES);
        }

        // Simulate professional plan entitlements
        boolean allowed = switch (feature) {
            case "ai_scoring", "analytics_dashboard", "api_access",
                 "gd_session", "interview_session", "dojo_match",
                 "invoice_download", "webhook_access" -> true;
            case "custom_branding", "bulk_assessments" -> false;
            default -> false;
        };

        ObjectNode result = success("Entitlement check complete");
        result.put("tenant_id",    tenantId);
        result.put("feature",      feature);
        result.put("allowed",      allowed);
        result.put("plan_id",      "professional");
        result.put("subscription_status", "active");

        if (!allowed) {
            result.put("upgrade_required", true);
            result.put("minimum_plan",     "enterprise");
            result.put("upgrade_url",      "https://api.ecoskiller.com/api/v1/billing/plans");
        }

        // Return quota info for metered features
        if (feature.equals("gd_session") || feature.equals("interview_session")) {
            ObjectNode quota = result.putObject("quota");
            quota.put("used",       47);
            quota.put("limit",      200);
            quota.put("remaining",  153);
            quota.put("resets_at",  futureIso(30));
        }

        return result;
    }
}
