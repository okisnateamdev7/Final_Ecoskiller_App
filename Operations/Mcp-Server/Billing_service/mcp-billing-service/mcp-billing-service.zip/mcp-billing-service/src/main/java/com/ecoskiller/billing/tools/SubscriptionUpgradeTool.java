package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** billing_upgrade_subscription — Upgrade or downgrade a tenant plan */
public class SubscriptionUpgradeTool extends AbstractBillingTool {

    public SubscriptionUpgradeTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_upgrade_subscription"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "Upgrade or downgrade a subscription plan. Pro-rated credit is applied " +
            "for the remaining billing period. Emits subscription.updated Kafka event.");
        addStringProp(schema, "tenant_id",         "UUID of the tenant (from JWT claim)",  true);
        addStringProp(schema, "subscription_id",   "UUID of the current subscription",     true);
        addEnumProp  (schema, "new_plan_id",        "Target plan",                          true,
                      "free", "professional", "enterprise");
        addStringProp(schema, "idempotency_key",   "UUID to prevent duplicate upgrades",   true);
        addBoolProp  (schema, "immediate",         "Apply immediately (true) or at period end (false)");
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId       = validator.requireUuid(args, "tenant_id");
        String subscriptionId = validator.requireUuid(args, "subscription_id");
        String newPlanId      = validator.requirePlanId(args, "new_plan_id");
        String idempotencyKey = validator.requireUuid(args, "idempotency_key");
        boolean immediate     = validator.optionalBoolean(args, "immediate", true);

        ObjectNode result = success("Subscription upgraded successfully");
        result.put("subscription_id",    subscriptionId);
        result.put("tenant_id",          tenantId);
        result.put("previous_plan_id",   "professional");
        result.put("new_plan_id",        newPlanId);
        result.put("effective_at",       immediate ? nowIso() : futureIso(30));
        result.put("prorated_credit",    immediate ? "1200.00" : "0.00");
        result.put("idempotency_key",    idempotencyKey);
        result.put("kafka_event",        "subscription.updated");
        result.put("audit_record_id",    newId());
        return result;
    }
}
