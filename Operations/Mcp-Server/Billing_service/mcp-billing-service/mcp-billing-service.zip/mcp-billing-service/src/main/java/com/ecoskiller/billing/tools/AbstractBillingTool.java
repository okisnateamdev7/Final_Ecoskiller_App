package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

/**
 * Base class for all 18 billing tools.
 *
 * Provides:
 *  - shared ObjectMapper (thread-safe, reuse)
 *  - shared RequestValidator
 *  - helper to build schema descriptors
 *  - helper to build success / error response envelopes
 *  - ISO-8601 UTC timestamp generator
 */
public abstract class AbstractBillingTool implements BillingTool {

    protected static final ObjectMapper MAPPER = new ObjectMapper();
    protected final RequestValidator validator;

    protected AbstractBillingTool(RequestValidator validator) {
        this.validator = validator;
    }

    // ─────────────────────────────────────────────
    //  Schema builder helpers
    // ─────────────────────────────────────────────

    protected ObjectNode buildSchema(String description) {
        ObjectNode schema = MAPPER.createObjectNode();
        schema.put("name", name());
        schema.put("description", description);
        ObjectNode inputSchema = schema.putObject("inputSchema");
        inputSchema.put("type", "object");
        return schema;
    }

    protected void addStringProp(ObjectNode schema, String prop, String description, boolean required) {
        ObjectNode props = getOrCreateProps(schema);
        ObjectNode p = props.putObject(prop);
        p.put("type", "string");
        p.put("description", description);
        if (required) addRequired(schema, prop);
    }

    protected void addNumberProp(ObjectNode schema, String prop, String description, boolean required) {
        ObjectNode props = getOrCreateProps(schema);
        ObjectNode p = props.putObject(prop);
        p.put("type", "string"); // amounts sent as strings to avoid float precision issues
        p.put("description", description + " (string representation, e.g. \"1250.00\")");
        if (required) addRequired(schema, prop);
    }

    protected void addEnumProp(ObjectNode schema, String prop, String description, boolean required, String... values) {
        ObjectNode props = getOrCreateProps(schema);
        ObjectNode p = props.putObject(prop);
        p.put("type", "string");
        p.put("description", description);
        var enumArr = p.putArray("enum");
        for (String v : values) enumArr.add(v);
        if (required) addRequired(schema, prop);
    }

    protected void addBoolProp(ObjectNode schema, String prop, String description) {
        ObjectNode props = getOrCreateProps(schema);
        ObjectNode p = props.putObject(prop);
        p.put("type", "boolean");
        p.put("description", description);
    }

    private ObjectNode getOrCreateProps(ObjectNode schema) {
        ObjectNode inputSchema = (ObjectNode) schema.get("inputSchema");
        if (!inputSchema.has("properties")) inputSchema.putObject("properties");
        return (ObjectNode) inputSchema.get("properties");
    }

    private void addRequired(ObjectNode schema, String prop) {
        ObjectNode inputSchema = (ObjectNode) schema.get("inputSchema");
        if (!inputSchema.has("required")) inputSchema.putArray("required");
        ((com.fasterxml.jackson.databind.node.ArrayNode) inputSchema.get("required")).add(prop);
    }

    // ─────────────────────────────────────────────
    //  Response helpers
    // ─────────────────────────────────────────────

    protected ObjectNode success(String message) {
        ObjectNode r = MAPPER.createObjectNode();
        r.put("status", "success");
        r.put("message", message);
        r.put("timestamp", nowIso());
        return r;
    }

    protected ObjectNode error(String code, String message) {
        ObjectNode r = MAPPER.createObjectNode();
        r.put("status", "error");
        r.put("error_code", code);
        r.put("message", message);
        r.put("timestamp", nowIso());
        return r;
    }

    // ─────────────────────────────────────────────
    //  Utilities
    // ─────────────────────────────────────────────

    protected String nowIso() {
        return DateTimeFormatter.ISO_INSTANT.format(Instant.now().atOffset(ZoneOffset.UTC));
    }

    protected String futureIso(int daysFromNow) {
        return DateTimeFormatter.ISO_INSTANT.format(
            Instant.now().plusSeconds((long) daysFromNow * 86_400).atOffset(ZoneOffset.UTC));
    }

    protected String newId() {
        return validator.generateId();
    }
}
