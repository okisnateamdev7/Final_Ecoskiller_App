package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** billing_get_payment_status — Retrieve full payment lifecycle status */
public class PaymentGetStatusTool extends AbstractBillingTool {

    public PaymentGetStatusTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_get_payment_status"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "Get current status of a payment, including gateway transaction details, " +
            "refund history, and audit trail references.");
        addStringProp(schema, "tenant_id",  "UUID of the tenant (from JWT claim)", true);
        addStringProp(schema, "payment_id", "UUID of the payment to check",        true);
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId  = validator.requireUuid(args, "tenant_id");
        String paymentId = validator.requireUuid(args, "payment_id");

        ObjectNode result = success("Payment status retrieved");
        result.put("payment_id",            paymentId);
        result.put("tenant_id",             tenantId);
        result.put("invoice_id",            newId());
        result.put("status",                "completed");
        result.put("amount",                "5898.82");
        result.put("currency",              "INR");
        result.put("payment_method",        "upi");
        result.put("gateway_provider",      "razorpay");
        result.put("gateway_transaction_id","pay_" + System.currentTimeMillis());
        result.put("initiated_at",          nowIso());
        result.put("confirmed_at",          nowIso());
        result.put("refund_status",         "none");
        result.put("refunded_amount",       "0.00");
        result.put("net_amount",            "5898.82");

        // Audit chain
        ObjectNode audit = result.putObject("audit");
        audit.put("audit_record_id",  newId());
        audit.put("ledger_entry_id",  newId());
        audit.put("immutable",        true);
        audit.put("retained_until",   futureIso(365 * 8));   // 8-year GST requirement

        return result;
    }
}
