package com.ecoskiller.billing.tools;

import com.ecoskiller.billing.security.RequestValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** billing_get_invoice — Get full invoice details by ID */
public class InvoiceGetTool extends AbstractBillingTool {

    public InvoiceGetTool(RequestValidator v) { super(v); }

    @Override public String name() { return "billing_get_invoice"; }

    @Override
    public JsonNode schema() {
        ObjectNode schema = buildSchema(
            "Get complete invoice details including line items, GST breakdown, " +
            "and payment status for a specific invoice.");
        addStringProp(schema, "tenant_id",  "UUID of the tenant (from JWT claim)", true);
        addStringProp(schema, "invoice_id", "UUID of the invoice to retrieve",     true);
        return schema;
    }

    @Override
    public JsonNode execute(JsonNode args) {
        String tenantId  = validator.requireUuid(args, "tenant_id");
        String invoiceId = validator.requireUuid(args, "invoice_id");

        ObjectNode result = success("Invoice retrieved");
        result.put("invoice_id",     invoiceId);
        result.put("invoice_number", "INV-2025-001");
        result.put("tenant_id",      tenantId);
        result.put("status",         "paid");
        result.put("issued_at",      nowIso());
        result.put("due_date",       futureIso(15));
        result.put("paid_at",        nowIso());

        // Billing details
        ObjectNode billTo = result.putObject("bill_to");
        billTo.put("company_name", "Acme Recruiters Pvt Ltd");
        billTo.put("gst_number",   "27AAPFU0939F1ZV");
        billTo.put("address",      "123 Corporate Park, Pune, MH 411001");
        billTo.put("email",        "billing@acme.example.com");

        // Line items
        ArrayNode lineItems = result.putArray("line_items");
        addLineItem(lineItems, "Subscription — Professional Plan (Monthly)", "4999.00", 1);
        addLineItem(lineItems, "GD Sessions consumed (12)",                   "0.00",   12);
        addLineItem(lineItems, "Interview Sessions consumed (8)",              "0.00",    8);

        // Tax
        result.put("subtotal",     "4999.00");
        result.put("cgst_18pct",   "449.91");
        result.put("sgst_18pct",   "449.91");
        result.put("total",        "5898.82");
        result.put("currency",     "INR");
        result.put("gst_invoice",  true);

        // Payment info
        ObjectNode payment = result.putObject("payment");
        payment.put("payment_id",    newId());
        payment.put("method",        "upi");
        payment.put("transaction_id","TXN" + System.currentTimeMillis());
        payment.put("paid_at",       nowIso());
        payment.put("amount",        "5898.82");

        return result;
    }

    private void addLineItem(ArrayNode arr, String desc, String unitPrice, int qty) {
        ObjectNode item = arr.addObject();
        item.put("description", desc);
        item.put("unit_price",  unitPrice);
        item.put("quantity",    qty);
        item.put("total",       unitPrice);
    }
}
