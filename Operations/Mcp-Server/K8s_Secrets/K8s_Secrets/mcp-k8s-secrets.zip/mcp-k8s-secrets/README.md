# mcp-k8s-secrets

**Ecoskiller | CAT-K8S — Kubernetes Secrets Management & Credential Distribution**  
MCP Server in Java | 12 Agents | Priority: HIGH | Zero External Dependencies

---

## Overview

`mcp-k8s-secrets` is the secure Kubernetes Secrets MCP server for the Ecoskiller platform.  
It implements the [Model Context Protocol](https://modelcontextprotocol.io/) (JSON-RPC 2.0 over stdio)
and exposes 12 tools covering the full lifecycle of Kubernetes Secrets management as documented
in the Ecoskiller Infrastructure v15 specification.

**Replaced:** HashiCorp Vault (removed in v15)  
**Backed by:** k3s native etcd — no additional installation required  
**Security layer:** RBAC + namespace isolation + AES-CBC envelope encryption

---

## Agents (12 Tools)

| # | Tool Name | Agent / Responsibility |
|---|-----------|------------------------|
| 1 | `secret_create` | Create Opaque / TLS / docker-registry / SA-token secrets |
| 2 | `secret_read` | Read metadata and key names (values always redacted) |
| 3 | `secret_update` | Update secret data via idempotent kubectl-apply pattern |
| 4 | `secret_delete` | Delete secrets with mandatory confirmation gate |
| 5 | `secret_list` | List all secrets in a namespace (metadata only) |
| 6 | `secret_rotate` | Full credential rotation plan with rolling restart |
| 7 | `rbac_provision` | Provision ServiceAccount + Role + RoleBinding (least-privilege) |
| 8 | `namespace_isolation` | Validate and enforce cross-namespace secret isolation |
| 9 | `tls_secret_manage` | Manage TLS secrets + cert-manager Certificate manifests |
| 10 | `registry_secret_manage` | Manage Harbor dockerconfigjson imagePullSecrets |
| 11 | `envelope_encryption_config` | Generate kube-apiserver AES-CBC encryption configuration |
| 12 | `secret_audit` | Audit reports, Wazuh SIEM rules, DPDPA 2023 compliance |

---

## Security Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    MCP Caller (Claude / CI)                     │
└───────────────────────────┬─────────────────────────────────────┘
                            │ JSON-RPC 2.0 / stdio
┌───────────────────────────▼─────────────────────────────────────┐
│                   McpServer (dispatcher)                        │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│   │ RbacValidator│  │ AuditLogger  │  │  ToolHandler (×12)   │  │
│   │ Namespace    │  │ Wazuh-ready  │  │  BaseTool (validate) │  │
│   │ isolation    │  │ JSON audit   │  │  Least-privilege RBAC│  │
│   └──────────────┘  └──────────────┘  └──────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
         │ kubectl / K8s API (replace with k8s Java client in prod)
┌────────▼────────────────────────────────────────────────────────┐
│  k3s Kubernetes cluster                                         │
│  ├── etcd (AES-CBC encrypted at rest)                           │
│  ├── RBAC (Role + RoleBinding + ServiceAccount per service)     │
│  ├── Namespace isolation (core/billing/analytics/…)             │
│  ├── cert-manager (TLS secrets, Let's Encrypt)                  │
│  └── Harbor (dockerconfigjson imagePullSecrets)                 │
└─────────────────────────────────────────────────────────────────┘
```

### Security Properties

| Property | Implementation |
|----------|----------------|
| Secret values never logged | All tools redact values — only key names and metadata exposed |
| RBAC enforced on every call | `RbacValidator` checks permission + namespace scope before execution |
| Namespace isolation | Cross-namespace reads blocked; ops-service has explicit wider scope |
| No wildcard permissions | `rbac_provision` rejects `*` verbs and write verbs for service accounts |
| Deletion safety gate | `secret_delete` requires `confirmed=true` explicitly |
| Elevated perms for prod | Prod namespace deletes require elevated ServiceAccount (ops-service) |
| Full audit trail | Every operation audit-logged in JSON format (Wazuh-compatible) |
| Envelope encryption | `envelope_encryption_config` generates AES-CBC / KMS kube-apiserver config |
| DPDPA 2023 compliance | `secret_audit` generates compliance evidence and gap analysis |

---

## Requirements

- **Java 17+** (compiled with `--release 17`; tested on OpenJDK 21)
- No external dependencies — pure JDK

---

## Build

```bash
./build.sh          # Compile + package JAR
./build.sh --test   # Compile + package + run all 29 tests
./build.sh --run    # Start MCP server in stdio mode
```

Manual build:
```bash
mkdir -p target/classes
find src/main/java -name "*.java" | xargs javac -d target/classes --release 17
jar --create --file=target/mcp-k8s-secrets.jar \
    --main-class=com.ecoskiller.mcp.k8s.server.McpServer \
    -C target/classes .
```

---

## Run the server

```bash
java -jar target/mcp-k8s-secrets.jar
```

The server communicates via **stdin/stdout** using JSON-RPC 2.0 (MCP protocol).  
All logs (including audit events) are written to **stderr** only — stdout is reserved for protocol messages.

---

## Connect to Claude Desktop

Edit `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "mcp-k8s-secrets": {
      "command": "java",
      "args": ["-jar", "/absolute/path/to/mcp-k8s-secrets/target/mcp-k8s-secrets.jar"]
    }
  }
}
```

---

## Run Tests

```bash
# Quick pass/fail
java -ea -cp target/classes:target/test-classes com.ecoskiller.mcp.k8s.TestAgents

# Verbose (with stack traces on failure)
java -ea -cp target/classes:target/test-classes com.ecoskiller.mcp.k8s.TestAgents --verbose
```

Expected: **29 passed, 0 failed**

---

## File Structure

```
mcp-k8s-secrets/
├── build.sh
├── README.md
├── target/
│   └── mcp-k8s-secrets.jar
└── src/
    ├── main/java/com/ecoskiller/mcp/k8s/
    │   ├── server/
    │   │   └── McpServer.java              ← Main MCP server (JSON-RPC dispatcher)
    │   ├── tools/
    │   │   ├── ToolHandler.java            ← Tool interface
    │   │   ├── BaseTool.java               ← Shared RBAC + validation helpers
    │   │   ├── SecretCreateTool.java       ← Tool 1: secret_create
    │   │   ├── SecretReadTool.java         ← Tool 2: secret_read
    │   │   ├── SecretUpdateTool.java       ← Tool 3: secret_update
    │   │   ├── SecretDeleteTool.java       ← Tool 4: secret_delete
    │   │   ├── SecretListTool.java         ← Tool 5: secret_list
    │   │   ├── SecretRotateTool.java       ← Tool 6: secret_rotate
    │   │   ├── RbacProvisionTool.java      ← Tool 7: rbac_provision
    │   │   ├── NamespaceIsolationTool.java ← Tool 8: namespace_isolation
    │   │   ├── TlsSecretTool.java          ← Tool 9: tls_secret_manage
    │   │   ├── RegistrySecretTool.java     ← Tool 10: registry_secret_manage
    │   │   ├── EnvelopeEncryptionTool.java ← Tool 11: envelope_encryption_config
    │   │   └── SecretAuditTool.java        ← Tool 12: secret_audit
    │   ├── security/
    │   │   ├── AuditLogger.java            ← Wazuh-ready JSON audit logging
    │   │   └── RbacValidator.java          ← RBAC + namespace isolation enforcement
    │   ├── model/
    │   │   └── KubernetesSecret.java       ← Immutable K8s Secret model
    │   └── util/
    │       ├── JsonRpc.java                ← Zero-dep JSON-RPC 2.0 parser/serialiser
    │       └── Base64Util.java             ← Safe Base64 encode/decode
    └── test/java/com/ecoskiller/mcp/k8s/
        └── TestAgents.java                 ← 29-test suite covering all tools
```

---

## Protocol

- Transport: **stdio** (stdin/stdout)
- Format: **JSON-RPC 2.0**
- MCP Version: **2024-11-05**
- Methods: `initialize`, `tools/list`, `tools/call`, `ping`

---

## Ecoskiller Secret Namespace Map

| Namespace | Secrets | Services |
|-----------|---------|----------|
| `core` | core-credentials, harbor-pull | core-service, auth-service |
| `billing` | billing-credentials, harbor-pull | billing-service |
| `analytics` | analytics-credentials, llm-claude, llm-ollama, harbor-pull | analytics-service |
| `realtime` | realtime-credentials, harbor-pull | realtime-service |
| `notification` | notification-creds, harbor-pull | notification-service |
| `media` | freeswitch-secrets, sip-trunk-creds, harbor-pull | gd-phone-bridge-service |
| `ops` | gcp-aws-service-acct, harbor-pull | ops tooling |
| `ingress-nginx` | ecoskiller-tls | NGINX Ingress Controller |

---

## Production Integration Notes

The `RbacValidator` and tool implementations simulate K8s API calls.  
In production, replace simulated checks with the **Kubernetes Java client**:

```java
// Replace RbacValidator.assertPermission() with:
ApiClient client = Config.defaultClient();
AuthorizationV1Api authApi = new AuthorizationV1Api(client);
V1SelfSubjectAccessReview review = new V1SelfSubjectAccessReview()
    .spec(new V1SelfSubjectAccessReviewSpec()
        .resourceAttributes(new V1ResourceAttributes()
            .namespace(namespace).verb(verb).resource("secrets")));
authApi.createSelfSubjectAccessReview(review, null, null, null, null);
```

Add the Kubernetes Java client to your dependency manager:
```xml
<!-- Maven -->
<dependency>
    <groupId>io.kubernetes</groupId>
    <artifactId>client-java</artifactId>
    <version>21.0.0</version>
</dependency>
```

---

*Ecoskiller Platform | mcp-k8s-secrets | v1.0.0 | Java 17+ | MCP 2024-11-05*
