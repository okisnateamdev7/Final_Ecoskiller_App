package com.ecoskiller.mcp.k8s;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;
import com.ecoskiller.mcp.k8s.tools.*;
import com.ecoskiller.mcp.k8s.util.JsonRpc;

import java.util.*;

/**
 * Test suite for all 12 Kubernetes Secrets MCP tools.
 *
 * Run: java -cp target/mcp-k8s-secrets.jar com.ecoskiller.mcp.k8s.TestAgents
 * Run verbose: java -cp target/mcp-k8s-secrets.jar com.ecoskiller.mcp.k8s.TestAgents --verbose
 */
public class TestAgents {

    private static boolean verbose = false;
    private static int passed = 0;
    private static int failed = 0;

    private static final AuditLogger   AUDIT = new AuditLogger();
    private static final RbacValidator RBAC  = new RbacValidator();

    public static void main(String[] args) {
        verbose = args.length > 0 && "--verbose".equals(args[0]);
        System.out.println("══════════════════════════════════════════════════════");
        System.out.println("  Ecoskiller K8s Secrets MCP Server — Test Suite");
        System.out.println("══════════════════════════════════════════════════════\n");

        // ── Tool 1: secret_create ──────────────────────────────────────────
        test("secret_create — happy path", () -> {
            var tool = new SecretCreateTool(AUDIT, RBAC);
            var args2 = Map.of(
                "namespace",       "billing",
                "name",            "billing-credentials",
                "type",            "Opaque",
                "environment",     "prod",
                "data",            Map.of("db-password", "supersecret123", "redis-password", "redispass"),
                "service_account", "ops-service"
            );
            String result = (String) tool.execute(args2);
            assert result.contains("SECRET CREATED") : "Expected SECRET CREATED";
            assert result.contains("billing-credentials") : "Expected secret name";
            assert result.contains("REDACTED") : "Must redact values";
            assert !result.contains("supersecret123") : "Must NOT expose plaintext";
        });

        test("secret_create — invalid namespace rejected", () -> {
            var tool = new SecretCreateTool(AUDIT, RBAC);
            try {
                tool.execute(Map.of(
                    "namespace", "unknown-ns", "name", "test",
                    "type", "Opaque", "environment", "dev",
                    "data", Map.of("k", "v"), "service_account", "ops-service"
                ));
                assert false : "Should have thrown";
            } catch (IllegalArgumentException e) {
                assert e.getMessage().contains("Invalid namespace") : "Expected namespace error";
            }
        });

        test("secret_create — wildcard secret name rejected", () -> {
            var tool = new SecretCreateTool(AUDIT, RBAC);
            try {
                tool.execute(Map.of(
                    "namespace", "core", "name", "UPPERCASE_INVALID",
                    "type", "Opaque", "environment", "dev",
                    "data", Map.of("k", "v"), "service_account", "ops-service"
                ));
                assert false : "Should have thrown for invalid name";
            } catch (IllegalArgumentException e) {
                assert e.getMessage().contains("invalid") : "Expected name validation error";
            }
        });

        // ── Tool 2: secret_read ────────────────────────────────────────────
        test("secret_read — metadata only, no values", () -> {
            var tool = new SecretReadTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "namespace",       "core",
                "name",            "core-credentials",
                "service_account", "ops-service"
            ));
            assert result.contains("SECRET METADATA") : "Expected metadata header";
            assert result.contains("Values are not returned") || result.contains("VALUES are not returned") || result.contains("not returned") : "Must say values not returned";
        });

        // ── Tool 3: secret_update ──────────────────────────────────────────
        test("secret_update — credential rotation", () -> {
            var tool = new SecretUpdateTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "namespace",       "billing",
                "name",            "billing-credentials",
                "data",            Map.of("db-password", "newpassword456"),
                "service_account", "ops-service",
                "environment",     "prod",
                "reason",          "scheduled rotation"
            ));
            assert result.contains("SECRET UPDATED") : "Expected update confirmation";
            assert !result.contains("newpassword456") : "Must not expose new password";
            assert result.contains("REDACTED") : "Must redact values";
        });

        // ── Tool 4: secret_delete ──────────────────────────────────────────
        test("secret_delete — blocked without confirmed=true", () -> {
            var tool = new SecretDeleteTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "namespace",       "billing",
                "name",            "billing-credentials",
                "service_account", "ops-service",
                "environment",     "prod",
                "reason",          "decommission",
                "confirmed",       "false"
            ));
            assert result.contains("DELETION BLOCKED") : "Expected deletion to be blocked";
        });

        test("secret_delete — proceeds with confirmed=true", () -> {
            var tool = new SecretDeleteTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "namespace",       "dev",
                "name",            "test-secret",
                "service_account", "ops-service",
                "environment",     "dev",
                "reason",          "test cleanup",
                "confirmed",       "true"
            ));
            assert result.contains("SECRET DELETED") : "Expected deletion confirmation";
            assert result.contains("IRREVERSIBLE") : "Must warn about irreversibility";
        });

        // ── Tool 5: secret_list ────────────────────────────────────────────
        test("secret_list — lists ecoskiller secrets", () -> {
            var tool = new SecretListTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "namespace",       "analytics",
                "service_account", "ops-service",
                "environment",     "prod"
            ));
            assert result.contains("analytics-credentials") : "Expected analytics secret";
            assert result.contains("llm-claude") : "Expected LLM secret";
            assert result.contains("harbor-pull") : "Expected registry secret";
        });

        // ── Tool 6: secret_rotate ──────────────────────────────────────────
        test("secret_rotate — generates rotation plan", () -> {
            var tool = new SecretRotateTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "namespace",         "core",
                "name",              "core-credentials",
                "rotation_reason",   "scheduled",
                "service_account",   "ops-service",
                "environment",       "prod",
                "affected_services", "core-service,auth-service",
                "mount_type",        "env_var"
            ));
            assert result.contains("CREDENTIAL ROTATION PLAN") : "Expected rotation plan header";
            assert result.contains("rollout restart") : "Expected rollout restart command";
            assert result.contains("Wazuh") : "Expected Wazuh SIEM reference";
        });

        // ── Tool 7: rbac_provision ─────────────────────────────────────────
        test("rbac_provision — generates RBAC manifests", () -> {
            var tool = new RbacProvisionTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "namespace",    "billing",
                "service_name", "billing-service",
                "secret_names", "billing-credentials",
                "verbs",        "get,list",
                "environment",  "prod",
                "operator",     "ops-lead"
            ));
            assert result.contains("RBAC PROVISIONED") : "Expected RBAC provisioned";
            assert result.contains("Role") : "Expected Role resource";
            assert result.contains("RoleBinding") : "Expected RoleBinding";
            assert !result.contains("wildcard") || result.contains("No wildcard") : "Must confirm no wildcards";
        });

        test("rbac_provision — rejects wildcard verbs", () -> {
            var tool = new RbacProvisionTool(AUDIT, RBAC);
            try {
                tool.execute(Map.of(
                    "namespace", "billing", "service_name", "billing-service",
                    "secret_names", "billing-credentials", "verbs", "*",
                    "environment", "prod", "operator", "ops-lead"
                ));
                assert false : "Should reject wildcard verbs";
            } catch (SecurityException e) {
                assert e.getMessage().contains("Wildcard") : "Expected wildcard rejection";
            }
        });

        test("rbac_provision — rejects write verbs", () -> {
            var tool = new RbacProvisionTool(AUDIT, RBAC);
            try {
                tool.execute(Map.of(
                    "namespace", "billing", "service_name", "billing-service",
                    "secret_names", "billing-credentials", "verbs", "delete",
                    "environment", "prod", "operator", "ops-lead"
                ));
                assert false : "Should reject delete verb";
            } catch (SecurityException e) {
                assert e.getMessage().contains("write verbs") : "Expected write verb rejection";
            }
        });

        // ── Tool 8: namespace_isolation ───────────────────────────────────
        test("namespace_isolation — same namespace passes", () -> {
            var tool = new NamespaceIsolationTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "source_namespace", "billing",
                "target_namespace", "billing",
                "service_account",  "billing-service",
                "environment",      "prod"
            ));
            assert result.contains("SAME NAMESPACE") : "Expected same namespace result";
        });

        test("namespace_isolation — cross-namespace blocked", () -> {
            var tool = new NamespaceIsolationTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "source_namespace", "billing",
                "target_namespace", "core",
                "service_account",  "billing-service",
                "environment",      "prod"
            ));
            assert result.contains("ISOLATION VIOLATION") : "Expected isolation violation";
        });

        // ── Tool 9: tls_secret_manage ──────────────────────────────────────
        test("tls_secret_manage — cert-manager config generated", () -> {
            var tool = new TlsSecretTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "action",          "generate_cert_manager",
                "namespace",       "ingress-nginx",
                "service_account", "ops-service",
                "secret_name",     "ecoskiller-tls",
                "domain",          "ecoskiller.com",
                "issuer",          "letsencrypt-prod"
            ));
            assert result.contains("cert-manager") : "Expected cert-manager config";
            assert result.contains("ClusterIssuer") : "Expected ClusterIssuer manifest";
            assert result.contains("letsencrypt") : "Expected Let's Encrypt reference";
        });

        test("tls_secret_manage — TLS list returned", () -> {
            var tool = new TlsSecretTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "action",          "list_tls",
                "namespace",       "ingress-nginx",
                "service_account", "ops-service"
            ));
            assert result.contains("ecoskiller-tls") : "Expected ecoskiller-tls";
        });

        // ── Tool 10: registry_secret_manage ───────────────────────────────
        test("registry_secret_manage — propagate all namespaces", () -> {
            var tool = new RegistrySecretTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "action",          "propagate_all_namespaces",
                "namespace",       "core",
                "service_account", "ops-service"
            ));
            assert result.contains("harbor.ecoskiller.com") : "Expected harbor server";
            assert result.contains("HARBOR_PASSWORD") : "Expected password env var reference";
            assert !result.contains("plaintext") || result.contains("never in") : "Must not expose password";
        });

        test("registry_secret_manage — deployment snippet", () -> {
            var tool = new RegistrySecretTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "action",          "generate_deployment_snippet",
                "namespace",       "billing",
                "service_account", "ops-service"
            ));
            assert result.contains("imagePullSecrets") : "Expected imagePullSecrets";
            assert result.contains("harbor-pull") : "Expected harbor-pull secret";
        });

        // ── Tool 11: envelope_encryption_config ───────────────────────────
        test("envelope_encryption_config — AES-CBC config generated", () -> {
            var tool = new EnvelopeEncryptionTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "action",      "generate_config",
                "provider",    "aes_cbc",
                "environment", "prod",
                "operator",    "ops-lead"
            ));
            assert result.contains("EncryptionConfiguration") : "Expected K8s EncryptionConfig";
            assert result.contains("aescbc") : "Expected AES-CBC provider";
            assert result.contains("DPDPA") : "Expected DPDPA compliance reference";
        });

        test("envelope_encryption_config — split custody plan", () -> {
            var tool = new EnvelopeEncryptionTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "action",      "split_custody_plan",
                "provider",    "aes_cbc",
                "environment", "prod",
                "operator",    "ops-lead"
            ));
            assert result.contains("Custodian") : "Expected custody assignment";
            assert result.contains("split") || result.contains("Split") || result.contains("custody") : "Expected split custody reference";
        });

        // ── Tool 12: secret_audit ──────────────────────────────────────────
        test("secret_audit — Wazuh alert rules generated", () -> {
            var tool = new SecretAuditTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "audit_type",  "wazuh_alert_rules",
                "namespace",   "core",
                "environment", "prod",
                "operator",    "security-auditor"
            ));
            assert result.contains("Wazuh") : "Expected Wazuh rule content";
            assert result.contains("rule id") : "Expected rule definition";
            assert result.contains("secrets") : "Expected secrets resource";
        });

        test("secret_audit — DPDPA compliance report", () -> {
            var tool = new SecretAuditTool(AUDIT, RBAC);
            var result = (String) tool.execute(Map.of(
                "audit_type",  "dpdpa_compliance",
                "namespace",   "core",
                "environment", "prod",
                "operator",    "security-auditor"
            ));
            assert result.contains("DPDPA 2023") : "Expected DPDPA reference";
            assert result.contains("compliant") : "Expected compliance status";
        });

        // ── JsonRpc utility tests ──────────────────────────────────────────
        test("JsonRpc — parse simple object", () -> {
            var map = JsonRpc.parse("{\"method\":\"initialize\",\"id\":\"1\"}");
            assert "initialize".equals(map.get("method")) : "Expected method=initialize";
            assert "1".equals(map.get("id")) : "Expected id=1";
        });

        test("JsonRpc — parse nested object", () -> {
            var map = JsonRpc.parse("{\"params\":{\"name\":\"secret_create\",\"arguments\":{}}}");
            @SuppressWarnings("unchecked")
            var params = (Map<String, Object>) map.get("params");
            assert "secret_create".equals(params.get("name")) : "Expected nested name";
        });

        test("JsonRpc — result serialisation", () -> {
            var json = JsonRpc.result("42", Map.of("status", "ok"));
            assert json.contains("\"id\":\"42\"") : "Expected id";
            assert json.contains("\"status\":\"ok\"") : "Expected result";
        });

        test("JsonRpc — error serialisation", () -> {
            var json = JsonRpc.error("1", -32601, "Method not found");
            assert json.contains("-32601") : "Expected error code";
            assert json.contains("Method not found") : "Expected error message";
        });

        // ── RBAC isolation tests ───────────────────────────────────────────
        test("RbacValidator — cross-namespace access blocked", () -> {
            var rbac = new RbacValidator();
            try {
                rbac.assertNamespaceAccess("billing-service", "core");
                assert false : "Should have thrown";
            } catch (SecurityException e) {
                assert e.getMessage().contains("NAMESPACE ISOLATION VIOLATION") : "Expected isolation violation message";
            }
        });

        test("RbacValidator — ops-service has cross-namespace access", () -> {
            var rbac = new RbacValidator();
            rbac.assertNamespaceAccess("ops-service", "core");    // Should not throw
            rbac.assertNamespaceAccess("ops-service", "billing"); // Should not throw
        });

        test("RbacValidator — standard SA cannot delete", () -> {
            var rbac = new RbacValidator();
            try {
                rbac.assertPermission("billing-service", "billing", "delete", "secrets");
                assert false : "Should have thrown";
            } catch (SecurityException e) {
                assert e.getMessage().contains("elevated permissions") : "Expected elevated permission message";
            }
        });

        // ── Summary ────────────────────────────────────────────────────────
        System.out.println("\n══════════════════════════════════════════════════════");
        System.out.printf("  Results: %d passed, %d failed%n", passed, failed);
        System.out.println("══════════════════════════════════════════════════════");
        if (failed > 0) System.exit(1);
    }

    // ── Test runner ────────────────────────────────────────────────────────────

    private static void test(String name, TestCase tc) {
        try {
            tc.run();
            System.out.printf("  ✅ PASS  %s%n", name);
            passed++;
        } catch (AssertionError e) {
            System.out.printf("  ❌ FAIL  %s%n    → %s%n", name, e.getMessage());
            if (verbose) e.printStackTrace();
            failed++;
        } catch (Exception e) {
            System.out.printf("  ❌ ERROR %s%n    → %s%n", name, e.getMessage());
            if (verbose) e.printStackTrace();
            failed++;
        }
    }

    @FunctionalInterface
    interface TestCase { void run() throws Exception; }
}
