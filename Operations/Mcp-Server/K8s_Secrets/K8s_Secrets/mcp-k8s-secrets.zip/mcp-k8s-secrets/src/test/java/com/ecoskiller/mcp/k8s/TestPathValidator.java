package com.ecoskiller.mcp.k8s;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;
import com.ecoskiller.mcp.k8s.tools.SecretPathTool;
import com.ecoskiller.mcp.k8s.util.SecretPathValidator;
import com.ecoskiller.mcp.k8s.util.SecretPathValidator.ValidationResult;

import java.util.*;

/**
 * Extended test suite — Tool 13 (secret_path_validate) and SecretPathValidator.
 *
 * Run: java -ea -cp target/classes:target/test-classes com.ecoskiller.mcp.k8s.TestPathValidator
 */
public class TestPathValidator {

    private static int passed = 0;
    private static int failed = 0;

    private static final AuditLogger   AUDIT = new AuditLogger();
    private static final RbacValidator RBAC  = new RbacValidator();

    public static void main(String[] args) {
        System.out.println("══════════════════════════════════════════════════════");
        System.out.println("  SecretPathValidator + Tool 13 — Test Suite");
        System.out.println("══════════════════════════════════════════════════════\n");

        // ── SecretPathValidator unit tests ─────────────────────────────────

        test("validate — valid prod db postgres path", () -> {
            ValidationResult r = SecretPathValidator.validate("secret/prod/db/postgres");
            assert r.valid() : "Expected valid, got: " + r.message();
            assert "prod".equals(r.environment()) : "Expected env=prod";
        });

        test("validate — valid dev kafka path", () -> {
            ValidationResult r = SecretPathValidator.validate("secret/dev/kafka");
            assert r.valid() : "Expected valid";
            assert "dev".equals(r.environment()) : "Expected env=dev";
        });

        test("validate — valid prod llm/claude path", () -> {
            ValidationResult r = SecretPathValidator.validate("secret/prod/llm/claude");
            assert r.valid() : "Expected valid";
        });

        test("validate — valid prod sip-trunk path", () -> {
            ValidationResult r = SecretPathValidator.validate("secret/prod/sip-trunk");
            assert r.valid() : "Expected valid";
        });

        test("validate — plain secret name (no path prefix)", () -> {
            ValidationResult r = SecretPathValidator.validate("billing-credentials");
            assert r.valid() : "Plain names should be valid";
        });

        test("validate — invalid environment rejected", () -> {
            ValidationResult r = SecretPathValidator.validate("secret/unknown-env/db/postgres");
            assert !r.valid() : "Unknown env should be invalid";
        });

        test("validate — blank path rejected", () -> {
            ValidationResult r = SecretPathValidator.validate("");
            assert !r.valid() : "Blank path should be invalid";
        });

        test("validate — path traversal attack blocked", () -> {
            ValidationResult r = SecretPathValidator.validate("secret/prod/../../../etc/passwd");
            assert !r.valid() : "Path traversal should be blocked";
            assert r.message().contains("traversal") : "Expected traversal error message";
        });

        test("validate — URL-encoded traversal blocked", () -> {
            ValidationResult r = SecretPathValidator.validate("secret/prod/%2e%2e/etc");
            assert !r.valid() : "URL-encoded traversal should be blocked";
        });

        test("validate — uppercase in name rejected", () -> {
            ValidationResult r = SecretPathValidator.validate("MY_SECRET");
            assert !r.valid() : "Uppercase plain name should fail";
        });

        test("isNamespaceAuthorised — analytics can access llm/claude", () -> {
            boolean ok = SecretPathValidator.isNamespaceAuthorised(
                "analytics", "secret/prod/llm/claude", "prod");
            assert ok : "Analytics namespace should access llm/claude";
        });

        test("isNamespaceAuthorised — billing cannot access llm/claude", () -> {
            boolean ok = SecretPathValidator.isNamespaceAuthorised(
                "billing", "secret/prod/llm/claude", "prod");
            assert !ok : "Billing namespace should NOT access llm/claude";
        });

        test("isNamespaceAuthorised — core only for keycloak", () -> {
            boolean coreOk    = SecretPathValidator.isNamespaceAuthorised("core", "secret/prod/keycloak", "prod");
            boolean billingOk = SecretPathValidator.isNamespaceAuthorised("billing", "secret/prod/keycloak", "prod");
            assert coreOk    : "Core should access keycloak";
            assert !billingOk : "Billing should NOT access keycloak";
        });

        test("isNamespaceAuthorised — ops only for gcp-aws", () -> {
            boolean opsOk      = SecretPathValidator.isNamespaceAuthorised("ops", "secret/prod/gcp-aws", "prod");
            boolean analyticsOk = SecretPathValidator.isNamespaceAuthorised("analytics", "secret/prod/gcp-aws", "prod");
            assert opsOk       : "Ops should access gcp-aws";
            assert !analyticsOk : "Analytics should NOT access gcp-aws";
        });

        test("isNamespaceAuthorised — media only for sip-trunk", () -> {
            boolean mediaOk = SecretPathValidator.isNamespaceAuthorised("media", "secret/prod/sip-trunk", "prod");
            boolean coreOk  = SecretPathValidator.isNamespaceAuthorised("core", "secret/prod/sip-trunk", "prod");
            assert mediaOk  : "Media should access sip-trunk";
            assert !coreOk  : "Core should NOT access sip-trunk";
        });

        test("expectedKeys — db/postgres has expected keys", () -> {
            List<String> keys = SecretPathValidator.expectedKeys("secret/prod/db/postgres", "prod");
            assert keys.contains("db-password") : "Expected db-password key";
            assert keys.contains("db-host") : "Expected db-host key";
            assert keys.size() >= 4 : "Expected at least 4 keys";
        });

        test("expectedKeys — llm/claude has api-key", () -> {
            List<String> keys = SecretPathValidator.expectedKeys("secret/prod/llm/claude", "prod");
            assert keys.contains("api-key") : "Expected api-key for claude";
            assert keys.contains("model-version") : "Expected model-version";
        });

        test("canonicalise — uppercase to lowercase", () -> {
            assert "my-secret".equals(SecretPathValidator.canonicalise("MY-SECRET"));
        });

        test("canonicalise — underscore to hyphen", () -> {
            assert "my-secret".equals(SecretPathValidator.canonicalise("my_secret"));
        });

        test("canonicalise — trims whitespace", () -> {
            assert "my-secret".equals(SecretPathValidator.canonicalise("  my-secret  "));
        });

        test("isSameEnvironment — same env returns true", () -> {
            assert SecretPathValidator.isSameEnvironment("secret/prod/db/postgres", "secret/prod/kafka");
        });

        test("isSameEnvironment — different envs returns false", () -> {
            assert !SecretPathValidator.isSameEnvironment("secret/dev/kafka", "secret/prod/db/postgres");
        });

        test("summaryTable — contains expected rows", () -> {
            String table = SecretPathValidator.summaryTable();
            assert table.contains("secret/{env}/db/postgres") : "Expected postgres path in table";
            assert table.contains("secret/prod/llm/claude") : "Expected llm/claude path";
            assert table.contains("analytics") : "Expected analytics namespace";
        });

        // ── SecretPathTool (Tool 13) integration tests ─────────────────────

        test("secret_path_validate — validate_path happy path", () -> {
            var tool = new SecretPathTool(AUDIT, RBAC);
            String result = (String) tool.execute(Map.of(
                "action",      "validate_path",
                "path",        "secret/prod/db/postgres",
                "environment", "prod",
                "operator",    "ops-lead"
            ));
            assert result.contains("VALID") : "Expected VALID result";
            assert result.contains("COMPLIANT") : "Expected COMPLIANT";
        });

        test("secret_path_validate — path traversal detected", () -> {
            var tool = new SecretPathTool(AUDIT, RBAC);
            String result = (String) tool.execute(Map.of(
                "action",      "validate_path",
                "path",        "secret/prod/../../../etc/passwd",
                "environment", "prod",
                "operator",    "ops-lead"
            ));
            assert result.contains("INVALID") : "Expected INVALID for traversal";
        });

        test("secret_path_validate — check_namespace_access authorised", () -> {
            var tool = new SecretPathTool(AUDIT, RBAC);
            String result = (String) tool.execute(Map.of(
                "action",      "check_namespace_access",
                "path",        "secret/prod/llm/claude",
                "namespace",   "analytics",
                "environment", "prod",
                "operator",    "ops-lead"
            ));
            assert result.contains("AUTHORISED") : "Expected AUTHORISED for analytics → llm/claude";
        });

        test("secret_path_validate — check_namespace_access denied", () -> {
            var tool = new SecretPathTool(AUDIT, RBAC);
            String result = (String) tool.execute(Map.of(
                "action",      "check_namespace_access",
                "path",        "secret/prod/llm/claude",
                "namespace",   "billing",
                "environment", "prod",
                "operator",    "ops-lead"
            ));
            assert result.contains("DENIED") : "Expected DENIED for billing → llm/claude";
        });

        test("secret_path_validate — get_expected_keys for keycloak", () -> {
            var tool = new SecretPathTool(AUDIT, RBAC);
            String result = (String) tool.execute(Map.of(
                "action",      "get_expected_keys",
                "path",        "secret/prod/keycloak",
                "environment", "prod",
                "operator",    "ops-lead"
            ));
            assert result.contains("client-secret") : "Expected client-secret key listed";
        });

        test("secret_path_validate — list_all_paths returns full registry", () -> {
            var tool = new SecretPathTool(AUDIT, RBAC);
            String result = (String) tool.execute(Map.of(
                "action",   "list_all_paths",
                "operator", "security-auditor"
            ));
            assert result.contains("secret/{env}/db/postgres") : "Expected postgres path";
            assert result.contains("secret/prod/llm/claude") : "Expected claude path";
            assert result.contains("secret/prod/sip-trunk") : "Expected sip-trunk path";
            assert result.contains("analytics") : "Expected analytics in table";
        });

        test("secret_path_validate — canonicalise", () -> {
            var tool = new SecretPathTool(AUDIT, RBAC);
            String result = (String) tool.execute(Map.of(
                "action",   "canonicalise",
                "path",     "MY_BILLING_SECRET",
                "operator", "ops-lead"
            ));
            assert result.contains("my-billing-secret") : "Expected canonicalised output";
            assert result.contains("YES") : "Expected changed=YES";
        });

        // ── Summary ────────────────────────────────────────────────────────

        System.out.println("\n══════════════════════════════════════════════════════");
        System.out.printf("  Results: %d passed, %d failed%n", passed, failed);
        System.out.println("══════════════════════════════════════════════════════");
        if (failed > 0) System.exit(1);
    }

    private static void test(String name, TestCase tc) {
        try {
            tc.run();
            System.out.printf("  ✅ PASS  %s%n", name);
            passed++;
        } catch (AssertionError e) {
            System.out.printf("  ❌ FAIL  %s%n    → %s%n", name, e.getMessage());
            failed++;
        } catch (Exception e) {
            System.out.printf("  ❌ ERROR %s%n    → %s%n", name, e.getMessage());
            failed++;
        }
    }

    @FunctionalInterface
    interface TestCase { void run() throws Exception; }
}
