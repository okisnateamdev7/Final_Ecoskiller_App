package com.ecoskiller.mcp.k8s;

import com.ecoskiller.mcp.k8s.server.McpServer;
import com.ecoskiller.mcp.k8s.util.JsonRpc;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/**
 * Integration test: exercises the full MCP JSON-RPC 2.0 protocol end-to-end.
 *
 * Spins up McpServer in a background thread, writes JSON-RPC requests to its
 * stdin pipe, reads responses from its stdout pipe, and validates the protocol.
 *
 * This tests the real dispatch path: JSON-RPC parse → tool dispatch →
 * RBAC validation → tool execute → JSON-RPC serialise → stdout.
 *
 * Run: java -ea -cp target/classes:target/test-classes
 *           com.ecoskiller.mcp.k8s.TestMcpIntegration
 */
public class TestMcpIntegration {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) throws Exception {
        System.out.println("══════════════════════════════════════════════════════");
        System.out.println("  MCP Protocol Integration Tests — Full JSON-RPC");
        System.out.println("══════════════════════════════════════════════════════\n");

        // ── Wire up a piped McpServer ──────────────────────────────────────
        PipedOutputStream clientToServer = new PipedOutputStream();
        PipedInputStream  serverIn       = new PipedInputStream(clientToServer);
        PipedOutputStream serverOut      = new PipedOutputStream();
        PipedInputStream  clientFromServer = new PipedInputStream(serverOut);

        // Redirect System.in/out for the server
        InputStream  origIn  = System.in;
        PrintStream  origOut = System.out;
        System.setIn(serverIn);
        System.setOut(new PrintStream(serverOut, true, StandardCharsets.UTF_8));

        // Run McpServer in background thread
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.submit(() -> {
            try { new McpServer().run(); }
            catch (Exception e) { /* Expected when pipes close */ }
        });

        // Writer to send requests to server
        PrintWriter  writer = new PrintWriter(new OutputStreamWriter(clientToServer, StandardCharsets.UTF_8), true);
        BufferedReader reader = new BufferedReader(new InputStreamReader(clientFromServer, StandardCharsets.UTF_8));

        try {
            // ── Test: initialize ──────────────────────────────────────────
            test("initialize — returns server info", () -> {
                String req = buildRequest("1", "initialize", Map.of(
                    "protocolVersion", "2024-11-05",
                    "clientInfo", Map.of("name", "test-client", "version", "1.0")
                ));
                writer.println(req);
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert parsed.containsKey("result") : "Expected result field";
                @SuppressWarnings("unchecked")
                Map<String, Object> result = (Map<String, Object>) parsed.get("result");
                assert result.containsKey("protocolVersion") : "Expected protocolVersion in result";
                assert result.containsKey("serverInfo") : "Expected serverInfo";
                @SuppressWarnings("unchecked")
                Map<String, Object> info = (Map<String, Object>) result.get("serverInfo");
                assert "mcp-k8s-secrets".equals(info.get("name")) : "Expected server name";
            });

            // ── Test: ping ────────────────────────────────────────────────
            test("ping — returns pong", () -> {
                writer.println(buildRequest("2", "ping", Map.of()));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                @SuppressWarnings("unchecked")
                Map<String, Object> result = (Map<String, Object>) parsed.get("result");
                assert result != null : "Expected result";
                assert "pong".equals(result.get("status")) : "Expected status=pong";
            });

            // ── Test: tools/list ──────────────────────────────────────────
            test("tools/list — returns 15 tools", () -> {
                writer.println(buildRequest("3", "tools/list", Map.of()));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                @SuppressWarnings("unchecked")
                Map<String, Object> result = (Map<String, Object>) parsed.get("result");
                @SuppressWarnings("unchecked")
                List<Object> tools = (List<Object>) result.get("tools");
                assert tools != null : "Expected tools list";
                assert tools.size() == 15 : "Expected 15 tools, got " + tools.size();
            });

            test("tools/list — all tools have name, description, inputSchema", () -> {
                writer.println(buildRequest("4", "tools/list", Map.of()));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                @SuppressWarnings("unchecked")
                Map<String, Object> result = (Map<String, Object>) parsed.get("result");
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> tools = (List<Map<String, Object>>) result.get("tools");
                for (Map<String, Object> tool : tools) {
                    assert tool.containsKey("name") : "Tool missing 'name'";
                    assert tool.containsKey("description") : "Tool missing 'description': " + tool.get("name");
                    assert tool.containsKey("inputSchema") : "Tool missing 'inputSchema': " + tool.get("name");
                    assert !((String) tool.get("name")).isBlank() : "Tool name is blank";
                }
            });

            test("tools/list — contains all 15 expected tool names", () -> {
                writer.println(buildRequest("5", "tools/list", Map.of()));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                @SuppressWarnings("unchecked")
                Map<String, Object> result = (Map<String, Object>) parsed.get("result");
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> tools = (List<Map<String, Object>>) result.get("tools");
                Set<String> names = new HashSet<>();
                tools.forEach(t -> names.add((String) t.get("name")));

                List<String> expected = List.of(
                    "secret_create", "secret_read", "secret_update", "secret_delete",
                    "secret_list", "secret_rotate", "rbac_provision", "namespace_isolation",
                    "tls_secret_manage", "registry_secret_manage", "envelope_encryption_config",
                    "secret_audit", "secret_path_validate", "rotation_schedule", "secret_env_diff"
                );
                for (String name : expected) {
                    assert names.contains(name) : "Missing tool: " + name;
                }
            });

            // ── Test: tools/call — secret_create ──────────────────────────
            test("tools/call secret_create — returns content array", () -> {
                writer.println(buildToolCall("6", "secret_create", Map.of(
                    "namespace",       "billing",
                    "name",            "billing-credentials",
                    "type",            "Opaque",
                    "environment",     "prod",
                    "data",            Map.of("db-password", "testpass"),
                    "service_account", "ops-service"
                )));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert !parsed.containsKey("error") : "Got error: " + parsed.get("error");
                @SuppressWarnings("unchecked")
                Map<String, Object> result = (Map<String, Object>) parsed.get("result");
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> content = (List<Map<String, Object>>) result.get("content");
                assert content != null && !content.isEmpty() : "Expected content array";
                String text = (String) content.get(0).get("text");
                assert text.contains("SECRET CREATED") : "Expected creation confirmation in text";
                assert !text.contains("testpass") : "Must not expose plaintext password in response";
            });

            // ── Test: tools/call — secret_list ────────────────────────────
            test("tools/call secret_list — analytics namespace", () -> {
                writer.println(buildToolCall("7", "secret_list", Map.of(
                    "namespace",       "analytics",
                    "service_account", "ops-service",
                    "environment",     "prod"
                )));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert !parsed.containsKey("error") : "Got error: " + parsed.get("error");
                @SuppressWarnings("unchecked")
                Map<String, Object> result = (Map<String, Object>) parsed.get("result");
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> content = (List<Map<String, Object>>) result.get("content");
                String text = (String) content.get(0).get("text");
                assert text.contains("llm-claude") : "Expected llm-claude in analytics list";
                assert text.contains("analytics-credentials") : "Expected analytics-credentials";
            });

            // ── Test: tools/call — RBAC violation returns error ────────────
            test("tools/call secret_delete — RBAC blocked for standard SA", () -> {
                writer.println(buildToolCall("8", "secret_delete", Map.of(
                    "namespace",       "core",
                    "name",            "core-credentials",
                    "service_account", "core-service",   // standard SA — cannot delete
                    "environment",     "prod",
                    "reason",          "test",
                    "confirmed",       "true"
                )));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                // Should get a security error
                assert parsed.containsKey("error") : "Expected RBAC security error for standard SA delete";
                @SuppressWarnings("unchecked")
                Map<String, Object> error = (Map<String, Object>) parsed.get("error");
                assert error.containsKey("message") : "Expected error message";
                String msg = (String) error.get("message");
                assert msg.contains("Security violation") || msg.contains("elevated") || msg.contains("permission")
                    : "Expected security violation message, got: " + msg;
            });

            // ── Test: tools/call — unknown tool returns -32602 ────────────
            test("tools/call unknown_tool — returns error -32602", () -> {
                writer.println(buildToolCall("9", "nonexistent_tool", Map.of()));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert parsed.containsKey("error") : "Expected error for unknown tool";
                @SuppressWarnings("unchecked")
                Map<String, Object> error = (Map<String, Object>) parsed.get("error");
                long code = ((Number) error.get("code")).longValue();
                assert code == -32602L : "Expected error code -32602, got " + code;
            });

            // ── Test: tools/call — unknown method returns -32601 ──────────
            test("unknown method — returns error -32601", () -> {
                writer.println(buildRequest("10", "tools/unknown_method", Map.of()));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert parsed.containsKey("error") : "Expected error for unknown method";
                @SuppressWarnings("unchecked")
                Map<String, Object> error = (Map<String, Object>) parsed.get("error");
                long code = ((Number) error.get("code")).longValue();
                assert code == -32601L : "Expected -32601 method not found, got " + code;
            });

            // ── Test: tools/call — rotation_schedule ──────────────────────
            test("tools/call rotation_schedule — policy_overview", () -> {
                writer.println(buildToolCall("11", "rotation_schedule", Map.of(
                    "action",   "policy_overview",
                    "operator", "ops-lead"
                )));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert !parsed.containsKey("error") : "Unexpected error";
                @SuppressWarnings("unchecked")
                Map<String, Object> result = (Map<String, Object>) parsed.get("result");
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> content = (List<Map<String, Object>>) result.get("content");
                String text = (String) content.get(0).get("text");
                assert text.contains("ROTATION POLICY") : "Expected rotation policy content";
                assert text.contains("DPDPA") : "Expected DPDPA reference";
            });

            // ── Test: tools/call — secret_env_diff ────────────────────────
            test("tools/call secret_env_diff — parity_report dev vs prod", () -> {
                writer.println(buildToolCall("12", "secret_env_diff", Map.of(
                    "action",          "parity_report",
                    "source_env",      "prod",
                    "target_env",      "dev",
                    "service_account", "ops-service",
                    "operator",        "ops-lead"
                )));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert !parsed.containsKey("error") : "Unexpected error: " + parsed.get("error");
                @SuppressWarnings("unchecked")
                Map<String, Object> result = (Map<String, Object>) parsed.get("result");
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> content = (List<Map<String, Object>>) result.get("content");
                String text = (String) content.get(0).get("text");
                assert text.contains("PARITY") : "Expected parity report content";
                assert text.contains("PROD") || text.contains("prod") : "Expected env references";
            });

            // ── Test: tools/call — rbac_provision YAML output ────────────
            test("tools/call rbac_provision — generates ServiceAccount YAML", () -> {
                writer.println(buildToolCall("13", "rbac_provision", Map.of(
                    "namespace",    "analytics",
                    "service_name", "analytics-service",
                    "secret_names", "analytics-credentials,llm-claude",
                    "verbs",        "get,list",
                    "environment",  "prod",
                    "operator",     "ops-lead"
                )));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert !parsed.containsKey("error") : "Unexpected error";
                @SuppressWarnings("unchecked")
                Map<String, Object> result = (Map<String, Object>) parsed.get("result");
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> content = (List<Map<String, Object>>) result.get("content");
                String text = (String) content.get(0).get("text");
                assert text.contains("ServiceAccount") : "Expected ServiceAccount in YAML";
                assert text.contains("RoleBinding") : "Expected RoleBinding in YAML";
                assert text.contains("analytics-credentials") : "Expected secret name in role";
                assert text.contains("llm-claude") : "Expected llm-claude in role";
            });

            // ── Test: tools/call — envelope_encryption KMS config ─────────
            test("tools/call envelope_encryption_config — KMS config", () -> {
                writer.println(buildToolCall("14", "envelope_encryption_config", Map.of(
                    "action",      "kms_config",
                    "provider",    "kms_v2",
                    "environment", "prod",
                    "operator",    "ops-lead"
                )));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert !parsed.containsKey("error") : "Unexpected error";
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> content = (List<Map<String, Object>>)
                    ((Map<String, Object>) parsed.get("result")).get("content");
                String text = (String) content.get(0).get("text");
                assert text.contains("KMS") : "Expected KMS config output";
                assert text.contains("gcloud") : "Expected GCP Cloud KMS commands";
            });

            // ── Test: id propagation ──────────────────────────────────────
            test("JSON-RPC id propagated correctly in response", () -> {
                String uniqueId = "req-" + System.currentTimeMillis();
                writer.println(buildRequest(uniqueId, "ping", Map.of()));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert uniqueId.equals(parsed.get("id")) : "Expected id=" + uniqueId + ", got=" + parsed.get("id");
            });

            // ── Test: jsonrpc version field ───────────────────────────────
            test("JSON-RPC 2.0 version field present in all responses", () -> {
                writer.println(buildRequest("v", "ping", Map.of()));
                String resp = readResponse(reader);
                Map<String, Object> parsed = JsonRpc.parse(resp);
                assert "2.0".equals(parsed.get("jsonrpc")) : "Expected jsonrpc=2.0";
            });

        } finally {
            // Restore System.in/out
            executor.shutdownNow();
            System.setIn(origIn);
            System.setOut(origOut);
        }

        System.out.println("\n══════════════════════════════════════════════════════");
        System.out.printf("  Integration Results: %d passed, %d failed%n", passed, failed);
        System.out.println("══════════════════════════════════════════════════════");
        if (failed > 0) System.exit(1);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private static String buildRequest(String id, String method, Map<String, Object> params) {
        return JsonRpc.toJson(Map.of(
            "jsonrpc", "2.0",
            "id", id,
            "method", method,
            "params", params
        ));
    }

    private static String buildToolCall(String id, String toolName, Map<String, Object> arguments) {
        return buildRequest(id, "tools/call", Map.of(
            "name", toolName,
            "arguments", arguments
        ));
    }

    private static String readResponse(BufferedReader reader) throws Exception {
        long deadline = System.currentTimeMillis() + 5000; // 5s timeout
        while (System.currentTimeMillis() < deadline) {
            if (reader.ready()) {
                String line = reader.readLine();
                if (line != null && line.trim().startsWith("{")) return line.trim();
            }
            Thread.sleep(10);
        }
        throw new TimeoutException("No response within 5 seconds");
    }

    private static void test(String name, TestCase tc) {
        try {
            tc.run();
            System.out.printf("  ✅ PASS  %s%n", name);
            passed++;
        } catch (AssertionError e) {
            System.out.printf("  ❌ FAIL  %s%n    → %s%n", name, e.getMessage());
            failed++;
        } catch (Exception e) {
            System.out.printf("  ❌ ERROR %s%n    → %s%n", name, e.getClass().getSimpleName() + ": " + e.getMessage());
            failed++;
        }
    }

    @FunctionalInterface
    interface TestCase { void run() throws Exception; }
}
