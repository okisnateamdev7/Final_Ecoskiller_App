package com.ecoskiller.mcp.k8s.util;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Base64Util — Safe Base64 encoding/decoding for Kubernetes Secret values.
 *
 * Kubernetes stores Secret data as Base64-encoded strings.
 * This utility ensures consistent encoding across all tools.
 *
 * Security note: decoded values should NEVER be logged.
 */
public final class Base64Util {

    private Base64Util() {}

    /**
     * Encode a plaintext string to Base64 (as Kubernetes expects for Secret data values).
     *
     * @param plaintext  Raw credential value
     * @return           Base64-encoded string
     */
    public static String encode(String plaintext) {
        if (plaintext == null) return "";
        return Base64.getEncoder().encodeToString(plaintext.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Decode a Base64 string back to plaintext.
     * ⚠  USE WITH CAUTION — never log the result of this method.
     *
     * @param encoded  Base64-encoded string
     * @return         Decoded plaintext
     */
    public static String decode(String encoded) {
        if (encoded == null || encoded.isBlank()) return "";
        return new String(Base64.getDecoder().decode(encoded), StandardCharsets.UTF_8);
    }

    /**
     * Check whether a string is already Base64-encoded.
     * Used to avoid double-encoding values submitted by callers.
     */
    public static boolean isBase64(String value) {
        if (value == null || value.isBlank()) return false;
        try {
            Base64.getDecoder().decode(value);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    /**
     * Encode only if not already Base64-encoded (idempotent encode).
     */
    public static String encodeIfNeeded(String value) {
        return isBase64(value) ? value : encode(value);
    }
}
