package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.util.*;

/**
 * Tool: secret_delete
 *
 * Deletes a Kubernetes Secret from the specified namespace.
 * Requires elevated RBAC 'delete' permission — strictly controlled.
 *
 * Security:
 *  - Production namespace deletes require explicit confirmation flag
 *  - RBAC 'delete' permission verified
 *  - Deletion audit-logged with timestamp and operator identity
 *  - Consumers warned to update references before deletion
 */
public class SecretDeleteTool extends BaseTool {

    private static final Set<String> PROD_NAMESPACES = Set.of("core","billing","analytics",
        "realtime","media","phone","ops","notification","ingress-nginx");

    public SecretDeleteTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "secret_delete"; }

    @Override
    public String description() {
        return "Delete a Kubernetes Secret from the specified namespace. " +
               "Production namespace deletions require explicit confirmation. " +
               "RBAC 'delete' permission required. All deletions are permanently audit-logged.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("namespace",       enumProp("Target namespace",
                                     "core","billing","analytics","realtime",
                                     "media","phone","ops","notification","ingress-nginx"));
        props.put("name",            stringProp("Secret name to delete"));
        props.put("service_account", stringProp("ServiceAccount performing the delete"));
        props.put("environment",     enumProp("Deployment environment",
                                     "dev","test","stage","prod"));
        props.put("reason",          stringProp("Mandatory reason for deletion"));
        props.put("confirmed",       boolProp("Must be true to proceed with deletion (safety gate)"));
        return schema(props, "namespace", "name", "service_account", "environment", "reason", "confirmed");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String namespace      = requireString(args, "namespace");
        String name           = requireString(args, "name");
        String serviceAccount = requireString(args, "service_account");
        String environment    = requireString(args, "environment");
        String reason         = requireString(args, "reason");
        boolean confirmed     = Boolean.parseBoolean(optString(args, "confirmed", "false"));

        validateNamespace(namespace);
        validateEnvironment(environment);
        validateSecretName(name);

        // Safety gate — must explicitly confirm
        if (!confirmed) {
            return "⛔ DELETION BLOCKED — 'confirmed' must be set to true.\n" +
                   "Secret '" + name + "' in namespace '" + namespace + "' was NOT deleted.\n" +
                   "Review consumers before deleting: pods referencing this secret will crash-loop.";
        }

        // Extra check: prod deletes are high-risk
        if ("prod".equals(environment) && PROD_NAMESPACES.contains(namespace)) {
            rbacValidator.assertElevatedPermission(serviceAccount, namespace, "delete", "secrets");
        } else {
            rbacValidator.assertPermission(serviceAccount, namespace, "delete", "secrets");
        }

        auditLogger.logSecretOperation("SECRET_DELETE", name, namespace, environment, serviceAccount,
            "reason=" + reason + " IRREVERSIBLE");

        return """
            🗑️  SECRET DELETED — %s/%s

            Environment: %s
            Deleted by:  %s
            Reason:      %s

            ── Kubectl equivalent ─────────────────────────
            kubectl delete secret %s -n %s

            ── Post-deletion checklist ───────────────────
            ⚠  Any pods referencing this secret via secretKeyRef or
               volumeMount will enter CrashLoopBackOff immediately.

            Action items:
            1. kubectl rollout restart deployment/<consumers> -n %s
            2. Remove secretKeyRef / volumeMount references from pod specs
            3. Remove imagePullSecrets reference if this was a docker-registry secret
            4. Update Helm chart values files to remove the secret reference

            ── Audit ──────────────────────────────────────
            ✔ IRREVERSIBLE deletion logged to Wazuh SIEM
            ✔ Deletion timestamp: %s
            ✔ Operator: %s
            ✔ Ecoskiller security incident log: record this event
            """.formatted(
                namespace, name,
                environment, serviceAccount, reason,
                name, namespace,
                namespace,
                new java.util.Date(),
                serviceAccount
            );
    }
}
