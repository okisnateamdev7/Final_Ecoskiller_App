package com.ecoskiller.mcp.k8s.server;

import com.ecoskiller.mcp.k8s.tools.*;
import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;
import com.ecoskiller.mcp.k8s.util.JsonRpc;

import java.io.*;
import java.util.*;
import java.util.logging.*;
import java.util.logging.Handler;

/**
 * Ecoskiller Kubernetes Secrets MCP Server
 *
 * Implements the Model Context Protocol (JSON-RPC 2.0) over stdio.
 * Manages all 12 Kubernetes Secret agents for the Ecoskiller platform.
 *
 * Security: RBAC validation, audit logging, namespace isolation enforced
 * on every tool call. No credentials are ever logged in plaintext.
 *
 * Protocol: MCP 2024-11-05 | Transport: stdio | Format: JSON-RPC 2.0
 */
public class McpServer {

    private static final Logger LOGGER = Logger.getLogger(McpServer.class.getName());
    private static final String MCP_VERSION   = "2024-11-05";
    private static final String SERVER_NAME   = "mcp-k8s-secrets";
    private static final String SERVER_VERSION = "1.0.0";

    private final Map<String, ToolHandler> toolRegistry = new LinkedHashMap<>();
    private final AuditLogger    auditLogger;
    private final RbacValidator  rbacValidator;

    public McpServer() {
        this.auditLogger   = new AuditLogger();
        this.rbacValidator = new RbacValidator();
        registerTools();
    }

    /** Register all 15 Kubernetes-Secrets tool handlers. */
    private void registerTools() {
        register(new SecretCreateTool(auditLogger, rbacValidator));
        register(new SecretReadTool(auditLogger, rbacValidator));
        register(new SecretUpdateTool(auditLogger, rbacValidator));
        register(new SecretDeleteTool(auditLogger, rbacValidator));
        register(new SecretListTool(auditLogger, rbacValidator));
        register(new SecretRotateTool(auditLogger, rbacValidator));
        register(new RbacProvisionTool(auditLogger, rbacValidator));
        register(new NamespaceIsolationTool(auditLogger, rbacValidator));
        register(new TlsSecretTool(auditLogger, rbacValidator));
        register(new RegistrySecretTool(auditLogger, rbacValidator));
        register(new EnvelopeEncryptionTool(auditLogger, rbacValidator));
        register(new SecretAuditTool(auditLogger, rbacValidator));
        register(new SecretPathTool(auditLogger, rbacValidator));
        register(new RotationScheduleTool(auditLogger, rbacValidator));
        register(new SecretEnvDiffTool(auditLogger, rbacValidator));
    }

    private void register(ToolHandler h) {
        toolRegistry.put(h.name(), h);
    }

    // ─── Main stdio loop ────────────────────────────────────────────────────────

    public void run() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter    writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));

        LOGGER.info("[MCP] Ecoskiller K8s Secrets MCP Server started — awaiting JSON-RPC requests");

        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;

            String response = dispatch(line);
            if (response != null) {
                writer.println(response);
                writer.flush();
            }
        }
    }

    // ─── JSON-RPC dispatcher ────────────────────────────────────────────────────

    private String dispatch(String rawJson) {
        String id     = null;
        String method = null;

        try {
            Map<String, Object> req = JsonRpc.parse(rawJson);
            id     = JsonRpc.str(req, "id");
            method = JsonRpc.str(req, "method");

            return switch (method) {
                case "initialize"   -> handleInitialize(id, req);
                case "tools/list"   -> handleToolsList(id);
                case "tools/call"   -> handleToolCall(id, req);
                case "ping"         -> JsonRpc.result(id, Map.of("status", "pong"));
                default             -> JsonRpc.error(id, -32601, "Method not found: " + method);
            };

        } catch (Exception e) {
            LOGGER.warning("[MCP] Dispatch error: " + e.getMessage());
            return JsonRpc.error(id, -32700, "Parse error: " + e.getMessage());
        }
    }

    // ─── Method handlers ────────────────────────────────────────────────────────

    private String handleInitialize(String id, Map<String, Object> req) {
        Map<String, Object> result = Map.of(
            "protocolVersion", MCP_VERSION,
            "capabilities", Map.of("tools", Map.of()),
            "serverInfo", Map.of(
                "name",    SERVER_NAME,
                "version", SERVER_VERSION
            )
        );
        return JsonRpc.result(id, result);
    }

    private String handleToolsList(String id) {
        List<Map<String, Object>> tools = new ArrayList<>();
        for (ToolHandler h : toolRegistry.values()) {
            tools.add(Map.of(
                "name",        h.name(),
                "description", h.description(),
                "inputSchema", h.inputSchema()
            ));
        }
        return JsonRpc.result(id, Map.of("tools", tools));
    }

    private String handleToolCall(String id, Map<String, Object> req) {
        @SuppressWarnings("unchecked")
        Map<String, Object> params    = (Map<String, Object>) req.getOrDefault("params", Map.of());
        String              toolName  = JsonRpc.str(params, "name");
        @SuppressWarnings("unchecked")
        Map<String, Object> arguments = (Map<String, Object>) params.getOrDefault("arguments", Map.of());

        ToolHandler handler = toolRegistry.get(toolName);
        if (handler == null) {
            return JsonRpc.error(id, -32602, "Unknown tool: " + toolName);
        }

        try {
            Object result = handler.execute(arguments);
            return JsonRpc.result(id, Map.of(
                "content", List.of(Map.of("type", "text", "text", result.toString()))
            ));
        } catch (SecurityException se) {
            auditLogger.logSecurityEvent("TOOL_ACCESS_DENIED", toolName, se.getMessage());
            return JsonRpc.error(id, -32000, "Security violation: " + se.getMessage());
        } catch (Exception e) {
            LOGGER.warning("[MCP] Tool error [" + toolName + "]: " + e.getMessage());
            return JsonRpc.error(id, -32000, "Tool execution failed: " + e.getMessage());
        }
    }

    // ─── Entry point ────────────────────────────────────────────────────────────

    public static void main(String[] args) throws IOException {
        // Configure logging to stderr only — stdout is reserved for JSON-RPC
        Logger root = Logger.getLogger("");
        root.setLevel(Level.INFO);
        for (Handler h : root.getHandlers()) root.removeHandler(h);
        StreamHandler sh = new StreamHandler(System.err, new SimpleFormatter());
        sh.setLevel(Level.ALL);
        root.addHandler(sh);

        new McpServer().run();
    }
}
