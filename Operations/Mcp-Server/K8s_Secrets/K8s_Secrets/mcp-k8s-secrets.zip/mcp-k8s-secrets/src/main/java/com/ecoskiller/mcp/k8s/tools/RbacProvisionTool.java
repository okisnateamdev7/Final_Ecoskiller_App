package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.util.*;

/**
 * Tool: rbac_provision
 *
 * Provisions RBAC Role + RoleBinding for a microservice's ServiceAccount.
 * Implements the Ecoskiller per-service least-privilege RBAC pattern.
 *
 * Pattern: ServiceAccount → Role (get,list on specific secret) → RoleBinding
 * No wildcard (*) permissions are ever generated.
 *
 * Ecoskiller doc: Section 3.3 RBAC-Controlled Access Enforcement,
 *                 Section 4.3 RBAC Role + RoleBinding Pattern
 */
public class RbacProvisionTool extends BaseTool {

    public RbacProvisionTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "rbac_provision"; }

    @Override
    public String description() {
        return "Provision Kubernetes RBAC Role + RoleBinding for a microservice ServiceAccount. " +
               "Implements least-privilege: Role grants get/list only on specifically named secrets. " +
               "No wildcard permissions. Generates ServiceAccount + Role + RoleBinding manifests " +
               "following the Ecoskiller per-service RBAC pattern.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("namespace",       enumProp("Target Ecoskiller namespace",
                                     "core","billing","analytics","realtime",
                                     "media","phone","ops","notification","ingress-nginx"));
        props.put("service_name",    stringProp("Microservice name (e.g. billing-service, core-service)"));
        props.put("secret_names",    stringProp("Comma-separated secret names this service should access"));
        props.put("verbs",           enumProp("RBAC verbs to grant (least-privilege recommended)",
                                     "get,list","get","list","get,list,watch"));
        props.put("environment",     enumProp("Environment", "dev","test","stage","prod"));
        props.put("operator",        stringProp("Operator performing the provisioning (ops team member)"));
        return schema(props, "namespace", "service_name", "secret_names", "verbs", "environment", "operator");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String namespace   = requireString(args, "namespace");
        String serviceName = requireString(args, "service_name");
        String secretNames = requireString(args, "secret_names");
        String verbs       = requireString(args, "verbs");
        String environment = requireString(args, "environment");
        String operator    = requireString(args, "operator");

        validateNamespace(namespace);
        validateEnvironment(environment);
        validateSecretName(serviceName.replace("-service","").replace("_","-"));

        // Security: no wildcard verbs allowed
        if (verbs.contains("*") || verbs.contains("create") || verbs.contains("delete") || verbs.contains("update")) {
            throw new SecurityException(
                "Wildcard or write verbs not permitted in auto-provisioned RBAC. " +
                "Only get/list/watch are allowed for secret reader roles.");
        }

        String[] secrets = secretNames.split(",");
        String roleRef   = serviceName.replace("-service","") + "-secret-reader";
        String bindRef   = serviceName.replace("-service","") + "-service-secret-access";

        auditLogger.logSecretOperation("RBAC_PROVISION", secretNames, namespace, environment, operator,
            "service=" + serviceName + ", verbs=" + verbs);

        StringBuilder secretArgs = new StringBuilder();
        for (String s : secrets) {
            secretArgs.append("  --resource-name=").append(s.trim()).append(" \\\n");
        }

        // Generate YAML manifests
        StringBuilder yaml = new StringBuilder();
        yaml.append(serviceAccountYaml(serviceName, namespace));
        yaml.append("---\n");
        yaml.append(roleYaml(roleRef, namespace, verbs, secrets));
        yaml.append("---\n");
        yaml.append(roleBindingYaml(bindRef, roleRef, serviceName, namespace));

        return """
            ✅ RBAC PROVISIONED — %s/%s

            ServiceAccount: %s
            Role:           %s
            RoleBinding:    %s
            Secrets granted: %s
            Verbs:          %s
            Environment:    %s

            ── Kubectl imperative commands ────────────────
            # 1. Create ServiceAccount
            kubectl create serviceaccount %s -n %s

            # 2. Create Role (least-privilege — specific secrets only, no wildcards)
            kubectl create role %s \\
              --verb=%s \\
              --resource=secrets \\
            %s  -n %s

            # 3. Bind Role to ServiceAccount
            kubectl create rolebinding %s \\
              --role=%s \\
              --serviceaccount=%s:%s \\
              -n %s

            ── Kubernetes YAML manifests ──────────────────
            %s

            ── Security validation ────────────────────────
            ✔ No wildcard (*) permissions generated
            ✔ No write verbs (create/update/delete) granted to service
            ✔ Secrets scoped to: %s
            ✔ Namespace isolation maintained: %s
            ✔ Principle of least privilege enforced per Ecoskiller v15 spec
            ✔ RBAC provision logged to Wazuh SIEM
            """.formatted(
                namespace, serviceName,
                serviceName, roleRef, bindRef,
                List.of(secrets), verbs, environment,
                serviceName, namespace,
                roleRef, verbs, secretArgs.toString(), namespace,
                bindRef, roleRef, namespace, serviceName, namespace,
                yaml.toString(),
                List.of(secrets),
                namespace
            );
    }

    private String serviceAccountYaml(String serviceName, String namespace) {
        return """
            apiVersion: v1
            kind: ServiceAccount
            metadata:
              name: %s
              namespace: %s
              labels:
                app: %s
                managed-by: ecoskiller-ci
            """.formatted(serviceName, namespace, serviceName);
    }

    private String roleYaml(String roleRef, String namespace, String verbs, String[] secrets) {
        StringBuilder resourceNames = new StringBuilder();
        for (String s : secrets) {
            resourceNames.append("    - ").append(s.trim()).append("\n");
        }
        return """
            apiVersion: rbac.authorization.k8s.io/v1
            kind: Role
            metadata:
              name: %s
              namespace: %s
            rules:
            - apiGroups: [""]
              resources: ["secrets"]
              verbs: ["%s"]
              resourceNames:
            %s""".formatted(roleRef, namespace, verbs.replace(",", "\", \""), resourceNames.toString());
    }

    private String roleBindingYaml(String bindRef, String roleRef, String serviceName, String namespace) {
        return """
            apiVersion: rbac.authorization.k8s.io/v1
            kind: RoleBinding
            metadata:
              name: %s
              namespace: %s
            roleRef:
              apiGroup: rbac.authorization.k8s.io
              kind: Role
              name: %s
            subjects:
            - kind: ServiceAccount
              name: %s
              namespace: %s
            """.formatted(bindRef, namespace, roleRef, serviceName, namespace);
    }
}
