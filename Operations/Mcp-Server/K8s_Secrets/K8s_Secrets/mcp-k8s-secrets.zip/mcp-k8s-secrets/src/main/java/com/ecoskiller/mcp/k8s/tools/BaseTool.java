package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.util.*;

/**
 * Base class for all K8s Secrets tools.
 *
 * Provides:
 *  - Shared RBAC / namespace validation helpers
 *  - Argument extraction utilities
 *  - Standard JSON Schema building utilities
 *  - Audit logging shortcuts
 */
public abstract class BaseTool implements ToolHandler {

    // Valid Ecoskiller namespaces per documentation
    protected static final Set<String> VALID_NAMESPACES = Set.of(
        "core", "billing", "analytics", "realtime",
        "media", "phone", "ops", "notification",
        "ingress-nginx", "dev", "test", "stage", "prod"
    );

    // Valid environments per documentation
    protected static final Set<String> VALID_ENVIRONMENTS = Set.of(
        "dev", "test", "stage", "prod"
    );

    // Valid secret types per K8s / Ecoskiller spec
    protected static final Set<String> VALID_SECRET_TYPES = Set.of(
        "Opaque",
        "kubernetes.io/tls",
        "kubernetes.io/dockerconfigjson",
        "kubernetes.io/service-account-token"
    );

    protected final AuditLogger   auditLogger;
    protected final RbacValidator rbacValidator;

    protected BaseTool(AuditLogger auditLogger, RbacValidator rbacValidator) {
        this.auditLogger   = auditLogger;
        this.rbacValidator = rbacValidator;
    }

    // ─── Argument helpers ────────────────────────────────────────────────────────

    protected String requireString(Map<String, Object> args, String key) {
        Object v = args.get(key);
        if (v == null || v.toString().isBlank())
            throw new IllegalArgumentException("Missing required argument: " + key);
        return v.toString().trim();
    }

    protected String optString(Map<String, Object> args, String key, String defaultVal) {
        Object v = args.get(key);
        return (v == null || v.toString().isBlank()) ? defaultVal : v.toString().trim();
    }

    @SuppressWarnings("unchecked")
    protected Map<String, String> requireMap(Map<String, Object> args, String key) {
        Object v = args.get(key);
        if (v == null) throw new IllegalArgumentException("Missing required argument: " + key);
        if (v instanceof Map) return (Map<String, String>) v;
        throw new IllegalArgumentException("Argument '" + key + "' must be an object/map");
    }

    // ─── Validation helpers ──────────────────────────────────────────────────────

    protected void validateNamespace(String namespace) {
        if (!VALID_NAMESPACES.contains(namespace))
            throw new IllegalArgumentException(
                "Invalid namespace '" + namespace + "'. Valid namespaces: " + VALID_NAMESPACES);
    }

    protected void validateEnvironment(String env) {
        if (!VALID_ENVIRONMENTS.contains(env))
            throw new IllegalArgumentException(
                "Invalid environment '" + env + "'. Valid environments: " + VALID_ENVIRONMENTS);
    }

    protected void validateSecretType(String type) {
        if (!VALID_SECRET_TYPES.contains(type))
            throw new IllegalArgumentException(
                "Invalid secret type '" + type + "'. Valid types: " + VALID_SECRET_TYPES);
    }

    protected void validateSecretName(String name) {
        if (name == null || name.isBlank())
            throw new IllegalArgumentException("Secret name cannot be blank");
        // K8s DNS subdomain naming rules
        if (!name.matches("[a-z0-9]([a-z0-9\\-]*[a-z0-9])?"))
            throw new IllegalArgumentException(
                "Secret name '" + name + "' is invalid. Must be lowercase alphanumeric / hyphens.");
        if (name.length() > 253)
            throw new IllegalArgumentException("Secret name exceeds 253-character K8s limit");
    }

    protected void validateServiceAccount(String sa) {
        if (sa == null || sa.isBlank())
            throw new IllegalArgumentException("ServiceAccount name cannot be blank");
    }

    // ─── Data sanitisation ──────────────────────────────────────────────────────

    /**
     * Redact a sensitive value for safe logging / display.
     * Never logs plaintext credentials.
     */
    protected String redact(String value) {
        if (value == null || value.isBlank()) return "<empty>";
        if (value.length() <= 4) return "****";
        return value.substring(0, 2) + "****" + value.substring(value.length() - 2);
    }

    // ─── Schema builders ─────────────────────────────────────────────────────────

    protected Map<String, Object> stringProp(String description) {
        return Map.of("type", "string", "description", description);
    }

    protected Map<String, Object> enumProp(String description, String... values) {
        return Map.of("type", "string", "description", description, "enum", List.of(values));
    }

    protected Map<String, Object> objectProp(String description) {
        return Map.of("type", "object", "description", description,
                      "additionalProperties", Map.of("type", "string"));
    }

    protected Map<String, Object> boolProp(String description) {
        return Map.of("type", "boolean", "description", description);
    }

    /**
     * Build a standard JSON Schema object with the given properties and required fields.
     */
    protected Map<String, Object> schema(Map<String, Object> properties, String... required) {
        Map<String, Object> schema = new LinkedHashMap<>();
        schema.put("type", "object");
        schema.put("properties", properties);
        schema.put("required", List.of(required));
        return schema;
    }
}
