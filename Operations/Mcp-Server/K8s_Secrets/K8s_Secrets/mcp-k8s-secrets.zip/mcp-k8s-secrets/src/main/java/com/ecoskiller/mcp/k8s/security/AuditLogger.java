package com.ecoskiller.mcp.k8s.security;

import java.time.Instant;
import java.util.logging.Logger;

/**
 * AuditLogger — Security audit logging for all Kubernetes Secrets operations.
 *
 * Every secret operation (create, read, update, delete, list, rotate)
 * is logged with timestamp, operator, namespace, and operation type.
 *
 * Credential VALUES are NEVER logged — only metadata.
 *
 * In production, this logger should forward to Wazuh SIEM via syslog
 * or structured JSON log shipping (per Ecoskiller v15 spec Section 11.4).
 */
public class AuditLogger {

    private static final Logger LOGGER = Logger.getLogger(AuditLogger.class.getName());

    /**
     * Log a Kubernetes Secret lifecycle operation.
     * Emits to stderr (Wazuh log shipper reads from here in production).
     *
     * @param operation   Operation type (SECRET_CREATE, SECRET_READ, etc.)
     * @param secretName  Secret name (never value)
     * @param namespace   Kubernetes namespace
     * @param environment Deployment environment
     * @param actor       ServiceAccount or operator identity
     * @param metadata    Additional non-sensitive metadata
     */
    public void logSecretOperation(
        String operation,
        String secretName,
        String namespace,
        String environment,
        String actor,
        String metadata
    ) {
        // Structured audit log format for Wazuh JSON parsing
        String auditEntry = String.format(
            "[AUDIT] {\"timestamp\":\"%s\",\"operation\":\"%s\",\"secret\":\"%s\"," +
            "\"namespace\":\"%s\",\"environment\":\"%s\",\"actor\":\"%s\",\"metadata\":\"%s\"," +
            "\"source\":\"mcp-k8s-secrets\",\"value_logged\":false}",
            Instant.now().toString(),
            sanitise(operation),
            sanitise(secretName),
            sanitise(namespace),
            sanitise(environment),
            sanitise(actor),
            sanitise(metadata)
        );

        // Write to stderr — stdout is reserved for MCP JSON-RPC responses
        System.err.println(auditEntry);
        LOGGER.info(auditEntry);
    }

    /**
     * Log a security event (RBAC violation, namespace violation, etc.)
     */
    public void logSecurityEvent(String eventType, String context, String detail) {
        String securityEntry = String.format(
            "[SECURITY] {\"timestamp\":\"%s\",\"event\":\"%s\",\"context\":\"%s\"," +
            "\"detail\":\"%s\",\"severity\":\"HIGH\",\"source\":\"mcp-k8s-secrets\"}",
            Instant.now().toString(),
            sanitise(eventType),
            sanitise(context),
            sanitise(detail)
        );
        System.err.println(securityEntry);
        LOGGER.warning(securityEntry);
    }

    /**
     * Sanitise a log field — prevent log injection, ensure no credential values leak.
     */
    private String sanitise(String input) {
        if (input == null) return "null";
        // Remove newlines (log injection prevention), truncate very long values
        String cleaned = input.replace("\n", " ").replace("\r", " ").replace("\"", "'");
        return cleaned.length() > 500 ? cleaned.substring(0, 497) + "..." : cleaned;
    }
}
