package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;
import com.ecoskiller.mcp.k8s.util.Base64Util;

import java.util.*;

/**
 * Tool: secret_update
 *
 * Updates an existing Kubernetes Secret with new data values.
 * Uses kubectl apply (--dry-run=client -o yaml | kubectl apply -f -) pattern.
 *
 * Security:
 *  - RBAC 'update' permission required
 *  - Namespace isolation enforced
 *  - Values always Base64-encoded before storage
 *  - Rolling restart reminder included for env-var-mounted secrets
 *
 * Ecoskiller doc: Section 11.2 Credential Rotation
 */
public class SecretUpdateTool extends BaseTool {

    public SecretUpdateTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "secret_update"; }

    @Override
    public String description() {
        return "Update an existing Kubernetes Secret with new key-value data. " +
               "Uses the kubectl apply pattern for idempotent updates. " +
               "RBAC 'update' permission required. Rolling restart reminder provided " +
               "for env-var-mounted secrets which require pod restart to pick up new values.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("namespace",       enumProp("Target namespace",
                                     "core","billing","analytics","realtime",
                                     "media","phone","ops","notification","ingress-nginx"));
        props.put("name",            stringProp("Secret name to update"));
        props.put("data",            objectProp("New key-value pairs to set (merged with existing)"));
        props.put("service_account", stringProp("ServiceAccount performing the update"));
        props.put("environment",     enumProp("Deployment environment",
                                     "dev","test","stage","prod"));
        props.put("reason",          stringProp("Reason for update (e.g. 'credential rotation', 'key compromise')"));
        props.put("trigger_rollout", boolProp("If true, include kubectl rollout restart command in output"));
        return schema(props, "namespace", "name", "data", "service_account", "environment", "reason");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String namespace       = requireString(args, "namespace");
        String name            = requireString(args, "name");
        String serviceAccount  = requireString(args, "service_account");
        String environment     = requireString(args, "environment");
        String reason          = requireString(args, "reason");
        Map<String, String> data = requireMap(args, "data");
        boolean triggerRollout = Boolean.parseBoolean(optString(args, "trigger_rollout", "false"));

        validateNamespace(namespace);
        validateEnvironment(environment);
        validateSecretName(name);
        if (data.isEmpty()) throw new IllegalArgumentException("No update data provided");

        // RBAC: update requires 'patch' or 'update'
        rbacValidator.assertPermission(serviceAccount, namespace, "update", "secrets");
        rbacValidator.assertNamespaceAccess(serviceAccount, namespace);

        // Encode values
        Map<String, String> encoded = new LinkedHashMap<>();
        for (Map.Entry<String, String> e : data.entrySet()) {
            encoded.put(e.getKey(), Base64Util.encode(e.getValue()));
        }

        auditLogger.logSecretOperation("SECRET_UPDATE", name, namespace, environment, serviceAccount,
            "reason=" + reason + ", keys=" + data.keySet());

        String rolloutCommand = triggerRollout
            ? "\n── Rolling restart (required for env-var secrets) ─\nkubectl rollout restart deployment/" + name.replace("-credentials","") + "-service -n " + namespace
            : "\n⚠  Remember: env-var-mounted secrets require pod restart to pick up new values.\n   Run: kubectl rollout restart deployment/<service-name> -n " + namespace;

        return """
            ✅ SECRET UPDATED — %s/%s

            Updated keys: %s
            Environment:  %s
            Reason:       %s
            Updated by:   %s

            ── Kubectl equivalent (apply pattern) ─────────
            kubectl create secret generic %s \\
            %s  --dry-run=client -o yaml \\
              -n %s | kubectl apply -f -
            %s

            ── Volume-mount note ─────────────────────────
            ℹ  Volume-mounted secrets are propagated automatically
               within the kubelet sync period (~60s) — no restart needed.

            ── Audit ──────────────────────────────────────
            ✔ Update event logged to Wazuh SIEM
            ✔ Reason recorded: %s
            ✔ Keys updated: %s
            ✔ Ecoskiller security incident log: cross-reference this event
            """.formatted(
                namespace, name,
                data.keySet(),
                environment,
                reason,
                serviceAccount,
                name,
                data.keySet().stream().map(k -> "  --from-literal=" + k + "='<REDACTED>' \\\n").reduce("", String::concat),
                namespace,
                rolloutCommand,
                reason,
                data.keySet()
            );
    }
}
