package com.ecoskiller.mcp.k8s.util;

import java.util.*;

/**
 * JsonRpc — Zero-dependency JSON-RPC 2.0 serialiser / parser.
 *
 * This implementation handles the MCP protocol messages without requiring
 * any external JSON library (Jackson, Gson, etc.), keeping the server
 * deployable with zero dependencies — just the JDK.
 *
 * Handles: parse(), result(), error(), str()
 *
 * Supports nested maps and lists for MCP tool schemas and responses.
 */
public final class JsonRpc {

    private JsonRpc() {}

    // ─── Serialisation ───────────────────────────────────────────────────────

    /**
     * Serialise an arbitrary Java object to a JSON string.
     * Supports: String, Number, Boolean, null, Map, List, and nested combinations.
     */
    public static String toJson(Object obj) {
        if (obj == null)                return "null";
        if (obj instanceof String s)    return jsonString(s);
        if (obj instanceof Boolean b)   return b.toString();
        if (obj instanceof Number n)    return n.toString();
        if (obj instanceof Map<?, ?> m) return mapToJson(m);
        if (obj instanceof List<?> l)   return listToJson(l);
        if (obj instanceof Object[] a)  return listToJson(List.of(a));
        return jsonString(obj.toString());
    }

    private static String jsonString(String s) {
        return "\"" + s
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
            + "\"";
    }

    private static String mapToJson(Map<?, ?> map) {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            if (!first) sb.append(",");
            sb.append(jsonString(entry.getKey().toString()));
            sb.append(":");
            sb.append(toJson(entry.getValue()));
            first = false;
        }
        return sb.append("}").toString();
    }

    private static String listToJson(List<?> list) {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (Object item : list) {
            if (!first) sb.append(",");
            sb.append(toJson(item));
            first = false;
        }
        return sb.append("]").toString();
    }

    // ─── Response builders ────────────────────────────────────────────────────

    /** Build a JSON-RPC 2.0 success response. */
    public static String result(String id, Object result) {
        String idJson = (id == null) ? "null" : jsonString(id);
        return "{\"jsonrpc\":\"2.0\",\"id\":" + idJson + ",\"result\":" + toJson(result) + "}";
    }

    /** Build a JSON-RPC 2.0 error response. */
    public static String error(String id, int code, String message) {
        String idJson = (id == null) ? "null" : jsonString(id);
        return "{\"jsonrpc\":\"2.0\",\"id\":" + idJson +
               ",\"error\":{\"code\":" + code +
               ",\"message\":" + jsonString(message) + "}}";
    }

    // ─── Parsing ──────────────────────────────────────────────────────────────

    /**
     * Parse a JSON object string into a Map<String, Object>.
     * Lightweight parser — handles objects, strings, numbers, booleans, arrays, null.
     *
     * @param json  JSON string to parse
     * @return      Parsed map
     * @throws IllegalArgumentException if JSON is malformed
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> parse(String json) {
        json = json.trim();
        if (!json.startsWith("{")) {
            throw new IllegalArgumentException("Expected JSON object, got: " + json.substring(0, Math.min(20, json.length())));
        }
        Object result = parseValue(new ParserState(json), 0)[0];
        if (result instanceof Map) {
            return (Map<String, Object>) result;
        }
        throw new IllegalArgumentException("Expected JSON object at root");
    }

    /** Extract a string field from a parsed map, or null if absent. */
    public static String str(Map<String, Object> map, String key) {
        Object v = map.get(key);
        return v == null ? null : v.toString();
    }

    // ─── Internal parser ──────────────────────────────────────────────────────

    private static class ParserState {
        final String src;
        int pos;
        ParserState(String src) { this.src = src; this.pos = 0; }
        char cur() { return pos < src.length() ? src.charAt(pos) : '\0'; }
        void skip() { while (pos < src.length() && Character.isWhitespace(src.charAt(pos))) pos++; }
    }

    /**
     * Parse a JSON value starting at state.pos.
     * Returns [parsedObject, endPosition].
     */
    @SuppressWarnings("unchecked")
    private static Object[] parseValue(ParserState s, int depth) {
        s.skip();
        char c = s.cur();

        if (c == '{') {
            return parseObject(s, depth + 1);
        } else if (c == '[') {
            return parseArray(s, depth + 1);
        } else if (c == '"') {
            return parseString(s);
        } else if (c == 't') {
            s.pos += 4; return new Object[]{Boolean.TRUE};
        } else if (c == 'f') {
            s.pos += 5; return new Object[]{Boolean.FALSE};
        } else if (c == 'n') {
            s.pos += 4; return new Object[]{null};
        } else if (c == '-' || Character.isDigit(c)) {
            return parseNumber(s);
        }
        throw new IllegalArgumentException("Unexpected character '" + c + "' at position " + s.pos);
    }

    private static Object[] parseObject(ParserState s, int depth) {
        Map<String, Object> map = new LinkedHashMap<>();
        s.pos++; // consume '{'
        s.skip();
        while (s.pos < s.src.length() && s.cur() != '}') {
            s.skip();
            if (s.cur() == '}') break;
            // Parse key
            Object[] keyResult = parseString(s);
            String key = (String) keyResult[0];
            s.skip();
            if (s.cur() != ':') throw new IllegalArgumentException("Expected ':' at position " + s.pos);
            s.pos++; // consume ':'
            // Parse value
            Object[] valResult = parseValue(s, depth);
            map.put(key, valResult[0]);
            s.skip();
            if (s.cur() == ',') { s.pos++; s.skip(); }
        }
        if (s.cur() == '}') s.pos++;
        return new Object[]{map};
    }

    private static Object[] parseArray(ParserState s, int depth) {
        List<Object> list = new ArrayList<>();
        s.pos++; // consume '['
        s.skip();
        while (s.pos < s.src.length() && s.cur() != ']') {
            s.skip();
            if (s.cur() == ']') break;
            Object[] val = parseValue(s, depth);
            list.add(val[0]);
            s.skip();
            if (s.cur() == ',') { s.pos++; s.skip(); }
        }
        if (s.cur() == ']') s.pos++;
        return new Object[]{list};
    }

    private static Object[] parseString(ParserState s) {
        s.pos++; // consume opening '"'
        StringBuilder sb = new StringBuilder();
        while (s.pos < s.src.length()) {
            char c = s.src.charAt(s.pos);
            if (c == '"') { s.pos++; break; }
            if (c == '\\') {
                s.pos++;
                char esc = s.src.charAt(s.pos);
                switch (esc) {
                    case '"'  -> sb.append('"');
                    case '\\' -> sb.append('\\');
                    case '/'  -> sb.append('/');
                    case 'n'  -> sb.append('\n');
                    case 'r'  -> sb.append('\r');
                    case 't'  -> sb.append('\t');
                    case 'b'  -> sb.append('\b');
                    case 'f'  -> sb.append('\f');
                    case 'u'  -> {
                        String hex = s.src.substring(s.pos + 1, s.pos + 5);
                        sb.append((char) Integer.parseInt(hex, 16));
                        s.pos += 4;
                    }
                    default -> sb.append(esc);
                }
            } else {
                sb.append(c);
            }
            s.pos++;
        }
        return new Object[]{sb.toString()};
    }

    private static Object[] parseNumber(ParserState s) {
        int start = s.pos;
        if (s.cur() == '-') s.pos++;
        while (s.pos < s.src.length() && (Character.isDigit(s.src.charAt(s.pos)) ||
               s.src.charAt(s.pos) == '.' || s.src.charAt(s.pos) == 'e' ||
               s.src.charAt(s.pos) == 'E' || s.src.charAt(s.pos) == '+' ||
               s.src.charAt(s.pos) == '-' && s.pos > start)) {
            s.pos++;
        }
        String numStr = s.src.substring(start, s.pos);
        if (numStr.contains(".") || numStr.contains("e") || numStr.contains("E")) {
            return new Object[]{Double.parseDouble(numStr)};
        }
        try {
            return new Object[]{Long.parseLong(numStr)};
        } catch (NumberFormatException e) {
            return new Object[]{Double.parseDouble(numStr)};
        }
    }
}
