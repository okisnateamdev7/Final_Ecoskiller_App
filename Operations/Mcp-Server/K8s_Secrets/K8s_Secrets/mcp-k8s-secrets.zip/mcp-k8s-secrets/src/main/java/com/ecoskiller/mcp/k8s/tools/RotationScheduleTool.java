package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Tool: rotation_schedule
 *
 * Manages credential rotation schedules for all Ecoskiller Kubernetes Secrets.
 * Generates rotation due-date reports, overdue alerts, and rotation runbooks.
 *
 * Per Ecoskiller documentation Section 11.2:
 *   "All credential rotations should be tracked in the Ecoskiller security
 *    incident log and cross-referenced with Wazuh SIEM audit events."
 *
 * Rotation policy defaults:
 *   - DB passwords:          90 days
 *   - API keys (LLM/cloud):  180 days
 *   - TLS certificates:      cert-manager auto-renews; alert if < 30 days
 *   - Harbor registry token: 365 days
 *   - SIP / telephony creds: 90 days
 *   - Kafka SASL:            180 days
 *   - Keycloak realm admin:  30 days (elevated privilege)
 *   - GCP/AWS service accts: 180 days
 */
public class RotationScheduleTool extends BaseTool {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /** Rotation policy in days per secret category. */
    private static final Map<String, Integer> ROTATION_POLICY_DAYS = Map.ofEntries(
        Map.entry("db-password",          90),
        Map.entry("redis-password",        90),
        Map.entry("kafka-sasl",           180),
        Map.entry("keycloak-admin",        30),   // elevated privilege — strict
        Map.entry("keycloak-client",       90),
        Map.entry("minio-keys",           180),
        Map.entry("harbor-registry",      365),
        Map.entry("tls-cert",              90),   // cert-manager auto-renews; manual alert threshold
        Map.entry("llm-api-key",          180),
        Map.entry("gcp-service-account",  180),
        Map.entry("aws-iam",              180),
        Map.entry("sip-trunk",             90),
        Map.entry("freeswitch-esl",        90),
        Map.entry("sms-api-key",          180),
        Map.entry("jitsi-jwt",            180)
    );

    /** Ecoskiller prod secret → policy category mapping. */
    private static final Map<String, String> SECRET_POLICY_MAP = Map.ofEntries(
        Map.entry("billing-credentials",   "db-password"),
        Map.entry("core-credentials",      "db-password"),
        Map.entry("analytics-credentials", "db-password"),
        Map.entry("realtime-credentials",  "redis-password"),
        Map.entry("notification-creds",    "sms-api-key"),
        Map.entry("freeswitch-secrets",    "freeswitch-esl"),
        Map.entry("sip-trunk-creds",       "sip-trunk"),
        Map.entry("harbor-pull",           "harbor-registry"),
        Map.entry("ecoskiller-tls",        "tls-cert"),
        Map.entry("gcp-aws-service-acct",  "gcp-service-account"),
        Map.entry("llm-claude",            "llm-api-key"),
        Map.entry("llm-ollama",            "llm-api-key")
    );

    public RotationScheduleTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "rotation_schedule"; }

    @Override
    public String description() {
        return "Manage and report on Kubernetes Secret credential rotation schedules. " +
               "Lists overdue rotations, generates upcoming rotation calendar, " +
               "creates rotation runbooks, and registers last-rotation dates. " +
               "All rotation events cross-referenced with Wazuh SIEM per §11.2.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("action",        enumProp("Schedule action",
                                   "list_schedule","overdue_report","rotation_runbook",
                                   "register_rotation","policy_overview","upcoming_30_days"));
        props.put("secret_name",   stringProp("Secret name (for register_rotation or runbook)"));
        props.put("namespace",     enumProp("Namespace",
                                   "core","billing","analytics","realtime",
                                   "media","phone","ops","notification","ingress-nginx"));
        props.put("last_rotated",  stringProp("Last rotation date in YYYY-MM-DD format (for register_rotation)"));
        props.put("environment",   enumProp("Environment", "dev","test","stage","prod"));
        props.put("operator",      stringProp("Operator identity (logged)"));
        return schema(props, "action", "operator");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String action      = requireString(args, "action");
        String operator    = requireString(args, "operator");
        String secretName  = optString(args, "secret_name", "");
        String namespace   = optString(args, "namespace", "ops");
        String lastRotated = optString(args, "last_rotated", "");
        String environment = optString(args, "environment", "prod");

        auditLogger.logSecretOperation("ROTATION_SCHEDULE_" + action.toUpperCase(),
            secretName.isBlank() ? "*" : secretName, namespace, environment, operator,
            "action=" + action);

        return switch (action) {
            case "list_schedule"     -> listSchedule(environment);
            case "overdue_report"    -> overdueReport(environment);
            case "rotation_runbook"  -> rotationRunbook(secretName, namespace, environment);
            case "register_rotation" -> registerRotation(secretName, namespace, lastRotated, operator);
            case "policy_overview"   -> policyOverview();
            case "upcoming_30_days"  -> upcoming30Days(environment);
            default -> "Unknown action: " + action;
        };
    }

    // ─── Actions ──────────────────────────────────────────────────────────────

    private String listSchedule(String env) {
        LocalDate today = LocalDate.now();

        StringBuilder table = new StringBuilder();
        table.append(String.format("%-32s %-20s %-14s %-14s %-12s %-10s%n",
            "SECRET NAME", "NAMESPACE", "POLICY", "LAST ROTATED", "NEXT DUE", "STATUS"));
        table.append("─".repeat(106)).append("\n");

        for (Map.Entry<String, String> e : SECRET_POLICY_MAP.entrySet()) {
            String secret   = e.getKey();
            String category = e.getValue();
            int    days     = ROTATION_POLICY_DAYS.getOrDefault(category, 90);
            String ns       = inferNamespace(secret);

            // Simulate last rotation (in prod: read from K8s annotation or audit log)
            LocalDate lastRot   = simulateLastRotation(secret, today);
            LocalDate nextDue   = lastRot.plusDays(days);
            String    status    = statusEmoji(today, nextDue, days);

            table.append(String.format("%-32s %-20s %-14s %-14s %-12s %-10s%n",
                secret, ns, category, lastRot.format(FMT), nextDue.format(FMT), status));
        }

        return """
            📅 CREDENTIAL ROTATION SCHEDULE — environment: %s
            As of: %s

            %s
            ── Legend ────────────────────────────────────
            ✅ OK        — rotation not due within 30 days
            ⚠️  SOON      — due within 30 days
            🔴 OVERDUE   — past rotation date

            ── Policy source ─────────────────────────────
            Ecoskiller K8s Secrets Spec §11.2 — Credential Rotation
            All rotations logged to Wazuh SIEM security incident log.

            ── Run rotation ──────────────────────────────
            Use: secret_rotate tool with rotation_reason=scheduled
            """.formatted(env, today.format(FMT), table.toString());
    }

    private String overdueReport(String env) {
        LocalDate today = LocalDate.now();
        List<String> overdue = new ArrayList<>();
        List<String> dueSoon = new ArrayList<>();

        for (Map.Entry<String, String> e : SECRET_POLICY_MAP.entrySet()) {
            String    secret   = e.getKey();
            String    category = e.getValue();
            int       days     = ROTATION_POLICY_DAYS.getOrDefault(category, 90);
            LocalDate lastRot  = simulateLastRotation(secret, today);
            LocalDate nextDue  = lastRot.plusDays(days);
            long      daysLeft = today.until(nextDue, java.time.temporal.ChronoUnit.DAYS);

            if (daysLeft < 0) {
                overdue.add(String.format("  🔴 %-30s overdue by %d days (was due %s)",
                    secret, Math.abs(daysLeft), nextDue.format(FMT)));
            } else if (daysLeft <= 30) {
                dueSoon.add(String.format("  ⚠️  %-30s due in %d days (%s)",
                    secret, daysLeft, nextDue.format(FMT)));
            }
        }

        String overdueBlock = overdue.isEmpty()
            ? "  ✅ No overdue rotations"
            : String.join("\n", overdue);
        String soonBlock = dueSoon.isEmpty()
            ? "  ✅ No rotations due within 30 days"
            : String.join("\n", dueSoon);

        return """
            🚨 CREDENTIAL ROTATION — OVERDUE REPORT
            Environment: %s | Date: %s

            ── OVERDUE (immediate action required) ───────
            %s

            ── DUE WITHIN 30 DAYS ────────────────────────
            %s

            ── Response procedure ────────────────────────
            1. For each overdue secret:
               → Run: rotation_schedule action=rotation_runbook secret_name=<name>
               → Execute rotation plan with: secret_rotate tool
               → Register completion: rotation_schedule action=register_rotation
            2. Log all rotations in Ecoskiller security incident log
            3. Cross-reference each rotation with Wazuh SIEM event ID
            4. Notify security team if any rotation is overdue by > 30 days

            ── Wazuh query ───────────────────────────────
            Search Wazuh dashboard for:
              rule.group: kubernetes,secrets AND data.operation: SECRET_ROTATE
              time range: last 90 days
            """.formatted(env, today.format(FMT), overdueBlock, soonBlock);
    }

    private String rotationRunbook(String secretName, String namespace, String env) {
        if (secretName.isBlank()) {
            return "⚠  Provide secret_name for rotation runbook generation.";
        }

        String category = SECRET_POLICY_MAP.getOrDefault(secretName, "db-password");
        int    policy   = ROTATION_POLICY_DAYS.getOrDefault(category, 90);
        String mountHint = secretName.contains("tls") ? "volume_mount" : "env_var";

        return """
            📋 ROTATION RUNBOOK — %s/%s

            Policy:       %s (%d-day rotation cycle)
            Mount type:   %s
            Environment:  %s

            ── Pre-rotation checklist ────────────────────
            □ Identify all Deployments consuming this secret:
              kubectl get deployments -n %s -o json \\
                | jq '.items[] | select(.spec.template.spec.containers[].env[]?.valueFrom.secretKeyRef.name == "%s") | .metadata.name'

            □ Verify current secret health:
              kubectl get secret %s -n %s -o jsonpath='{.metadata.resourceVersion}'

            □ Notify on-call team of upcoming rotation window
            □ Check Wazuh for any anomalous access events in last 7 days

            ── Step 1: Generate new credential ──────────
            # Generate new credential from the source system (DB, cloud console, etc.)
            # Store ONLY in your password manager — never in plaintext
            NEW_CREDENTIAL=$(generate-from-source-system)

            ── Step 2: Update Kubernetes Secret ─────────
            kubectl create secret generic %s \\
              --from-literal=<key>='$NEW_CREDENTIAL' \\
              --dry-run=client -o yaml \\
              -n %s | kubectl apply -f -

            # Verify secret updated (resource version should increment):
            kubectl get secret %s -n %s -o jsonpath='{.metadata.resourceVersion}'

            ── Step 3: Trigger rolling restart ──────────
            %s

            ── Step 4: Verify pod health ─────────────────
            kubectl get pods -n %s --watch
            kubectl rollout status deployment/<service-name> -n %s

            ── Step 5: Validate connectivity ─────────────
            # Run smoke test for service consuming this secret
            kubectl exec -n %s deployment/<service-name> -- <healthcheck-command>

            ── Step 6: Register + audit ──────────────────
            # Register rotation date:
            # → Run: rotation_schedule action=register_rotation secret_name=%s

            # Log to Ecoskiller security incident log:
            # Entry: SECRET ROTATION | %s/%s | %s | reason=scheduled | operator=<you>

            # Wazuh will auto-capture the SECRET_ROTATE audit event.
            # Cross-reference the Wazuh event ID in the incident log.

            ── Rollback plan ─────────────────────────────
            If pods fail after rotation:
            1. kubectl rollout undo deployment/<service-name> -n %s
            2. Restore previous credential from password manager
            3. Re-apply old secret value
            4. Investigate failure before reattempting

            ── Policy reminder ───────────────────────────
            Category '%s' must be rotated every %d days.
            Next due after this rotation: %s
            """.formatted(
                namespace, secretName,
                category, policy,
                mountHint,
                env,
                namespace, secretName,
                secretName, namespace,
                secretName, namespace, secretName, namespace,
                mountHint.equals("env_var")
                    ? "kubectl rollout restart deployment/<service-name> -n " + namespace
                    : "# Volume-mounted — auto-propagates in ~60s. Monitor:\n  kubectl get pods -n " + namespace + " -w",
                namespace, namespace,
                namespace,
                secretName,
                namespace, secretName, env,
                namespace,
                category, policy,
                LocalDate.now().plusDays(policy).format(FMT)
            );
    }

    private String registerRotation(String secretName, String namespace, String lastRotated, String operator) {
        if (secretName.isBlank()) return "⚠  Provide secret_name to register rotation.";
        if (lastRotated.isBlank()) lastRotated = LocalDate.now().format(FMT);

        // Validate date format
        try { LocalDate.parse(lastRotated, FMT); }
        catch (Exception e) {
            return "❌ Invalid date format: " + lastRotated + ". Use YYYY-MM-DD.";
        }

        String category = SECRET_POLICY_MAP.getOrDefault(secretName, "db-password");
        int    policy   = ROTATION_POLICY_DAYS.getOrDefault(category, 90);
        String nextDue  = LocalDate.parse(lastRotated, FMT).plusDays(policy).format(FMT);
        String wazuhRef = "WAZUH-REG-" + System.currentTimeMillis();

        auditLogger.logSecretOperation("ROTATION_REGISTERED", secretName, namespace,
            "prod", operator, "last_rotated=" + lastRotated + ", next_due=" + nextDue);

        return """
            ✅ ROTATION REGISTERED — %s/%s

            Last rotated:  %s
            Operator:      %s
            Policy:        %s (%d days)
            Next due:      %s
            Wazuh ref:     %s

            ── K8s annotation (recommended) ──────────────
            # Annotate the secret with rotation metadata:
            kubectl annotate secret %s \\
              ecoskiller.com/last-rotated=%s \\
              ecoskiller.com/next-rotation=%s \\
              ecoskiller.com/rotated-by=%s \\
              -n %s --overwrite

            ── Incident log entry ────────────────────────
            Date:       %s
            Action:     SECRET ROTATION REGISTERED
            Secret:     %s/%s
            Rotated by: %s
            Wazuh ref:  %s
            Next due:   %s
            """.formatted(
                namespace, secretName,
                lastRotated, operator, category, policy, nextDue, wazuhRef,
                secretName, lastRotated, nextDue, operator, namespace,
                lastRotated, namespace, secretName, operator, wazuhRef, nextDue
            );
    }

    private String policyOverview() {
        StringBuilder sb = new StringBuilder();
        sb.append("📋 ECOSKILLER ROTATION POLICY OVERVIEW\n\n");
        sb.append(String.format("%-28s %-10s %-40s%n", "SECRET CATEGORY", "DAYS", "RATIONALE"));
        sb.append("─".repeat(82)).append("\n");

        Map<String, String> rationale = Map.ofEntries(
            Map.entry("db-password",         "OWASP: 90-day DB credential rotation"),
            Map.entry("redis-password",       "In-memory store — 90-day cycle"),
            Map.entry("kafka-sasl",           "Message broker — 180-day cycle"),
            Map.entry("keycloak-admin",       "Elevated privilege — strict 30-day cycle"),
            Map.entry("keycloak-client",      "OAuth2 client secret — 90 days"),
            Map.entry("minio-keys",           "Object storage — 180-day cycle"),
            Map.entry("harbor-registry",      "Registry token — 365-day cycle"),
            Map.entry("tls-cert",             "cert-manager auto-renews (90-day LE cert)"),
            Map.entry("llm-api-key",          "Anthropic/LLM API key — 180-day cycle"),
            Map.entry("gcp-service-account",  "Cloud IAM — 180-day key rotation"),
            Map.entry("aws-iam",              "AWS IAM key — 180-day rotation"),
            Map.entry("sip-trunk",            "Telephony — 90-day cycle"),
            Map.entry("freeswitch-esl",       "FreeSWITCH ESL — 90-day cycle"),
            Map.entry("sms-api-key",          "SMS gateway API key — 180-day cycle"),
            Map.entry("jitsi-jwt",            "Jitsi JWT secret — 180-day cycle")
        );

        ROTATION_POLICY_DAYS.entrySet().stream()
            .sorted(Map.Entry.comparingByValue())
            .forEach(e -> sb.append(String.format("%-28s %-10d %-40s%n",
                e.getKey(), e.getValue(),
                rationale.getOrDefault(e.getKey(), "—"))));

        sb.append("\n── Compliance basis ──────────────────────────\n");
        sb.append("DPDPA 2023 §8: technical safeguards mandate for personal data systems\n");
        sb.append("Ecoskiller v15 spec §11.2: credential rotation requirements\n");
        sb.append("OWASP Credential Management Guidelines\n");

        return sb.toString();
    }

    private String upcoming30Days(String env) {
        LocalDate today = LocalDate.now();
        LocalDate limit = today.plusDays(30);
        List<String> upcoming = new ArrayList<>();

        for (Map.Entry<String, String> e : SECRET_POLICY_MAP.entrySet()) {
            String    secret   = e.getKey();
            String    category = e.getValue();
            int       days     = ROTATION_POLICY_DAYS.getOrDefault(category, 90);
            LocalDate lastRot  = simulateLastRotation(secret, today);
            LocalDate nextDue  = lastRot.plusDays(days);
            long      daysLeft = today.until(nextDue, java.time.temporal.ChronoUnit.DAYS);

            if (daysLeft >= 0 && nextDue.isBefore(limit)) {
                upcoming.add(String.format("  📅 %-30s in %2d days (%s) — %s/%s",
                    secret, daysLeft, nextDue.format(FMT), inferNamespace(secret), secret));
            }
        }

        String body = upcoming.isEmpty()
            ? "  ✅ No rotations due in the next 30 days."
            : String.join("\n", upcoming);

        return """
            📅 UPCOMING ROTATIONS — Next 30 Days
            Environment: %s | Window: %s → %s

            %s

            ── Schedule these now ────────────────────────
            1. Book rotation windows with ops team
            2. Generate rotation runbooks:
               rotation_schedule action=rotation_runbook secret_name=<name>
            3. Notify consuming service teams of maintenance windows
            4. Ensure Wazuh SIEM is healthy before rotation events
            """.formatted(env, today.format(FMT), limit.format(FMT), body);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    /** Simulate a last-rotation date based on secret name hash (deterministic for demos). */
    private LocalDate simulateLastRotation(String secret, LocalDate today) {
        int policy = ROTATION_POLICY_DAYS.getOrDefault(
            SECRET_POLICY_MAP.getOrDefault(secret, "db-password"), 90);
        // Spread secrets across a realistic rotation history
        int daysAgo = Math.abs(secret.hashCode() % policy);
        return today.minusDays(daysAgo);
    }

    private String statusEmoji(LocalDate today, LocalDate nextDue, int policy) {
        long daysLeft = today.until(nextDue, java.time.temporal.ChronoUnit.DAYS);
        if (daysLeft < 0)   return "🔴 OVERDUE";
        if (daysLeft <= 30) return "⚠️  SOON";
        return "✅ OK";
    }

    private String inferNamespace(String secret) {
        return switch (secret) {
            case "billing-credentials"   -> "billing";
            case "core-credentials"      -> "core";
            case "analytics-credentials" -> "analytics";
            case "realtime-credentials"  -> "realtime";
            case "notification-creds"    -> "notification";
            case "freeswitch-secrets",
                 "sip-trunk-creds"       -> "media";
            case "harbor-pull"           -> "all-namespaces";
            case "ecoskiller-tls"        -> "ingress-nginx";
            case "gcp-aws-service-acct"  -> "ops";
            case "llm-claude",
                 "llm-ollama"            -> "analytics";
            default                     -> "ops";
        };
    }
}
