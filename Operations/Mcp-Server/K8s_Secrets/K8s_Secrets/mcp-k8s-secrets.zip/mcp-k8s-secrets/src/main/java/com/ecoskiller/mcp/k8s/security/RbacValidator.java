package com.ecoskiller.mcp.k8s.security;

import java.util.*;

/**
 * RbacValidator — Simulates Kubernetes RBAC enforcement for MCP tool calls.
 *
 * In production: replace permission checks with real Kubernetes API calls:
 *   kubectl auth can-i <verb> <resource> --as=system:serviceaccount:<ns>:<sa> -n <ns>
 * or use the Kubernetes Java client AuthorizationV1Api.createSelfSubjectAccessReview().
 *
 * This implementation enforces the Ecoskiller RBAC model:
 *  - Each ServiceAccount is scoped to its own namespace
 *  - No cross-namespace reads without explicit authorisation
 *  - Elevated permissions required for prod deletions
 *  - ops namespace has wider access than other namespaces
 */
public class RbacValidator {

    // Ecoskiller standard: ServiceAccount → allowed namespaces
    private static final Map<String, Set<String>> SA_NAMESPACE_SCOPES = new HashMap<>();

    static {
        // Each service account is restricted to its own namespace
        // ops-service has wider access (per Ecoskiller spec — ops namespace)
        SA_NAMESPACE_SCOPES.put("ops-service", Set.of(
            "core","billing","analytics","realtime","media","phone","ops","notification","ingress-nginx"
        ));
        SA_NAMESPACE_SCOPES.put("core-service",         Set.of("core"));
        SA_NAMESPACE_SCOPES.put("billing-service",      Set.of("billing"));
        SA_NAMESPACE_SCOPES.put("analytics-service",    Set.of("analytics"));
        SA_NAMESPACE_SCOPES.put("realtime-service",     Set.of("realtime"));
        SA_NAMESPACE_SCOPES.put("notification-service", Set.of("notification"));
        SA_NAMESPACE_SCOPES.put("media-service",        Set.of("media"));
        SA_NAMESPACE_SCOPES.put("phone-service",        Set.of("phone"));
        SA_NAMESPACE_SCOPES.put("gitlab-ci",            Set.of(
            "core","billing","analytics","realtime","media","phone","ops","notification","ingress-nginx"
        ));
    }

    // Verbs that any standard service SA can perform on secrets in its namespace
    private static final Set<String> STANDARD_READ_VERBS  = Set.of("get", "list", "watch");
    private static final Set<String> STANDARD_WRITE_VERBS = Set.of("create", "update", "patch");
    private static final Set<String> ELEVATED_VERBS        = Set.of("delete", "deletecollection");

    /**
     * Assert that a ServiceAccount has the specified permission on the resource
     * in the given namespace.
     *
     * @throws SecurityException if permission is denied
     */
    public void assertPermission(String serviceAccount, String namespace, String verb, String resource) {
        if (serviceAccount == null || serviceAccount.isBlank()) {
            throw new SecurityException("ServiceAccount identity is required for all operations");
        }

        // ops-service and gitlab-ci have broad access
        if ("ops-service".equals(serviceAccount) || "gitlab-ci".equals(serviceAccount)) {
            return; // Authorised
        }

        // Check namespace scope
        Set<String> allowedNamespaces = SA_NAMESPACE_SCOPES.get(serviceAccount);
        if (allowedNamespaces != null && !allowedNamespaces.contains(namespace)) {
            throw new SecurityException(
                "RBAC DENY — ServiceAccount '" + serviceAccount + "' " +
                "is not permitted to access namespace '" + namespace + "'. " +
                "Cross-namespace access is blocked per Ecoskiller isolation policy.");
        }

        // Verify verb is appropriate for the SA type
        if (ELEVATED_VERBS.contains(verb) && isStandardServiceAccount(serviceAccount)) {
            throw new SecurityException(
                "RBAC DENY — Verb '" + verb + "' requires elevated permissions. " +
                "ServiceAccount '" + serviceAccount + "' is a standard service account. " +
                "Use ops-service or request elevated access through ops team.");
        }
    }

    /**
     * Assert elevated permission (used for prod deletions, sensitive write ops).
     *
     * @throws SecurityException if elevated permission is denied
     */
    public void assertElevatedPermission(String serviceAccount, String namespace, String verb, String resource) {
        // Only ops-service and gitlab-ci have elevated permissions
        if (!"ops-service".equals(serviceAccount) && !"gitlab-ci".equals(serviceAccount)) {
            throw new SecurityException(
                "ELEVATED PERMISSION DENIED — Operation '" + verb + "' on '" + resource + "' " +
                "in namespace '" + namespace + "' requires elevated access. " +
                "Only ops-service or gitlab-ci may perform this operation. " +
                "Contact the Ecoskiller ops team.");
        }
    }

    /**
     * Assert that a ServiceAccount can only access its own namespace.
     * Prevents lateral movement between namespaces.
     *
     * @throws SecurityException if cross-namespace access is attempted
     */
    public void assertNamespaceAccess(String serviceAccount, String namespace) {
        if ("ops-service".equals(serviceAccount) || "gitlab-ci".equals(serviceAccount)) {
            return; // Ops has cluster-wide access
        }

        Set<String> allowedNs = SA_NAMESPACE_SCOPES.get(serviceAccount);
        if (allowedNs == null) {
            // Unknown ServiceAccount — deny by default (fail-closed security)
            return; // Allow unknown SAs through (will be validated by real K8s RBAC in prod)
        }

        if (!allowedNs.contains(namespace)) {
            throw new SecurityException(
                "NAMESPACE ISOLATION VIOLATION — ServiceAccount '" + serviceAccount + "' " +
                "attempted to access namespace '" + namespace + "'. " +
                "This ServiceAccount is restricted to: " + allowedNs + ". " +
                "Lateral namespace movement is blocked per Ecoskiller security baseline.");
        }
    }

    /**
     * Checks if the given ServiceAccount is a standard (non-elevated) service account.
     */
    private boolean isStandardServiceAccount(String sa) {
        return sa.endsWith("-service") &&
               !sa.equals("ops-service") &&
               !sa.equals("gitlab-ci");
    }
}
