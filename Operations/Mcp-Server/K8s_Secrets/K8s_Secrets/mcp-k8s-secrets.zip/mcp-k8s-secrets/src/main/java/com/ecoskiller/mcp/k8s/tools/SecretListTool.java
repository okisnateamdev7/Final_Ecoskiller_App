package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.util.*;

/**
 * Tool: secret_list
 *
 * Lists all Kubernetes Secret names (not values) in a given namespace.
 * Aligned with the Ecoskiller prod secret inventory from Appendix of K8s Secrets doc.
 *
 * Security:
 *  - Only lists secrets within the caller's namespace (no cross-namespace listing)
 *  - RBAC 'list' permission required
 *  - Values never exposed
 */
public class SecretListTool extends BaseTool {

    // Ecoskiller prod secret registry from documentation Appendix
    private static final Map<String, List<String>> ECOSKILLER_SECRETS = Map.of(
        "billing",       List.of("billing-credentials", "harbor-pull"),
        "core",          List.of("core-credentials", "harbor-pull"),
        "analytics",     List.of("analytics-credentials", "llm-claude", "llm-ollama", "harbor-pull"),
        "realtime",      List.of("realtime-credentials", "harbor-pull"),
        "notification",  List.of("notification-creds", "harbor-pull"),
        "media",         List.of("freeswitch-secrets", "sip-trunk-creds", "harbor-pull"),
        "phone",         List.of("harbor-pull"),
        "ops",           List.of("gcp-aws-service-acct", "harbor-pull"),
        "ingress-nginx", List.of("ecoskiller-tls")
    );

    public SecretListTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "secret_list"; }

    @Override
    public String description() {
        return "List all Kubernetes Secret names (metadata only, no values) in the specified namespace. " +
               "Returns the Ecoskiller standard secret inventory per namespace. " +
               "RBAC 'list' permission required for the target namespace.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("namespace",       enumProp("Target Ecoskiller namespace to list secrets in",
                                     "core","billing","analytics","realtime",
                                     "media","phone","ops","notification","ingress-nginx"));
        props.put("service_account", stringProp("ServiceAccount making the list request"));
        props.put("environment",     enumProp("Deployment environment (filters by env path convention)",
                                     "dev","test","stage","prod"));
        props.put("filter_type",     enumProp("Optional: filter by secret type",
                                     "all","Opaque","kubernetes.io/tls","kubernetes.io/dockerconfigjson"));
        return schema(props, "namespace", "service_account", "environment");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String namespace      = requireString(args, "namespace");
        String serviceAccount = requireString(args, "service_account");
        String environment    = requireString(args, "environment");
        String filterType     = optString(args, "filter_type", "all");

        validateNamespace(namespace);
        validateEnvironment(environment);
        validateServiceAccount(serviceAccount);

        rbacValidator.assertPermission(serviceAccount, namespace, "list", "secrets");
        rbacValidator.assertNamespaceAccess(serviceAccount, namespace);

        auditLogger.logSecretOperation("SECRET_LIST", "*", namespace, environment, serviceAccount,
            "filter=" + filterType);

        List<String> secrets = ECOSKILLER_SECRETS.getOrDefault(namespace, List.of());

        StringBuilder table = new StringBuilder();
        table.append(String.format("%-35s %-40s %-30s%n", "SECRET NAME", "TYPE", "CONTENTS HINT"));
        table.append("-".repeat(110)).append("\n");
        for (String s : secrets) {
            table.append(String.format("%-35s %-40s %-30s%n", s, inferType(s), inferHint(s)));
        }

        return """
            📋 SECRETS LIST — namespace: %s | env: %s

            %s
            Total: %d secret(s)

            ── Kubectl equivalent ─────────────────────────
            kubectl get secrets -n %s

            ── Security note ─────────────────────────────
            ⚠  Secret values are NEVER listed. Only names and type metadata.
            ⚠  Cross-namespace listing is blocked by RBAC.
               ServiceAccount '%s' is restricted to namespace '%s'.

            ── Ecoskiller path convention ────────────────
            secret/%s/<service-name> — use this pattern for all new secrets.

            ── Audit ──────────────────────────────────────
            ✔ List operation logged to Wazuh SIEM
            ✔ Caller: %s | Namespace: %s
            """.formatted(
                namespace, environment,
                table.toString(),
                secrets.size(),
                namespace,
                serviceAccount, namespace,
                environment,
                serviceAccount, namespace
            );
    }

    private String inferType(String name) {
        if (name.endsWith("-tls"))    return "kubernetes.io/tls";
        if (name.startsWith("harbor")) return "kubernetes.io/dockerconfigjson";
        return "Opaque";
    }

    private String inferHint(String name) {
        return switch (name) {
            case "billing-credentials"  -> "db-password, redis-password, minio-keys";
            case "core-credentials"     -> "db-password, keycloak-secret, kafka-sasl";
            case "analytics-credentials"-> "db-password, llm-api-key";
            case "realtime-credentials" -> "redis-password, kafka-sasl, jitsi-jwt";
            case "notification-creds"   -> "exotel-key, twilio-sid, gupshup-key";
            case "freeswitch-secrets"   -> "esl-password, jitsi-app-secret, xmpp-password";
            case "sip-trunk-creds"      -> "sip-host, sip-username, sip-password";
            case "harbor-pull"          -> ".dockerconfigjson (harbor.ecoskiller.com)";
            case "ecoskiller-tls"       -> "tls.crt, tls.key";
            case "gcp-aws-service-acct" -> "gcp-sa-json, aws-iam-key";
            case "llm-claude"           -> "api_key, model_version";
            case "llm-ollama"           -> "endpoint_url";
            default                    -> "—";
        };
    }
}
