package com.ecoskiller.mcp.k8s.tools;

import java.util.Map;

/**
 * Contract for all Kubernetes Secrets MCP tool handlers.
 * Every tool must declare its name, description, JSON schema, and execution logic.
 */
public interface ToolHandler {
    /** Unique tool identifier used in tools/call requests. */
    String name();

    /** Human-readable description shown in tools/list. */
    String description();

    /** JSON Schema (as a Java Map) describing the tool's input arguments. */
    Map<String, Object> inputSchema();

    /**
     * Execute the tool with the given arguments.
     *
     * @param args  Key-value arguments from the MCP caller
     * @return      Result object — will be serialised to JSON text
     * @throws SecurityException  if RBAC / namespace check fails
     * @throws IllegalArgumentException  if required arguments are missing / invalid
     */
    Object execute(Map<String, Object> args) throws Exception;
}
