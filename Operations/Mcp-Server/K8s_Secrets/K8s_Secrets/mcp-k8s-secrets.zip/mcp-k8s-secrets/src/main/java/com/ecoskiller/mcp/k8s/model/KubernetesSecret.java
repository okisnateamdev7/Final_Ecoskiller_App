package com.ecoskiller.mcp.k8s.model;

import java.util.*;

/**
 * KubernetesSecret — Immutable model representing a Kubernetes Secret object.
 *
 * Mirrors the Kubernetes Secret API object structure:
 *   apiVersion: v1
 *   kind: Secret
 *   metadata: { name, namespace, labels }
 *   type: Opaque | kubernetes.io/tls | ...
 *   data: { key: base64value }
 *
 * Values are always stored as Base64-encoded strings (as K8s requires).
 * This model does NOT store plaintext values.
 */
public class KubernetesSecret {

    private final String name;
    private final String namespace;
    private final String type;
    private final Map<String, String> data;   // Base64-encoded values
    private final Map<String, String> labels;
    private final long createdAt;

    public KubernetesSecret(
        String name,
        String namespace,
        String type,
        Map<String, String> data,
        Map<String, String> labels
    ) {
        this.name      = Objects.requireNonNull(name,      "name");
        this.namespace = Objects.requireNonNull(namespace, "namespace");
        this.type      = Objects.requireNonNull(type,      "type");
        this.data      = Collections.unmodifiableMap(new LinkedHashMap<>(data));
        this.labels    = Collections.unmodifiableMap(new LinkedHashMap<>(labels));
        this.createdAt = System.currentTimeMillis();
    }

    public String              getName()      { return name; }
    public String              getNamespace() { return namespace; }
    public String              getType()      { return type; }
    public Map<String, String> getData()      { return data; }
    public Map<String, String> getLabels()    { return labels; }
    public long                getCreatedAt() { return createdAt; }

    /**
     * Returns a Kubernetes YAML manifest for this secret (data values redacted).
     * Safe to log / display.
     */
    public String toRedactedYaml() {
        StringBuilder sb = new StringBuilder();
        sb.append("apiVersion: v1\n");
        sb.append("kind: Secret\n");
        sb.append("metadata:\n");
        sb.append("  name: ").append(name).append("\n");
        sb.append("  namespace: ").append(namespace).append("\n");
        if (!labels.isEmpty()) {
            sb.append("  labels:\n");
            labels.forEach((k, v) -> sb.append("    ").append(k).append(": ").append(v).append("\n"));
        }
        sb.append("type: ").append(type).append("\n");
        sb.append("data:\n");
        data.keySet().forEach(k -> sb.append("  ").append(k).append(": <REDACTED>\n"));
        return sb.toString();
    }

    @Override
    public String toString() {
        return "KubernetesSecret{name='" + name + "', namespace='" + namespace +
               "', type='" + type + "', keys=" + data.keySet() + "}";
    }
}
