package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.util.*;

/**
 * Tool: secret_read
 *
 * Reads metadata and key names for a Kubernetes Secret.
 * Values are NEVER returned in plaintext — only key names and metadata.
 *
 * Security:
 *  - Namespace isolation enforced (cross-namespace reads blocked)
 *  - RBAC 'get' permission verified before read
 *  - Secret values are always redacted in output
 *  - Every read is audit-logged per Ecoskiller security baseline
 *
 * Ecoskiller doc: Section 3.2 Namespace-Scoped Isolation,
 *                 Section 11.4 Audit and Monitoring
 */
public class SecretReadTool extends BaseTool {

    public SecretReadTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "secret_read"; }

    @Override
    public String description() {
        return "Read metadata and key names for a Kubernetes Secret. " +
               "Secret VALUES are never returned — only key names and metadata are shown. " +
               "RBAC 'get' permission required. Every read operation is audit-logged.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("namespace",       enumProp("Target Ecoskiller namespace",
                                     "core","billing","analytics","realtime",
                                     "media","phone","ops","notification","ingress-nginx"));
        props.put("name",            stringProp("Secret name to read"));
        props.put("service_account", stringProp("ServiceAccount making the read request"));
        props.put("show_keys_only",  boolProp("If true (default), only list key names, never values"));
        return schema(props, "namespace", "name", "service_account");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String namespace      = requireString(args, "namespace");
        String name           = requireString(args, "name");
        String serviceAccount = requireString(args, "service_account");

        validateNamespace(namespace);
        validateSecretName(name);
        validateServiceAccount(serviceAccount);

        // RBAC: only 'get' required for read
        rbacValidator.assertPermission(serviceAccount, namespace, "get", "secrets");

        // Cross-namespace isolation check
        rbacValidator.assertNamespaceAccess(serviceAccount, namespace);

        auditLogger.logSecretOperation("SECRET_READ", name, namespace, "runtime", serviceAccount,
            "read_metadata_only");

        // Simulate metadata response — actual values would come from K8s API
        Map<String, Object> mockMeta = simulateSecretMetadata(name, namespace);

        return """
            📋 SECRET METADATA — %s/%s

            Name:              %s
            Namespace:         %s
            Type:              %s
            Data keys:         %s
            Labels:            %s
            Creation time:     %s
            Resource version:  %s

            ── Security note ─────────────────────────────
            ⚠  Secret VALUES are not returned by this tool.
               To use credentials: reference them via secretKeyRef
               in your pod spec — never read raw values programmatically.

            ── Kubectl equivalent ─────────────────────────
            kubectl get secret %s -n %s -o jsonpath='{.data}' | base64 --decode
            # (Values redacted in all MCP responses per Ecoskiller security baseline)

            ── Audit ──────────────────────────────────────
            ✔ Read event logged: %s → %s/%s
            ✔ Cross-namespace isolation verified
            ✔ RBAC 'get' permission confirmed
            """.formatted(
                namespace, name,
                name, namespace,
                mockMeta.get("type"),
                mockMeta.get("keys"),
                mockMeta.get("labels"),
                mockMeta.get("creationTimestamp"),
                mockMeta.get("resourceVersion"),
                name, namespace,
                serviceAccount, namespace, name
            );
    }

    /** Simulates K8s API metadata response (replace with real K8s client call). */
    private Map<String, Object> simulateSecretMetadata(String name, String namespace) {
        // In production: replace with Kubernetes Java client call
        // e.g., CoreV1Api.readNamespacedSecret(name, namespace, ...)
        return Map.of(
            "type",              inferType(name),
            "keys",              inferKeys(name),
            "labels",            Map.of("app", namespace + "-service", "managed-by", "ecoskiller-ci"),
            "creationTimestamp", "2025-01-01T00:00:00Z",
            "resourceVersion",   "100" + (int)(Math.random() * 9999)
        );
    }

    private String inferType(String name) {
        if (name.endsWith("-tls"))        return "kubernetes.io/tls";
        if (name.startsWith("harbor-"))  return "kubernetes.io/dockerconfigjson";
        return "Opaque";
    }

    private String inferKeys(String name) {
        if (name.contains("credential"))   return "[db-password, redis-password, kafka-sasl-password]";
        if (name.contains("tls"))          return "[tls.crt, tls.key]";
        if (name.contains("harbor"))       return "[.dockerconfigjson]";
        if (name.contains("claude"))       return "[api_key, model_version]";
        if (name.contains("sip"))          return "[sip-host, sip-username, sip-password]";
        return "[<keys-not-disclosed>]";
    }
}
