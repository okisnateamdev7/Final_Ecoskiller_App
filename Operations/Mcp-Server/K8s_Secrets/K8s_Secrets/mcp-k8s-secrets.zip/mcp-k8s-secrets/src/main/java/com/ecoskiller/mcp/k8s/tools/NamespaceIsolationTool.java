package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.util.*;

/**
 * Tool: namespace_isolation
 *
 * Validates and audits namespace isolation between Ecoskiller services.
 * Checks that a given ServiceAccount cannot access secrets in other namespaces.
 * Generates NetworkPolicy manifests to block cross-namespace secret API calls.
 *
 * Ecoskiller doc: Section 3.2 Namespace-Scoped Isolation,
 *                 Section 4.2 Namespace-Scoped Secret Path Hierarchy
 */
public class NamespaceIsolationTool extends BaseTool {

    // Ecoskiller cross-namespace access map (authorised only)
    private static final Map<String, List<String>> AUTHORISED_CROSS_NS = Map.of(
        "core",         List.of(),
        "billing",      List.of(),
        "analytics",    List.of(),
        "realtime",     List.of(),
        "media",        List.of(),
        "notification", List.of(),
        "ops",          List.of("core","billing","analytics","realtime","media","phone","notification")
    );

    public NamespaceIsolationTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "namespace_isolation"; }

    @Override
    public String description() {
        return "Validate and audit namespace isolation for Ecoskiller microservices. " +
               "Checks RBAC isolation, generates NetworkPolicy manifests to prevent " +
               "cross-namespace secret access. Verifies the secret path hierarchy " +
               "secret/{env}/{service} is correctly scoped per namespace.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("source_namespace",   enumProp("Source namespace (the one requesting access)",
                                        "core","billing","analytics","realtime",
                                        "media","phone","ops","notification","ingress-nginx"));
        props.put("target_namespace",   enumProp("Target namespace (being accessed)",
                                        "core","billing","analytics","realtime",
                                        "media","phone","ops","notification","ingress-nginx"));
        props.put("service_account",    stringProp("ServiceAccount to check for isolation compliance"));
        props.put("environment",        enumProp("Environment", "dev","test","stage","prod"));
        props.put("generate_policy",    boolProp("If true, generate a NetworkPolicy manifest to enforce isolation"));
        return schema(props, "source_namespace", "target_namespace", "service_account", "environment");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String sourceNs       = requireString(args, "source_namespace");
        String targetNs       = requireString(args, "target_namespace");
        String serviceAccount = requireString(args, "service_account");
        String environment    = requireString(args, "environment");
        boolean generatePolicy = Boolean.parseBoolean(optString(args, "generate_policy", "false"));

        validateNamespace(sourceNs);
        validateNamespace(targetNs);
        validateEnvironment(environment);

        boolean isAuthorised = AUTHORISED_CROSS_NS.getOrDefault(sourceNs, List.of()).contains(targetNs);
        boolean isSameNs     = sourceNs.equals(targetNs);

        auditLogger.logSecretOperation("NAMESPACE_ISOLATION_CHECK", "*",
            sourceNs + "→" + targetNs, environment, serviceAccount,
            "authorised=" + (isAuthorised || isSameNs));

        String isolationResult;
        if (isSameNs) {
            isolationResult = "✅ SAME NAMESPACE — access within namespace is permitted by default RBAC.";
        } else if (isAuthorised) {
            isolationResult = "⚠️  CROSS-NAMESPACE ACCESS — authorised for ops namespace only per Ecoskiller spec.";
        } else {
            isolationResult = "🚫 ISOLATION VIOLATION — cross-namespace access NOT authorised.\n" +
                "A Secret in '" + targetNs + "' is inaccessible to pods in '" + sourceNs + "'.";
        }

        String networkPolicy = generatePolicy
            ? "\n── Generated NetworkPolicy ─────────────────\n" + networkPolicyYaml(sourceNs)
            : "";

        return """
            🔒 NAMESPACE ISOLATION REPORT

            Source namespace: %s
            Target namespace: %s
            ServiceAccount:   %s
            Environment:      %s

            ── Isolation verdict ─────────────────────────
            %s

            ── Ecoskiller isolation rules ────────────────
            • Dev credentials cannot access prod namespaces
            • Billing secrets inaccessible to media/phone namespaces
            • Keycloak secrets restricted to core namespace only
            • GCP/AWS credentials restricted to ops namespace only
            • SIP trunk credentials restricted to media namespace only
            • LLM API keys restricted to analytics namespace only

            ── Secret path validation ────────────────────
            Expected pattern: secret/%s/<service-name>
            ✔ Dev namespace cannot read from secret/prod/*
            ✔ Prod credentials physically isolated from non-prod namespaces
            %s
            ── Audit ──────────────────────────────────────
            ✔ Isolation check logged to Wazuh SIEM
            ✔ Result: %s
            """.formatted(
                sourceNs, targetNs, serviceAccount, environment,
                isolationResult,
                environment,
                networkPolicy,
                isSameNs || isAuthorised ? "COMPLIANT" : "POTENTIAL VIOLATION"
            );
    }

    private String networkPolicyYaml(String namespace) {
        return """
            apiVersion: networking.k8s.io/v1
            kind: NetworkPolicy
            metadata:
              name: deny-cross-namespace-secret-access
              namespace: %s
            spec:
              podSelector: {}
              policyTypes:
              - Ingress
              - Egress
              egress:
              - to:
                - namespaceSelector:
                    matchLabels:
                      kubernetes.io/metadata.name: %s
              - to:
                - namespaceSelector:
                    matchLabels:
                      kubernetes.io/metadata.name: kube-system
                ports:
                - protocol: TCP
                  port: 443  # kube-apiserver
            """.formatted(namespace, namespace);
    }
}
