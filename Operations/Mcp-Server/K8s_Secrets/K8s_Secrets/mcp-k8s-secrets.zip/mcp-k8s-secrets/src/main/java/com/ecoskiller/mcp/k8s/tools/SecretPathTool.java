package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;
import com.ecoskiller.mcp.k8s.util.SecretPathValidator;
import com.ecoskiller.mcp.k8s.util.SecretPathValidator.ValidationResult;

import java.util.*;

/**
 * Tool: secret_path_validate
 *
 * Validates and enforces the Ecoskiller secret path naming convention:
 *   secret/{env}/{service-category}
 *
 * Per Ecoskiller K8s Secrets documentation Section 4.2:
 *   "Namespace-Scoped Secret Path Hierarchy"
 *
 * Also checks:
 *  - Whether a given namespace is authorised to access a secret path
 *  - Expected keys for a given path (pre-flight creation validation)
 *  - Path traversal attack detection
 *  - Full path registry listing for audit purposes
 */
public class SecretPathTool extends BaseTool {

    public SecretPathTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "secret_path_validate"; }

    @Override
    public String description() {
        return "Validate Ecoskiller secret path naming convention (secret/{env}/{service}). " +
               "Checks path format, environment scope, namespace authorisation, " +
               "expected key names, and detects path traversal attacks. " +
               "Lists the full authorised path registry for audit purposes.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("action",     enumProp("Validation action",
                                "validate_path","check_namespace_access",
                                "get_expected_keys","list_all_paths","canonicalise"));
        props.put("path",       stringProp("Secret path to validate (e.g. secret/prod/db/postgres)"));
        props.put("namespace",  enumProp("Namespace requesting access (for check_namespace_access)",
                                "core","billing","analytics","realtime",
                                "media","phone","ops","notification","ingress-nginx"));
        props.put("environment",enumProp("Deployment environment",
                                "dev","test","stage","prod"));
        props.put("operator",   stringProp("Operator identity (logged)"));
        return schema(props, "action", "operator");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String action      = requireString(args, "action");
        String operator    = requireString(args, "operator");
        String path        = optString(args, "path", "");
        String namespace   = optString(args, "namespace", "core");
        String environment = optString(args, "environment", "prod");

        auditLogger.logSecretOperation("SECRET_PATH_" + action.toUpperCase(),
            path, namespace, environment, operator, "action=" + action);

        return switch (action) {
            case "validate_path"          -> validatePath(path, environment);
            case "check_namespace_access" -> checkNamespaceAccess(path, namespace, environment);
            case "get_expected_keys"      -> getExpectedKeys(path, environment);
            case "list_all_paths"         -> listAllPaths();
            case "canonicalise"           -> canonicalisePath(path);
            default -> "Unknown action: " + action;
        };
    }

    // ─────────────────────────────────────────────────────────────────────────

    private String validatePath(String path, String env) {
        if (path.isBlank()) return "⚠  No path provided — provide 'path' argument.";

        ValidationResult result = SecretPathValidator.validate(path);

        if (result.valid()) {
            String specInfo = result.spec() != null
                ? "\nAllowed envs:       " + result.spec().environments() +
                  "\nAllowed namespaces: " + result.spec().authorisedNamespaces() +
                  "\nExpected keys:      " + result.spec().expectedKeys()
                : "\n(Custom/Opaque secret — no path spec constraints)";

            return """
                ✅ VALID SECRET PATH

                Path:        %s
                Environment: %s
                Service:     %s
                %s

                ── Ecoskiller convention ─────────────────────
                ✔ Format: secret/{env}/{service-category}
                ✔ Environment segment: %s
                ✔ Path traversal check: CLEAN
                ✔ Naming convention: COMPLIANT
                """.formatted(path, result.environment(), result.servicePath(), specInfo, result.environment());
        } else {
            return """
                ❌ INVALID SECRET PATH

                Path:   %s
                Reason: %s

                ── Valid path examples ────────────────────────
                secret/prod/db/postgres       ← PostgreSQL credentials
                secret/dev/kafka              ← Kafka SASL (all envs)
                secret/prod/llm/claude        ← Anthropic API key (prod only)
                secret/stage/keycloak         ← Keycloak realm secrets
                secret/prod/sip-trunk         ← SIP gateway credentials
                secret/prod/gcp-aws           ← Cloud provider credentials

                ── Convention rule ────────────────────────────
                secret/{env}/{service-category}
                  env ∈ {dev, test, stage, prod}
                  service-category: lowercase, alphanumeric, hyphens, forward-slashes
                """.formatted(path, result.message());
        }
    }

    private String checkNamespaceAccess(String path, String namespace, String env) {
        if (path.isBlank()) return "⚠  Provide a 'path' to check namespace access for.";

        boolean authorised = SecretPathValidator.isNamespaceAuthorised(namespace, path, env);

        String verdict = authorised
            ? "✅ AUTHORISED — namespace '" + namespace + "' may access secret path '" + path + "'"
            : "🚫 DENIED — namespace '" + namespace + "' is NOT authorised to access '" + path + "'";

        return """
            %s

            Path:      %s
            Namespace: %s
            Env:       %s

            ── Why this matters ──────────────────────────
            Ecoskiller enforces strict namespace isolation:
            • Billing secrets inaccessible to media/analytics namespaces
            • Keycloak secrets restricted to core namespace only
            • GCP/AWS credentials restricted to ops namespace only
            • LLM API keys restricted to analytics namespace only

            ── RBAC enforcement ──────────────────────────
            If this check shows DENIED, the Kubernetes RBAC Role for
            the requesting ServiceAccount does NOT include this secret
            in its resourceNames list.

            Fix: run rbac_provision tool to grant access correctly.
            """.formatted(verdict, path, namespace, env);
    }

    private String getExpectedKeys(String path, String env) {
        if (path.isBlank()) return "⚠  Provide a 'path' to get expected keys for.";

        List<String> keys = SecretPathValidator.expectedKeys(path, env);

        if (keys.isEmpty()) {
            return """
                ℹ  No key specification found for path: %s

                This may be a custom/Opaque secret without a registered spec.
                Ensure your secret includes all keys required by the consuming service.
                """.formatted(path);
        }

        StringBuilder keyList = new StringBuilder();
        for (String k : keys) {
            keyList.append("  --from-literal=").append(k).append("='<VALUE>' \\\n");
        }

        return """
            📋 EXPECTED KEYS — %s

            Required keys:
            %s

            ── Kubectl creation command ──────────────────
            kubectl create secret generic %s \\
            %s  -n <namespace>

            ── Validation tip ────────────────────────────
            Before creating, verify all %d keys are present.
            Missing keys cause CrashLoopBackOff in consuming services.
            """.formatted(
                path,
                String.join(", ", keys),
                path.substring(path.lastIndexOf('/') + 1),
                keyList.toString(),
                keys.size()
            );
    }

    private String listAllPaths() {
        return """
            📋 ECOSKILLER AUTHORISED SECRET PATH REGISTRY

            %s
            ── Convention ────────────────────────────────
            Pattern:  secret/{env}/{service-category}
            Envs:     dev | test | stage | prod
            Prod-only paths: gcp-aws, sip-trunk, freeswitch, llm/*, sms/*

            ── Security rules ────────────────────────────
            • Dev namespace cannot access secret/prod/* paths
            • Prod credentials isolated from non-prod namespaces (physical isolation)
            • Namespace access is enforced by Kubernetes RBAC resourceNames
            • All path accesses are audit-logged to Wazuh SIEM
            """.formatted(SecretPathValidator.summaryTable());
    }

    private String canonicalisePath(String path) {
        if (path.isBlank()) return "⚠  Provide a 'path' to canonicalise.";

        String canonical = SecretPathValidator.canonicalise(path);
        boolean changed  = !canonical.equals(path);

        return """
            🔧 CANONICALISED SECRET NAME

            Input:     %s
            Output:    %s
            Changed:   %s

            ── Canonicalisation rules ────────────────────
            • Lowercase
            • Underscores → hyphens
            • Leading/trailing whitespace removed
            • Non-alphanumeric/hyphen/slash/dot characters removed
            """.formatted(path, canonical, changed ? "YES — use canonical form" : "NO — already canonical");
    }
}
