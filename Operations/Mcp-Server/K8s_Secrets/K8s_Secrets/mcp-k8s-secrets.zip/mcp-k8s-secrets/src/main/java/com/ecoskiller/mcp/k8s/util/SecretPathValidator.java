package com.ecoskiller.mcp.k8s.util;

import java.util.*;
import java.util.regex.*;

/**
 * SecretPathValidator — Enforces the Ecoskiller secret path convention.
 *
 * Per the Ecoskiller Kubernetes Secrets documentation (Section 4.2):
 *   secret/{env}/{service-category}
 *
 * Examples:
 *   secret/prod/db/postgres       → valid
 *   secret/dev/kafka              → valid
 *   secret/prod/llm/claude        → valid
 *   secret/prod/sip-trunk         → valid
 *   plain-secret-name             → valid (legacy/Opaque, no path prefix)
 *   secret/unknown-env/db         → INVALID (unknown environment)
 *   secret/prod/../../etc/passwd  → INVALID (path traversal attempt)
 *
 * Also provides:
 *  - Namespace-to-authorised-secrets mapping (who can read what)
 *  - Secret name canonicalisation
 *  - Path traversal attack detection
 */
public final class SecretPathValidator {

    private SecretPathValidator() {}

    // ── Ecoskiller secret path registry (from doc Section 4.2) ──────────────

    /** All authorised secret path patterns per the documentation. */
    public static final Map<String, SecretPathSpec> AUTHORISED_PATHS;

    static {
        Map<String, SecretPathSpec> paths = new LinkedHashMap<>();

        // Database credentials
        paths.put("secret/{env}/db/postgres",  new SecretPathSpec(
            Set.of("dev","test","stage","prod"),
            Set.of("core","billing","analytics","realtime"),
            List.of("db-host","db-port","db-user","db-password")));

        paths.put("secret/{env}/db/redis",     new SecretPathSpec(
            Set.of("dev","test","stage","prod"),
            Set.of("core","realtime","billing"),
            List.of("redis-password","redis-tls-cert")));

        // Message broker
        paths.put("secret/{env}/kafka",        new SecretPathSpec(
            Set.of("dev","test","stage","prod"),
            Set.of("core","billing","analytics","realtime","media","phone","notification","ops"),
            List.of("kafka-sasl-username","kafka-sasl-password")));

        // Identity
        paths.put("secret/{env}/keycloak",     new SecretPathSpec(
            Set.of("dev","test","stage","prod"),
            Set.of("core"),  // core namespace only per doc
            List.of("client-secret","realm-admin-password")));

        // Object storage
        paths.put("secret/{env}/minio",        new SecretPathSpec(
            Set.of("dev","test","stage","prod"),
            Set.of("billing","ops"),
            List.of("access-key","secret-key")));

        // Video conferencing
        paths.put("secret/{env}/jitsi",        new SecretPathSpec(
            Set.of("stage","prod"),  // stage/prod only per doc
            Set.of("realtime","media"),
            List.of("xmpp-password","jwt-secret")));

        // Cloud providers — prod only
        paths.put("secret/prod/gcp-aws",       new SecretPathSpec(
            Set.of("prod"),
            Set.of("ops"),  // ops namespace only
            List.of("gcp-service-account-json","aws-iam-key","aws-iam-secret")));

        // Telephony — prod only
        paths.put("secret/prod/sip-trunk",     new SecretPathSpec(
            Set.of("prod"),
            Set.of("media"),
            List.of("sip-host","sip-username","sip-password")));

        paths.put("secret/prod/freeswitch",    new SecretPathSpec(
            Set.of("prod"),
            Set.of("phone"),
            List.of("esl-password","jitsi-app-secret")));

        // SMS gateways — prod only
        paths.put("secret/prod/sms/exotel",    new SecretPathSpec(
            Set.of("prod"),
            Set.of("notification"),
            List.of("api-key","caller-id")));

        paths.put("secret/prod/sms/twilio",    new SecretPathSpec(
            Set.of("prod"),
            Set.of("notification"),
            List.of("account-sid","auth-token")));

        // LLM API keys — prod only, analytics namespace only
        paths.put("secret/prod/llm/claude",    new SecretPathSpec(
            Set.of("prod"),
            Set.of("analytics"),
            List.of("api-key","model-version")));

        paths.put("secret/prod/llm/ollama",    new SecretPathSpec(
            Set.of("prod"),
            Set.of("analytics"),
            List.of("endpoint-url")));

        AUTHORISED_PATHS = Collections.unmodifiableMap(paths);
    }

    // ── Path pattern ─────────────────────────────────────────────────────────

    private static final Pattern PATH_PATTERN =
        Pattern.compile("^secret/(dev|test|stage|prod)/([a-z0-9][a-z0-9/\\-]*)$");

    private static final Pattern TRAVERSAL_PATTERN =
        Pattern.compile("(\\.\\.|~|%2e%2e|%252e)", Pattern.CASE_INSENSITIVE);

    // ── Validation API ────────────────────────────────────────────────────────

    /**
     * Validate a secret path against the Ecoskiller naming convention.
     *
     * @param path     The path to validate (e.g. "secret/prod/db/postgres")
     * @return         ValidationResult with status and details
     */
    public static ValidationResult validate(String path) {
        if (path == null || path.isBlank()) {
            return ValidationResult.fail("Secret path cannot be blank");
        }

        // Security: path traversal detection
        if (TRAVERSAL_PATTERN.matcher(path).find()) {
            return ValidationResult.fail(
                "SECURITY: Path traversal attempt detected in: " + path);
        }

        // If it doesn't start with "secret/", it's a plain K8s secret name — allow
        if (!path.startsWith("secret/")) {
            return validatePlainName(path);
        }

        // Validate Ecoskiller path format
        Matcher m = PATH_PATTERN.matcher(path);
        if (!m.matches()) {
            return ValidationResult.fail(
                "Invalid secret path format. Expected: secret/{env}/{service} " +
                "where env ∈ {dev,test,stage,prod} and service is lowercase alphanumeric/hyphens. " +
                "Got: " + path);
        }

        String env     = m.group(1);
        String service = m.group(2);

        // Env-specific restriction: prod-only paths
        if (path.contains("/prod/") && !"prod".equals(env)) {
            return ValidationResult.fail(
                "Path contains 'prod' service category but environment is '" + env + "'. " +
                "Prod-only secrets (gcp-aws, sip-trunk, freeswitch, llm/*, sms/*) " +
                "must use secret/prod/... path.");
        }

        return ValidationResult.ok(env, service, lookupSpec(path));
    }

    /**
     * Check whether a namespace is authorised to access a given secret path.
     *
     * @param namespace  Kubernetes namespace making the request
     * @param path       Secret path being accessed
     * @param env        Target environment
     * @return           true if access is permitted
     */
    public static boolean isNamespaceAuthorised(String namespace, String path, String env) {
        // Try exact match first (for prod-only static keys like "secret/prod/llm/claude")
        SecretPathSpec spec = AUTHORISED_PATHS.get(path);
        if (spec == null) {
            // Then try template-based match ({env} substitution)
            String templateKey = toTemplateKey(path, env);
            spec = AUTHORISED_PATHS.get(templateKey);
        }
        if (spec == null) return true; // Unknown path — allow (K8s RBAC will enforce)
        return spec.authorisedNamespaces().contains(namespace);
    }

    /**
     * Get the expected keys for a given secret path.
     * Useful for validating that a secret being created has all required keys.
     *
     * @param path  Secret path
     * @param env   Environment
     * @return      List of expected key names, or empty list if path is unknown
     */
    public static List<String> expectedKeys(String path, String env) {
        // Try exact match first
        SecretPathSpec spec = AUTHORISED_PATHS.get(path);
        if (spec == null) {
            String templateKey = toTemplateKey(path, env);
            spec = AUTHORISED_PATHS.get(templateKey);
        }
        return spec != null ? spec.expectedKeys() : List.of();
    }

    /**
     * Canonicalise a secret name: lowercase, replace underscores with hyphens,
     * strip leading/trailing whitespace.
     */
    public static String canonicalise(String name) {
        if (name == null) return "";
        return name.trim().toLowerCase().replace("_", "-").replaceAll("[^a-z0-9\\-/.]", "");
    }

    /**
     * Check if two secret paths are in the same environment scope.
     * Used to prevent cross-environment secret access.
     */
    public static boolean isSameEnvironment(String path1, String path2) {
        String env1 = extractEnv(path1);
        String env2 = extractEnv(path2);
        return env1 != null && env1.equals(env2);
    }

    /**
     * Summarise all authorised paths — for documentation / audit output.
     */
    public static String summaryTable() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-38s %-26s %-30s%n", "PATH PATTERN", "ENVIRONMENTS", "AUTHORISED NAMESPACES"));
        sb.append("-".repeat(98)).append("\n");
        for (Map.Entry<String, SecretPathSpec> e : AUTHORISED_PATHS.entrySet()) {
            sb.append(String.format("%-38s %-26s %-30s%n",
                e.getKey(),
                e.getValue().environments(),
                e.getValue().authorisedNamespaces()));
        }
        return sb.toString();
    }

    // ── Internal helpers ──────────────────────────────────────────────────────

    private static ValidationResult validatePlainName(String name) {
        if (!name.matches("[a-z0-9]([a-z0-9\\-]*[a-z0-9])?") || name.length() > 253) {
            return ValidationResult.fail(
                "Plain secret name '" + name + "' is invalid. " +
                "Must be lowercase alphanumeric/hyphens, max 253 chars.");
        }
        return ValidationResult.ok("any", name, null);
    }

    private static String toTemplateKey(String path, String env) {
        if (path == null) return "";
        // First try exact match (for prod-only paths like "secret/prod/gcp-aws")
        if (AUTHORISED_PATHS.containsKey(path)) return path;
        // Replace env segment with {env} placeholder to match template keys
        return path.replace("/dev/", "/{env}/")
                   .replace("/test/", "/{env}/")
                   .replace("/stage/", "/{env}/")
                   .replace("/prod/", "/{env}/");
    }

    private static String extractEnv(String path) {
        if (path == null || !path.startsWith("secret/")) return null;
        String[] parts = path.split("/");
        return parts.length > 1 ? parts[1] : null;
    }

    private static SecretPathSpec lookupSpec(String path) {
        for (Map.Entry<String, SecretPathSpec> e : AUTHORISED_PATHS.entrySet()) {
            String template = e.getKey();
            // Convert template to regex: {env} → (dev|test|stage|prod)
            String regex = template
                .replace("/", "\\/")
                .replace("{env}", "(dev|test|stage|prod)");
            if (path.matches(regex)) return e.getValue();
        }
        return null;
    }

    // ── Result types ──────────────────────────────────────────────────────────

    public record ValidationResult(
        boolean valid,
        String  message,
        String  environment,
        String  servicePath,
        SecretPathSpec spec
    ) {
        static ValidationResult ok(String env, String svc, SecretPathSpec spec) {
            return new ValidationResult(true, "Valid secret path", env, svc, spec);
        }
        static ValidationResult fail(String message) {
            return new ValidationResult(false, message, null, null, null);
        }
    }

    public record SecretPathSpec(
        Set<String>  environments,
        Set<String>  authorisedNamespaces,
        List<String> expectedKeys
    ) {}
}
