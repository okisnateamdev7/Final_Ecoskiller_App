package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;
import com.ecoskiller.mcp.k8s.util.SecretPathValidator;

import java.util.*;

/**
 * Tool: secret_env_diff
 *
 * Compares secret state across Ecoskiller deployment environments.
 * Detects parity drift: secrets present in prod but missing in dev/test/stage,
 * key mismatches, type mismatches, and naming convention violations.
 *
 * Per Ecoskiller documentation:
 *   §4.6 Environment Parity with Isolation:
 *   "The secret/{env}/ path pattern means dev, test, staging, and prod all have
 *    structurally identical secret sets but with environment-specific values."
 *
 *   §9.5 Multi-Environment Secret Parity:
 *   "Ensures staging behaviour is genuinely representative of production security posture."
 */
public class SecretEnvDiffTool extends BaseTool {

    // Ecoskiller canonical secret set per namespace (from documentation Appendix)
    // Maps namespace → list of expected secret names (same across all envs)
    private static final Map<String, List<String>> EXPECTED_SECRETS = Map.of(
        "billing",      List.of("billing-credentials", "harbor-pull"),
        "core",         List.of("core-credentials", "harbor-pull"),
        "analytics",    List.of("analytics-credentials", "llm-claude", "llm-ollama", "harbor-pull"),
        "realtime",     List.of("realtime-credentials", "harbor-pull"),
        "notification", List.of("notification-creds", "harbor-pull"),
        "media",        List.of("freeswitch-secrets", "sip-trunk-creds", "harbor-pull"),
        "ops",          List.of("gcp-aws-service-acct", "harbor-pull"),
        "ingress-nginx",List.of("ecoskiller-tls")
    );

    // Expected keys per secret (from documentation Appendix + Section 4.2)
    private static final Map<String, List<String>> EXPECTED_KEYS = Map.ofEntries(
        Map.entry("billing-credentials",   List.of("db-password","redis-password","minio-access-key","minio-secret-key")),
        Map.entry("core-credentials",      List.of("db-password","keycloak-client-secret","kafka-sasl-password")),
        Map.entry("analytics-credentials", List.of("db-password","llm-api-key")),
        Map.entry("realtime-credentials",  List.of("redis-password","kafka-sasl-password","jitsi-jwt-secret")),
        Map.entry("notification-creds",    List.of("exotel-api-key","twilio-account-sid","twilio-auth-token")),
        Map.entry("freeswitch-secrets",    List.of("esl-password","jitsi-app-secret","xmpp-password")),
        Map.entry("sip-trunk-creds",       List.of("sip-host","sip-username","sip-password")),
        Map.entry("harbor-pull",           List.of(".dockerconfigjson")),
        Map.entry("ecoskiller-tls",        List.of("tls.crt","tls.key")),
        Map.entry("gcp-aws-service-acct",  List.of("gcp-service-account-json","aws-iam-access-key","aws-iam-secret-key")),
        Map.entry("llm-claude",            List.of("api-key","model-version")),
        Map.entry("llm-ollama",            List.of("endpoint-url"))
    );

    public SecretEnvDiffTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "secret_env_diff"; }

    @Override
    public String description() {
        return "Compare Kubernetes Secret state across Ecoskiller deployment environments. " +
               "Detects parity drift: secrets missing from an environment, key mismatches, " +
               "naming convention violations, and type inconsistencies. " +
               "Ensures staging is structurally identical to production per §4.6 and §9.5.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("action",          enumProp("Diff action",
                                     "full_diff","namespace_diff","key_diff",
                                     "missing_secrets","parity_report","convention_check"));
        props.put("source_env",      enumProp("Source environment (baseline — usually prod)",
                                     "prod","stage","test","dev"));
        props.put("target_env",      enumProp("Target environment to compare against source",
                                     "dev","test","stage","prod"));
        props.put("namespace",       enumProp("Namespace to diff (or all)",
                                     "core","billing","analytics","realtime",
                                     "media","phone","ops","notification","ingress-nginx"));
        props.put("service_account", stringProp("ServiceAccount performing the comparison (ops-service recommended)"));
        props.put("operator",        stringProp("Operator running the diff"));
        return schema(props, "action", "source_env", "target_env", "operator");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String action        = requireString(args, "action");
        String sourceEnv     = requireString(args, "source_env");
        String targetEnv     = requireString(args, "target_env");
        String namespace     = optString(args, "namespace", "all");
        String serviceAccount = optString(args, "service_account", "ops-service");
        String operator      = requireString(args, "operator");

        validateEnvironment(sourceEnv);
        validateEnvironment(targetEnv);

        if (!namespace.equals("all")) validateNamespace(namespace);

        // Ops-level permission required for cross-env diff
        rbacValidator.assertPermission(serviceAccount, "ops", "list", "secrets");

        auditLogger.logSecretOperation("ENV_DIFF_" + action.toUpperCase(),
            "*", namespace, sourceEnv + "→" + targetEnv, operator,
            "source=" + sourceEnv + ", target=" + targetEnv);

        return switch (action) {
            case "full_diff"        -> fullDiff(sourceEnv, targetEnv);
            case "namespace_diff"   -> namespaceDiff(namespace, sourceEnv, targetEnv);
            case "key_diff"         -> keyDiff(namespace, sourceEnv, targetEnv);
            case "missing_secrets"  -> missingSecrets(sourceEnv, targetEnv);
            case "parity_report"    -> parityReport(sourceEnv, targetEnv);
            case "convention_check" -> conventionCheck(targetEnv);
            default -> "Unknown action: " + action;
        };
    }

    // ─── Actions ─────────────────────────────────────────────────────────────

    private String fullDiff(String src, String tgt) {
        StringBuilder sb = new StringBuilder();
        sb.append("🔍 FULL ENVIRONMENT DIFF\n");
        sb.append(String.format("   Source: %-6s  Target: %s%n%n", src.toUpperCase(), tgt.toUpperCase()));

        boolean anyDrift = false;

        for (Map.Entry<String, List<String>> nsEntry : EXPECTED_SECRETS.entrySet()) {
            String ns = nsEntry.getKey();
            String nsDiff = namespaceDiff(ns, src, tgt);

            // Only include namespaces with actual drift
            if (nsDiff.contains("MISSING") || nsDiff.contains("KEY MISMATCH") ||
                nsDiff.contains("DRIFT")) {
                sb.append("── ").append(ns).append(" ─────────────────────────────────\n");
                sb.append(nsDiff).append("\n");
                anyDrift = true;
            }
        }

        if (!anyDrift) {
            sb.append("✅ ENVIRONMENTS ARE IN PARITY\n");
            sb.append("   All namespaces have identical secret structure.\n");
            sb.append("   (Note: values differ by design — only structure is compared)\n");
        }

        sb.append("\n── Summary ───────────────────────────────────\n");
        sb.append(parityReport(src, tgt));

        return sb.toString();
    }

    private String namespaceDiff(String namespace, String src, String tgt) {
        if (namespace.equals("all")) return fullDiff(src, tgt);

        List<String> expected = EXPECTED_SECRETS.getOrDefault(namespace, List.of());

        // Simulate secrets present in each env (in prod: use K8s API to list)
        Set<String> srcSecrets = simulateEnvSecrets(namespace, src, expected);
        Set<String> tgtSecrets = simulateEnvSecrets(namespace, tgt, expected);

        List<String> missingInTarget = new ArrayList<>(srcSecrets);
        missingInTarget.removeAll(tgtSecrets);

        List<String> extraInTarget = new ArrayList<>(tgtSecrets);
        extraInTarget.removeAll(srcSecrets);

        if (missingInTarget.isEmpty() && extraInTarget.isEmpty()) {
            return String.format("  ✅ %s: parity OK (%d secrets match)", namespace, expected.size());
        }

        StringBuilder result = new StringBuilder();
        result.append(String.format("  ⚠️  DRIFT DETECTED in namespace: %s%n", namespace));

        if (!missingInTarget.isEmpty()) {
            result.append(String.format("  Missing in %s:%n", tgt.toUpperCase()));
            missingInTarget.forEach(s -> result.append("    🔴 ").append(s).append("\n"));
            result.append(String.format("  Fix: create these secrets in %s namespace%n", tgt));
            result.append("       Run: secret_create tool for each missing secret\n");
        }

        if (!extraInTarget.isEmpty()) {
            result.append(String.format("  Extra in %s (not in %s):%n", tgt.toUpperCase(), src.toUpperCase()));
            extraInTarget.forEach(s -> result.append("    ℹ️  ").append(s).append("\n"));
        }

        return result.toString();
    }

    private String keyDiff(String namespace, String src, String tgt) {
        if (namespace.equals("all")) {
            StringBuilder sb = new StringBuilder();
            sb.append("🔑 KEY DIFF — All Namespaces\n");
            sb.append(String.format("   %s → %s%n%n", src.toUpperCase(), tgt.toUpperCase()));
            EXPECTED_SECRETS.keySet().forEach(ns -> {
                String result = keyDiffForNamespace(ns, src, tgt);
                if (!result.contains("✅")) {
                    sb.append("── ").append(ns).append(" ──\n");
                    sb.append(result).append("\n");
                }
            });
            return sb.toString();
        }
        return "🔑 KEY DIFF — " + namespace + "\n" + keyDiffForNamespace(namespace, src, tgt);
    }

    private String keyDiffForNamespace(String ns, String src, String tgt) {
        List<String> secrets = EXPECTED_SECRETS.getOrDefault(ns, List.of());
        StringBuilder sb = new StringBuilder();
        boolean anyMismatch = false;

        for (String secret : secrets) {
            List<String> expectedKeys = EXPECTED_KEYS.getOrDefault(secret, List.of());
            // In prod: fetch actual keys from K8s API for both envs and compare
            // Simulation: target env may randomly be missing a key (for demo purposes)
            Set<String> srcKeys = new HashSet<>(expectedKeys);
            Set<String> tgtKeys = simulateMissingKey(secret, tgt, expectedKeys);

            List<String> missingKeys = new ArrayList<>(srcKeys);
            missingKeys.removeAll(tgtKeys);

            if (!missingKeys.isEmpty()) {
                sb.append(String.format("  ⚠️  %s: key mismatch%n", secret));
                sb.append(String.format("     Missing in %s: %s%n", tgt.toUpperCase(), missingKeys));
                sb.append(String.format("     Fix: kubectl create secret generic %s --from-literal=%s='<VALUE>' --dry-run=client -o yaml | kubectl apply -f - -n %s%n",
                    secret, missingKeys.get(0), ns));
                anyMismatch = true;
            }
        }

        return anyMismatch ? sb.toString() : "  ✅ All keys match across " + src + " → " + tgt;
    }

    private String missingSecrets(String src, String tgt) {
        StringBuilder sb = new StringBuilder();
        sb.append("📋 MISSING SECRETS REPORT\n");
        sb.append(String.format("   Baseline: %s  →  Target: %s%n%n", src.toUpperCase(), tgt.toUpperCase()));

        boolean anyMissing = false;

        for (Map.Entry<String, List<String>> nsEntry : EXPECTED_SECRETS.entrySet()) {
            String ns           = nsEntry.getKey();
            List<String> expected = nsEntry.getValue();
            Set<String> tgtPresent = simulateEnvSecrets(ns, tgt, expected);

            List<String> missing = new ArrayList<>(expected);
            missing.removeAll(tgtPresent);

            if (!missing.isEmpty()) {
                sb.append(String.format("  Namespace: %s%n", ns));
                missing.forEach(s -> {
                    List<String> keys = EXPECTED_KEYS.getOrDefault(s, List.of());
                    sb.append(String.format("    🔴 %s (expected keys: %s)%n", s, keys));

                    // Generate creation command
                    StringBuilder keyArgs = new StringBuilder();
                    keys.forEach(k -> keyArgs.append("      --from-literal=").append(k).append("='<VALUE>' \\\n"));
                    sb.append(String.format("       kubectl create secret generic %s \\%n%s      -n %s%n%n",
                        s, keyArgs, ns));
                });
                anyMissing = true;
            }
        }

        if (!anyMissing) {
            sb.append("  ✅ No missing secrets — ").append(tgt.toUpperCase())
              .append(" is complete relative to ").append(src.toUpperCase()).append("\n");
        }

        sb.append("\n── After creating missing secrets ──────────\n");
        sb.append("Run RBAC provisioning for each new secret:\n");
        sb.append("  rotation_schedule action=rbac_provision (via rbac_provision tool)\n");

        return sb.toString();
    }

    private String parityReport(String src, String tgt) {
        int total = EXPECTED_SECRETS.values().stream().mapToInt(List::size).sum();
        int matched = 0;
        int drifted = 0;

        for (Map.Entry<String, List<String>> entry : EXPECTED_SECRETS.entrySet()) {
            String ns = entry.getKey();
            List<String> expected = entry.getValue();
            Set<String> tgtPresent = simulateEnvSecrets(ns, tgt, expected);
            long nsMatched = expected.stream().filter(tgtPresent::contains).count();
            matched += (int) nsMatched;
            drifted += (int)(expected.size() - nsMatched);
        }

        double pct = total > 0 ? (matched * 100.0 / total) : 100.0;

        return """
            📊 ENVIRONMENT PARITY REPORT
            Source: %s  →  Target: %s

            Total expected secrets: %d
            Matched:                %d  (%.1f%%)
            Drifted / Missing:      %d

            Parity status: %s

            ── §4.6 Ecoskiller compliance ────────────────
            "Dev, test, staging, and production all have structurally
            identical secret sets but with environment-specific values."

            %s
            ── Remediation priority ──────────────────────
            1. Run: secret_env_diff action=missing_secrets
            2. Run: secret_env_diff action=key_diff
            3. Create missing secrets using: secret_create tool
            4. Verify RBAC using: rbac_provision tool
            5. Re-run parity_report to confirm remediation
            """.formatted(
                src.toUpperCase(), tgt.toUpperCase(),
                total, matched, pct, drifted,
                pct >= 100 ? "✅ FULL PARITY" : pct >= 80 ? "⚠️  PARTIAL DRIFT" : "🔴 SIGNIFICANT DRIFT",
                pct >= 100
                    ? "✅ Fully compliant with §4.6 environment parity requirement."
                    : "⚠️  Drift detected. Remediate before next deployment to " + tgt + "."
            );
    }

    private String conventionCheck(String env) {
        StringBuilder sb = new StringBuilder();
        sb.append("📐 NAMING CONVENTION CHECK — environment: ").append(env.toUpperCase()).append("\n\n");

        boolean anyViolation = false;

        for (Map.Entry<String, List<String>> nsEntry : EXPECTED_SECRETS.entrySet()) {
            String ns = nsEntry.getKey();
            for (String secret : nsEntry.getValue()) {
                // Check against K8s naming rules
                boolean validName = secret.matches("[a-z0-9]([a-z0-9\\-]*[a-z0-9])?")
                                    && secret.length() <= 253;
                // Check path convention for secrets that should use it
                boolean hasPathConvention = SecretPathValidator.validate(
                    "secret/" + env + "/" + secret.replace("-credentials","").replace("-creds","")
                ).valid();

                if (!validName) {
                    sb.append(String.format("  🔴 VIOLATION: %s/%s — invalid K8s name%n", ns, secret));
                    anyViolation = true;
                }
            }
        }

        if (!anyViolation) {
            sb.append("  ✅ All secret names comply with Kubernetes DNS subdomain naming rules\n");
            sb.append("  ✅ All names are lowercase, alphanumeric, hyphen-separated\n");
            sb.append("  ✅ No names exceed 253 characters\n");
        }

        sb.append("\n── Convention rules (Ecoskiller §4.2) ──────\n");
        sb.append("• Secret names: lowercase, alphanumeric, hyphens only\n");
        sb.append("• Path pattern: secret/{env}/{service-category}\n");
        sb.append("• Max length: 253 characters (K8s DNS subdomain limit)\n");
        sb.append("• No underscores — use hyphens instead\n");
        sb.append("• No UPPERCASE — K8s is case-sensitive\n");
        sb.append("\nRun: secret_path_validate action=validate_path for individual path checks.\n");

        return sb.toString();
    }

    // ─── Simulation helpers (replace with real K8s API calls in production) ──

    /** Simulate which secrets exist in a given env/namespace.
     *  In prod: replace with CoreV1Api.listNamespacedSecret(...).getItems() */
    private Set<String> simulateEnvSecrets(String ns, String env, List<String> expected) {
        Set<String> present = new HashSet<>(expected);
        // Simulate: dev/test may be missing some prod-only secrets
        if ("dev".equals(env) || "test".equals(env)) {
            // LLM and cloud credentials often not provisioned in dev
            present.remove("llm-claude");
            present.remove("llm-ollama");
            present.remove("gcp-aws-service-acct");
        }
        return present;
    }

    /** Simulate: target env occasionally missing a key — makes diffs interesting. */
    private Set<String> simulateMissingKey(String secret, String env, List<String> allKeys) {
        Set<String> keys = new HashSet<>(allKeys);
        // In prod: fetch real key names from K8s API
        return keys;
    }
}
