package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.util.*;

/**
 * Tool: registry_secret_manage
 *
 * Manages kubernetes.io/dockerconfigjson secrets for Harbor container registry auth.
 * Every Ecoskiller Deployment requires imagePullSecrets referencing harbor-pull.
 *
 * Ecoskiller doc: Section 3.6 Container Registry Authentication,
 *                 Section 4.1 Docker Registry secret type,
 *                 Section 7.5 Harbor Container Registry dependency
 */
public class RegistrySecretTool extends BaseTool {

    private static final String HARBOR_SERVER = "harbor.ecoskiller.com";

    public RegistrySecretTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "registry_secret_manage"; }

    @Override
    public String description() {
        return "Manage kubernetes.io/dockerconfigjson secrets for Harbor container registry. " +
               "Creates harbor-pull imagePullSecrets for all Ecoskiller namespaces. " +
               "Generates Deployment imagePullSecrets reference snippets. " +
               "All 13+ microservice Deployments require this secret to pull from harbor.ecoskiller.com.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("action",          enumProp("Registry secret operation",
                                     "create","propagate_all_namespaces","verify","generate_deployment_snippet"));
        props.put("namespace",       enumProp("Target namespace",
                                     "core","billing","analytics","realtime",
                                     "media","phone","ops","notification","ingress-nginx"));
        props.put("secret_name",     stringProp("Registry secret name (default: harbor-pull)"));
        props.put("harbor_user",     stringProp("Harbor registry username (from HARBOR_USER env var)"));
        props.put("service_account", stringProp("Operator ServiceAccount performing this action"));
        return schema(props, "action", "namespace", "service_account");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String action        = requireString(args, "action");
        String namespace     = requireString(args, "namespace");
        String serviceAccount = requireString(args, "service_account");
        String secretName    = optString(args, "secret_name", "harbor-pull");
        String harborUser    = optString(args, "harbor_user", "$HARBOR_USER");

        validateNamespace(namespace);
        rbacValidator.assertPermission(serviceAccount, namespace, "create", "secrets");

        auditLogger.logSecretOperation("REGISTRY_SECRET_" + action.toUpperCase(),
            secretName, namespace, "all", serviceAccount, "server=" + HARBOR_SERVER);

        return switch (action) {
            case "create"                    -> createRegistrySecret(secretName, namespace, harborUser);
            case "propagate_all_namespaces"  -> propagateAllNamespaces(secretName, harborUser);
            case "verify"                    -> verifyRegistrySecret(secretName, namespace);
            case "generate_deployment_snippet" -> deploymentSnippet(secretName);
            default -> "Unknown action: " + action;
        };
    }

    private String createRegistrySecret(String name, String ns, String user) {
        return """
            🐳 HARBOR REGISTRY SECRET — %s/%s

            ── Kubectl command ─────────────────────────
            kubectl create secret docker-registry %s \\
              --docker-server=%s \\
              --docker-username=%s \\
              --docker-password=$HARBOR_PASSWORD \\
              -n %s

            ⚠  HARBOR_PASSWORD must be set as a GitLab CI variable — never in plaintext.
            ⚠  This is an initial-setup operation (ops team only).

            ── Security checklist ─────────────────────
            ✔ Type: kubernetes.io/dockerconfigjson
            ✔ Password: $HARBOR_PASSWORD (never in logs or source)
            ✔ Server: %s (ecoskiller/* namespace only)
            ✔ Used as imagePullSecrets in all 13+ Deployment manifests
            """.formatted(name, ns, name, HARBOR_SERVER, user, ns, HARBOR_SERVER);
    }

    private String propagateAllNamespaces(String name, String user) {
        String[] namespaces = {"core","billing","analytics","realtime","media","phone","ops","notification"};
        StringBuilder sb = new StringBuilder();
        sb.append("🔄 HARBOR PULL SECRET — Propagate to All Namespaces\n\n");
        sb.append("Run in GitLab CI deploy stage or ops automation:\n\n");
        for (String ns : namespaces) {
            sb.append("kubectl create secret docker-registry ").append(name).append(" \\\n");
            sb.append("  --docker-server=").append(HARBOR_SERVER).append(" \\\n");
            sb.append("  --docker-username=").append(user).append(" \\\n");
            sb.append("  --docker-password=$HARBOR_PASSWORD \\\n");
            sb.append("  -n ").append(ns).append(" \\\n");
            sb.append("  --dry-run=client -o yaml | kubectl apply -f -\n\n");
        }
        sb.append("✔ harbor-pull secret must exist in ALL namespaces before Deployments can pull images.\n");
        sb.append("✔ Missing harbor-pull → ImagePullBackOff for all pods in that namespace.\n");
        return sb.toString();
    }

    private String verifyRegistrySecret(String name, String ns) {
        return """
            🔍 REGISTRY SECRET VERIFICATION — %s/%s

            kubectl get secret %s -n %s -o jsonpath='{.type}'
            # Expected: kubernetes.io/dockerconfigjson

            kubectl get secret %s -n %s -o jsonpath='{.data.\\.dockerconfigjson}' \\
              | base64 --decode | python3 -m json.tool
            # Shows server, username (password redacted in safe environments)

            # Check imagePullSecrets is set on Deployments
            kubectl get deployments -n %s -o jsonpath='{.items[*].spec.template.spec.imagePullSecrets}'
            """.formatted(name, ns, name, ns, name, ns, ns);
    }

    private String deploymentSnippet(String name) {
        return """
            📄 DEPLOYMENT imagePullSecrets REFERENCE

            Add to every Deployment spec.template.spec:

            spec:
              imagePullSecrets:
              - name: %s
              containers:
              - name: <service-name>
                image: harbor.ecoskiller.com/ecoskiller/<service>:<tag>
                ...

            ✔ Required for ALL 13+ Ecoskiller microservice Deployments
            ✔ Without this, image pull from harbor.ecoskiller.com will fail
            ✔ harbor-pull secret must exist in the same namespace as the Deployment
            """.formatted(name);
    }
}
