package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.util.*;

/**
 * Tool: tls_secret_manage
 *
 * Manages TLS secrets provisioned by cert-manager for Ecoskiller ingress endpoints.
 * Handles kubernetes.io/tls secrets for NGINX Ingress and planned mTLS between services.
 *
 * Ecoskiller doc: Section 3.5 TLS Certificate Lifecycle Management,
 *                 Section 4.1 (TLS secret type), Section 7.3 cert-manager dependency
 */
public class TlsSecretTool extends BaseTool {

    // Ecoskiller known TLS secrets
    private static final Map<String, String> KNOWN_TLS_SECRETS = Map.of(
        "ecoskiller-tls",      "ingress-nginx",
        "core-tls",            "core",
        "billing-tls",         "billing",
        "analytics-tls",       "analytics",
        "realtime-tls",        "realtime"
    );

    public TlsSecretTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "tls_secret_manage"; }

    @Override
    public String description() {
        return "Manage kubernetes.io/tls secrets for Ecoskiller ingress and mTLS. " +
               "Generates cert-manager Certificate manifests, creates manual TLS secrets, " +
               "and verifies TLS secret references in Ingress resources. " +
               "Integrates with Let's Encrypt via cert-manager.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("action",          enumProp("TLS secret operation",
                                     "create_manual","generate_cert_manager","verify","list_tls","renew_check"));
        props.put("secret_name",     stringProp("TLS secret name (e.g. ecoskiller-tls)"));
        props.put("namespace",       enumProp("Target namespace",
                                     "core","billing","analytics","realtime",
                                     "media","phone","ops","notification","ingress-nginx"));
        props.put("domain",          stringProp("Domain name for the certificate (e.g. ecoskiller.com)"));
        props.put("issuer",          enumProp("cert-manager issuer to use",
                                     "letsencrypt-prod","letsencrypt-staging","self-signed"));
        props.put("service_account", stringProp("ServiceAccount performing the TLS operation"));
        return schema(props, "action", "namespace", "service_account");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String action        = requireString(args, "action");
        String namespace     = requireString(args, "namespace");
        String serviceAccount = requireString(args, "service_account");
        String secretName    = optString(args, "secret_name", "ecoskiller-tls");
        String domain        = optString(args, "domain", "ecoskiller.com");
        String issuer        = optString(args, "issuer", "letsencrypt-prod");

        validateNamespace(namespace);
        rbacValidator.assertPermission(serviceAccount, namespace, "create", "secrets");

        auditLogger.logSecretOperation("TLS_SECRET_" + action.toUpperCase(),
            secretName, namespace, "all-envs", serviceAccount, "domain=" + domain);

        return switch (action) {
            case "create_manual"         -> createManualTls(secretName, namespace, domain);
            case "generate_cert_manager" -> generateCertManager(secretName, namespace, domain, issuer);
            case "verify"                -> verifyTlsSecret(secretName, namespace);
            case "list_tls"              -> listTlsSecrets();
            case "renew_check"           -> renewCheck(secretName, namespace);
            default -> "Unknown TLS action: " + action;
        };
    }

    private String createManualTls(String name, String ns, String domain) {
        return """
            🔐 TLS SECRET — Manual Creation

            Secret: %s | Namespace: %s | Domain: %s

            ── Kubectl command ─────────────────────────
            kubectl create secret tls %s \\
              --cert=tls.crt \\
              --key=tls.key \\
              -n %s

            ── Ingress reference ──────────────────────
            spec:
              tls:
              - hosts:
                - %s
                secretName: %s

            ── Security checklist ─────────────────────
            ✔ TLS secret type: kubernetes.io/tls
            ✔ Keys: tls.crt (certificate chain), tls.key (private key)
            ✔ Namespace: %s (NGINX Ingress reads from ingress-nginx namespace)
            ⚠  Prefer cert-manager (letsencrypt-prod) over manual TLS in production
            ✔ Audit logged to Wazuh SIEM
            """.formatted(name, ns, domain, name, ns, domain, name, ns);
    }

    private String generateCertManager(String name, String ns, String domain, String issuer) {
        return """
            🤖 CERT-MANAGER CERTIFICATE — Auto-provisioned TLS

            Secret: %s | Namespace: %s | Domain: %s | Issuer: %s

            ── Certificate manifest ───────────────────
            apiVersion: cert-manager.io/v1
            kind: Certificate
            metadata:
              name: %s-cert
              namespace: %s
            spec:
              secretName: %s
              issuerRef:
                name: %s
                kind: ClusterIssuer
              dnsNames:
              - %s
              - www.%s
              duration: 2160h    # 90 days
              renewBefore: 360h  # Renew 15 days before expiry

            ── ClusterIssuer (if not already created) ─
            apiVersion: cert-manager.io/v1
            kind: ClusterIssuer
            metadata:
              name: %s
            spec:
              acme:
                server: https://acme%s.api.letsencrypt.org/directory
                email: ops@ecoskiller.com
                privateKeySecretRef:
                  name: %s-account-key
                solvers:
                - http01:
                    ingress:
                      class: nginx

            ── Apply commands ─────────────────────────
            kubectl apply -f clusterissuer.yaml
            kubectl apply -f certificate.yaml
            kubectl describe certificate %s-cert -n %s

            ✔ cert-manager will auto-provision and renew the TLS secret
            ✔ Secret '%s' created automatically by cert-manager
            ✔ mTLS between services uses same pattern with client certs
            """.formatted(name, ns, domain, issuer,
                name, ns, name, issuer, domain, domain,
                issuer, issuer.contains("staging") ? "-staging" : "",
                issuer,
                name, ns, name);
    }

    private String verifyTlsSecret(String name, String ns) {
        return """
            🔍 TLS SECRET VERIFICATION — %s/%s

            ── Verification commands ──────────────────
            # Check secret exists and has correct keys
            kubectl get secret %s -n %s -o jsonpath='{.type}'
            # Expected: kubernetes.io/tls

            # Check certificate expiry (decode the cert)
            kubectl get secret %s -n %s -o jsonpath='{.data.tls\\.crt}' \\
              | base64 --decode | openssl x509 -noout -dates

            # Check cert-manager certificate status
            kubectl describe certificate %s-cert -n %s

            # Verify Ingress TLS reference
            kubectl get ingress -n %s -o jsonpath='{.items[*].spec.tls}'

            ── Known Ecoskiller TLS secrets ──────────
            %s
            """.formatted(name, ns, name, ns, name, ns, name, ns, ns,
                KNOWN_TLS_SECRETS.entrySet().stream()
                    .map(e -> "  " + e.getKey() + " → " + e.getValue())
                    .reduce("", (a, b) -> a + b + "\n"));
    }

    private String listTlsSecrets() {
        StringBuilder sb = new StringBuilder();
        sb.append("📋 ECOSKILLER TLS SECRETS\n\n");
        sb.append(String.format("%-30s %-20s%n", "SECRET NAME", "NAMESPACE"));
        sb.append("-".repeat(52)).append("\n");
        KNOWN_TLS_SECRETS.forEach((k, v) ->
            sb.append(String.format("%-30s %-20s%n", k, v)));
        return sb.toString();
    }

    private String renewCheck(String name, String ns) {
        return """
            🔄 TLS RENEWAL CHECK — %s/%s

            ── Check commands ─────────────────────────
            kubectl get certificate %s-cert -n %s
            kubectl describe certificate %s-cert -n %s | grep -A5 "Status:"

            ── cert-manager auto-renewal ──────────────
            ✔ cert-manager renews Let's Encrypt certs 15 days before expiry
            ✔ renewBefore: 360h configured in Certificate spec
            ✔ ACME HTTP-01 challenge via NGINX Ingress

            ── Manual renewal (if needed) ─────────────
            kubectl delete secret %s -n %s
            # cert-manager will re-provision automatically

            ── Alert configuration ────────────────────
            Configure Wazuh alert: TLS cert expiry < 30 days
            kubectl get certificate -A | grep -v True
            """.formatted(name, ns, name, ns, name, ns, name, ns);
    }
}
