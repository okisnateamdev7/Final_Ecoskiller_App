package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.util.*;

/**
 * Tool: secret_rotate
 *
 * Orchestrates credential rotation for a Kubernetes Secret.
 * Generates a full rotation plan: update secret → rolling restart → verify.
 *
 * Security:
 *  - Rotation events recorded in Ecoskiller security incident log
 *  - Wazuh SIEM cross-reference generated
 *  - Prod rotations require elevated RBAC
 *
 * Ecoskiller doc: Section 11.2 Credential Rotation
 */
public class SecretRotateTool extends BaseTool {

    public SecretRotateTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "secret_rotate"; }

    @Override
    public String description() {
        return "Orchestrate Kubernetes Secret credential rotation. " +
               "Generates the full rotation plan: update secret, rolling restart affected deployments, " +
               "verify pod health, update security incident log. " +
               "Required for periodic key rotation and incident response.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("namespace",         enumProp("Target namespace",
                                       "core","billing","analytics","realtime",
                                       "media","phone","ops","notification","ingress-nginx"));
        props.put("name",              stringProp("Secret name to rotate"));
        props.put("rotation_reason",   enumProp("Reason for credential rotation",
                                       "scheduled","key_compromise","employee_offboarding","audit_finding","incident_response"));
        props.put("service_account",   stringProp("ServiceAccount performing the rotation"));
        props.put("environment",       enumProp("Environment", "dev","test","stage","prod"));
        props.put("affected_services", stringProp("Comma-separated list of deployment names to restart after rotation"));
        props.put("mount_type",        enumProp("How the secret is mounted (affects restart requirement)",
                                       "env_var","volume_mount","both"));
        return schema(props, "namespace", "name", "rotation_reason",
                      "service_account", "environment", "affected_services", "mount_type");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String namespace        = requireString(args, "namespace");
        String name             = requireString(args, "name");
        String rotationReason   = requireString(args, "rotation_reason");
        String serviceAccount   = requireString(args, "service_account");
        String environment      = requireString(args, "environment");
        String affectedServices = requireString(args, "affected_services");
        String mountType        = requireString(args, "mount_type");

        validateNamespace(namespace);
        validateEnvironment(environment);
        validateSecretName(name);

        rbacValidator.assertPermission(serviceAccount, namespace, "update", "secrets");
        if ("prod".equals(environment)) {
            rbacValidator.assertElevatedPermission(serviceAccount, namespace, "patch", "secrets");
        }

        String[] services = affectedServices.split(",");
        String wazuhRef = "WAZUH-ROT-" + System.currentTimeMillis();

        auditLogger.logSecretOperation("SECRET_ROTATE", name, namespace, environment, serviceAccount,
            "reason=" + rotationReason + ", wazuh_ref=" + wazuhRef);

        boolean needsRestart = "env_var".equals(mountType) || "both".equals(mountType);

        StringBuilder restartCommands = new StringBuilder();
        StringBuilder verifyCommands  = new StringBuilder();
        for (String svc : services) {
            String s = svc.trim();
            if (needsRestart) {
                restartCommands.append("kubectl rollout restart deployment/").append(s)
                               .append(" -n ").append(namespace).append("\n");
            }
            verifyCommands.append("kubectl rollout status deployment/").append(s)
                          .append(" -n ").append(namespace).append("\n");
        }

        return """
            🔄 CREDENTIAL ROTATION PLAN — %s/%s

            Reason:       %s
            Environment:  %s
            Operator:     %s
            Wazuh Ref:    %s
            Mount type:   %s
            Restart req:  %s

            ── Step 1: Update the secret ─────────────────
            kubectl create secret generic %s \\
              --from-literal=<key>='<NEW_VALUE>' \\
              --dry-run=client -o yaml \\
              -n %s | kubectl apply -f -

            ── Step 2: Verify secret updated ────────────
            kubectl get secret %s -n %s -o jsonpath='{.metadata.resourceVersion}'
            # ResourceVersion should have incremented

            %s
            ── Step 3: Restart affected deployments ─────
            %s
            ── Step 4: Verify pod health ─────────────────
            %s
            ── Step 5: Audit / Compliance ────────────────
            ✔ Record in Ecoskiller security incident log
            ✔ Wazuh SIEM reference: %s
            ✔ Cross-reference with kube-apiserver audit log
            ✔ Update credential rotation schedule for next rotation

            ── Volume-mount note ─────────────────────────
            %s
            """.formatted(
                namespace, name,
                rotationReason, environment, serviceAccount, wazuhRef, mountType,
                needsRestart ? "YES — env-var secrets require pod restart" : "NO — volume mounts auto-propagate in ~60s",
                name, namespace,
                name, namespace,
                needsRestart ? "" : "ℹ  Volume-mounted secrets: auto-propagated within kubelet sync period (~60s).\n",
                restartCommands.toString(),
                verifyCommands.toString(),
                wazuhRef,
                "volume_mount".equals(mountType)
                    ? "ℹ  Volume-mounted secrets propagate automatically.\n   Monitor pods: kubectl get pods -n " + namespace + " -w"
                    : "⚠  Env-var secrets require pod restart to pick up new values.\n   All affected deployments restarted above."
            );
    }
}
