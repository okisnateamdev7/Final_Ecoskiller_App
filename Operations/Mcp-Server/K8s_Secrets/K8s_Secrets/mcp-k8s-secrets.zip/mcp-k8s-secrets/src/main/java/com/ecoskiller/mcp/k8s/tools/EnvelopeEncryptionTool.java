package com.ecoskiller.mcp.k8s.tools;

import com.ecoskiller.mcp.k8s.security.AuditLogger;
import com.ecoskiller.mcp.k8s.security.RbacValidator;

import java.util.*;

/**
 * Tool: envelope_encryption_config
 *
 * Generates kube-apiserver encryption configuration for envelope encryption of
 * Kubernetes Secrets at rest in etcd. Implements AES-CBC encryption as mandated
 * by Ecoskiller Infrastructure v15 specification.
 *
 * Also enforces split-custody rule for etcd encryption keys.
 *
 * Ecoskiller doc: Section 4.5 Envelope Encryption at Rest,
 *                 Section 7.1 etcd dependency,
 *                 Section 11.3 Split-custody requirement
 */
public class EnvelopeEncryptionTool extends BaseTool {

    public EnvelopeEncryptionTool(AuditLogger al, RbacValidator rbac) {
        super(al, rbac);
    }

    @Override public String name() { return "envelope_encryption_config"; }

    @Override
    public String description() {
        return "Generate and validate kube-apiserver encryption configuration for " +
               "AES-CBC envelope encryption of Kubernetes Secrets at rest in etcd. " +
               "Required by Ecoskiller v15 spec — prevents plaintext etcd reads. " +
               "Also generates split-custody documentation for encryption key material.";
    }

    @Override
    public Map<String, Object> inputSchema() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("action",      enumProp("Encryption configuration action",
                                 "generate_config","verify_enabled","generate_key","split_custody_plan","kms_config"));
        props.put("provider",    enumProp("Encryption provider",
                                 "aes_cbc","aes_gcm","kms_v2","identity_only"));
        props.put("environment", enumProp("Environment", "dev","test","stage","prod"));
        props.put("operator",    stringProp("Ops team operator performing this action"));
        return schema(props, "action", "provider", "environment", "operator");
    }

    @Override
    public Object execute(Map<String, Object> args) throws Exception {
        String action      = requireString(args, "action");
        String provider    = requireString(args, "provider");
        String environment = requireString(args, "environment");
        String operator    = requireString(args, "operator");

        validateEnvironment(environment);

        auditLogger.logSecretOperation("ENVELOPE_ENCRYPTION_" + action.toUpperCase(),
            "etcd-encryption-config", "kube-system", environment, operator,
            "provider=" + provider);

        return switch (action) {
            case "generate_config"       -> generateEncryptionConfig(provider, environment);
            case "verify_enabled"        -> verifyEnabled();
            case "generate_key"          -> generateKeyInstructions(provider);
            case "split_custody_plan"    -> splitCustodyPlan();
            case "kms_config"            -> kmsConfig(environment);
            default -> "Unknown action: " + action;
        };
    }

    private String generateEncryptionConfig(String provider, String env) {
        String providerYaml = switch (provider) {
            case "aes_cbc" -> """
                  - aescbc:
                      keys:
                      - name: ecoskiller-%s-key-1
                        secret: <BASE64_ENCODED_32_BYTE_KEY>  # NEVER commit to git
                """.formatted(env);
            case "aes_gcm" -> """
                  - aesgcm:
                      keys:
                      - name: ecoskiller-%s-gcm-key-1
                        secret: <BASE64_ENCODED_32_BYTE_KEY>
                """.formatted(env);
            case "kms_v2" -> """
                  - kms:
                      apiVersion: v2
                      name: ecoskiller-%s-kms
                      endpoint: unix:///var/run/kmsplugin/socket.sock
                      timeout: 3s
                """.formatted(env);
            default -> "  - identity: {}  # ⚠ NO ENCRYPTION — for dev only";
        };

        return """
            🔒 ENVELOPE ENCRYPTION CONFIG — %s | %s

            ── /etc/kubernetes/encryption-config.yaml ──
            apiVersion: apiserver.config.k8s.io/v1
            kind: EncryptionConfiguration
            resources:
            - resources:
              - secrets
              providers:
            %s
              - identity: {}  # Fallback (allows reading pre-encrypted secrets)

            ── Apply to k3s kube-apiserver ─────────────
            # 1. Place config file on k3s server node
            sudo cp encryption-config.yaml /etc/kubernetes/

            # 2. Add to k3s server startup args (/etc/systemd/system/k3s.service)
            ExecStart=/usr/local/bin/k3s server \\
              --kube-apiserver-arg="--encryption-provider-config=/etc/kubernetes/encryption-config.yaml"

            # 3. Restart k3s
            sudo systemctl daemon-reload && sudo systemctl restart k3s

            # 4. Re-encrypt all existing secrets (they were stored unencrypted before)
            kubectl get secrets --all-namespaces -o json | kubectl replace -f -

            # 5. Verify encryption is active
            ETCDCTL_API=3 etcdctl get /registry/secrets/default/test-secret \\
              | hexdump -C | head
            # Should NOT show plaintext — should start with 'k8s:enc:aescbc:v1:'

            ── Security checklist (v15 spec) ─────────
            ✔ AES-CBC / AES-GCM encryption at rest
            ✔ identity provider as fallback only (allows migration)
            ✔ Encryption key stored separately from etcd
            ✔ Split-custody rule: encryption keys never co-located with etcd data
            ✔ Rotation: generate new key, add to top of list, restart apiserver,
                        re-encrypt all secrets, remove old key
            ⚠  DPDPA 2023 compliance: encryption at rest is MANDATORY

            ── Key security ─────────────────────────
            ⚠  The secret: field is a 32-byte base64-encoded key
            ⚠  NEVER store this in Git, Helm values, or CI/CD logs
            ⚠  Store key material in a hardware security module or split-custody
            """.formatted(provider, env, providerYaml);
    }

    private String verifyEnabled() {
        return """
            🔍 VERIFY ENVELOPE ENCRYPTION

            ── Check 1: etcd value inspection ─────────
            # On k3s control plane node:
            ETCDCTL_API=3 etcdctl \\
              --endpoints=https://127.0.0.1:2379 \\
              --cert=/var/lib/rancher/k3s/server/tls/etcd/server-client.crt \\
              --key=/var/lib/rancher/k3s/server/tls/etcd/server-client.key \\
              --cacert=/var/lib/rancher/k3s/server/tls/etcd/server-ca.crt \\
              get /registry/secrets/core/core-credentials | hexdump -C | head

            # If encrypted, output starts with: k8s:enc:aescbc:v1:
            # If NOT encrypted, output shows plaintext base64 — SECURITY RISK

            ── Check 2: kube-apiserver flags ────────
            ps aux | grep kube-apiserver | grep encryption-provider-config
            # Should show: --encryption-provider-config=/etc/kubernetes/encryption-config.yaml

            ── Check 3: Encryption config file ──────
            cat /etc/kubernetes/encryption-config.yaml
            # Should show aescbc or aesgcm provider (NOT identity-only)

            ── Ecoskiller v15 requirement ───────────
            ✔ Envelope encryption MANDATORY for all environments
            ✔ identity-only provider is acceptable ONLY in dev for initial setup
            ✔ Prod, stage, test must all have AES-CBC or KMS encryption active
            ✔ DPDPA 2023 Section 8: technical safeguards require encryption at rest
            """;
    }

    private String generateKeyInstructions(String provider) {
        return """
            🔑 ENCRYPTION KEY GENERATION — %s

            ── Generate a 32-byte AES key ──────────────
            # On a secure, air-gapped or HSM-backed system:
            openssl rand -base64 32
            # Output: <BASE64_KEY> — store securely, NEVER in Git

            ── Key storage rules (split-custody) ───────
            1. Key is split between at minimum 2 custodians (ops leads)
            2. No single person holds the complete key
            3. Key is NOT stored in:
               - Git repositories (including private)
               - CI/CD variable stores (GitLab CI Variables)
               - Helm values files
               - Application configuration files
            4. Key IS stored in:
               - Hardware Security Module (HSM) — preferred for prod
               - Encrypted password manager with MFA (at minimum)
               - Physical secure storage with split parts

            ── Rotation procedure ─────────────────────
            1. Generate new key
            2. Add new key at TOP of keys list in encryption-config.yaml
            3. Restart kube-apiserver
            4. Re-encrypt all secrets: kubectl get secrets --all-namespaces -o json | kubectl replace -f -
            5. Remove old key from encryption-config.yaml
            6. Restart kube-apiserver again
            7. Verify old key is no longer referenced

            ✔ Ecoskiller v15 split-custody mandate enforced
            ✔ Audit this key generation event in security incident log
            """.formatted(provider);
    }

    private String splitCustodyPlan() {
        return """
            🔐 SPLIT-CUSTODY PLAN — Ecoskiller v15 Specification

            Per Section 11.3 (trivyignore equivalent — secrets governance):
            "Never store all unseal keys (or KMS key material) in the same location.
            Split custody is required per the v15 specification."

            ── Custody assignment ────────────────────
            Custodian A (Primary Ops Lead):
              - Holds: First 16 bytes of AES-256 key (or Part A of KMS key)
              - Storage: Personal HSM token or encrypted vault with MFA
              - Location: Primary office safe (backup)

            Custodian B (Secondary Ops Lead / CTO):
              - Holds: Last 16 bytes of AES-256 key (or Part B of KMS key)
              - Storage: Personal HSM token or separate encrypted vault
              - Location: Separate physical location (backup)

            ── Emergency access procedure ────────────
            1. Both custodians must be present (or provide parts securely)
            2. Emergency access requires dual approval (documented in incident log)
            3. Emergency access is audited and reported to security team
            4. Key is rotated immediately after any emergency access

            ── Key compromise response ───────────────
            1. Immediately rotate to a new key (both custodians required)
            2. Re-encrypt all secrets with new key
            3. File security incident report
            4. Notify Ecoskiller security team
            5. Cross-reference in Wazuh SIEM

            ✔ Compliant with DPDPA 2023 technical safeguards
            ✔ Compliant with Ecoskiller Infrastructure v15 Section 11.3
            """;
    }

    private String kmsConfig(String env) {
        return """
            ☁️  KMS PROVIDER CONFIG — %s

            For production-grade key management, use a KMS provider
            instead of a static AES key in the encryption config file.

            ── GCP Cloud KMS example ──────────────────
            apiVersion: apiserver.config.k8s.io/v1
            kind: EncryptionConfiguration
            resources:
            - resources:
              - secrets
              providers:
              - kms:
                  apiVersion: v2
                  name: ecoskiller-%s-gcp-kms
                  endpoint: unix:///var/run/kmsplugin/socket.sock
                  timeout: 3s
              - identity: {}

            ── Deploy GCP KMS plugin ─────────────────
            # 1. Create GCP KMS key ring and key
            gcloud kms keyrings create ecoskiller-%s --location=asia-south1
            gcloud kms keys create ecoskiller-k8s-secrets --location=asia-south1 \\
              --keyring=ecoskiller-%s --purpose=encryption

            # 2. Deploy KMS plugin DaemonSet on k3s control plane nodes
            # 3. Configure socket path: /var/run/kmsplugin/socket.sock

            ✔ KMS removes static key material from filesystem entirely
            ✔ Key rotation managed by GCP KMS — automatic rotation supported
            ✔ Recommended for production per Ecoskiller v15 spec
            """.formatted(env, env, env, env);
    }
}
