{{/*
_helpers.tpl — Common template helpers for mcp-k8s-secrets Helm chart
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "mcp-k8s-secrets.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "mcp-k8s-secrets.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- printf "%s" $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Chart label
*/}}
{{- define "mcp-k8s-secrets.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "mcp-k8s-secrets.labels" -}}
helm.sh/chart: {{ include "mcp-k8s-secrets.chart" . }}
{{ include "mcp-k8s-secrets.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
ecoskiller.com/security-baseline: v15
{{- end }}

{{/*
Selector labels
*/}}
{{- define "mcp-k8s-secrets.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mcp-k8s-secrets.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
ServiceAccount name
*/}}
{{- define "mcp-k8s-secrets.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "mcp-k8s-secrets.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
