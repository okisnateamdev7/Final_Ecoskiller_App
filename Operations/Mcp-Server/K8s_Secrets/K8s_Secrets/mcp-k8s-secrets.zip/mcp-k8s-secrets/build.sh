#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# build.sh — Build and test the Ecoskiller Kubernetes Secrets MCP Server
#
# Usage:
#   ./build.sh              — compile + package JAR
#   ./build.sh --test       — compile + package + run all 75 tests
#   ./build.sh --test -v    — same, with verbose test output
#   ./build.sh --run        — compile + start MCP server (stdio mode)
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

JAR="target/mcp-k8s-secrets.jar"
SRC_DIR="src/main/java"
TEST_DIR="src/test/java"
OUT_DIR="target/classes"
TEST_OUT="target/test-classes"
VERBOSE_FLAG=""
RUN_TESTS=false
RUN_SERVER=false

for arg in "$@"; do
    case "$arg" in
        --test)        RUN_TESTS=true ;;
        --run)         RUN_SERVER=true ;;
        -v|--verbose)  VERBOSE_FLAG="--verbose" ;;
    esac
done

mkdir -p "$OUT_DIR" "$TEST_OUT" target

echo "── Compiling main sources ─────────────────────────────────────────────"
find "$SRC_DIR" -name "*.java" | \
    xargs javac -d "$OUT_DIR" --release 17 -encoding UTF-8
echo "  ✅ Compiled $(find "$SRC_DIR" -name "*.java" | wc -l | tr -d ' ') source files"

echo ""
echo "── Packaging JAR ──────────────────────────────────────────────────────"
jar --create --file="$JAR" \
    --main-class=com.ecoskiller.mcp.k8s.server.McpServer \
    -C "$OUT_DIR" .
echo "  ✅ JAR: $JAR ($(du -h $JAR | cut -f1))"

if [ "$RUN_TESTS" = true ]; then
    echo ""
    echo "── Compiling test sources ─────────────────────────────────────────────"
    find "$TEST_DIR" -name "*.java" | \
        xargs javac -cp "$OUT_DIR" -d "$TEST_OUT" --release 17 -encoding UTF-8
    echo "  ✅ Test sources compiled"

    echo ""
    echo "═══ Suite 1/3: Unit Tests (TestAgents — 29) ═══════════════════════════"
    java -ea -cp "$OUT_DIR:$TEST_OUT" com.ecoskiller.mcp.k8s.TestAgents $VERBOSE_FLAG

    echo ""
    echo "═══ Suite 2/3: Path Validator (TestPathValidator — 30) ════════════════"
    java -ea -cp "$OUT_DIR:$TEST_OUT" com.ecoskiller.mcp.k8s.TestPathValidator $VERBOSE_FLAG

    echo ""
    echo "═══ Suite 3/3: MCP Integration (TestMcpIntegration — 16) ═════════════"
    java -ea -cp "$OUT_DIR:$TEST_OUT" com.ecoskiller.mcp.k8s.TestMcpIntegration

    echo ""
    echo "  ✅ All 75 tests passed across 3 suites"
fi

if [ "$RUN_SERVER" = true ]; then
    echo ""
    echo "── Starting MCP Server ────────────────────────────────────────────────"
    echo "   Protocol: JSON-RPC 2.0  |  Transport: stdio  |  Tools: 15"
    java -jar "$JAR"
fi
