# ecoskiller-prometheus-mcp

**Ecoskiller | Prometheus Observability MCP Server**  
MCP Server in **Java 17** | **18 Tools** | Priority: **Community → Custom Build**

> Built from: `Ecoskiller_Prometheus_Service_Specification.docx` v1.0 (2026)  
> Wraps: Prometheus HTTP API v1 (:9090) + Alertmanager API v2 (:9093)  
> Platform: k3s Kubernetes — ops namespace, GCP asia-south1 + AWS ap-south-1

---

## Overview

Secure Java MCP server exposing Prometheus metrics, alert rules, SLO health, TSDB admin, and Alertmanager integration to Claude via JSON-RPC 2.0 (stdio).

Covers all spec capabilities:
- ✅ Instant + range PromQL queries (spec §3.5, §6 GET /api/v1/query)
- ✅ **8-SLO health dashboard** — evaluates all 8 Ecoskiller SLOs in real-time (spec §9)
- ✅ Firing alerts, alert rules, recording rules (spec §3.3, §10.2)
- ✅ Alertmanager active alerts + silence creation (spec §3.4, §10.3)
- ✅ Scrape target listing (all 50 services via pod annotations, spec §3.1)
- ✅ Exemplar queries for Grafana Tempo trace correlation (spec §6)
- ✅ TSDB cardinality status + series search (spec §3.2)
- ✅ Server health (liveness + readiness probes, spec §3.5)
- ✅ Label names/values discovery

---

## Tools (18)

### Query (5)
| # | Tool | Description |
|---|------|-------------|
| 1 | `prom_instant_query` | Instant PromQL — gauges, current values |
| 2 | `prom_range_query` | Range PromQL — time-series graphs |
| 3 | `prom_query_exemplars` | Exemplars → Grafana Tempo trace correlation |
| 4 | `prom_label_values` | Values for a label (job, namespace, service…) |
| 5 | `prom_label_names` | All label names in Prometheus |

### Targets & Scrape (3)
| # | Tool | Description |
|---|------|-------------|
| 6 | `prom_list_targets` | All 50 scrape targets — health, last scrape, errors |
| 7 | `prom_target_metadata` | Metric metadata for a specific target |
| 8 | `prom_metric_metadata` | Type/help/unit for a metric name |

### Alerts & SLO (4)
| # | Tool | Description |
|---|------|-------------|
| 9 | `prom_list_alerts` | Currently firing/pending alerts |
| 10 | `prom_list_alert_rules` | All configured alert rules + PromQL + state |
| 11 | `prom_list_recording_rules` | Recording rules (SLO burn rate) |
| 12 | `prom_slo_health` | **8-SLO real-time health dashboard** (spec §9) |

### Alertmanager (2)
| # | Tool | Description |
|---|------|-------------|
| 13 | `prom_alertmanager_alerts` | Active alerts in Alertmanager |
| 14 | `prom_silence_alert` | Create silence (operator/admin) |

### TSDB & Admin (4)
| # | Tool | Description |
|---|------|-------------|
| 15 | `prom_tsdb_status` | TSDB cardinality + head stats |
| 16 | `prom_series_search` | Search time-series by label matchers |
| 17 | `prom_delete_series` | Delete series — **admin only**, confirm required |
| 18 | `prom_server_health` | /health + /-/ready + build info + runtime |

---

## The 8 SLO Dashboard (`prom_slo_health`)

Evaluates all 8 Ecoskiller SLOs from spec §9 in one call:

| SLO | PromQL | Threshold | Severity |
|-----|--------|-----------|----------|
| API Success Rate | `sum(rate(http_requests_total{status=~"2.."}[5m])) / sum(...)` | ≥ 99% | P0 |
| API Latency p95 | `histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))` | < 800ms | P1 |
| GD Completion Rate | `gd_session_completion_rate` | ≥ 97% | P0 |
| Interview WSS Stability | `ws_connection_stability` | < 0.1% drops/15m | P0 |
| Auth Login Success | `login_success_rate` | ≥ 99.5% | P1 |
| Kafka Consumer Lag | `kafka_consumer_group_lag` | < 5000 msgs | P1 |
| PostgreSQL Latency p95 | `histogram_quantile(0.95, rate(pg_stat_statements_total_time_bucket[5m]))` | < 100ms | P1 |
| WebRTC Connection Success | `coturn_relay_success_rate` | ≥ 90% | P1 |

---

## Quick Start

### 1 — Build
```bash
mvn clean package -q
# Output: target/ecoskiller-prometheus-mcp-1.0.0.jar
```

### 2 — Set environment variables
```bash
export PROM_URL="http://prometheus.ops.svc.cluster.local:9090"
export PROM_BEARER_TOKEN="your-token"        # or use PROM_BASIC_USER/PASSWORD
export MCP_ROLE="read_only"                  # read_only | operator | admin
export ALERTMANAGER_URL="http://alertmanager.ops.svc.cluster.local:9093"
export PROM_TLS_VERIFY="true"                # always true in production
```

### 3 — Run
```bash
java -jar target/ecoskiller-prometheus-mcp-1.0.0.jar
```

### 4 — Test
```bash
python3 test_mcp_server.py --verbose
python3 test_mcp_server.py prom_slo_health  # just the SLO test
```

---

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PROM_URL` | No | `http://localhost:9090` | Prometheus base URL |
| `PROM_BEARER_TOKEN` | No | — | Bearer auth token (from K8s Secret) |
| `PROM_BASIC_USER` | No | — | Basic auth username |
| `PROM_BASIC_PASSWORD` | No | — | Basic auth password |
| `PROM_TLS_VERIFY` | No | `true` | Verify TLS (`false` for dev only) |
| `PROM_DEFAULT_RANGE` | No | `1h` | Default look-back for range queries |
| `PROM_DEFAULT_STEP` | No | `60s` | Default step for range queries |
| `MCP_ROLE` | No | `read_only` | `read_only` / `operator` / `admin` |
| `ALERTMANAGER_URL` | No | — | Alertmanager base URL (enables alert tools) |
| `PROM_CONNECT_TIMEOUT` | No | `5000` | HTTP connect timeout ms |
| `PROM_READ_TIMEOUT` | No | `30000` | HTTP read timeout ms (PromQL can be slow) |

---

## Security Controls

| Control | Implementation |
|---|---|
| Auth (Bearer/Basic) | `PrometheusHttpClient` — from env, never logged |
| PromQL injection | 5 pattern checks block `file()`, shell chars, path traversal, `eval` |
| Duration validation | Format check + 90-day max cap (prevents expensive queries) |
| Step validation | 1s–1h range (prevents absurdly fine-grained range queries) |
| Metric/label name | RFC regex `[a-zA-Z_:][a-zA-Z0-9_:]*` enforced |
| RBAC | `read_only` → `operator` → `admin` (delete series, clean tombstones) |
| Rate limiting | 120 calls/min per tool |
| Response size cap | 10 MB max |
| TLS configurable | `PROM_TLS_VERIFY=true` always in prod |
| HTTP timeouts | 5s connect, 30s read |

---

## File Structure

```
ecoskiller-prometheus-mcp/
├── pom.xml
├── claude_desktop_config.json
├── test_mcp_server.py                            ← 26-test suite
├── README.md
└── src/main/java/com/ecoskiller/mcp/
    ├── server/McpServer.java                     ← JSON-RPC 2.0 stdio loop
    ├── server/McpException.java
    ├── config/PrometheusConfig.java              ← All config from env
    ├── config/PrometheusHttpClient.java          ← Secure HTTP (auth, TLS, timeouts)
    ├── security/SecurityManager.java             ← PromQL guard, RBAC, rate limiter
    └── tools/
        ├── ToolRegistry.java                     ← 18-tool registration
        ├── BaseTools.java                        ← Shared utilities
        ├── QueryTools.java                       ← instant, range, exemplars, labels
        ├── TargetTools.java                      ← list_targets, metadata
        ├── AlertTools.java                       ← alerts, rules, SLO health, alertmanager
        └── AdminTools.java                       ← TSDB, series, delete, health
```

---

## Spec Compliance

| Spec Section | Tool |
|---|---|
| §3.1 Metrics Scraping 50 services | `prom_list_targets` |
| §3.2 TSDB storage + cardinality | `prom_tsdb_status`, `prom_series_search`, `prom_delete_series` |
| §3.3 SLO alert rule evaluation | `prom_list_alert_rules`, `prom_list_recording_rules`, `prom_slo_health` |
| §3.4 Alertmanager P0/P1/P2 routing | `prom_alertmanager_alerts`, `prom_silence_alert` |
| §3.5 Grafana datasource API | `prom_instant_query`, `prom_range_query` |
| §6 Exemplars → Tempo correlation | `prom_query_exemplars` |
| §9 8 SLO business metrics table | `prom_slo_health` (evaluates all 8) |
| §10.2 Alert rules config | `prom_list_alert_rules` |
| §10.3 Alertmanager routing | `prom_alertmanager_alerts` |
