# ecoskiller-powerdns-mcp

**Ecoskiller | CAT-04 — PowerDNS DNS Management**  
MCP Server in **Java 17** | **18 Tools** | Priority: **MEDIUM** | Type: **Custom Build**

> Built from: `PowerDNS_Service_Description.docx`  
> Wraps: PowerDNS REST API (port 8081)  
> Architecture: Kubernetes Multi-Cloud (GCP us-central1 + AWS us-east-1)

---

## Overview

Secure Java MCP server that exposes the PowerDNS Authoritative DNS Server REST API to Claude via the Model Context Protocol (JSON-RPC 2.0, stdio transport).

Covers all capabilities described in the spec:
- ✅ DNS zone management (list, get, create, delete)
- ✅ Record operations — A, AAAA, MX, TXT, CNAME, NS, SOA (all types from spec §4)
- ✅ ExternalDNS / MetalLB integration workflow (spec §3 automation)
- ✅ Subdomain routing & service IP upsert (idempotent — MetalLB helper)
- ✅ Zone maintenance — NOTIFY slaves, AXFR retrieve, rectify
- ✅ DNSSEC — get status, enable, disable (spec §4 §Security)
- ✅ Server statistics & health metrics (spec §§4, 9 Prometheus metrics)

### Security controls
- ✅ X-API-Key from environment — never hard-coded, never logged
- ✅ RBAC: `read_only` / `operator` / `admin` role enforcement
- ✅ Input validation — hostname labels, record types, IPv4/IPv6, TTL
- ✅ Injection guard — shell/SQL chars blocked in all DNS names
- ✅ Rate limiting — 60 calls/min per tool
- ✅ TLS configurable (`PDNS_TLS_VERIFY=true` in prod)
- ✅ Response size cap — 5 MB max (memory exhaustion prevention)
- ✅ HTTP timeouts — connect 5s, read 10s
- ✅ Audit log appended to every write operation response

---

## Tools (18)

### Zone Management
| # | Tool | Description |
|---|------|-------------|
| 1 | `pdns_list_zones` | List all zones with kind, serial, record counts |
| 2 | `pdns_get_zone` | Full zone detail with all RRsets |
| 3 | `pdns_create_zone` | Create new authoritative zone (Native/Master/Slave) |
| 4 | `pdns_delete_zone` | Delete zone permanently (**admin only**, confirm required) |

### Record Operations
| # | Tool | Description |
|---|------|-------------|
| 5 | `pdns_list_records` | List all RRsets, filterable by name/type |
| 6 | `pdns_get_record` | Get specific record by name + type |
| 7 | `pdns_create_record` | Create/replace RRset (REPLACE changetype) |
| 8 | `pdns_update_record` | Update TTL or content of existing RRset |
| 9 | `pdns_delete_record` | Delete an RRset |

### ExternalDNS / MetalLB
| # | Tool | Description |
|---|------|-------------|
| 10 | `pdns_patch_rrset` | Atomic PATCH multiple RRsets (ExternalDNS workflow) |
| 11 | `pdns_search_records` | Search across all zones by name/type/content |

### Subdomain & Routing
| # | Tool | Description |
|---|------|-------------|
| 12 | `pdns_list_subdomains` | List all A/AAAA records = Kubernetes service IPs |
| 13 | `pdns_upsert_service_ip` | Idempotent A-record create/update for MetalLB IPs |

### Zone Maintenance
| # | Tool | Description |
|---|------|-------------|
| 14 | `pdns_notify_slaves` | Send NOTIFY to secondaries → triggers AXFR |
| 15 | `pdns_axfr_retrieve` | Trigger zone transfer from master (slave zones) |
| 16 | `pdns_rectify_zone` | Re-order DNSSEC records after zone changes |

### DNSSEC
| # | Tool | Description |
|---|------|-------------|
| 17 | `pdns_get_dnssec` | DNSSEC status, keys, DS records |
| 18 | `pdns_enable_dnssec` | Enable DNSSEC signing (**admin only**) |
| — | `pdns_disable_dnssec` | Disable DNSSEC (**admin only**) |

### Monitoring
| # | Tool | Description |
|---|------|-------------|
| + | `pdns_server_stats` | Query rate, cache hit %, latency, uptime, alerts |

---

## Requirements

- Java 17+
- Maven 3.8+
- PowerDNS 4.8.x running with REST API enabled (`webserver=yes`)
- PowerDNS API key configured in `pdns.conf` or Kubernetes Secret

### PowerDNS minimal config (pdns.conf)
```ini
webserver=yes
webserver-address=0.0.0.0
webserver-port=8081
webserver-allow-from=10.0.0.0/8,172.16.0.0/12
api=yes
api-key=YOUR_STRONG_API_KEY_HERE
launch=gpgsql
gpgsql-host=postgres-host
gpgsql-dbname=pdns
gpgsql-user=pdns
gpgsql-password=DB_PASSWORD
```

---

## Quick Start

### 1 — Build
```bash
mvn clean package -q
# Output: target/ecoskiller-powerdns-mcp-1.0.0.jar
```

### 2 — Set environment variables
```bash
export PDNS_API_URL="http://your-powerdns-host:8081"
export PDNS_API_KEY="your-api-key-from-k8s-secret"
export PDNS_DEFAULT_ZONE="ecoskiller.com."
export PDNS_SERVER_ID="localhost"
export MCP_ROLE="operator"             # read_only | operator | admin
export PDNS_TLS_VERIFY="true"          # always true in production
```

### 3 — Run
```bash
java -jar target/ecoskiller-powerdns-mcp-1.0.0.jar
```
Reads JSON-RPC from **stdin**, writes to **stdout**.  
All logs go to **stderr** (stdout stays clean for MCP).

### 4 — Test
```bash
python3 test_mcp_server.py           # quick pass/fail
python3 test_mcp_server.py --verbose # full JSON output
python3 test_mcp_server.py pdns_list # filter by tool name
```

### 5 — Connect to Claude Desktop
Edit `~/Library/Application Support/Claude/claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "ecoskiller-powerdns-mcp": {
      "command": "java",
      "args": ["-jar", "/absolute/path/to/target/ecoskiller-powerdns-mcp-1.0.0.jar"],
      "env": {
        "PDNS_API_URL":  "http://your-powerdns-host:8081",
        "PDNS_API_KEY":  "YOUR_KEY",
        "MCP_ROLE":      "operator"
      }
    }
  }
}
```

---

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PDNS_API_URL` | No | `http://localhost:8081` | PowerDNS REST API base URL |
| `PDNS_API_KEY` | **Yes** | — | X-API-Key from Kubernetes Secret (never logged) |
| `PDNS_DEFAULT_ZONE` | No | `ecoskiller.com.` | Default zone for tools that accept optional zone |
| `PDNS_SERVER_ID` | No | `localhost` | PowerDNS server ID (from `/api/v1/servers`) |
| `PDNS_TLS_VERIFY` | No | `true` | Verify TLS cert (`false` for dev only) |
| `PDNS_DEFAULT_TTL` | No | `300` | Default TTL for new records (spec §3: 300s) |
| `PDNS_CONNECT_TIMEOUT_MS` | No | `5000` | HTTP connection timeout ms |
| `PDNS_READ_TIMEOUT_MS` | No | `10000` | HTTP read timeout ms |
| `MCP_ROLE` | No | `operator` | `read_only` / `operator` / `admin` |

---

## Role Permissions

| Tool Category | read_only | operator | admin |
|---|---|---|---|
| List/Get zones & records | ✅ | ✅ | ✅ |
| Create/update records | ❌ | ✅ | ✅ |
| Patch rrsets (ExternalDNS) | ❌ | ✅ | ✅ |
| Notify slaves, AXFR, rectify | ❌ | ✅ | ✅ |
| Create zone | ❌ | ✅ | ✅ |
| Delete zone | ❌ | ❌ | ✅ |
| Enable/disable DNSSEC | ❌ | ❌ | ✅ |
| Server stats | ✅ | ✅ | ✅ |

---

## File Structure

```
ecoskiller-powerdns-mcp/
├── pom.xml                                           ← Maven (Java 17, fat JAR)
├── claude_desktop_config.json                        ← Claude Desktop config
├── test_mcp_server.py                                ← 28-test suite (Python 3)
├── README.md
└── src/main/java/com/ecoskiller/mcp/
    ├── server/
    │   ├── McpServer.java                            ← JSON-RPC 2.0 stdio loop
    │   └── McpException.java                         ← Typed error codes
    ├── config/
    │   ├── PowerDnsConfig.java                       ← Env vars → config
    │   └── PowerDnsHttpClient.java                   ← Secure HTTP client (X-API-Key, TLS, timeouts)
    ├── security/
    │   └── SecurityManager.java                      ← RBAC, validation, rate limiting
    └── tools/
        ├── ToolRegistry.java                         ← 18-tool registration & dispatch
        ├── BaseTools.java                            ← Shared utilities
        ├── ZoneTools.java                            ← list, get, create, delete zones
        ├── RecordTools.java                          ← list, get, create, update, delete records
        ├── ExternalDnsTools.java                     ← patch_rrset, search, list_subdomains, upsert_service_ip
        ├── MaintenanceTools.java                     ← notify_slaves, axfr_retrieve, rectify_zone
        ├── DnssecTools.java                          ← get, enable, disable DNSSEC
        └── StatsTools.java                           ← server stats & health alerts
```

---

## Protocol

| Property | Value |
|----------|-------|
| Transport | **stdio** (stdin/stdout) |
| Format | **JSON-RPC 2.0** |
| MCP Version | **2024-11-05** |
| Methods | `initialize`, `ping`, `tools/list`, `tools/call` |

---

## Spec Compliance Mapping

| Spec Section | Implemented By |
|---|---|
| §2 Authoritative DNS Zone Management | `pdns_list_zones`, `pdns_get_zone`, `pdns_create_zone` |
| §2 Dynamic DNS Updates via REST API | `pdns_patch_rrset`, `pdns_create_record` |
| §2 ExternalDNS Integration | `pdns_patch_rrset`, `pdns_upsert_service_ip` |
| §3 DNS Query Resolution (monitoring) | `pdns_server_stats` (query rate metric) |
| §3 API Endpoint X-API-Key auth | `PowerDnsHttpClient` (X-API-Key header) |
| §3 ExternalDNS workflow POST rrsets | `pdns_patch_rrset` (REPLACE changetype) |
| §3 Record TTL Management | `security.validateTtl()`, default 300s |
| §3 PostgreSQL Backend | Zone CRUD mirrors DB state via REST API |
| §3 Slave Zone Transfers | `pdns_notify_slaves`, `pdns_axfr_retrieve` |
| §3 DNSSEC Support | `pdns_get_dnssec`, `pdns_enable_dnssec`, `pdns_disable_dnssec` |
| §3 Rate Limiting & DDoS Protection | `SecurityManager` rate limiter + `pdns_server_stats` throttle metric |
| §4 REST API Dynamic Updates | All write tools use PATCH/POST/DELETE |
| §4 Multiple Record Types | `ALLOWED_RECORD_TYPES`: A,AAAA,MX,NS,TXT,CNAME,SOA,SRV,PTR,CAA,DNSKEY,DS,TLSA |
| §4 Slave Zone Transfers AXFR/IXFR | `pdns_notify_slaves`, `pdns_axfr_retrieve` |
| §4 DNSSEC Signing & Validation | `DnssecTools` — KSK + ZSK key creation |
| §4 Query Caching TTL Respect | `pdns_server_stats` cache_hit_rate_pct metric + alert |
| §4 Prometheus Metrics Export | `pdns_server_stats` maps all pdns_* metrics |
| §9 pdns_query_rate | `pdns_server_stats` queries_per_second |
| §9 pdns_response_time | `pdns_server_stats` latency_us (alert >10ms) |
| §9 pdns_cache_hitrate | `pdns_server_stats` cache_hit_rate_pct (alert <80%) |
| §Security DNS Amplification DDoS | Rate limiting + throttled_queries metric |
| §Security Unauthorized zone updates | X-API-Key + RBAC role enforcement |
| §Security DNSSEC signing | `pdns_enable_dnssec` (admin only, confirm required) |
