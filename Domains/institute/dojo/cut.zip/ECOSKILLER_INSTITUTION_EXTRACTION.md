
# ECOSKILLER — COMPLETE INSTITUTE SIDE EXTRACTION

Source: Ecoskiller – COMPLETE LIST OF TECHSTACK BACKEND SERVICES

---

## PLATFORM IDENTITY — INSTITUTE AS CORE TENANT

PLATFORM_CATEGORY =
- ERP for Enterprises / Institutes / Colleges / Recruiters

Institutions operate as full ERP tenants.

---

## USER ECOSYSTEM

User Groups:
- STUDENTS
- TRAINERS / MENTORS
- EVALUATORS
- INSTITUTES (Schools, Colleges, Universities)
- ENTERPRISES
- RECRUITERS / HR
- ADMINS
- PARENTS
- AI AGENTS

Hierarchy rule:
User hierarchy, domain separation, SME handling, corporate L1–L7, institute roles, parent visibility must be enforced.

---

## DOMAIN & HIERARCHY ISOLATION

DOMAIN_TRACKS =
- Arts
- Commerce
- Science
- Technology
- Administration

Rule:
Institute ≠ Company ≠ Platform

---

## ERP LAYER

ERP modules include:
- Institute ERP
- Corporate hiring ERP
- SME hiring workflow
- Compliance & audit ERP
- Analytics dashboards

---

## UI ROLE SYSTEM

Roles:
- Students
- Trainers / Mentors
- Recruiters
- Institute Users
- Enterprise Users
- ERP Admins

Rules:
No recruiter UI for institutes.
No admin UI for students.

---

## SEO ROUTING

Public institution page:
/institute/[id] → Institution Profile

---

## DATABASE MODEL

Tenant(
 id UUID,
 name TEXT,
 type ENUM('individual','company','institution'),
 domain TEXT,
 verified BOOLEAN
)

---

## DOMAIN VERIFICATION

Domain Verification Tool (Company / Institution)

Purpose:
Verify official institution email domains.

---

## SOCIAL & ORGANIZATION SYSTEM

Institution Organization Management

Schemas:
Organization & Department Schema Registry

---

## INSTITUTION ORGANIZATION LAW

Requirements:
- Institution entity with verified domain
- Institution admin onboarding
- Department creation
- Roles:
  - Principal
  - HOD
  - Professor
  - Staff
  - Student
- Invitation via institution email
- Email domain verification
- Student enrollment via institution ID
- Institution groups & feeds

Absence → STOP EXECUTION

---

## COMPLAINT SYSTEM

Anonymous Verified Complaint System

Students may tag:
- Departments
- HODs
- Principals
- Institutions
- Government bodies

---

## ERP MODULE UI

ERP_UI

Used for institutional workflows.

---

## ROLE VISIBILITY RULE

UI visibility = Role + Tenant + Domain + State

---

## SOCIAL GROUPS

Groups may be:
- public
- private
- institutional

Examples:
- campus groups
- department groups
- research groups

---

## MULTI-TENANT SECURITY

Tenant isolation = HARD

Institution data must remain isolated.

---

## EDUCATION MODULE

EducationCourse(
 id,
 tenant_id,
 title,
 description
)

Tenant may represent an institution.

---

## BACKEND SERVICES USED BY INSTITUTES

Services:
- Auth Service
- User Service
- Notification Service
- Analytics Service
- Integration Hub
- Admin Governance Service

---

## ANALYTICS

Analytics Service writes metrics to ClickHouse.

Examples:
- GD performance
- skill scores
- placement analytics

---

## GOVERNANCE

Admin Governance Service handles:
- disputes
- misconduct
- moderation
- audit review

---

## FINAL RULE

Institution Organization System is mandatory.

Absence → STOP EXECUTION
