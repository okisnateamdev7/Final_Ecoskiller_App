# mcp-23-session-pstn-audio-stt

**Ecoskiller | CAT-23 — Session & Lifecycle / PSTN & Bridge / Audio Processing / STT & ML**  
MCP Server in Java | 11 Agents | Priority: HIGH

---

## Agents (11)

| # | Tool Name | Agent |
|---|-----------|-------|
| 1 | `sip_health_monitor` | SIP_HEALTH_MONITOR_AGENT__PSTN_BRIDGE__ECOSKILLER |
| 2 | `sip_route_cost_optimization` | SIP_ROUTE_COST_OPTIMIZATION_AGENT__PSTN_BRIDGE__ECOSKILLER |
| 3 | `call_failover` | CALL_FAILOVER_AGENT__PSTN_BRIDGE__ECOSKILLER |
| 4 | `phone_call_loop_detection` | PHONE_CALL_LOOP_DETECTION_AGENT__PSTN_BRIDGE__ECOSKILLER |
| 5 | `audio_packet_loss_detector` | AUDIO_PACKET_LOSS_DETECTOR_AGENT |
| 6 | `transcript_schema_version_migration` | TRANSCRIPT_SCHEMA_VERSION_MIGRATION_AGENT |
| 7 | `speaker_diarization` | SPEAKER_DIARIZATION_AGENT |
| 8 | `transcript_integrity` | TRANSCRIPT_INTEGRITY_AGENT |
| 9 | `transcript_sequence_repair` | TRANSCRIPT_SEQUENCE_REPAIR_AGENT |
| 10 | `realtime_stt_latency_guard` | REALTIME_STT_LATENCY_GUARD_AGENT |
| 11 | `session_lifecycle_manager` | SESSION_LIFECYCLE_MANAGER_AGENT |

---

## Requirements

- **Java 11+** (tested on Java 21)
- No external dependencies — pure Java stdlib only

---

## Build

```bash
mkdir -p out
javac -d out $(find src -name "*.java")
```

Or use the convenience script:

```bash
chmod +x build.sh
./build.sh          # shows usage
```

---

## Run the server

```bash
java -cp out com.ecoskiller.mcp.server.McpServer
```

Or via build script:

```bash
./build.sh server
```

The server communicates via **stdin/stdout** using JSON-RPC 2.0 (MCP protocol).

---

## Run tests

```bash
./build.sh test            # quick pass/fail (19 tests)
./build.sh test --verbose  # with full JSON output
```

Expected output: `19 passed, 0 failed`

---

## Connect to Claude Desktop

Edit `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "mcp-23-session-pstn-audio-stt": {
      "command": "java",
      "args": ["-cp", "/absolute/path/to/mcp-23-java/out",
               "com.ecoskiller.mcp.server.McpServer"]
    }
  }
}
```

---

## File Structure

```
mcp-23-java/
├── build.sh                            ← Build & run script
├── claude_desktop_config.json          ← Claude Desktop config snippet
├── README.md
└── src/main/java/com/ecoskiller/mcp/
    ├── TestAgents.java                 ← Test all 11 agents (19 test cases)
    ├── server/
    │   └── McpServer.java             ← Main entry point (stdio loop)
    ├── protocol/
    │   ├── JsonRpcHandler.java        ← JSON-RPC 2.0 dispatcher
    │   ├── JsonParser.java            ← Zero-dep JSON parser
    │   └── JsonSerializer.java        ← Zero-dep JSON serializer
    └── agents/
        ├── Agent.java                 ← Interface
        ├── BaseAgent.java             ← Schema/arg helpers
        ├── SipHealthMonitorAgent.java
        ├── SipRouteCostOptimizationAgent.java
        ├── CallFailoverAgent.java
        ├── PhoneCallLoopDetectionAgent.java
        ├── AudioPacketLossDetectorAgent.java
        ├── TranscriptSchemaVersionMigrationAgent.java
        ├── SpeakerDiarizationAgent.java
        ├── TranscriptIntegrityAgent.java
        ├── TranscriptSequenceRepairAgent.java
        ├── RealtimeSttLatencyGuardAgent.java
        └── SessionLifecycleManagerAgent.java
```

---

## Protocol

- Transport: **stdio** (stdin/stdout)
- Format: **JSON-RPC 2.0**
- MCP Version: **2024-11-05**
- Methods: `initialize`, `tools/list`, `tools/call`, `ping`

---

## Adding a new agent

1. Create `src/main/java/com/ecoskiller/mcp/agents/MyNewAgent.java` extending `BaseAgent`
2. Implement `toolName()`, `description()`, `inputSchema()`, `execute()`
3. Register with `register(new MyNewAgent())` in `JsonRpcHandler.registerAgents()`
4. Add a test case in `TestAgents.java`
5. Recompile: `javac -d out $(find src -name "*.java")`
