package com.ecoskiller.mcp.agents;

import java.util.*;

/**
 * PHONE_CALL_LOOP_DETECTION_AGENT__PSTN_BRIDGE__ECOSKILLER
 *
 * Detects SIP call forwarding / trampoline loops and terminates
 * them before they exhaust platform resources.
 */
public class PhoneCallLoopDetectionAgent extends BaseAgent {

    @Override public String toolName() { return "phone_call_loop_detection"; }

    @Override public String description() {
        return "Detect SIP call forwarding loops and terminate them before they exhaust platform resources.";
    }

    @Override public Map<String, Object> inputSchema() {
        return schema(
                "call_id",         "string",
                "via_header_chain","string"   // comma-separated hop list
        );
    }

    @Override
    public String execute(Map<String, Object> args) {
        String callId   = str(args, "call_id",          "call-0000");
        String viaChain = str(args, "via_header_chain", "proxy-A");

        String[] hops = viaChain.split(",");
        Set<String> seen = new LinkedHashSet<>();
        boolean loopDetected = false;
        String loopAt = "";

        for (String hop : hops) {
            String h = hop.trim();
            if (!seen.add(h)) {
                loopDetected = true;
                loopAt = h;
                break;
            }
        }

        String status = loopDetected ? "LOOP_DETECTED" : "CLEAN";
        List<String> lines = new ArrayList<>(Arrays.asList(
                "call_id="    + callId,
                "hop_count="  + hops.length,
                "status="     + status
        ));
        if (loopDetected) {
            lines.add("loop_at="   + loopAt);
            lines.add("action=Session terminated; 482 Loop Detected sent");
        }
        lines.add("timestamp=" + new Date());
        return result("PHONE_CALL_LOOP_DETECTION_AGENT", status,
                lines.toArray(new String[0]));
    }
}
