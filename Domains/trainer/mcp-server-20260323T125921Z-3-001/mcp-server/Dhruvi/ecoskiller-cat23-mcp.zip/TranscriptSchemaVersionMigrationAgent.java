package com.ecoskiller.mcp.agents;

import java.util.*;

/**
 * TRANSCRIPT_SCHEMA_VERSION_MIGRATION_AGENT
 *
 * Migrates transcript payloads between schema versions to ensure
 * backward/forward compatibility across Ecoskiller STT pipelines.
 */
public class TranscriptSchemaVersionMigrationAgent extends BaseAgent {

    @Override public String toolName() { return "transcript_schema_version_migration"; }

    @Override public String description() {
        return "Migrate transcript payloads between schema versions to ensure compatibility across Ecoskiller STT pipelines.";
    }

    @Override public Map<String, Object> inputSchema() {
        return schema(
                "transcript_id",   "string",
                "source_version",  "string",   // e.g. "v1", "v2"
                "target_version",  "string"    // e.g. "v3"
        );
    }

    @Override
    public String execute(Map<String, Object> args) {
        String transcriptId   = str(args, "transcript_id",   "tx-0000");
        String sourceVersion  = str(args, "source_version",  "v1");
        String targetVersion  = str(args, "target_version",  "v3");

        // Migration path validation (only sequential upgrades supported)
        boolean supported = isMigrationSupported(sourceVersion, targetVersion);

        List<String> lines = new ArrayList<>();
        lines.add("transcript_id="  + transcriptId);
        lines.add("source_version=" + sourceVersion);
        lines.add("target_version=" + targetVersion);

        if (!supported) {
            lines.add("error=Unsupported migration path " + sourceVersion + " -> " + targetVersion);
            return result("TRANSCRIPT_SCHEMA_VERSION_MIGRATION_AGENT", "FAILED",
                    lines.toArray(new String[0]));
        }

        lines.add("fields_added="   + getFieldsAdded(sourceVersion, targetVersion));
        lines.add("fields_removed=" + getFieldsRemoved(sourceVersion, targetVersion));
        lines.add("action=Schema migration applied successfully");
        lines.add("timestamp="      + new Date());

        return result("TRANSCRIPT_SCHEMA_VERSION_MIGRATION_AGENT", "MIGRATED",
                lines.toArray(new String[0]));
    }

    private boolean isMigrationSupported(String src, String tgt) {
        List<String> versions = Arrays.asList("v1", "v2", "v3", "v4");
        int srcIdx = versions.indexOf(src);
        int tgtIdx = versions.indexOf(tgt);
        return srcIdx >= 0 && tgtIdx > srcIdx;
    }

    private String getFieldsAdded(String src, String tgt) {
        if ("v1".equals(src) && "v3".equals(tgt)) return "confidence,speaker_id,language_code";
        if ("v1".equals(src) && "v2".equals(tgt)) return "confidence";
        if ("v2".equals(src) && "v3".equals(tgt)) return "speaker_id,language_code";
        return "none";
    }

    private String getFieldsRemoved(String src, String tgt) {
        if ("v1".equals(src)) return "raw_audio_ref";
        return "none";
    }
}
