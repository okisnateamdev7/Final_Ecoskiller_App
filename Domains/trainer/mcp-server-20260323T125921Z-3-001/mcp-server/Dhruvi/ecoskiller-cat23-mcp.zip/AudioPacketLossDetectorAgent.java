package com.ecoskiller.mcp.agents;

import java.util.*;

/**
 * AUDIO_PACKET_LOSS_DETECTOR_AGENT
 *
 * Analyses RTP stream statistics to detect, classify, and report
 * audio packet loss events that degrade call quality.
 */
public class AudioPacketLossDetectorAgent extends BaseAgent {

    @Override public String toolName() { return "audio_packet_loss_detector"; }

    @Override public String description() {
        return "Analyse RTP stream statistics to detect and classify audio packet loss events degrading call quality.";
    }

    @Override public Map<String, Object> inputSchema() {
        return schema(
                "stream_id",           "string",
                "packets_sent",        "number",
                "packets_received",    "number"
        );
    }

    @Override
    public String execute(Map<String, Object> args) {
        String streamId   = str(args,    "stream_id", "rtp-0000");
        int    sent       = intVal(args, "packets_sent",     1000);
        int    received   = intVal(args, "packets_received", 980);

        int    lost       = Math.max(0, sent - received);
        double lossRate   = sent > 0 ? (lost * 100.0 / sent) : 0.0;

        String quality;
        String recommendation;
        if (lossRate < 1.0) {
            quality = "EXCELLENT";
            recommendation = "No action needed";
        } else if (lossRate < 3.0) {
            quality = "GOOD";
            recommendation = "Monitor; consider FEC if sustained";
        } else if (lossRate < 8.0) {
            quality = "DEGRADED";
            recommendation = "Enable FEC; alert ops team";
        } else {
            quality = "POOR";
            recommendation = "Trigger call failover; investigate network path";
        }

        return result("AUDIO_PACKET_LOSS_DETECTOR_AGENT", quality,
                "stream_id="      + streamId,
                "packets_sent="   + sent,
                "packets_received=" + received,
                "packets_lost="   + lost,
                String.format("loss_rate=%.2f%%", lossRate),
                "quality="        + quality,
                "recommendation=" + recommendation,
                "timestamp="      + new Date());
    }
}
