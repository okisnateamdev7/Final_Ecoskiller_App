package com.ecoskiller.mcp.agents;

import java.util.*;

/**
 * TRANSCRIPT_INTEGRITY_AGENT
 *
 * Validates transcript payloads for completeness, checksum correctness,
 * and format compliance before persistence or downstream processing.
 */
public class TranscriptIntegrityAgent extends BaseAgent {

    @Override public String toolName() { return "transcript_integrity"; }

    @Override public String description() {
        return "Validate transcript payloads for completeness, checksum, and format compliance before persistence.";
    }

    @Override public Map<String, Object> inputSchema() {
        return schema(
                "transcript_id", "string",
                "payload",       "string",
                "checksum",      "string"
        );
    }

    @Override
    public String execute(Map<String, Object> args) {
        String transcriptId = str(args, "transcript_id", "tx-0000");
        String payload      = str(args, "payload",       "");
        String checksum     = str(args, "checksum",      "");

        List<String> violations = new ArrayList<>();

        if (payload.isEmpty()) violations.add("EMPTY_PAYLOAD");
        if (checksum.isEmpty()) violations.add("MISSING_CHECKSUM");

        // Simple length-based checksum simulation
        String computedChecksum = String.valueOf(payload.length());
        if (!checksum.isEmpty() && !checksum.equals(computedChecksum)) {
            violations.add("CHECKSUM_MISMATCH(expected=" + computedChecksum + ",got=" + checksum + ")");
        }

        // Format check: must contain at least one alphanumeric character
        if (!payload.isEmpty() && !payload.matches(".*[a-zA-Z0-9].*")) {
            violations.add("NON_PRINTABLE_CONTENT");
        }

        String status = violations.isEmpty() ? "VALID" : "INVALID";
        List<String> lines = new ArrayList<>();
        lines.add("transcript_id=" + transcriptId);
        lines.add("payload_length=" + payload.length());
        lines.add("violations=" + (violations.isEmpty() ? "none" : String.join(", ", violations)));
        lines.add("timestamp=" + new Date());

        return result("TRANSCRIPT_INTEGRITY_AGENT", status, lines.toArray(new String[0]));
    }
}
