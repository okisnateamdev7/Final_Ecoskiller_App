package com.ecoskiller.mcp.protocol;

import com.ecoskiller.mcp.agents.*;

import java.util.*;

/**
 * Handles all incoming JSON-RPC 2.0 messages and dispatches to the correct agent.
 */
public class JsonRpcHandler {

    private final Map<String, Agent> agents = new LinkedHashMap<>();

    public JsonRpcHandler() {
        registerAgents();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Agent registration
    // ─────────────────────────────────────────────────────────────────────────

    private void registerAgents() {
        register(new SipHealthMonitorAgent());
        register(new SipRouteCostOptimizationAgent());
        register(new CallFailoverAgent());
        register(new PhoneCallLoopDetectionAgent());
        register(new AudioPacketLossDetectorAgent());
        register(new TranscriptSchemaVersionMigrationAgent());
        register(new SpeakerDiarizationAgent());
        register(new TranscriptIntegrityAgent());
        register(new TranscriptSequenceRepairAgent());
        register(new RealtimeSttLatencyGuardAgent());
        register(new SessionLifecycleManagerAgent());
    }

    private void register(Agent agent) {
        agents.put(agent.toolName(), agent);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Main dispatch
    // ─────────────────────────────────────────────────────────────────────────

    public String handle(String json) {
        try {
            Map<String, Object> req = JsonParser.parse(json);
            String method = (String) req.get("method");
            Object id = req.get("id");

            if ("initialize".equals(method)) {
                return respond(id, buildInitializeResult());
            }
            if ("ping".equals(method)) {
                return respond(id, new LinkedHashMap<>());
            }
            if ("tools/list".equals(method)) {
                return respond(id, buildToolsList());
            }
            if ("tools/call".equals(method)) {
                return handleToolCall(id, req);
            }

            return errorResponse(id, -32601, "Method not found: " + method);

        } catch (Exception e) {
            return errorResponse(null, -32700, "Parse error: " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // initialize
    // ─────────────────────────────────────────────────────────────────────────

    private Map<String, Object> buildInitializeResult() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("protocolVersion", "2024-11-05");

        Map<String, Object> serverInfo = new LinkedHashMap<>();
        serverInfo.put("name", "mcp-23-session-pstn-audio-stt");
        serverInfo.put("version", "1.0.0");
        result.put("serverInfo", serverInfo);

        Map<String, Object> capabilities = new LinkedHashMap<>();
        capabilities.put("tools", new LinkedHashMap<>());
        result.put("capabilities", capabilities);

        return result;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // tools/list
    // ─────────────────────────────────────────────────────────────────────────

    private Map<String, Object> buildToolsList() {
        List<Map<String, Object>> tools = new ArrayList<>();
        for (Agent agent : agents.values()) {
            Map<String, Object> tool = new LinkedHashMap<>();
            tool.put("name", agent.toolName());
            tool.put("description", agent.description());
            tool.put("inputSchema", agent.inputSchema());
            tools.add(tool);
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("tools", tools);
        return result;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // tools/call
    // ─────────────────────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private String handleToolCall(Object id, Map<String, Object> req) {
        Map<String, Object> params = (Map<String, Object>) req.getOrDefault("params", new LinkedHashMap<>());
        String toolName = (String) params.get("name");
        Map<String, Object> arguments = (Map<String, Object>) params.getOrDefault("arguments", new LinkedHashMap<>());

        Agent agent = agents.get(toolName);
        if (agent == null) {
            return errorResponse(id, -32602, "Unknown tool: " + toolName);
        }

        try {
            String resultText = agent.execute(arguments);
            Map<String, Object> content = new LinkedHashMap<>();
            content.put("type", "text");
            content.put("text", resultText);

            Map<String, Object> result = new LinkedHashMap<>();
            result.put("content", Collections.singletonList(content));
            result.put("isError", false);
            return respond(id, result);
        } catch (Exception e) {
            Map<String, Object> content = new LinkedHashMap<>();
            content.put("type", "text");
            content.put("text", "Error: " + e.getMessage());

            Map<String, Object> result = new LinkedHashMap<>();
            result.put("content", Collections.singletonList(content));
            result.put("isError", true);
            return respond(id, result);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Response helpers
    // ─────────────────────────────────────────────────────────────────────────

    private String respond(Object id, Object result) {
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("jsonrpc", "2.0");
        response.put("id", id);
        response.put("result", result);
        return JsonSerializer.toJson(response);
    }

    private String errorResponse(Object id, int code, String message) {
        Map<String, Object> error = new LinkedHashMap<>();
        error.put("code", code);
        error.put("message", message);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("jsonrpc", "2.0");
        response.put("id", id);
        response.put("error", error);
        return JsonSerializer.toJson(response);
    }
}
