package com.ecoskiller.mcp;

import com.ecoskiller.mcp.protocol.JsonRpcHandler;

import java.util.*;

/**
 * Test all 11 CAT-23 agents.
 * Run: java -cp . com.ecoskiller.mcp.TestAgents [--verbose]
 */
public class TestAgents {

    private static final JsonRpcHandler HANDLER = new JsonRpcHandler();
    private static boolean verbose = false;
    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {
        for (String arg : args) {
            if ("--verbose".equals(arg)) verbose = true;
        }

        System.out.println("=== Ecoskiller mcp-23 — CAT-23 Agent Tests ===\n");

        // 1. initialize
        test("initialize",
                "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"initialize\",\"params\":{}}");

        // 2. ping
        test("ping",
                "{\"jsonrpc\":\"2.0\",\"id\":2,\"method\":\"ping\"}");

        // 3. tools/list
        test("tools/list",
                "{\"jsonrpc\":\"2.0\",\"id\":3,\"method\":\"tools/list\",\"params\":{}}");

        // 4. sip_health_monitor
        test("sip_health_monitor",
                "{\"jsonrpc\":\"2.0\",\"id\":4,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"sip_health_monitor\"," +
                "\"arguments\":{\"sip_endpoint\":\"sip:bridge01@ecoskiller.io\",\"check_type\":\"full\"}}}");

        // 5. sip_route_cost_optimization
        test("sip_route_cost_optimization",
                "{\"jsonrpc\":\"2.0\",\"id\":5,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"sip_route_cost_optimization\"," +
                "\"arguments\":{\"destination_number\":\"+919876543210\",\"max_cost_per_min\":0.04}}}");

        // 6. call_failover
        test("call_failover",
                "{\"jsonrpc\":\"2.0\",\"id\":6,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"call_failover\"," +
                "\"arguments\":{\"session_id\":\"sess-abc123\",\"failure_reason\":\"503\"}}}");

        // 7. phone_call_loop_detection — loop present
        test("phone_call_loop_detection (loop)",
                "{\"jsonrpc\":\"2.0\",\"id\":7,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"phone_call_loop_detection\"," +
                "\"arguments\":{\"call_id\":\"call-xyz\",\"via_header_chain\":\"proxy-A,proxy-B,proxy-A\"}}}");

        // 8. audio_packet_loss_detector — degraded
        test("audio_packet_loss_detector (degraded)",
                "{\"jsonrpc\":\"2.0\",\"id\":8,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"audio_packet_loss_detector\"," +
                "\"arguments\":{\"stream_id\":\"rtp-001\",\"packets_sent\":1000,\"packets_received\":940}}}");

        // 9. transcript_schema_version_migration
        test("transcript_schema_version_migration",
                "{\"jsonrpc\":\"2.0\",\"id\":9,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"transcript_schema_version_migration\"," +
                "\"arguments\":{\"transcript_id\":\"tx-001\",\"source_version\":\"v1\",\"target_version\":\"v3\"}}}");

        // 10. speaker_diarization
        test("speaker_diarization",
                "{\"jsonrpc\":\"2.0\",\"id\":10,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"speaker_diarization\"," +
                "\"arguments\":{\"session_id\":\"sess-001\",\"transcript_text\":\"Hello how are you. I am fine. What did you learn today. I learnt about photosynthesis.\",\"expected_speakers\":2}}}");

        // 11. transcript_integrity — checksum mismatch
        test("transcript_integrity (mismatch)",
                "{\"jsonrpc\":\"2.0\",\"id\":11,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"transcript_integrity\"," +
                "\"arguments\":{\"transcript_id\":\"tx-002\",\"payload\":\"Hello world\",\"checksum\":\"99\"}}}");

        // 12. transcript_sequence_repair — gaps & duplicates
        test("transcript_sequence_repair",
                "{\"jsonrpc\":\"2.0\",\"id\":12,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"transcript_sequence_repair\"," +
                "\"arguments\":{\"transcript_id\":\"tx-003\",\"sequence_numbers\":\"1,3,2,5,5\"}}}");

        // 13. realtime_stt_latency_guard — breach
        test("realtime_stt_latency_guard (breach)",
                "{\"jsonrpc\":\"2.0\",\"id\":13,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"realtime_stt_latency_guard\"," +
                "\"arguments\":{\"pipeline_id\":\"stt-pipe-01\",\"current_latency_ms\":520,\"threshold_ms\":400}}}");

        // 14. session_lifecycle_manager — full lifecycle
        for (String action : new String[]{"create","start","pause","resume","end"}) {
            test("session_lifecycle_manager/" + action,
                    "{\"jsonrpc\":\"2.0\",\"id\":14,\"method\":\"tools/call\",\"params\":{" +
                    "\"name\":\"session_lifecycle_manager\"," +
                    "\"arguments\":{\"session_id\":\"sess-TEST\",\"action\":\"" + action + "\"}}}");
        }

        // 15. unknown tool — should return JSON-RPC error (not throw)
        testExpectError("unknown_tool (expect error)",
                "{\"jsonrpc\":\"2.0\",\"id\":99,\"method\":\"tools/call\",\"params\":{" +
                "\"name\":\"does_not_exist\",\"arguments\":{}}}");

        System.out.println("\n=== Results: " + passed + " passed, " + failed + " failed ===");
    }

    private static void testExpectError(String label, String request) {
        try {
            String response = HANDLER.handle(request);
            boolean ok = response != null && response.contains("\"error\"");
            if (ok) { passed++; System.out.println("[PASS] " + label + " (error returned as expected)"); }
            else    { failed++; System.out.println("[FAIL] " + label + " — expected error but got: " + response); }
            if (verbose) System.out.println("       " + response);
        } catch (Exception e) {
            failed++;
            System.out.println("[ERROR] " + label + " — " + e.getMessage());
        }
    }

    private static void test(String label, String request) {
        try {
            String response = HANDLER.handle(request);
            boolean ok = response != null && response.contains("\"result\"");
            if (ok) {
                passed++;
                System.out.println("[PASS] " + label);
            } else {
                failed++;
                System.out.println("[FAIL] " + label);
                if (verbose) System.out.println("       Response: " + response);
            }
            if (verbose) System.out.println("       " + response);
        } catch (Exception e) {
            failed++;
            System.out.println("[ERROR] " + label + " — " + e.getMessage());
        }
    }
}
