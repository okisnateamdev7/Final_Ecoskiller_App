package com.ecoskiller.mcp.agents;

import java.util.*;

/**
 * TRANSCRIPT_SEQUENCE_REPAIR_AGENT
 *
 * Detects and repairs out-of-order, missing, or duplicate transcript
 * segments caused by network jitter or STT pipeline failures.
 */
public class TranscriptSequenceRepairAgent extends BaseAgent {

    @Override public String toolName() { return "transcript_sequence_repair"; }

    @Override public String description() {
        return "Detect and repair out-of-order, missing, or duplicate transcript segments caused by network jitter or STT failures.";
    }

    @Override public Map<String, Object> inputSchema() {
        return schema(
                "transcript_id",     "string",
                "sequence_numbers",  "string"   // comma-separated ints, e.g. "1,3,2,5,5"
        );
    }

    @Override
    public String execute(Map<String, Object> args) {
        String transcriptId = str(args, "transcript_id",    "tx-0000");
        String seqRaw       = str(args, "sequence_numbers", "1,2,3");

        String[] parts = seqRaw.split(",");
        List<Integer> seqNums = new ArrayList<>();
        for (String p : parts) {
            try { seqNums.add(Integer.parseInt(p.trim())); } catch (NumberFormatException ignored) {}
        }

        // Detect issues
        Set<Integer> seen = new LinkedHashSet<>();
        List<Integer> duplicates = new ArrayList<>();
        List<Integer> gaps       = new ArrayList<>();

        for (int n : seqNums) {
            if (!seen.add(n)) duplicates.add(n);
        }

        List<Integer> sorted = new ArrayList<>(seen);
        Collections.sort(sorted);
        for (int i = 0; i + 1 < sorted.size(); i++) {
            for (int g = sorted.get(i) + 1; g < sorted.get(i + 1); g++) {
                gaps.add(g);
            }
        }

        boolean outOfOrder = !new ArrayList<>(seqNums).equals(new ArrayList<>(seen));

        String status = (duplicates.isEmpty() && gaps.isEmpty() && !outOfOrder) ? "OK" : "REPAIRED";

        return result("TRANSCRIPT_SEQUENCE_REPAIR_AGENT", status,
                "transcript_id=" + transcriptId,
                "original_seq="  + seqRaw,
                "duplicates="    + (duplicates.isEmpty() ? "none" : duplicates.toString()),
                "gaps="          + (gaps.isEmpty()       ? "none" : gaps.toString()),
                "out_of_order="  + outOfOrder,
                "repaired_seq="  + sorted.toString(),
                "timestamp="     + new Date());
    }
}
