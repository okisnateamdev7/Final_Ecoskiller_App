#!/bin/bash
# ─────────────────────────────────────────────────────────────
# Ecoskiller mcp-23 — Build & Run Script
# ─────────────────────────────────────────────────────────────
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC_DIR="$SCRIPT_DIR/src/main/java"
OUT_DIR="$SCRIPT_DIR/out"

# ── Compile ───────────────────────────────────────────────────
echo "[build] Compiling Java sources..."
mkdir -p "$OUT_DIR"
find "$SRC_DIR" -name "*.java" > /tmp/mcp23_sources.txt
javac -d "$OUT_DIR" @/tmp/mcp23_sources.txt
echo "[build] Compilation successful."

# ── Run mode ─────────────────────────────────────────────────
case "${1:-}" in
  test)
    echo "[test] Running agent tests..."
    java -cp "$OUT_DIR" com.ecoskiller.mcp.TestAgents "${@:2}"
    ;;
  server)
    echo "[server] Starting MCP server (stdio)..."
    java -cp "$OUT_DIR" com.ecoskiller.mcp.server.McpServer
    ;;
  *)
    echo ""
    echo "Usage:"
    echo "  ./build.sh test            # Run all agent tests"
    echo "  ./build.sh test --verbose  # Run tests with full JSON output"
    echo "  ./build.sh server          # Start the MCP stdio server"
    echo ""
    ;;
esac
