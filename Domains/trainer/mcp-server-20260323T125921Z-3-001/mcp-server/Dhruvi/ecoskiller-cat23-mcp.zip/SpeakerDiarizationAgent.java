package com.ecoskiller.mcp.agents;

import java.util.*;

/**
 * SPEAKER_DIARIZATION_AGENT
 *
 * Segments a transcript into labelled speaker turns and assigns
 * speaker identities based on voice embeddings or session metadata.
 */
public class SpeakerDiarizationAgent extends BaseAgent {

    @Override public String toolName() { return "speaker_diarization"; }

    @Override public String description() {
        return "Segment a transcript into labelled speaker turns and assign speaker identities for Ecoskiller sessions.";
    }

    @Override public Map<String, Object> inputSchema() {
        return schema(
                "session_id",      "string",
                "transcript_text", "string",
                "expected_speakers","number"
        );
    }

    @Override
    public String execute(Map<String, Object> args) {
        String sessionId  = str(args,    "session_id",       "sess-0000");
        String transcript = str(args,    "transcript_text",  "");
        int    expected   = intVal(args, "expected_speakers", 2);

        // Simulate speaker segmentation
        String[] sentences = transcript.isEmpty()
                ? new String[]{"[no transcript provided]"}
                : transcript.split("[.?!]+");

        int detected = Math.min(expected, Math.max(1, sentences.length / 2));

        StringBuilder segmentation = new StringBuilder();
        for (int i = 0; i < sentences.length; i++) {
            String s = sentences[i].trim();
            if (!s.isEmpty()) {
                segmentation.append("SPEAKER_")
                        .append((i % detected) + 1)
                        .append(": ")
                        .append(s)
                        .append(" | ");
            }
        }

        return result("SPEAKER_DIARIZATION_AGENT", "OK",
                "session_id="         + sessionId,
                "expected_speakers="  + expected,
                "detected_speakers="  + detected,
                "segments="           + segmentation.toString().trim(),
                "timestamp="          + new Date());
    }
}
