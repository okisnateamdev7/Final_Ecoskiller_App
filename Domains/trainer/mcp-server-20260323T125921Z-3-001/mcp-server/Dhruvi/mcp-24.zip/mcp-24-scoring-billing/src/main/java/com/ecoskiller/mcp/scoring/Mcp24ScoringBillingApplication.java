package com.ecoskiller.mcp.scoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mcp24ScoringBillingApplication {
    public static void main(String[] args) {
        SpringApplication.run(Mcp24ScoringBillingApplication.class, args);
    }
}
