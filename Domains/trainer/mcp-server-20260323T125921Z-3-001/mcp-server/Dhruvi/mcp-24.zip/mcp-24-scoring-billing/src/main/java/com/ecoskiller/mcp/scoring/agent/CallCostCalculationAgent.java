package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-24: CALL_COST_CALCULATION_AGENT
 * Calculates the billable cost of each phone session including
 * call minutes, STT processing, and AI scoring components.
 * Supports multi-tier pricing and volume discounts.
 */
@Component
public class CallCostCalculationAgent {

    @Tool(name = "call_cost_calculate",
          description = "Calculate the total billable cost of a phone assessment session.")
    public AgentResponse calculateCallCost(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Call duration in seconds") int durationSeconds,
            @ToolParam(description = "STT minutes consumed") double sttMinutes,
            @ToolParam(description = "AI scoring units consumed (1 per scored utterance)") int aiScoringUnits,
            @ToolParam(description = "Tenant plan: FREE | STARTER | PROFESSIONAL | ENTERPRISE") String plan) {

        double callRatePerMin   = getCallRate(plan);
        double sttRatePerMin    = getSttRate(plan);
        double scoringRatePerUnit = getScoringRate(plan);

        double callMinutes      = durationSeconds / 60.0;
        double callCost         = callMinutes * callRatePerMin;
        double sttCost          = sttMinutes * sttRatePerMin;
        double scoringCost      = aiScoringUnits * scoringRatePerUnit;
        double totalCost        = callCost + sttCost + scoringCost;

        String invoiceLineId = "INV-LINE-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        return AgentResponse.ok("CALL_COST_CALCULATION_AGENT",
                "Call cost calculated for session " + sessionId,
                Map.of(
                        "invoiceLineId",   invoiceLineId,
                        "sessionId",       sessionId,
                        "tenantId",        tenantId,
                        "plan",            plan,
                        "callMinutes",     Math.round(callMinutes * 100.0) / 100.0,
                        "sttMinutes",      sttMinutes,
                        "aiScoringUnits",  aiScoringUnits,
                        "callCostINR",     Math.round(callCost * 100.0) / 100.0,
                        "sttCostINR",      Math.round(sttCost * 100.0) / 100.0,
                        "scoringCostINR",  Math.round(scoringCost * 100.0) / 100.0,
                        "totalCostINR",    Math.round(totalCost * 100.0) / 100.0,
                        "calculatedAt",    Instant.now().toString()
                ));
    }

    @Tool(name = "call_cost_estimate",
          description = "Estimate the cost of a planned session before it starts based on expected parameters.")
    public AgentResponse estimateCost(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Expected call duration in minutes") int expectedMinutes,
            @ToolParam(description = "Tenant plan") String plan) {

        double callCost   = expectedMinutes * getCallRate(plan);
        double sttCost    = expectedMinutes * getSttRate(plan);
        double scoreCost  = (expectedMinutes * 2) * getScoringRate(plan); // ~2 scored utterances per minute
        double total      = callCost + sttCost + scoreCost;

        return AgentResponse.ok("CALL_COST_CALCULATION_AGENT",
                "Cost estimate for " + expectedMinutes + " min session",
                Map.of(
                        "tenantId",       tenantId,
                        "plan",           plan,
                        "expectedMinutes",expectedMinutes,
                        "estimatedINR",   Math.round(total * 100.0) / 100.0,
                        "currency",       "INR",
                        "estimatedAt",    Instant.now().toString()
                ));
    }

    private double getCallRate(String plan) {
        return switch (plan.toUpperCase()) {
            case "ENTERPRISE"   -> 0.40;
            case "PROFESSIONAL" -> 0.55;
            case "STARTER"      -> 0.75;
            default             -> 1.00;
        };
    }

    private double getSttRate(String plan) {
        return switch (plan.toUpperCase()) {
            case "ENTERPRISE"   -> 0.80;
            case "PROFESSIONAL" -> 1.00;
            case "STARTER"      -> 1.20;
            default             -> 1.50;
        };
    }

    private double getScoringRate(String plan) {
        return switch (plan.toUpperCase()) {
            case "ENTERPRISE"   -> 0.10;
            case "PROFESSIONAL" -> 0.15;
            case "STARTER"      -> 0.20;
            default             -> 0.00;
        };
    }
}
