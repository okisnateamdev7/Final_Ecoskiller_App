package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-31: PHONE_EVENT_SCHEMA_VALIDATION_AGENT
 * Validates incoming platform events against their registered JSON schemas
 * before they are accepted into the event bus. Prevents malformed events
 * from corrupting downstream processors.
 */
@Component
public class PhoneEventSchemaValidationAgent {

    @Tool(name = "event_schema_validate",
          description = "Validate a platform event payload against its registered schema version.")
    public AgentResponse validateEvent(
            @ToolParam(description = "Event type (e.g. SESSION_STARTED, SCORE_COMPUTED, CALL_ENDED)") String eventType,
            @ToolParam(description = "Event schema version (e.g. v1.2)") String schemaVersion,
            @ToolParam(description = "Event source service ID") String sourceService,
            @ToolParam(description = "Whether required fields are all present") boolean requiredFieldsPresent,
            @ToolParam(description = "Whether all field types match the schema") boolean fieldTypesValid,
            @ToolParam(description = "Whether enum values are within allowed set") boolean enumValuesValid) {

        boolean valid = requiredFieldsPresent && fieldTypesValid && enumValuesValid;
        List<String> errors = new java.util.ArrayList<>();
        if (!requiredFieldsPresent) errors.add("MISSING_REQUIRED_FIELDS");
        if (!fieldTypesValid)       errors.add("FIELD_TYPE_MISMATCH");
        if (!enumValuesValid)       errors.add("INVALID_ENUM_VALUE");

        return AgentResponse.ok("PHONE_EVENT_SCHEMA_VALIDATION_AGENT",
                valid ? "Event schema valid: " + eventType : "Event schema INVALID: " + eventType,
                Map.of(
                        "eventType",     eventType,
                        "schemaVersion", schemaVersion,
                        "sourceService", sourceService,
                        "valid",         valid,
                        "errors",        errors,
                        "action",        valid ? "ACCEPT_TO_BUS" : "REJECT_EVENT",
                        "validatedAt",   Instant.now().toString()
                ));
    }

    @Tool(name = "event_schema_version_check",
          description = "Check if an event schema version is current or requires migration.")
    public AgentResponse checkSchemaVersion(
            @ToolParam(description = "Event type") String eventType,
            @ToolParam(description = "Schema version in the incoming event") String incomingVersion,
            @ToolParam(description = "Current production schema version") String currentVersion) {

        boolean isCurrent   = incomingVersion.equals(currentVersion);
        boolean isDeprecated = incomingVersion.compareTo(currentVersion) < 0;

        return AgentResponse.ok("PHONE_EVENT_SCHEMA_VALIDATION_AGENT",
                isCurrent ? "Schema version current" : "Schema version outdated: " + incomingVersion,
                Map.of(
                        "eventType",        eventType,
                        "incomingVersion",  incomingVersion,
                        "currentVersion",   currentVersion,
                        "isCurrent",        isCurrent,
                        "isDeprecated",     isDeprecated,
                        "action",           isCurrent ? "ACCEPT" : "MIGRATE_OR_REJECT",
                        "checkedAt",        Instant.now().toString()
                ));
    }

    @Tool(name = "event_schema_registry_list",
          description = "List all registered event types and their current schema versions.")
    public AgentResponse listSchemas() {

        return AgentResponse.ok("PHONE_EVENT_SCHEMA_VALIDATION_AGENT",
                "Event schema registry retrieved",
                Map.of(
                        "schemas", List.of(
                                Map.of("eventType", "SESSION_STARTED",    "version", "v2.1", "status", "ACTIVE"),
                                Map.of("eventType", "SESSION_ENDED",      "version", "v2.1", "status", "ACTIVE"),
                                Map.of("eventType", "SCORE_COMPUTED",     "version", "v3.0", "status", "ACTIVE"),
                                Map.of("eventType", "CALL_ENDED",         "version", "v1.5", "status", "ACTIVE"),
                                Map.of("eventType", "QUOTA_EXCEEDED",     "version", "v1.0", "status", "ACTIVE"),
                                Map.of("eventType", "BILLING_CYCLE_END",  "version", "v2.0", "status", "ACTIVE"),
                                Map.of("eventType", "TRANSCRIPT_READY",   "version", "v2.2", "status", "ACTIVE")
                        ),
                        "retrievedAt", Instant.now().toString()
                ));
    }
}
