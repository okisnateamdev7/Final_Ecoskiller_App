package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-05: PHONE_SPEAKING_TIME_AGENT
 * Measures actual learner speaking time from VAD-gated audio segments.
 * Distinguishes learner speech from silence, filler, and agent prompts.
 * Speaking time is a key input to participation and scoring models.
 */
@Component
public class PhoneSpeakingTimeAgent {

    @Tool(name = "speaking_time_calculate",
          description = "Calculate learner speaking time metrics from a completed phone session.")
    public AgentResponse calculateSpeakingTime(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Total session duration in seconds") int totalDurationSec,
            @ToolParam(description = "Total VAD-active (speech detected) duration in seconds") int vadActiveSec,
            @ToolParam(description = "Filler word duration in seconds (um, uh, er)") int fillerDurationSec,
            @ToolParam(description = "Agent/prompt speaking duration in seconds") int agentSpeakingTimeSec) {

        int netSpeakingTimeSec = vadActiveSec - fillerDurationSec;
        double speakingRatio   = totalDurationSec > 0 ? (double) netSpeakingTimeSec / totalDurationSec : 0.0;
        double fillerRatio     = vadActiveSec > 0 ? (double) fillerDurationSec / vadActiveSec : 0.0;

        String fluencyHint = fillerRatio > 0.20 ? "HIGH_FILLER_USAGE"
                           : fillerRatio > 0.10 ? "MODERATE_FILLER_USAGE"
                           : "LOW_FILLER_USAGE";

        return AgentResponse.ok("PHONE_SPEAKING_TIME_AGENT",
                "Speaking time calculated for session " + sessionId,
                Map.of(
                        "sessionId",           sessionId,
                        "learnerId",           learnerId,
                        "totalDurationSec",    totalDurationSec,
                        "vadActiveSec",        vadActiveSec,
                        "fillerDurationSec",   fillerDurationSec,
                        "agentSpeakingTimeSec",agentSpeakingTimeSec,
                        "netSpeakingTimeSec",  netSpeakingTimeSec,
                        "speakingRatioPct",    Math.round(speakingRatio * 1000.0) / 10.0,
                        "fillerRatioPct",      Math.round(fillerRatio * 1000.0) / 10.0,
                        "fluencyHint",         fluencyHint,
                        "calculatedAt",        Instant.now().toString()
                ));
    }

    @Tool(name = "speaking_time_turn_breakdown",
          description = "Break down speaking time by conversational turns for speaker-diarized sessions.")
    public AgentResponse turnBreakdown(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Number of learner turns") int learnerTurns,
            @ToolParam(description = "Average learner turn duration in seconds") double avgTurnDurationSec,
            @ToolParam(description = "Longest single learner turn in seconds") double longestTurnSec,
            @ToolParam(description = "Number of turns shorter than 2 seconds (short-response turns)") int shortTurns) {

        double shortTurnRatio = learnerTurns > 0 ? (double) shortTurns / learnerTurns : 0.0;

        return AgentResponse.ok("PHONE_SPEAKING_TIME_AGENT",
                "Turn breakdown for session " + sessionId,
                Map.of(
                        "sessionId",          sessionId,
                        "learnerTurns",       learnerTurns,
                        "avgTurnDurationSec", avgTurnDurationSec,
                        "longestTurnSec",     longestTurnSec,
                        "shortTurns",         shortTurns,
                        "shortTurnRatioPct",  Math.round(shortTurnRatio * 1000.0) / 10.0,
                        "engagementHint",     shortTurnRatio > 0.5 ? "DISENGAGED" : "ENGAGED",
                        "calculatedAt",       Instant.now().toString()
                ));
    }
}
