package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-09: PHONE_BEHAVIOR_ANALYTICS_AGENT
 * Analyses learner in-call behaviour patterns: response latency,
 * topic avoidance, nervous markers, and engagement signals.
 * Feeds into adaptive prompting and learner risk flagging.
 */
@Component
public class PhoneBehaviorAnalyticsAgent {

    @Tool(name = "behavior_analyze_session",
          description = "Analyse learner behaviour signals from a completed phone assessment session.")
    public AgentResponse analyzeSession(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Average response latency after prompts in seconds") double avgResponseLatencySec,
            @ToolParam(description = "Number of topic-avoidance deflections detected") int topicDeflections,
            @ToolParam(description = "Filler word count (um, uh, err)") int fillerCount,
            @ToolParam(description = "Number of self-corrections made by the learner") int selfCorrections,
            @ToolParam(description = "Number of clarification requests made") int clarificationRequests) {

        String anxietyLevel = fillerCount > 20 && avgResponseLatencySec > 3.0 ? "HIGH"
                            : fillerCount > 10 || avgResponseLatencySec > 2.0  ? "MEDIUM"
                            : "LOW";

        String engagementLevel = topicDeflections > 3 ? "DISENGAGED"
                               : selfCorrections > 5  ? "HIGHLY_ENGAGED"
                               : "ENGAGED";

        return AgentResponse.ok("PHONE_BEHAVIOR_ANALYTICS_AGENT",
                "Behaviour analytics completed for session " + sessionId,
                Map.of(
                        "sessionId",               sessionId,
                        "learnerId",               learnerId,
                        "avgResponseLatencySec",   avgResponseLatencySec,
                        "topicDeflections",        topicDeflections,
                        "fillerCount",             fillerCount,
                        "selfCorrections",         selfCorrections,
                        "clarificationRequests",   clarificationRequests,
                        "anxietyLevel",            anxietyLevel,
                        "engagementLevel",         engagementLevel,
                        "riskFlags",               anxietyLevel.equals("HIGH") ? List.of("HIGH_ANXIETY") : List.of(),
                        "analyzedAt",              Instant.now().toString()
                ));
    }

    @Tool(name = "behavior_trend_report",
          description = "Generate a multi-session behaviour trend report for a learner.")
    public AgentResponse trendReport(
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Number of recent sessions to analyse") int sessionCount) {

        return AgentResponse.ok("PHONE_BEHAVIOR_ANALYTICS_AGENT",
                "Behaviour trend report for learner " + learnerId,
                Map.of(
                        "learnerId",         learnerId,
                        "sessionCount",      sessionCount,
                        "anxietyTrend",      "DECREASING",
                        "engagementTrend",   "INCREASING",
                        "fillerTrend",       "IMPROVING",
                        "latencyTrend",      "STABLE",
                        "overallProgression","POSITIVE",
                        "generatedAt",       Instant.now().toString()
                ));
    }
}
