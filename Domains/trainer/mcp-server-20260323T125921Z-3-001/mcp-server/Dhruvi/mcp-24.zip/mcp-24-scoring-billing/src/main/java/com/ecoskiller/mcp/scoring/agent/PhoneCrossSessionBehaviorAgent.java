package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-11: PHONE_CROSS_SESSION_BEHAVIOR_AGENT
 * Detects anomalous behaviour patterns that span multiple sessions:
 * sudden score spikes, identical answer patterns, and ghost attendance.
 * Flags potential impersonation or coaching assistance.
 */
@Component
public class PhoneCrossSessionBehaviorAgent {

    @Tool(name = "cross_session_anomaly_detect",
          description = "Detect anomalous cross-session behaviour patterns for a learner.")
    public AgentResponse detectAnomalies(
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Number of recent sessions to analyse") int sessionWindow,
            @ToolParam(description = "Scores in chronological order (comma-separated, e.g. '45,47,46,89,91')") String sessionScores,
            @ToolParam(description = "Whether voice biometric match failed in any recent session") boolean voiceMismatchDetected,
            @ToolParam(description = "Whether identical answer sequences were detected across sessions") boolean identicalAnswerPattern) {

        String[] scoreArr = sessionScores.split(",");
        double maxJump = 0;
        for (int i = 1; i < scoreArr.length; i++) {
            double jump = Double.parseDouble(scoreArr[i].trim()) - Double.parseDouble(scoreArr[i-1].trim());
            if (jump > maxJump) maxJump = jump;
        }

        boolean scoreSpikeDetected = maxJump >= 20.0;
        List<String> anomalies     = new java.util.ArrayList<>();
        if (scoreSpikeDetected)      anomalies.add("SUDDEN_SCORE_SPIKE +" + Math.round(maxJump));
        if (voiceMismatchDetected)   anomalies.add("VOICE_BIOMETRIC_MISMATCH");
        if (identicalAnswerPattern)  anomalies.add("IDENTICAL_ANSWER_PATTERN");

        String riskLevel = anomalies.size() >= 2 ? "HIGH"
                         : anomalies.size() == 1 ? "MEDIUM"
                         : "LOW";

        return AgentResponse.ok("PHONE_CROSS_SESSION_BEHAVIOR_AGENT",
                "Cross-session anomaly check for learner " + learnerId,
                Map.of(
                        "learnerId",          learnerId,
                        "sessionWindow",      sessionWindow,
                        "anomaliesDetected",  anomalies,
                        "riskLevel",          riskLevel,
                        "maxScoreJump",       maxJump,
                        "action",             riskLevel.equals("HIGH") ? "FLAG_FOR_REVIEW" : "LOG_AND_MONITOR",
                        "analyzedAt",         Instant.now().toString()
                ));
    }

    @Tool(name = "cross_session_learning_curve",
          description = "Generate a learning curve analysis across sessions to validate expected score progression.")
    public AgentResponse learningCurveAnalysis(
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Session count") int sessionCount,
            @ToolParam(description = "Expected weekly improvement rate percent (e.g. 2.5)") double expectedWeeklyImprovementPct,
            @ToolParam(description = "Observed weekly improvement rate percent") double observedWeeklyImprovementPct) {

        double deviation = Math.abs(observedWeeklyImprovementPct - expectedWeeklyImprovementPct);
        String progressionType = deviation <= 2.0 ? "NORMAL"
                               : observedWeeklyImprovementPct > expectedWeeklyImprovementPct + 5 ? "UNUSUALLY_FAST"
                               : "UNUSUALLY_SLOW";

        return AgentResponse.ok("PHONE_CROSS_SESSION_BEHAVIOR_AGENT",
                "Learning curve analysis for learner " + learnerId,
                Map.of(
                        "learnerId",                    learnerId,
                        "sessionCount",                 sessionCount,
                        "expectedWeeklyImprovementPct", expectedWeeklyImprovementPct,
                        "observedWeeklyImprovementPct", observedWeeklyImprovementPct,
                        "deviationPct",                 Math.round(deviation * 10.0) / 10.0,
                        "progressionType",              progressionType,
                        "flagForReview",                progressionType.equals("UNUSUALLY_FAST"),
                        "analyzedAt",                   Instant.now().toString()
                ));
    }
}
