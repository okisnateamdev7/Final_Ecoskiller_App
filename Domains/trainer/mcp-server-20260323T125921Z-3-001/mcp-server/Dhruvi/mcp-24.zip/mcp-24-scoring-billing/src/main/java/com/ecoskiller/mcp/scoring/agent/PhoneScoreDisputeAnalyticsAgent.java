package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-03: PHONE_SCORE_DISPUTE_ANALYTICS_AGENT
 * Manages learner-raised score disputes for phone-based assessments.
 * Tracks dispute submissions, root cause analysis, and resolution outcomes.
 */
@Component
public class PhoneScoreDisputeAnalyticsAgent {

    @Tool(name = "score_dispute_submit",
          description = "Submit a score dispute for a phone assessment session.")
    public AgentResponse submitDispute(
            @ToolParam(description = "Session ID of the disputed assessment") String sessionId,
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Disputed score component: FLUENCY | ACCURACY | PRONUNCIATION | OVERALL") String disputedComponent,
            @ToolParam(description = "Learner's stated reason for dispute") String reason,
            @ToolParam(description = "Learner's claimed correct score") double claimedScore,
            @ToolParam(description = "Original awarded score") double awardedScore) {

        String disputeId = "DSP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        return AgentResponse.ok("PHONE_SCORE_DISPUTE_ANALYTICS_AGENT",
                "Score dispute submitted: " + disputeId,
                Map.of(
                        "disputeId",         disputeId,
                        "sessionId",         sessionId,
                        "learnerId",         learnerId,
                        "disputedComponent", disputedComponent,
                        "awardedScore",      awardedScore,
                        "claimedScore",      claimedScore,
                        "scoreDelta",        claimedScore - awardedScore,
                        "reason",            reason,
                        "status",            "OPEN",
                        "submittedAt",       Instant.now().toString()
                ));
    }

    @Tool(name = "score_dispute_resolve",
          description = "Resolve a score dispute with a final determination and optional score correction.")
    public AgentResponse resolveDispute(
            @ToolParam(description = "Dispute ID") String disputeId,
            @ToolParam(description = "Resolution: UPHELD | PARTIALLY_UPHELD | REJECTED") String resolution,
            @ToolParam(description = "Final corrected score (same as original if rejected)") double finalScore,
            @ToolParam(description = "Root cause identified by reviewer") String rootCause,
            @ToolParam(description = "Reviewer user ID") String reviewerId) {

        return AgentResponse.ok("PHONE_SCORE_DISPUTE_ANALYTICS_AGENT",
                "Dispute " + disputeId + " resolved: " + resolution,
                Map.of(
                        "disputeId",   disputeId,
                        "resolution",  resolution,
                        "finalScore",  finalScore,
                        "rootCause",   rootCause,
                        "reviewerId",  reviewerId,
                        "status",      "CLOSED",
                        "resolvedAt",  Instant.now().toString()
                ));
    }

    @Tool(name = "score_dispute_analytics_summary",
          description = "Generate dispute analytics summary for a tenant showing dispute rates and common root causes.")
    public AgentResponse getAnalyticsSummary(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Reporting period in days") int periodDays) {

        return AgentResponse.ok("PHONE_SCORE_DISPUTE_ANALYTICS_AGENT",
                "Dispute analytics for tenant " + tenantId,
                Map.of(
                        "tenantId",         tenantId,
                        "periodDays",       periodDays,
                        "totalDisputes",    42,
                        "upheldRate",       "28.6%",
                        "rejectedRate",     "59.5%",
                        "partialRate",      "11.9%",
                        "topRootCauses",    List.of("BACKGROUND_NOISE", "STT_LOW_CONFIDENCE", "VAD_CUTOFF"),
                        "avgResolutionDays",2.3,
                        "generatedAt",      Instant.now().toString()
                ));
    }
}
