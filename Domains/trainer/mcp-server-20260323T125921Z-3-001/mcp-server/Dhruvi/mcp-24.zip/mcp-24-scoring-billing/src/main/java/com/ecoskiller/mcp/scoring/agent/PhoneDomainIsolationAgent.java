package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-13: PHONE_DOMAIN_ISOLATION_AGENT
 * Ensures that scoring models, language models, and assessment content
 * are isolated per academic domain (e.g. K-12, Corporate, Medical).
 * Prevents domain bleed in multi-tenant multi-domain deployments.
 */
@Component
public class PhoneDomainIsolationAgent {

    @Tool(name = "domain_isolation_check",
          description = "Verify that a session's resources (model, content, prompts) are scoped to the correct domain.")
    public AgentResponse checkDomainIsolation(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Expected domain: K12 | CORPORATE | MEDICAL | LEGAL | GENERAL") String expectedDomain,
            @ToolParam(description = "Scoring model's declared domain") String modelDomain,
            @ToolParam(description = "Content pack's declared domain") String contentDomain,
            @ToolParam(description = "Language model's declared domain") String languageModelDomain) {

        boolean modelMatch    = expectedDomain.equalsIgnoreCase(modelDomain) || modelDomain.equalsIgnoreCase("GENERAL");
        boolean contentMatch  = expectedDomain.equalsIgnoreCase(contentDomain) || contentDomain.equalsIgnoreCase("GENERAL");
        boolean lmMatch       = expectedDomain.equalsIgnoreCase(languageModelDomain) || languageModelDomain.equalsIgnoreCase("GENERAL");
        boolean isolated      = modelMatch && contentMatch && lmMatch;

        List<String> mismatches = new java.util.ArrayList<>();
        if (!modelMatch)   mismatches.add("SCORING_MODEL_DOMAIN_MISMATCH (" + modelDomain + ")");
        if (!contentMatch) mismatches.add("CONTENT_PACK_DOMAIN_MISMATCH (" + contentDomain + ")");
        if (!lmMatch)      mismatches.add("LANGUAGE_MODEL_DOMAIN_MISMATCH (" + languageModelDomain + ")");

        return AgentResponse.ok("PHONE_DOMAIN_ISOLATION_AGENT",
                isolated ? "Domain isolation verified" : "Domain isolation FAILED",
                Map.of(
                        "sessionId",      sessionId,
                        "expectedDomain", expectedDomain,
                        "isolated",       isolated,
                        "mismatches",     mismatches,
                        "action",         isolated ? "ALLOW" : "BLOCK_SESSION",
                        "checkedAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "domain_content_classify",
          description = "Classify a content item's domain to ensure correct isolation assignment.")
    public AgentResponse classifyContent(
            @ToolParam(description = "Content item ID") String contentId,
            @ToolParam(description = "Content title or description") String contentDescription,
            @ToolParam(description = "Current assigned domain") String currentDomain) {

        // Heuristic domain detection from description keywords
        String detected = contentDescription.toLowerCase().contains("patient")    ? "MEDICAL"
                        : contentDescription.toLowerCase().contains("clause")     ? "LEGAL"
                        : contentDescription.toLowerCase().contains("quarterly")  ? "CORPORATE"
                        : contentDescription.toLowerCase().contains("student")    ? "K12"
                        : "GENERAL";

        boolean domainMismatch = !detected.equalsIgnoreCase(currentDomain) && !currentDomain.equalsIgnoreCase("GENERAL");

        return AgentResponse.ok("PHONE_DOMAIN_ISOLATION_AGENT",
                "Content " + contentId + " classified as " + detected,
                Map.of(
                        "contentId",      contentId,
                        "currentDomain",  currentDomain,
                        "detectedDomain", detected,
                        "mismatch",       domainMismatch,
                        "action",         domainMismatch ? "RECLASSIFY_CONTENT" : "CONFIRMED",
                        "classifiedAt",   Instant.now().toString()
                ));
    }
}
