package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-10: PHONE_PARTICIPATION_REPUTATION_AGENT
 * Maintains a reputation score per learner based on their historical
 * participation quality across phone sessions. Factors: completion rate,
 * no-show rate, dispute rate, and engagement consistency.
 */
@Component
public class PhoneParticipationReputationAgent {

    @Tool(name = "reputation_score_compute",
          description = "Compute a learner's participation reputation score from historical session data.")
    public AgentResponse computeReputationScore(
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Total scheduled sessions") int scheduledSessions,
            @ToolParam(description = "Completed sessions") int completedSessions,
            @ToolParam(description = "No-show sessions") int noShowSessions,
            @ToolParam(description = "Disputed scores count") int disputesRaised,
            @ToolParam(description = "Disputes found invalid (rejected)") int disputesRejected) {

        double completionRate  = scheduledSessions > 0 ? (double) completedSessions / scheduledSessions : 0.0;
        double noShowRate      = scheduledSessions > 0 ? (double) noShowSessions / scheduledSessions : 0.0;
        double disputeAbusePct = disputesRaised > 0 ? (double) disputesRejected / disputesRaised : 0.0;

        double reputationScore = (completionRate * 50)
                               - (noShowRate * 30)
                               - (disputeAbusePct * 20);

        reputationScore = Math.max(0, Math.min(100, reputationScore * 100.0 / 50.0));

        String tier = reputationScore >= 80 ? "GOLD"
                    : reputationScore >= 60 ? "SILVER"
                    : reputationScore >= 40 ? "BRONZE"
                    : "AT_RISK";

        return AgentResponse.ok("PHONE_PARTICIPATION_REPUTATION_AGENT",
                "Reputation score computed for learner " + learnerId,
                Map.of(
                        "learnerId",       learnerId,
                        "reputationScore", Math.round(reputationScore * 10.0) / 10.0,
                        "tier",            tier,
                        "completionRate",  Math.round(completionRate * 1000.0) / 10.0,
                        "noShowRate",      Math.round(noShowRate * 1000.0) / 10.0,
                        "disputeAbusePct", Math.round(disputeAbusePct * 1000.0) / 10.0,
                        "computedAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "reputation_penalty_apply",
          description = "Apply a reputation penalty to a learner for a specific infraction.")
    public AgentResponse applyPenalty(
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Infraction type: NO_SHOW | ABUSE_DISPUTE | DISRUPTIVE_BEHAVIOR | CHEATING_ATTEMPT") String infractionType,
            @ToolParam(description = "Penalty points to deduct (1–20)") int penaltyPoints,
            @ToolParam(description = "Evidence reference ID") String evidenceRef) {

        return AgentResponse.ok("PHONE_PARTICIPATION_REPUTATION_AGENT",
                "Reputation penalty applied to learner " + learnerId,
                Map.of(
                        "learnerId",      learnerId,
                        "infractionType", infractionType,
                        "penaltyPoints",  penaltyPoints,
                        "evidenceRef",    evidenceRef,
                        "appliedAt",      Instant.now().toString()
                ));
    }
}
