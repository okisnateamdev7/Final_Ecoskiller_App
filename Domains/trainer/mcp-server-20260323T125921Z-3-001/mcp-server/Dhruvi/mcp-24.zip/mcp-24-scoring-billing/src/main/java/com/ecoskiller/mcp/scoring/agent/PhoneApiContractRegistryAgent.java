package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-32: PHONE_API_CONTRACT_REGISTRY_AGENT
 * Manages the registry of API contracts (OpenAPI specs) between
 * phone platform services. Detects breaking changes, validates
 * consumer compatibility, and triggers contract test pipelines.
 */
@Component
public class PhoneApiContractRegistryAgent {

    @Tool(name = "api_contract_register",
          description = "Register or update an OpenAPI contract for a phone platform service.")
    public AgentResponse registerContract(
            @ToolParam(description = "Service name (e.g. mcp-23b-audio)") String serviceName,
            @ToolParam(description = "API version (e.g. v2.1)") String apiVersion,
            @ToolParam(description = "OpenAPI spec URL or inline spec identifier") String specRef,
            @ToolParam(description = "Previous version this replaces (null if new)") String previousVersion,
            @ToolParam(description = "Has breaking changes compared to previous version") boolean breakingChange) {

        String contractId = "CONTRACT-" + serviceName.toUpperCase().replace("-", "_") + "-" + apiVersion;

        return AgentResponse.ok("PHONE_API_CONTRACT_REGISTRY_AGENT",
                "API contract registered: " + contractId,
                Map.of(
                        "contractId",     contractId,
                        "serviceName",    serviceName,
                        "apiVersion",     apiVersion,
                        "specRef",        specRef,
                        "previousVersion",previousVersion != null ? previousVersion : "NONE",
                        "breakingChange", breakingChange,
                        "status",         breakingChange ? "PENDING_CONSUMER_APPROVAL" : "ACTIVE",
                        "registeredAt",   Instant.now().toString()
                ));
    }

    @Tool(name = "api_contract_breaking_change_check",
          description = "Check if a proposed API change is breaking for registered consumers.")
    public AgentResponse checkBreakingChange(
            @ToolParam(description = "Service name") String serviceName,
            @ToolParam(description = "Current API version") String currentVersion,
            @ToolParam(description = "Proposed new version") String newVersion,
            @ToolParam(description = "Changed endpoint path") String endpointPath,
            @ToolParam(description = "Change type: FIELD_REMOVED | TYPE_CHANGED | ENDPOINT_REMOVED | NEW_REQUIRED_FIELD") String changeType) {

        boolean breaking = List.of("FIELD_REMOVED", "TYPE_CHANGED", "ENDPOINT_REMOVED", "NEW_REQUIRED_FIELD").contains(changeType);

        return AgentResponse.ok("PHONE_API_CONTRACT_REGISTRY_AGENT",
                "Breaking change check: " + (breaking ? "BREAKING" : "NON_BREAKING"),
                Map.of(
                        "serviceName",     serviceName,
                        "currentVersion",  currentVersion,
                        "newVersion",      newVersion,
                        "endpointPath",    endpointPath,
                        "changeType",      changeType,
                        "breaking",        breaking,
                        "action",          breaking ? "NOTIFY_CONSUMERS_BEFORE_DEPLOY" : "SAFE_TO_DEPLOY",
                        "checkedAt",       Instant.now().toString()
                ));
    }

    @Tool(name = "api_contract_registry_list",
          description = "List all registered API contracts for phone platform services.")
    public AgentResponse listContracts() {

        return AgentResponse.ok("PHONE_API_CONTRACT_REGISTRY_AGENT",
                "API contract registry retrieved",
                Map.of(
                        "contracts", List.of(
                                Map.of("service", "mcp-23b-audio",           "version", "v2.1", "status", "ACTIVE"),
                                Map.of("service", "mcp-24-scoring-billing",  "version", "v1.0", "status", "ACTIVE"),
                                Map.of("service", "mcp-17-royalty",          "version", "v1.0", "status", "ACTIVE"),
                                Map.of("service", "session-orchestrator",    "version", "v3.2", "status", "ACTIVE"),
                                Map.of("service", "learner-profile-service", "version", "v2.0", "status", "ACTIVE")
                        ),
                        "retrievedAt", Instant.now().toString()
                ));
    }
}
