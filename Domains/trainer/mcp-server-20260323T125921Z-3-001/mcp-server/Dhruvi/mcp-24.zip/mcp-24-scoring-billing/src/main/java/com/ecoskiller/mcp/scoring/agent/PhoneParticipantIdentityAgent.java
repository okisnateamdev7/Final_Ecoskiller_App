package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-19: PHONE_PARTICIPANT_IDENTITY_AGENT
 * Verifies and registers the identity of phone session participants
 * using voice biometrics, OTP, and caller-ID cross-checks.
 * Prevents impersonation and ghost attendance.
 */
@Component
public class PhoneParticipantIdentityAgent {

    @Tool(name = "participant_identity_verify",
          description = "Verify a phone participant's identity using available signals (voice biometric, OTP, caller-ID).")
    public AgentResponse verifyIdentity(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Claimed learner user ID") String claimedLearnerId,
            @ToolParam(description = "Caller phone number") String callerPhoneNumber,
            @ToolParam(description = "Registered phone number for learner") String registeredPhoneNumber,
            @ToolParam(description = "Voice biometric match score 0.0–1.0 (0 if not available)") double voiceBiometricScore,
            @ToolParam(description = "OTP verified: true if OTP was successfully validated") boolean otpVerified) {

        boolean phoneMatch   = callerPhoneNumber.equals(registeredPhoneNumber);
        boolean voiceMatch   = voiceBiometricScore >= 0.75;
        boolean identityConfirmed = otpVerified && phoneMatch;
        String confidenceLevel = identityConfirmed && voiceMatch ? "HIGH"
                               : identityConfirmed               ? "MEDIUM"
                               : "LOW";

        return AgentResponse.ok("PHONE_PARTICIPANT_IDENTITY_AGENT",
                "Identity verification: " + confidenceLevel,
                Map.of(
                        "sessionId",          sessionId,
                        "claimedLearnerId",   claimedLearnerId,
                        "phoneMatch",         phoneMatch,
                        "voiceBiometricScore",voiceBiometricScore,
                        "voiceMatch",         voiceMatch,
                        "otpVerified",        otpVerified,
                        "identityConfirmed",  identityConfirmed,
                        "confidenceLevel",    confidenceLevel,
                        "action",             identityConfirmed ? "ALLOW_SESSION" : "BLOCK_AND_ALERT",
                        "verifiedAt",         Instant.now().toString()
                ));
    }

    @Tool(name = "participant_identity_register",
          description = "Register a learner's voice biometric enrolment for future session identity verification.")
    public AgentResponse registerVoiceBiometric(
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Enrolment audio quality score 0–100") double enrolmentQuality,
            @ToolParam(description = "Number of voice samples provided (min 3 recommended)") int sampleCount) {

        boolean sufficient = enrolmentQuality >= 60 && sampleCount >= 3;
        String enrolId = "ENROL-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        return AgentResponse.ok("PHONE_PARTICIPANT_IDENTITY_AGENT",
                sufficient ? "Voice biometric enrolled for learner " + learnerId : "Enrolment quality insufficient",
                Map.of(
                        "enrolId",          enrolId,
                        "learnerId",        learnerId,
                        "enrolmentQuality", enrolmentQuality,
                        "sampleCount",      sampleCount,
                        "enrolled",         sufficient,
                        "minSamplesNeeded", sufficient ? 0 : 3 - sampleCount,
                        "enrolledAt",       Instant.now().toString()
                ));
    }
}
