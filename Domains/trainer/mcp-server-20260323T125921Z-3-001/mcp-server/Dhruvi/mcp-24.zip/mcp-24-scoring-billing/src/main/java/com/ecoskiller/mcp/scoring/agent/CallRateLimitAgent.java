package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-25: CALL_RATE_LIMIT_AGENT
 * Enforces concurrent call and per-minute call initiation rate limits
 * per tenant to prevent system overload and enforce fair usage.
 */
@Component
public class CallRateLimitAgent {

    @Tool(name = "call_rate_limit_check",
          description = "Check if a tenant is within their call rate limits before allowing a new session.")
    public AgentResponse checkRateLimit(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Current concurrent calls for this tenant") int currentConcurrentCalls,
            @ToolParam(description = "Max concurrent calls allowed for their plan") int maxConcurrentCalls,
            @ToolParam(description = "Calls initiated in last 60 seconds") int callsLastMinute,
            @ToolParam(description = "Max calls per minute allowed for their plan") int maxCallsPerMinute) {

        boolean concurrentOk = currentConcurrentCalls < maxConcurrentCalls;
        boolean rateOk       = callsLastMinute < maxCallsPerMinute;
        boolean allowed      = concurrentOk && rateOk;

        String limitHit = !concurrentOk ? "CONCURRENT_LIMIT"
                        : !rateOk       ? "RATE_LIMIT_PER_MINUTE"
                        : null;

        return AgentResponse.ok("CALL_RATE_LIMIT_AGENT",
                allowed ? "Rate limit check PASSED" : "Rate limit EXCEEDED: " + limitHit,
                Map.of(
                        "tenantId",              tenantId,
                        "allowed",               allowed,
                        "limitHit",              limitHit != null ? limitHit : "NONE",
                        "currentConcurrent",     currentConcurrentCalls,
                        "maxConcurrent",         maxConcurrentCalls,
                        "callsLastMinute",       callsLastMinute,
                        "maxCallsPerMinute",     maxCallsPerMinute,
                        "retryAfterSeconds",     allowed ? 0 : 60,
                        "checkedAt",             Instant.now().toString()
                ));
    }

    @Tool(name = "call_rate_limit_config",
          description = "Retrieve or update rate limit configuration for a tenant plan.")
    public AgentResponse getRateLimitConfig(
            @ToolParam(description = "Plan tier: FREE | STARTER | PROFESSIONAL | ENTERPRISE") String plan) {

        record Config(int concurrent, int perMinute, int perDay) {}
        Config cfg = switch (plan.toUpperCase()) {
            case "ENTERPRISE"   -> new Config(500, 100, 50000);
            case "PROFESSIONAL" -> new Config(100, 30,  10000);
            case "STARTER"      -> new Config(20,  10,  2000);
            default             -> new Config(2,   2,   100);
        };

        return AgentResponse.ok("CALL_RATE_LIMIT_AGENT",
                "Rate limit config for plan " + plan,
                Map.of(
                        "plan",              plan,
                        "maxConcurrent",     cfg.concurrent(),
                        "maxPerMinute",      cfg.perMinute(),
                        "maxPerDay",         cfg.perDay(),
                        "retrievedAt",       Instant.now().toString()
                ));
    }
}
