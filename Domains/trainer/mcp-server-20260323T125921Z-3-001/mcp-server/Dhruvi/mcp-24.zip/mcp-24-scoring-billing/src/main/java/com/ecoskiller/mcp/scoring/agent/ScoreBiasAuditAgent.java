package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-01: SCORE_BIAS_AUDIT_AGENT
 * Audits scoring model outputs for demographic and linguistic bias.
 * Compares score distributions across cohorts (gender, language, region)
 * and flags statistically significant disparities.
 */
@Component
public class ScoreBiasAuditAgent {

    @Tool(name = "score_bias_audit_run",
          description = "Run a bias audit on a scoring model across defined demographic cohorts.")
    public AgentResponse runBiasAudit(
            @ToolParam(description = "Scoring model ID to audit") String modelId,
            @ToolParam(description = "Cohort dimension: GENDER | LANGUAGE | REGION | AGE_GROUP") String cohortDimension,
            @ToolParam(description = "Evaluation dataset ID") String datasetId,
            @ToolParam(description = "Minimum acceptable score parity ratio (e.g. 0.80 = 80/100 rule)") double parityThreshold) {

        String auditId = "BIAS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        // Simulated cohort parity results
        double observedParity = 0.87;
        boolean biasDetected  = observedParity < parityThreshold;

        return AgentResponse.ok("SCORE_BIAS_AUDIT_AGENT",
                biasDetected ? "Bias detected in model " + modelId : "Model " + modelId + " passes bias audit",
                Map.of(
                        "auditId",          auditId,
                        "modelId",          modelId,
                        "cohortDimension",  cohortDimension,
                        "datasetId",        datasetId,
                        "parityThreshold",  parityThreshold,
                        "observedParity",   observedParity,
                        "biasDetected",     biasDetected,
                        "action",           biasDetected ? "FLAG_MODEL_FOR_RETRAINING" : "APPROVED",
                        "auditedAt",        Instant.now().toString()
                ));
    }

    @Tool(name = "score_bias_cohort_compare",
          description = "Compare mean scores between two cohorts and report statistical significance.")
    public AgentResponse compareCohorts(
            @ToolParam(description = "Model ID") String modelId,
            @ToolParam(description = "Cohort A label (e.g. MALE)") String cohortA,
            @ToolParam(description = "Cohort A mean score") double meanA,
            @ToolParam(description = "Cohort B label (e.g. FEMALE)") String cohortB,
            @ToolParam(description = "Cohort B mean score") double meanB,
            @ToolParam(description = "Sample size for significance test") int sampleSize) {

        double gap         = Math.abs(meanA - meanB);
        double pValue      = gap > 5.0 ? 0.02 : 0.18; // Simulated
        boolean significant = pValue < 0.05;

        return AgentResponse.ok("SCORE_BIAS_AUDIT_AGENT",
                "Cohort comparison: " + cohortA + " vs " + cohortB,
                Map.of(
                        "modelId",      modelId,
                        "cohortA",      cohortA,
                        "meanA",        meanA,
                        "cohortB",      cohortB,
                        "meanB",        meanB,
                        "scoreDelta",   gap,
                        "pValue",       pValue,
                        "significant",  significant,
                        "sampleSize",   sampleSize,
                        "verdict",      significant ? "STATISTICALLY_SIGNIFICANT_BIAS" : "WITHIN_ACCEPTABLE_VARIANCE",
                        "comparedAt",   Instant.now().toString()
                ));
    }

    @Tool(name = "score_bias_audit_history",
          description = "Retrieve historical bias audit results for a model to track improvement over time.")
    public AgentResponse getAuditHistory(
            @ToolParam(description = "Scoring model ID") String modelId,
            @ToolParam(description = "Number of most recent audits to return") int limit) {

        return AgentResponse.ok("SCORE_BIAS_AUDIT_AGENT",
                "Bias audit history for model " + modelId,
                Map.of(
                        "modelId", modelId,
                        "audits", List.of(
                                Map.of("auditId", "BIAS-A1B2C3D4", "date", Instant.now().minusSeconds(864000).toString(), "parity", 0.79, "result", "BIAS_DETECTED"),
                                Map.of("auditId", "BIAS-E5F6G7H8", "date", Instant.now().minusSeconds(432000).toString(), "parity", 0.83, "result", "BIAS_DETECTED"),
                                Map.of("auditId", "BIAS-I9J0K1L2", "date", Instant.now().minusSeconds(86400).toString(),  "parity", 0.87, "result", "APPROVED")
                        ),
                        "trend",       "IMPROVING",
                        "retrievedAt", Instant.now().toString()
                ));
    }
}
