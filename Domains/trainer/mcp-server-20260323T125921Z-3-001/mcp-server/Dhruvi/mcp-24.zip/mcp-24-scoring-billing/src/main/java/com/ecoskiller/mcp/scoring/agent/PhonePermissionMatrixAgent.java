package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-16: PHONE_PERMISSION_MATRIX_AGENT
 * Evaluates role-based access control (RBAC) permission matrix for
 * phone platform operations. Returns allow/deny decisions with
 * the matched policy rule for auditability.
 */
@Component
public class PhonePermissionMatrixAgent {

    @Tool(name = "permission_check",
          description = "Check if a role has permission to perform an action on a resource type.")
    public AgentResponse checkPermission(
            @ToolParam(description = "User ID requesting access") String userId,
            @ToolParam(description = "User role: LEARNER | ASSESSOR | SCHOOL_ADMIN | TENANT_ADMIN | SUPER_ADMIN") String role,
            @ToolParam(description = "Resource type: SESSION | SCORE | TRANSCRIPT | AUDIO | BILLING | USER_PROFILE") String resource,
            @ToolParam(description = "Action: READ | WRITE | DELETE | EXPORT | ADMIN") String action,
            @ToolParam(description = "Tenant ID scope") String tenantId) {

        boolean allowed = evaluatePermission(role, resource, action);
        String matchedPolicy = "RBAC-" + role + "-" + resource + "-" + action;

        return AgentResponse.ok("PHONE_PERMISSION_MATRIX_AGENT",
                allowed ? "Permission GRANTED" : "Permission DENIED",
                Map.of(
                        "userId",        userId,
                        "role",          role,
                        "resource",      resource,
                        "action",        action,
                        "tenantId",      tenantId,
                        "allowed",       allowed,
                        "matchedPolicy", matchedPolicy,
                        "checkedAt",     Instant.now().toString()
                ));
    }

    @Tool(name = "permission_matrix_list",
          description = "List the full permission matrix for a given role.")
    public AgentResponse listPermissions(
            @ToolParam(description = "Role to inspect: LEARNER | ASSESSOR | SCHOOL_ADMIN | TENANT_ADMIN | SUPER_ADMIN") String role) {

        Map<String, List<String>> matrix = switch (role.toUpperCase()) {
            case "LEARNER"      -> Map.of(
                    "SESSION",   List.of("READ"),
                    "SCORE",     List.of("READ"),
                    "TRANSCRIPT",List.of("READ"));
            case "ASSESSOR"     -> Map.of(
                    "SESSION",   List.of("READ", "WRITE"),
                    "SCORE",     List.of("READ", "WRITE"),
                    "TRANSCRIPT",List.of("READ", "WRITE"),
                    "AUDIO",     List.of("READ"));
            case "SCHOOL_ADMIN" -> Map.of(
                    "SESSION",   List.of("READ", "WRITE", "DELETE"),
                    "SCORE",     List.of("READ", "WRITE", "EXPORT"),
                    "USER_PROFILE", List.of("READ", "WRITE"),
                    "BILLING",   List.of("READ"));
            case "TENANT_ADMIN" -> Map.of(
                    "SESSION",   List.of("READ", "WRITE", "DELETE", "EXPORT"),
                    "SCORE",     List.of("READ", "WRITE", "DELETE", "EXPORT"),
                    "BILLING",   List.of("READ", "WRITE"),
                    "USER_PROFILE", List.of("READ", "WRITE", "DELETE", "ADMIN"));
            default             -> Map.of("ALL", List.of("READ", "WRITE", "DELETE", "EXPORT", "ADMIN"));
        };

        return AgentResponse.ok("PHONE_PERMISSION_MATRIX_AGENT",
                "Permission matrix for role " + role,
                Map.of(
                        "role",          role,
                        "permissions",   matrix,
                        "retrievedAt",   Instant.now().toString()
                ));
    }

    private boolean evaluatePermission(String role, String resource, String action) {
        if (role.equals("SUPER_ADMIN")) return true;
        if (role.equals("LEARNER") && (action.equals("WRITE") || action.equals("DELETE") || action.equals("ADMIN") || action.equals("EXPORT"))) return false;
        if (role.equals("ASSESSOR") && resource.equals("BILLING")) return false;
        return true;
    }
}
