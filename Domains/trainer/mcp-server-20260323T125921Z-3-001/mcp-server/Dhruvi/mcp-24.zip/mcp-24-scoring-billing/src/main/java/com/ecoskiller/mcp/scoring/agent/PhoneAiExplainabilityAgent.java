package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-08: PHONE_AI_EXPLAINABILITY_AGENT
 * Generates human-readable explanations for AI-produced phone assessment scores.
 * Surfaces top positive and negative score drivers and produces learner-friendly feedback.
 */
@Component
public class PhoneAiExplainabilityAgent {

    @Tool(name = "score_explain_generate",
          description = "Generate a human-readable explanation for an AI-produced phone assessment score.")
    public AgentResponse generateExplanation(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Overall score 0–100") double overallScore,
            @ToolParam(description = "Fluency sub-score") double fluencyScore,
            @ToolParam(description = "Accuracy sub-score") double accuracyScore,
            @ToolParam(description = "Pronunciation sub-score") double pronunciationScore,
            @ToolParam(description = "Vocabulary sub-score") double vocabularyScore) {

        String topStrength  = deriveTopFactor(fluencyScore, accuracyScore, pronunciationScore, vocabularyScore, true);
        String topWeakness  = deriveTopFactor(fluencyScore, accuracyScore, pronunciationScore, vocabularyScore, false);

        String feedbackText = "Your overall score is " + Math.round(overallScore) + "/100. "
                + "Your strongest area is " + topStrength.toLowerCase().replace("_", " ") + ". "
                + "Focus on improving " + topWeakness.toLowerCase().replace("_", " ") + " to raise your score.";

        return AgentResponse.ok("PHONE_AI_EXPLAINABILITY_AGENT",
                "Explanation generated for session " + sessionId,
                Map.of(
                        "sessionId",        sessionId,
                        "learnerId",        learnerId,
                        "overallScore",     overallScore,
                        "topStrength",      topStrength,
                        "topWeakness",      topWeakness,
                        "feedbackText",     feedbackText,
                        "scoreDrivers", Map.of(
                                "FLUENCY",       fluencyScore,
                                "ACCURACY",      accuracyScore,
                                "PRONUNCIATION", pronunciationScore,
                                "VOCABULARY",    vocabularyScore
                        ),
                        "generatedAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "score_explain_feature_importance",
          description = "Return SHAP-style feature importance values for a scored session.")
    public AgentResponse featureImportance(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Scoring model ID used") String modelId) {

        return AgentResponse.ok("PHONE_AI_EXPLAINABILITY_AGENT",
                "Feature importance for session " + sessionId,
                Map.of(
                        "sessionId",  sessionId,
                        "modelId",    modelId,
                        "features", List.of(
                                Map.of("feature", "speaking_rate_wpm",       "shapValue",  0.14, "direction", "POSITIVE"),
                                Map.of("feature", "filler_ratio",            "shapValue", -0.11, "direction", "NEGATIVE"),
                                Map.of("feature", "pronunciation_score",     "shapValue",  0.09, "direction", "POSITIVE"),
                                Map.of("feature", "vocabulary_diversity",    "shapValue",  0.08, "direction", "POSITIVE"),
                                Map.of("feature", "silence_ratio",           "shapValue", -0.07, "direction", "NEGATIVE"),
                                Map.of("feature", "avg_sentence_length",     "shapValue",  0.05, "direction", "POSITIVE")
                        ),
                        "generatedAt", Instant.now().toString()
                ));
    }

    private String deriveTopFactor(double f, double a, double p, double v, boolean highest) {
        Map<String, Double> scores = Map.of("FLUENCY", f, "ACCURACY", a, "PRONUNCIATION", p, "VOCABULARY", v);
        return scores.entrySet().stream()
                .sorted(highest
                        ? Map.Entry.<String, Double>comparingByValue().reversed()
                        : Map.Entry.comparingByValue())
                .findFirst().map(Map.Entry::getKey).orElse("UNKNOWN");
    }
}
