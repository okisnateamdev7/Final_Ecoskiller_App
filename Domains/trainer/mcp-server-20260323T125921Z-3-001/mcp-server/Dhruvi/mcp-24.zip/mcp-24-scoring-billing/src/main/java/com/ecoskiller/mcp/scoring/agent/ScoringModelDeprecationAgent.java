package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;

/**
 * AGENT-02: SCORING_MODEL_DEPRECATION_AGENT
 * Manages the lifecycle of scoring models: schedules deprecation,
 * notifies tenants of sunset dates, migrates active sessions to
 * successor models, and hard-retires deprecated models.
 */
@Component
public class ScoringModelDeprecationAgent {

    @Tool(name = "scoring_model_deprecate_schedule",
          description = "Schedule a scoring model for deprecation with a sunset date and successor model.")
    public AgentResponse scheduleDeprecation(
            @ToolParam(description = "Model ID to deprecate") String modelId,
            @ToolParam(description = "Successor model ID that replaces it") String successorModelId,
            @ToolParam(description = "Days until hard deprecation (e.g. 90)") int sunsetDays,
            @ToolParam(description = "Deprecation reason") String reason) {

        Instant sunsetDate = Instant.now().plus(sunsetDays, ChronoUnit.DAYS);

        return AgentResponse.ok("SCORING_MODEL_DEPRECATION_AGENT",
                "Model " + modelId + " scheduled for deprecation",
                Map.of(
                        "modelId",          modelId,
                        "successorModelId", successorModelId,
                        "sunsetDate",       sunsetDate.toString(),
                        "sunsetDays",       sunsetDays,
                        "reason",           reason,
                        "status",           "DEPRECATION_SCHEDULED",
                        "scheduledAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "scoring_model_tenant_notify",
          description = "Send deprecation notices to all tenants actively using a model slated for sunset.")
    public AgentResponse notifyTenants(
            @ToolParam(description = "Model ID being deprecated") String modelId,
            @ToolParam(description = "Sunset date in ISO-8601") String sunsetDate,
            @ToolParam(description = "Successor model ID") String successorModelId,
            @ToolParam(description = "Number of affected tenants") int affectedTenantCount) {

        return AgentResponse.ok("SCORING_MODEL_DEPRECATION_AGENT",
                "Deprecation notices sent for model " + modelId,
                Map.of(
                        "modelId",           modelId,
                        "successorModelId",  successorModelId,
                        "sunsetDate",        sunsetDate,
                        "affectedTenants",   affectedTenantCount,
                        "notificationsSent", affectedTenantCount,
                        "channel",           "EMAIL + IN_APP_BANNER",
                        "notifiedAt",        Instant.now().toString()
                ));
    }

    @Tool(name = "scoring_model_hard_retire",
          description = "Hard-retire a deprecated model — blocks all new scoring requests against it.")
    public AgentResponse hardRetire(
            @ToolParam(description = "Model ID to retire") String modelId,
            @ToolParam(description = "Confirmed by admin user ID") String adminUserId) {

        return AgentResponse.ok("SCORING_MODEL_DEPRECATION_AGENT",
                "Model " + modelId + " hard-retired",
                Map.of(
                        "modelId",     modelId,
                        "retiredBy",   adminUserId,
                        "status",      "RETIRED",
                        "retiredAt",   Instant.now().toString(),
                        "newRequests", "BLOCKED"
                ));
    }

    @Tool(name = "scoring_model_lifecycle_status",
          description = "Get the full lifecycle status of all scoring models (active, deprecated, retired).")
    public AgentResponse getLifecycleStatus() {

        return AgentResponse.ok("SCORING_MODEL_DEPRECATION_AGENT",
                "Scoring model lifecycle status retrieved",
                Map.of(
                        "models", List.of(
                                Map.of("modelId", "SCR-V1", "status", "RETIRED",              "retiredDate", "2024-01-01"),
                                Map.of("modelId", "SCR-V2", "status", "DEPRECATED",           "sunsetDate",  Instant.now().plus(30, ChronoUnit.DAYS).toString()),
                                Map.of("modelId", "SCR-V3", "status", "ACTIVE",               "launchedDate","2025-06-01"),
                                Map.of("modelId", "SCR-V4", "status", "BETA",                 "launchedDate", Instant.now().toString())
                        ),
                        "retrievedAt", Instant.now().toString()
                ));
    }
}
