package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-18: PHONE_FEATURE_GATING_AGENT
 * Controls feature flag evaluation for phone platform features.
 * Supports plan-based gating, percentage rollouts, and tenant allowlists.
 */
@Component
public class PhoneFeatureGatingAgent {

    @Tool(name = "feature_gate_check",
          description = "Check whether a feature is enabled for a given tenant, plan, and user context.")
    public AgentResponse checkFeatureGate(
            @ToolParam(description = "Feature flag key (e.g. REALTIME_FEEDBACK, AI_EXPLAINABILITY)") String featureKey,
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Tenant plan: FREE | STARTER | PROFESSIONAL | ENTERPRISE") String plan,
            @ToolParam(description = "User ID for percentage rollout targeting") String userId) {

        boolean enabled = evaluateGate(featureKey, plan);
        String gatingReason = enabled ? "PLAN_ENTITLEMENT" : "PLAN_INSUFFICIENT";

        return AgentResponse.ok("PHONE_FEATURE_GATING_AGENT",
                "Feature gate: " + featureKey + " is " + (enabled ? "ENABLED" : "DISABLED"),
                Map.of(
                        "featureKey",   featureKey,
                        "tenantId",     tenantId,
                        "plan",         plan,
                        "userId",       userId,
                        "enabled",      enabled,
                        "gatingReason", gatingReason,
                        "checkedAt",    Instant.now().toString()
                ));
    }

    @Tool(name = "feature_gate_override",
          description = "Set a temporary override for a feature flag for a specific tenant (for trials or support).")
    public AgentResponse setOverride(
            @ToolParam(description = "Feature flag key") String featureKey,
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Override value: ENABLED | DISABLED") String overrideValue,
            @ToolParam(description = "Override expiry in hours") int expiryHours,
            @ToolParam(description = "Reason for override") String reason) {

        Instant expiresAt = Instant.now().plusSeconds(expiryHours * 3600L);

        return AgentResponse.ok("PHONE_FEATURE_GATING_AGENT",
                "Feature gate override set: " + featureKey + " → " + overrideValue,
                Map.of(
                        "featureKey",    featureKey,
                        "tenantId",      tenantId,
                        "overrideValue", overrideValue,
                        "expiresAt",     expiresAt.toString(),
                        "reason",        reason,
                        "setAt",         Instant.now().toString()
                ));
    }

    @Tool(name = "feature_gate_plan_matrix",
          description = "List all feature flags and their availability by plan tier.")
    public AgentResponse getPlanMatrix() {

        return AgentResponse.ok("PHONE_FEATURE_GATING_AGENT",
                "Feature gate plan matrix retrieved",
                Map.of(
                        "features", List.of(
                                Map.of("key", "BASIC_STT",             "FREE", true,  "STARTER", true,  "PROFESSIONAL", true,  "ENTERPRISE", true),
                                Map.of("key", "REALTIME_FEEDBACK",     "FREE", false, "STARTER", true,  "PROFESSIONAL", true,  "ENTERPRISE", true),
                                Map.of("key", "AI_EXPLAINABILITY",     "FREE", false, "STARTER", false, "PROFESSIONAL", true,  "ENTERPRISE", true),
                                Map.of("key", "BIAS_AUDIT",            "FREE", false, "STARTER", false, "PROFESSIONAL", false, "ENTERPRISE", true),
                                Map.of("key", "DOJO_SYNC",             "FREE", false, "STARTER", true,  "PROFESSIONAL", true,  "ENTERPRISE", true),
                                Map.of("key", "CROSS_SESSION_ANALYSIS","FREE", false, "STARTER", false, "PROFESSIONAL", true,  "ENTERPRISE", true)
                        ),
                        "retrievedAt", Instant.now().toString()
                ));
    }

    private boolean evaluateGate(String feature, String plan) {
        return switch (plan.toUpperCase()) {
            case "ENTERPRISE"    -> true;
            case "PROFESSIONAL"  -> !feature.equals("BIAS_AUDIT");
            case "STARTER"       -> List.of("BASIC_STT", "REALTIME_FEEDBACK", "DOJO_SYNC").contains(feature);
            default              -> feature.equals("BASIC_STT");
        };
    }
}
