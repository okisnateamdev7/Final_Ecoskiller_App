package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-06: PHONE_MINIMUM_PARTICIPATION_AGENT
 * Enforces minimum participation thresholds before a phone session
 * is eligible for scoring. Prevents scoring of abandoned or silent sessions.
 */
@Component
public class PhoneMinimumParticipationAgent {

    @Tool(name = "participation_threshold_check",
          description = "Check if a phone session meets minimum participation thresholds for scoring eligibility.")
    public AgentResponse checkThreshold(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Learner net speaking time in seconds") int speakingTimeSec,
            @ToolParam(description = "Minimum required speaking time in seconds (e.g. 30)") int minSpeakingTimeSec,
            @ToolParam(description = "Number of learner turns completed") int turnsCompleted,
            @ToolParam(description = "Minimum required turns (e.g. 3)") int minTurns,
            @ToolParam(description = "Percentage of prompts answered (0–100)") double promptAnswerPct,
            @ToolParam(description = "Minimum required prompt answer percentage (e.g. 50.0)") double minPromptAnswerPct) {

        boolean speakingOk  = speakingTimeSec >= minSpeakingTimeSec;
        boolean turnsOk     = turnsCompleted >= minTurns;
        boolean promptsOk   = promptAnswerPct >= minPromptAnswerPct;
        boolean eligible    = speakingOk && turnsOk && promptsOk;

        String ineligibilityReason = !speakingOk ? "INSUFFICIENT_SPEAKING_TIME"
                                   : !turnsOk    ? "TOO_FEW_TURNS"
                                   : !promptsOk  ? "INSUFFICIENT_PROMPT_RESPONSES"
                                   : null;

        return AgentResponse.ok("PHONE_MINIMUM_PARTICIPATION_AGENT",
                eligible ? "Session " + sessionId + " eligible for scoring" : "Session ineligible: " + ineligibilityReason,
                Map.of(
                        "sessionId",          sessionId,
                        "eligible",           eligible,
                        "ineligibilityReason",ineligibilityReason != null ? ineligibilityReason : "NONE",
                        "speakingTimeSec",    speakingTimeSec,
                        "turnsCompleted",     turnsCompleted,
                        "promptAnswerPct",    promptAnswerPct,
                        "action",             eligible ? "PROCEED_TO_SCORING" : "MARK_INCOMPLETE",
                        "checkedAt",          Instant.now().toString()
                ));
    }

    @Tool(name = "participation_partial_credit",
          description = "Calculate partial credit for a session that partially meets minimum participation thresholds.")
    public AgentResponse calculatePartialCredit(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Actual speaking time in seconds") int actualSpeakingSec,
            @ToolParam(description = "Required speaking time in seconds") int requiredSpeakingSec,
            @ToolParam(description = "Actual turns completed") int actualTurns,
            @ToolParam(description = "Required turns") int requiredTurns) {

        double speakingCredit = Math.min(1.0, (double) actualSpeakingSec / requiredSpeakingSec);
        double turnsCredit    = Math.min(1.0, (double) actualTurns / requiredTurns);
        double partialCredit  = (speakingCredit + turnsCredit) / 2.0;

        return AgentResponse.ok("PHONE_MINIMUM_PARTICIPATION_AGENT",
                "Partial credit calculated for session " + sessionId,
                Map.of(
                        "sessionId",       sessionId,
                        "speakingCredit",  Math.round(speakingCredit * 100.0) / 100.0,
                        "turnsCredit",     Math.round(turnsCredit * 100.0) / 100.0,
                        "partialCredit",   Math.round(partialCredit * 100.0) / 100.0,
                        "partialCreditPct",Math.round(partialCredit * 1000.0) / 10.0,
                        "calculatedAt",    Instant.now().toString()
                ));
    }
}
