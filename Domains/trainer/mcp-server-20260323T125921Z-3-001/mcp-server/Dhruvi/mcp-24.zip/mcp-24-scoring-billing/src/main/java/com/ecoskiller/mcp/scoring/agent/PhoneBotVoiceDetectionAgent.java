package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-22: PHONE_BOT_VOICE_DETECTION_AGENT
 * Detects TTS-generated (bot) voice in phone assessments to prevent
 * learners from using AI voice assistants to answer prompts.
 * Uses prosodic flatness, spectral regularity, and timing uniformity signals.
 */
@Component
public class PhoneBotVoiceDetectionAgent {

    @Tool(name = "bot_voice_detect",
          description = "Detect whether a phone audio segment is from a human speaker or a TTS bot.")
    public AgentResponse detectBotVoice(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Audio segment ID") String segmentId,
            @ToolParam(description = "Prosodic flatness score 0.0–1.0 (1.0 = completely flat/robotic)") double prosodicFlatness,
            @ToolParam(description = "Spectral regularity score 0.0–1.0 (1.0 = perfectly regular = synthetic)") double spectralRegularity,
            @ToolParam(description = "Inter-word timing variance in ms (low variance = TTS)") double timingVarianceMs,
            @ToolParam(description = "Breathing artifacts detected (absent in TTS)") boolean breathingDetected) {

        double botProbability = (prosodicFlatness * 0.35)
                              + (spectralRegularity * 0.30)
                              + ((timingVarianceMs < 20 ? 0.9 : Math.max(0, 1.0 - timingVarianceMs / 100.0)) * 0.25)
                              + (breathingDetected ? 0.0 : 0.10);

        boolean botDetected = botProbability > 0.65;
        String confidence   = botProbability > 0.85 ? "HIGH"
                            : botProbability > 0.65 ? "MEDIUM"
                            : "LOW";

        return AgentResponse.ok("PHONE_BOT_VOICE_DETECTION_AGENT",
                botDetected ? "BOT VOICE DETECTED in segment " + segmentId : "Human voice confirmed",
                Map.of(
                        "sessionId",          sessionId,
                        "segmentId",          segmentId,
                        "botDetected",        botDetected,
                        "botProbability",     Math.round(botProbability * 1000.0) / 1000.0,
                        "confidence",         confidence,
                        "prosodicFlatness",   prosodicFlatness,
                        "spectralRegularity", spectralRegularity,
                        "timingVarianceMs",   timingVarianceMs,
                        "breathingDetected",  breathingDetected,
                        "action",             botDetected ? "FLAG_SESSION_FOR_REVIEW" : "ALLOW",
                        "detectedAt",         Instant.now().toString()
                ));
    }

    @Tool(name = "bot_voice_session_summary",
          description = "Summarise bot voice detection results across all segments in a session.")
    public AgentResponse sessionSummary(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Total segments analysed") int totalSegments,
            @ToolParam(description = "Segments flagged as bot voice") int botSegments) {

        double botRatio = totalSegments > 0 ? (double) botSegments / totalSegments : 0.0;
        String verdict  = botRatio >= 0.5 ? "LIKELY_BOT_ASSISTED"
                        : botRatio >= 0.2 ? "PARTIALLY_SUSPICIOUS"
                        : "HUMAN";

        return AgentResponse.ok("PHONE_BOT_VOICE_DETECTION_AGENT",
                "Bot voice summary for session " + sessionId + ": " + verdict,
                Map.of(
                        "sessionId",     sessionId,
                        "totalSegments", totalSegments,
                        "botSegments",   botSegments,
                        "botRatioPct",   Math.round(botRatio * 1000.0) / 10.0,
                        "verdict",       verdict,
                        "escalate",      verdict.equals("LIKELY_BOT_ASSISTED"),
                        "summarizedAt",  Instant.now().toString()
                ));
    }
}
