package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-07: OFFLINE_GO_TO_DOJO_SCORE_SYNC_AGENT
 * Synchronises scores from offline "Go-to-Dojo" physical practice sessions
 * back to the central learner profile. Handles conflict resolution when
 * both offline and online scores exist for the same period.
 */
@Component
public class OfflineGoToDojoScoreSyncAgent {

    @Tool(name = "dojo_score_sync_submit",
          description = "Submit an offline Dojo session score batch for synchronisation to the central system.")
    public AgentResponse submitSyncBatch(
            @ToolParam(description = "Dojo centre ID") String dojoCentreId,
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Offline session date (ISO-8601 date)") String sessionDate,
            @ToolParam(description = "Offline score achieved (0–100)") double offlineScore,
            @ToolParam(description = "Skill area: SPEAKING | PRONUNCIATION | VOCABULARY | GRAMMAR") String skillArea,
            @ToolParam(description = "Assessor staff ID who conducted the offline session") String assessorId) {

        String syncId = "SYNC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        return AgentResponse.ok("OFFLINE_GO_TO_DOJO_SCORE_SYNC_AGENT",
                "Offline Dojo score submitted for sync",
                Map.of(
                        "syncId",       syncId,
                        "dojoCentreId", dojoCentreId,
                        "learnerId",    learnerId,
                        "sessionDate",  sessionDate,
                        "offlineScore", offlineScore,
                        "skillArea",    skillArea,
                        "assessorId",   assessorId,
                        "syncStatus",   "QUEUED",
                        "submittedAt",  Instant.now().toString()
                ));
    }

    @Tool(name = "dojo_score_conflict_resolve",
          description = "Resolve a conflict between an offline Dojo score and an online score for the same period.")
    public AgentResponse resolveConflict(
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Skill area") String skillArea,
            @ToolParam(description = "Offline score") double offlineScore,
            @ToolParam(description = "Online score for the same period") double onlineScore,
            @ToolParam(description = "Conflict resolution policy: TAKE_HIGHER | TAKE_OFFLINE | TAKE_ONLINE | AVERAGE") String policy) {

        double resolvedScore = switch (policy.toUpperCase()) {
            case "TAKE_HIGHER"  -> Math.max(offlineScore, onlineScore);
            case "TAKE_OFFLINE" -> offlineScore;
            case "TAKE_ONLINE"  -> onlineScore;
            default             -> (offlineScore + onlineScore) / 2.0;
        };

        return AgentResponse.ok("OFFLINE_GO_TO_DOJO_SCORE_SYNC_AGENT",
                "Conflict resolved for learner " + learnerId + " using policy " + policy,
                Map.of(
                        "learnerId",      learnerId,
                        "skillArea",      skillArea,
                        "offlineScore",   offlineScore,
                        "onlineScore",    onlineScore,
                        "resolvedScore",  Math.round(resolvedScore * 10.0) / 10.0,
                        "policy",         policy,
                        "resolvedAt",     Instant.now().toString()
                ));
    }

    @Tool(name = "dojo_sync_status",
          description = "Get the synchronisation status of pending offline Dojo score batches for a centre.")
    public AgentResponse getSyncStatus(
            @ToolParam(description = "Dojo centre ID") String dojoCentreId) {

        return AgentResponse.ok("OFFLINE_GO_TO_DOJO_SCORE_SYNC_AGENT",
                "Sync status for Dojo centre " + dojoCentreId,
                Map.of(
                        "dojoCentreId",  dojoCentreId,
                        "pending",       7,
                        "synced",        142,
                        "failed",        1,
                        "lastSyncAt",    Instant.now().minusSeconds(1800).toString(),
                        "nextSyncAt",    Instant.now().plusSeconds(600).toString(),
                        "checkedAt",     Instant.now().toString()
                ));
    }
}
