package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-30: PHONE_RESOURCE_QUOTA_AGENT
 * Manages per-learner and per-school resource quotas for phone assessments:
 * daily attempt limits, cooldown periods, and retry windows.
 */
@Component
public class PhoneResourceQuotaAgent {

    @Tool(name = "learner_quota_check",
          description = "Check whether a learner has remaining quota to start a phone assessment session today.")
    public AgentResponse checkLearnerQuota(
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Assessment type: SPEAKING | PRONUNCIATION | FULL_TEST") String assessmentType,
            @ToolParam(description = "Attempts already used today") int attemptsToday,
            @ToolParam(description = "Max daily attempts allowed") int maxDailyAttempts,
            @ToolParam(description = "Minutes since last attempt (cooldown check)") int minutesSinceLastAttempt,
            @ToolParam(description = "Required cooldown period in minutes") int requiredCooldownMinutes) {

        boolean attemptOk  = attemptsToday < maxDailyAttempts;
        boolean cooldownOk = minutesSinceLastAttempt >= requiredCooldownMinutes;
        boolean allowed    = attemptOk && cooldownOk;

        String blockReason = !attemptOk  ? "DAILY_LIMIT_REACHED"
                           : !cooldownOk ? "COOLDOWN_PERIOD_ACTIVE"
                           : null;

        int cooldownRemainingMin = cooldownOk ? 0 : requiredCooldownMinutes - minutesSinceLastAttempt;

        return AgentResponse.ok("PHONE_RESOURCE_QUOTA_AGENT",
                allowed ? "Learner quota available" : "Learner quota blocked: " + blockReason,
                Map.of(
                        "learnerId",             learnerId,
                        "assessmentType",        assessmentType,
                        "allowed",               allowed,
                        "blockReason",           blockReason != null ? blockReason : "NONE",
                        "attemptsToday",         attemptsToday,
                        "maxDailyAttempts",      maxDailyAttempts,
                        "remainingAttempts",     Math.max(0, maxDailyAttempts - attemptsToday),
                        "cooldownRemainingMin",  cooldownRemainingMin,
                        "checkedAt",             Instant.now().toString()
                ));
    }

    @Tool(name = "school_quota_check",
          description = "Check whether a school has remaining concurrent session quota.")
    public AgentResponse checkSchoolQuota(
            @ToolParam(description = "School ID") String schoolId,
            @ToolParam(description = "Current active sessions for this school") int activeSessions,
            @ToolParam(description = "Max concurrent sessions allowed for this school's plan") int maxConcurrent) {

        boolean allowed = activeSessions < maxConcurrent;

        return AgentResponse.ok("PHONE_RESOURCE_QUOTA_AGENT",
                allowed ? "School quota available" : "School concurrent session limit reached",
                Map.of(
                        "schoolId",       schoolId,
                        "activeSessions", activeSessions,
                        "maxConcurrent",  maxConcurrent,
                        "available",      Math.max(0, maxConcurrent - activeSessions),
                        "allowed",        allowed,
                        "checkedAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "learner_quota_reset",
          description = "Manually reset a learner's daily quota (admin use only — e.g. after technical failure).")
    public AgentResponse resetQuota(
            @ToolParam(description = "Learner user ID") String learnerId,
            @ToolParam(description = "Assessment type to reset") String assessmentType,
            @ToolParam(description = "Admin user ID authorising reset") String adminId,
            @ToolParam(description = "Reason for manual reset") String reason) {

        return AgentResponse.ok("PHONE_RESOURCE_QUOTA_AGENT",
                "Quota reset for learner " + learnerId,
                Map.of(
                        "learnerId",      learnerId,
                        "assessmentType", assessmentType,
                        "adminId",        adminId,
                        "reason",         reason,
                        "resetStatus",    "COMPLETED",
                        "resetAt",        Instant.now().toString()
                ));
    }
}
