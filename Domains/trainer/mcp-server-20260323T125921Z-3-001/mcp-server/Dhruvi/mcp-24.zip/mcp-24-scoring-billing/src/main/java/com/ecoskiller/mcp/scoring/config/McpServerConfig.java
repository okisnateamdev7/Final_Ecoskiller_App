package com.ecoskiller.mcp.scoring.config;

import com.ecoskiller.mcp.scoring.agent.*;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Registers all 33 CAT-24 agents as MCP tools.
 */
@Configuration
public class McpServerConfig {

    @Bean
    public ToolCallbackProvider scoringBillingToolCallbacks(
            ScoreBiasAuditAgent                  scoreBiasAuditAgent,
            ScoringModelDeprecationAgent         scoringModelDeprecationAgent,
            PhoneScoreDisputeAnalyticsAgent      phoneScoreDisputeAnalyticsAgent,
            PhoneScoringInputSanitizerAgent      phoneScoringInputSanitizerAgent,
            PhoneSpeakingTimeAgent               phoneSpeakingTimeAgent,
            PhoneMinimumParticipationAgent       phoneMinimumParticipationAgent,
            OfflineGoToDojoScoreSyncAgent        offlineGoToDojoScoreSyncAgent,
            PhoneAiExplainabilityAgent           phoneAiExplainabilityAgent,
            PhoneBehaviorAnalyticsAgent          phoneBehaviorAnalyticsAgent,
            PhoneParticipationReputationAgent    phoneParticipationReputationAgent,
            PhoneCrossSessionBehaviorAgent       phoneCrossSessionBehaviorAgent,
            PhoneTenantBoundaryEnforcementAgent  phoneTenantBoundaryEnforcementAgent,
            PhoneDomainIsolationAgent            phoneDomainIsolationAgent,
            TenantAudioObjectIsolationAgent      tenantAudioObjectIsolationAgent,
            TenantTranscriptEncryptionAgent      tenantTranscriptEncryptionAgent,
            PhonePermissionMatrixAgent           phonePermissionMatrixAgent,
            PhoneRoleEscalationGuardAgent        phoneRoleEscalationGuardAgent,
            PhoneFeatureGatingAgent              phoneFeatureGatingAgent,
            PhoneParticipantIdentityAgent        phoneParticipantIdentityAgent,
            ShortLivedTokenRevocationAgent       shortLivedTokenRevocationAgent,
            HumanOverrideAuditAgent              humanOverrideAuditAgent,
            PhoneBotVoiceDetectionAgent          phoneBotVoiceDetectionAgent,
            PhoneTransparencyNotificationAgent   phoneTransparencyNotificationAgent,
            CallCostCalculationAgent             callCostCalculationAgent,
            CallRateLimitAgent                   callRateLimitAgent,
            HighUsageAlertAgent                  highUsageAlertAgent,
            TenantQuotaEnforcementAgent          tenantQuotaEnforcementAgent,
            SmsSegmentCalculationAgent           smsSegmentCalculationAgent,
            TelecomUsageReconciliationAgent      telecomUsageReconciliationAgent,
            PhoneResourceQuotaAgent              phoneResourceQuotaAgent,
            PhoneEventSchemaValidationAgent      phoneEventSchemaValidationAgent,
            PhoneApiContractRegistryAgent        phoneApiContractRegistryAgent,
            GlobalEventRegistrySyncAgent         globalEventRegistrySyncAgent) {

        return MethodToolCallbackProvider.builder()
                .toolObjects(
                        scoreBiasAuditAgent,
                        scoringModelDeprecationAgent,
                        phoneScoreDisputeAnalyticsAgent,
                        phoneScoringInputSanitizerAgent,
                        phoneSpeakingTimeAgent,
                        phoneMinimumParticipationAgent,
                        offlineGoToDojoScoreSyncAgent,
                        phoneAiExplainabilityAgent,
                        phoneBehaviorAnalyticsAgent,
                        phoneParticipationReputationAgent,
                        phoneCrossSessionBehaviorAgent,
                        phoneTenantBoundaryEnforcementAgent,
                        phoneDomainIsolationAgent,
                        tenantAudioObjectIsolationAgent,
                        tenantTranscriptEncryptionAgent,
                        phonePermissionMatrixAgent,
                        phoneRoleEscalationGuardAgent,
                        phoneFeatureGatingAgent,
                        phoneParticipantIdentityAgent,
                        shortLivedTokenRevocationAgent,
                        humanOverrideAuditAgent,
                        phoneBotVoiceDetectionAgent,
                        phoneTransparencyNotificationAgent,
                        callCostCalculationAgent,
                        callRateLimitAgent,
                        highUsageAlertAgent,
                        tenantQuotaEnforcementAgent,
                        smsSegmentCalculationAgent,
                        telecomUsageReconciliationAgent,
                        phoneResourceQuotaAgent,
                        phoneEventSchemaValidationAgent,
                        phoneApiContractRegistryAgent,
                        globalEventRegistrySyncAgent
                )
                .build();
    }
}
