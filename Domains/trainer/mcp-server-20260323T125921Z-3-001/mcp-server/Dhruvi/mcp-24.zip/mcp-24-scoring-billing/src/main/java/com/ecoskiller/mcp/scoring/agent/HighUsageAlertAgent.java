package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-26: HIGH_USAGE_ALERT_AGENT
 * Monitors tenant usage metrics and fires alerts when usage approaches
 * or exceeds plan quotas. Supports anomalous spike detection and
 * automated throttle recommendations.
 */
@Component
public class HighUsageAlertAgent {

    @Tool(name = "high_usage_check",
          description = "Check if a tenant's current usage is approaching or has exceeded plan thresholds.")
    public AgentResponse checkUsage(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Usage type: CALL_MINUTES | STT_MINUTES | SCORING_UNITS | STORAGE_GB") String usageType,
            @ToolParam(description = "Current usage value in this billing period") double currentUsage,
            @ToolParam(description = "Plan quota for this usage type") double planQuota,
            @ToolParam(description = "Warning threshold percent (e.g. 80.0)") double warningThresholdPct) {

        double usagePct = planQuota > 0 ? (currentUsage / planQuota) * 100 : 100;
        boolean exceeded = usagePct >= 100;
        boolean warning  = usagePct >= warningThresholdPct;

        String alertLevel = exceeded ? "QUOTA_EXCEEDED" : warning ? "WARNING" : "NORMAL";

        return AgentResponse.ok("HIGH_USAGE_ALERT_AGENT",
                "Usage check: " + alertLevel + " for " + usageType,
                Map.of(
                        "tenantId",           tenantId,
                        "usageType",          usageType,
                        "currentUsage",       currentUsage,
                        "planQuota",          planQuota,
                        "usagePct",           Math.round(usagePct * 10.0) / 10.0,
                        "alertLevel",         alertLevel,
                        "action",             exceeded ? "THROTTLE_AND_NOTIFY" : warning ? "NOTIFY_ONLY" : "NO_ACTION",
                        "checkedAt",          Instant.now().toString()
                ));
    }

    @Tool(name = "high_usage_spike_detect",
          description = "Detect anomalous usage spikes by comparing current usage to historical baseline.")
    public AgentResponse detectSpike(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Usage type") String usageType,
            @ToolParam(description = "Current hourly usage") double currentHourlyUsage,
            @ToolParam(description = "30-day average hourly usage baseline") double baselineHourlyUsage) {

        double spikeMultiple = baselineHourlyUsage > 0 ? currentHourlyUsage / baselineHourlyUsage : 1.0;
        boolean spikeDetected = spikeMultiple >= 3.0;

        return AgentResponse.ok("HIGH_USAGE_ALERT_AGENT",
                spikeDetected ? "Usage spike detected: " + Math.round(spikeMultiple * 10.0) / 10.0 + "x baseline" : "Usage normal",
                Map.of(
                        "tenantId",            tenantId,
                        "usageType",           usageType,
                        "currentHourly",       currentHourlyUsage,
                        "baseline",            baselineHourlyUsage,
                        "spikeMultiple",       Math.round(spikeMultiple * 10.0) / 10.0,
                        "spikeDetected",       spikeDetected,
                        "action",              spikeDetected ? "ALERT_AND_INVESTIGATE" : "LOG",
                        "checkedAt",           Instant.now().toString()
                ));
    }

    @Tool(name = "high_usage_tenant_dashboard",
          description = "Return a usage dashboard summary for a tenant across all metered resources.")
    public AgentResponse tenantDashboard(
            @ToolParam(description = "Tenant ID") String tenantId) {

        return AgentResponse.ok("HIGH_USAGE_ALERT_AGENT",
                "Usage dashboard for tenant " + tenantId,
                Map.of(
                        "tenantId", tenantId,
                        "usage", List.of(
                                Map.of("type", "CALL_MINUTES",   "used", 7240,  "quota", 10000, "pct", "72.4%"),
                                Map.of("type", "STT_MINUTES",    "used", 6890,  "quota", 10000, "pct", "68.9%"),
                                Map.of("type", "SCORING_UNITS",  "used", 14230, "quota", 20000, "pct", "71.2%"),
                                Map.of("type", "STORAGE_GB",     "used", 18.4,  "quota", 50,    "pct", "36.8%")
                        ),
                        "billingPeriodEnd",  Instant.now().plusSeconds(864000).toString(),
                        "retrievedAt",       Instant.now().toString()
                ));
    }
}
