package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-21: HUMAN_OVERRIDE_AUDIT_AGENT
 * Records and audits all human overrides to AI-generated scores.
 * Ensures every manual correction is traceable, justified, and
 * feeds back into model retraining pipelines.
 */
@Component
public class HumanOverrideAuditAgent {

    @Tool(name = "human_override_record",
          description = "Record a human reviewer's override of an AI-generated score with justification.")
    public AgentResponse recordOverride(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Reviewer user ID") String reviewerId,
            @ToolParam(description = "Score component overridden: FLUENCY | ACCURACY | PRONUNCIATION | OVERALL") String component,
            @ToolParam(description = "Original AI score") double aiScore,
            @ToolParam(description = "Human override score") double humanScore,
            @ToolParam(description = "Justification for the override") String justification) {

        String overrideId = "OVR-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        double delta = humanScore - aiScore;
        String direction = delta > 0 ? "UPWARD" : delta < 0 ? "DOWNWARD" : "UNCHANGED";

        return AgentResponse.ok("HUMAN_OVERRIDE_AUDIT_AGENT",
                "Human override recorded: " + overrideId,
                Map.of(
                        "overrideId",   overrideId,
                        "sessionId",    sessionId,
                        "reviewerId",   reviewerId,
                        "component",    component,
                        "aiScore",      aiScore,
                        "humanScore",   humanScore,
                        "delta",        Math.round(delta * 10.0) / 10.0,
                        "direction",    direction,
                        "justification",justification,
                        "flaggedForML", Math.abs(delta) > 10,
                        "recordedAt",   Instant.now().toString()
                ));
    }

    @Tool(name = "human_override_audit_report",
          description = "Generate an audit report of human overrides for a tenant and period.")
    public AgentResponse generateAuditReport(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Period in days") int periodDays) {

        return AgentResponse.ok("HUMAN_OVERRIDE_AUDIT_AGENT",
                "Override audit report for tenant " + tenantId,
                Map.of(
                        "tenantId",         tenantId,
                        "periodDays",       periodDays,
                        "totalOverrides",   28,
                        "upwardOverrides",  18,
                        "downwardOverrides",10,
                        "avgDelta",         3.7,
                        "largeDeltaFlags",  4,
                        "topReviewers",     List.of("REV-001", "REV-003", "REV-007"),
                        "mlFeedbackQueued", 4,
                        "generatedAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "human_override_ml_feedback_export",
          description = "Export flagged human overrides as labelled training data for scoring model retraining.")
    public AgentResponse exportMlFeedback(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Minimum score delta to include in export (e.g. 5.0)") double minDelta,
            @ToolParam(description = "Export format: JSONL | CSV") String format) {

        String exportId = "MLEXP-" + System.currentTimeMillis();

        return AgentResponse.ok("HUMAN_OVERRIDE_AUDIT_AGENT",
                "ML feedback export queued: " + exportId,
                Map.of(
                        "exportId",      exportId,
                        "tenantId",      tenantId,
                        "minDelta",      minDelta,
                        "format",        format,
                        "samplesQueued", 4,
                        "status",        "QUEUED",
                        "exportedAt",    Instant.now().toString()
                ));
    }
}
