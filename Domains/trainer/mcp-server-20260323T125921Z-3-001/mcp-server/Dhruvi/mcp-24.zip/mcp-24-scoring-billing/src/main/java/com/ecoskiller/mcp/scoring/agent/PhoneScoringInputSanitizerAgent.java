package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-04: PHONE_SCORING_INPUT_SANITIZER_AGENT
 * Validates and sanitizes all inputs to the phone scoring pipeline:
 * transcript payloads, session metadata, and scoring parameters.
 * Prevents injection, schema violations, and malformed payloads.
 */
@Component
public class PhoneScoringInputSanitizerAgent {

    @Tool(name = "scoring_input_sanitize",
          description = "Sanitize and validate a scoring input payload before it enters the scoring pipeline.")
    public AgentResponse sanitizeInput(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Transcript text payload to validate") String transcriptText,
            @ToolParam(description = "Word count in transcript") int wordCount,
            @ToolParam(description = "Session duration in seconds") int durationSeconds,
            @ToolParam(description = "Language code") String languageCode) {

        List<String> violations = new java.util.ArrayList<>();

        if (transcriptText == null || transcriptText.isBlank()) violations.add("EMPTY_TRANSCRIPT");
        if (wordCount < 5)                                        violations.add("TRANSCRIPT_TOO_SHORT");
        if (durationSeconds < 10)                                 violations.add("SESSION_TOO_SHORT");
        if (transcriptText != null && transcriptText.length() > 50000) violations.add("TRANSCRIPT_EXCEEDS_MAX_LENGTH");
        if (languageCode == null || languageCode.length() < 2)   violations.add("INVALID_LANGUAGE_CODE");

        boolean valid = violations.isEmpty();

        return AgentResponse.ok("PHONE_SCORING_INPUT_SANITIZER_AGENT",
                valid ? "Scoring input valid for session " + sessionId : "Input validation failed",
                Map.of(
                        "sessionId",      sessionId,
                        "valid",          valid,
                        "violations",     violations,
                        "wordCount",      wordCount,
                        "durationSec",    durationSeconds,
                        "languageCode",   languageCode,
                        "action",         valid ? "PROCEED_TO_SCORER" : "REJECT_INPUT",
                        "sanitizedAt",    Instant.now().toString()
                ));
    }

    @Tool(name = "scoring_parameter_validate",
          description = "Validate scoring configuration parameters (weights, thresholds) before applying to a session.")
    public AgentResponse validateParameters(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Fluency weight (0.0–1.0)") double fluencyWeight,
            @ToolParam(description = "Accuracy weight (0.0–1.0)") double accuracyWeight,
            @ToolParam(description = "Pronunciation weight (0.0–1.0)") double pronunciationWeight,
            @ToolParam(description = "Vocabulary weight (0.0–1.0)") double vocabularyWeight) {

        double totalWeight = fluencyWeight + accuracyWeight + pronunciationWeight + vocabularyWeight;
        boolean weightsValid = Math.abs(totalWeight - 1.0) < 0.001;
        boolean allPositive  = fluencyWeight >= 0 && accuracyWeight >= 0
                            && pronunciationWeight >= 0 && vocabularyWeight >= 0;

        List<String> errors = new java.util.ArrayList<>();
        if (!weightsValid)  errors.add("WEIGHTS_DO_NOT_SUM_TO_1 (sum=" + Math.round(totalWeight * 1000.0) / 1000.0 + ")");
        if (!allPositive)   errors.add("NEGATIVE_WEIGHT_DETECTED");

        return AgentResponse.ok("PHONE_SCORING_INPUT_SANITIZER_AGENT",
                errors.isEmpty() ? "Scoring parameters valid" : "Parameter validation failed",
                Map.of(
                        "sessionId",           sessionId,
                        "valid",               errors.isEmpty(),
                        "errors",              errors,
                        "totalWeight",         Math.round(totalWeight * 1000.0) / 1000.0,
                        "validatedAt",         Instant.now().toString()
                ));
    }

    @Tool(name = "scoring_payload_injection_check",
          description = "Scan a scoring payload for prompt injection, script injection, or malicious content patterns.")
    public AgentResponse checkInjection(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Raw payload text to scan") String payload) {

        boolean hasScript   = payload.matches("(?i).*<script.*?>.*</script>.*");
        boolean hasSqlInj   = payload.matches("(?i).*(drop table|select \\* from|union select).*");
        boolean hasPromptInj= payload.matches("(?i).*(ignore previous instructions|you are now|act as).*");
        boolean malicious   = hasScript || hasSqlInj || hasPromptInj;

        return AgentResponse.ok("PHONE_SCORING_INPUT_SANITIZER_AGENT",
                malicious ? "Malicious payload detected" : "Payload clean",
                Map.of(
                        "sessionId",      sessionId,
                        "malicious",      malicious,
                        "hasScript",      hasScript,
                        "hasSqlInjection",hasSqlInj,
                        "hasPromptInj",   hasPromptInj,
                        "action",         malicious ? "BLOCK_AND_LOG" : "ALLOW",
                        "scannedAt",      Instant.now().toString()
                ));
    }
}
