package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-17: PHONE_ROLE_ESCALATION_GUARD_AGENT
 * Detects and blocks unauthorised role escalation attempts.
 * Validates that role-change requests follow the approved escalation path
 * and are backed by proper approval workflows.
 */
@Component
public class PhoneRoleEscalationGuardAgent {

    @Tool(name = "role_escalation_validate",
          description = "Validate a role escalation request against the allowed escalation paths.")
    public AgentResponse validateEscalation(
            @ToolParam(description = "User ID requesting escalation") String userId,
            @ToolParam(description = "Current role") String currentRole,
            @ToolParam(description = "Requested target role") String targetRole,
            @ToolParam(description = "Approver user ID") String approverId,
            @ToolParam(description = "Approval ticket reference") String approvalTicket) {

        boolean validPath    = isValidEscalationPath(currentRole, targetRole);
        boolean hasApprover  = approverId != null && !approverId.isBlank();
        boolean hasTicket    = approvalTicket != null && !approvalTicket.isBlank();
        boolean allowed      = validPath && hasApprover && hasTicket;

        String denyReason = !validPath  ? "INVALID_ESCALATION_PATH"
                          : !hasApprover ? "MISSING_APPROVER"
                          : !hasTicket   ? "MISSING_APPROVAL_TICKET"
                          : null;

        return AgentResponse.ok("PHONE_ROLE_ESCALATION_GUARD_AGENT",
                allowed ? "Role escalation approved" : "Role escalation BLOCKED: " + denyReason,
                Map.of(
                        "userId",         userId,
                        "currentRole",    currentRole,
                        "targetRole",     targetRole,
                        "approverId",     approverId,
                        "approvalTicket", approvalTicket,
                        "allowed",        allowed,
                        "denyReason",     denyReason != null ? denyReason : "NONE",
                        "action",         allowed ? "APPLY_ROLE_CHANGE" : "BLOCK_AND_ALERT",
                        "validatedAt",    Instant.now().toString()
                ));
    }

    @Tool(name = "role_escalation_temp_grant",
          description = "Grant a temporary role escalation with an automatic expiry for break-glass scenarios.")
    public AgentResponse grantTemporaryEscalation(
            @ToolParam(description = "User ID") String userId,
            @ToolParam(description = "Temporary target role") String tempRole,
            @ToolParam(description = "Duration in minutes (max 480)") int durationMinutes,
            @ToolParam(description = "Break-glass justification") String justification,
            @ToolParam(description = "Authorising admin user ID") String adminId) {

        int safeDuration = Math.min(durationMinutes, 480);
        String grantId   = "TEMP-GRANT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        Instant expiresAt = Instant.now().plusSeconds(safeDuration * 60L);

        return AgentResponse.ok("PHONE_ROLE_ESCALATION_GUARD_AGENT",
                "Temporary role escalation granted for user " + userId,
                Map.of(
                        "grantId",        grantId,
                        "userId",         userId,
                        "tempRole",       tempRole,
                        "durationMinutes",safeDuration,
                        "expiresAt",      expiresAt.toString(),
                        "justification",  justification,
                        "authorisedBy",   adminId,
                        "autoRevoke",     true,
                        "grantedAt",      Instant.now().toString()
                ));
    }

    private boolean isValidEscalationPath(String from, String to) {
        return switch (from.toUpperCase()) {
            case "LEARNER"      -> to.equalsIgnoreCase("ASSESSOR");
            case "ASSESSOR"     -> to.equalsIgnoreCase("SCHOOL_ADMIN");
            case "SCHOOL_ADMIN" -> to.equalsIgnoreCase("TENANT_ADMIN");
            case "TENANT_ADMIN" -> to.equalsIgnoreCase("SUPER_ADMIN");
            default             -> false;
        };
    }
}
