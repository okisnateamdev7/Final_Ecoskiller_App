package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-20: SHORT_LIVED_TOKEN_REVOCATION_AGENT
 * Manages revocation of short-lived JWTs and session tokens for
 * phone assessment sessions. Maintains a revocation list and validates
 * tokens against it for zero-trust session continuity.
 */
@Component
public class ShortLivedTokenRevocationAgent {

    @Tool(name = "token_revoke",
          description = "Revoke a short-lived JWT or session token before its natural expiry.")
    public AgentResponse revokeToken(
            @ToolParam(description = "Token JTI (JWT ID) to revoke") String jti,
            @ToolParam(description = "Token type: SESSION | PRESIGNED_URL | API_KEY | MFA_TOKEN") String tokenType,
            @ToolParam(description = "Revocation reason: LOGOUT | SECURITY_INCIDENT | ADMIN_REVOKE | ROLE_CHANGE") String reason,
            @ToolParam(description = "Revoked by user/system ID") String revokedBy) {

        return AgentResponse.ok("SHORT_LIVED_TOKEN_REVOCATION_AGENT",
                "Token " + jti + " revoked",
                Map.of(
                        "jti",          jti,
                        "tokenType",    tokenType,
                        "reason",       reason,
                        "revokedBy",    revokedBy,
                        "status",       "REVOKED",
                        "addedToJrl",   true,
                        "revokedAt",    Instant.now().toString()
                ));
    }

    @Tool(name = "token_revocation_check",
          description = "Check if a token JTI is on the revocation list (JRL check).")
    public AgentResponse checkRevocation(
            @ToolParam(description = "Token JTI to check") String jti,
            @ToolParam(description = "Token type") String tokenType) {

        // Simulated: tokens starting with "REV" are revoked
        boolean revoked = jti.toUpperCase().startsWith("REV");

        return AgentResponse.ok("SHORT_LIVED_TOKEN_REVOCATION_AGENT",
                revoked ? "Token " + jti + " is REVOKED" : "Token " + jti + " is VALID",
                Map.of(
                        "jti",       jti,
                        "tokenType", tokenType,
                        "revoked",   revoked,
                        "action",    revoked ? "REJECT_REQUEST" : "ALLOW",
                        "checkedAt", Instant.now().toString()
                ));
    }

    @Tool(name = "token_revocation_bulk_user",
          description = "Bulk-revoke all active tokens for a user — used for account suspension or compromise.")
    public AgentResponse bulkRevokeUser(
            @ToolParam(description = "User ID whose tokens to revoke") String userId,
            @ToolParam(description = "Reason: ACCOUNT_SUSPENDED | SECURITY_BREACH | PASSWORD_RESET") String reason,
            @ToolParam(description = "Authorised by admin user ID") String adminId) {

        return AgentResponse.ok("SHORT_LIVED_TOKEN_REVOCATION_AGENT",
                "All tokens revoked for user " + userId,
                Map.of(
                        "userId",        userId,
                        "reason",        reason,
                        "adminId",       adminId,
                        "tokensRevoked", 7,
                        "types",         List.of("SESSION", "PRESIGNED_URL", "API_KEY"),
                        "revokedAt",     Instant.now().toString()
                ));
    }
}
