package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-29: TELECOM_USAGE_RECONCILIATION_AGENT
 * Reconciles internal call usage records against telecom carrier CDRs
 * (Call Detail Records). Detects billing discrepancies, unbilled sessions,
 * and overcharges from the carrier.
 */
@Component
public class TelecomUsageReconciliationAgent {

    @Tool(name = "telecom_reconcile_daily",
          description = "Reconcile internal CDRs with carrier billing records for a given date.")
    public AgentResponse reconcileDaily(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Reconciliation date (ISO-8601 date e.g. 2026-03-05)") String reconcileDate,
            @ToolParam(description = "Carrier name: AIRTEL | JIO | VODAFONE | TATA_COMM") String carrier,
            @ToolParam(description = "Internal recorded call minutes") double internalMinutes,
            @ToolParam(description = "Carrier billed call minutes") double carrierBilledMinutes) {

        double discrepancyMinutes = Math.abs(internalMinutes - carrierBilledMinutes);
        double discrepancyPct     = internalMinutes > 0
                ? (discrepancyMinutes / internalMinutes) * 100 : 0;
        boolean withinTolerance   = discrepancyPct <= 1.0;

        String reconcileId = "REC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        return AgentResponse.ok("TELECOM_USAGE_RECONCILIATION_AGENT",
                withinTolerance ? "Reconciliation PASSED for " + reconcileDate : "Discrepancy DETECTED for " + reconcileDate,
                Map.of(
                        "reconcileId",        reconcileId,
                        "tenantId",           tenantId,
                        "reconcileDate",      reconcileDate,
                        "carrier",            carrier,
                        "internalMinutes",    internalMinutes,
                        "carrierMinutes",     carrierBilledMinutes,
                        "discrepancyMinutes", Math.round(discrepancyMinutes * 100.0) / 100.0,
                        "discrepancyPct",     Math.round(discrepancyPct * 100.0) / 100.0,
                        "withinTolerance",    withinTolerance,
                        "action",             withinTolerance ? "APPROVED" : "RAISE_CARRIER_DISPUTE",
                        "reconciledAt",       Instant.now().toString()
                ));
    }

    @Tool(name = "telecom_unbilled_session_detect",
          description = "Detect internal call sessions that were not reflected in the carrier's CDR.")
    public AgentResponse detectUnbilledSessions(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Reconciliation period date") String date,
            @ToolParam(description = "Carrier") String carrier,
            @ToolParam(description = "Count of sessions in internal records") int internalSessionCount,
            @ToolParam(description = "Count of sessions in carrier CDR") int carrierCdrCount) {

        int delta = internalSessionCount - carrierCdrCount;
        boolean unbilledDetected = delta > 0;

        return AgentResponse.ok("TELECOM_USAGE_RECONCILIATION_AGENT",
                unbilledDetected ? delta + " unbilled sessions detected" : "All sessions accounted for",
                Map.of(
                        "tenantId",             tenantId,
                        "date",                 date,
                        "carrier",              carrier,
                        "internalSessionCount", internalSessionCount,
                        "carrierCdrCount",      carrierCdrCount,
                        "unbilledCount",        Math.max(0, delta),
                        "action",               unbilledDetected ? "ESCALATE_TO_CARRIER" : "RECONCILED",
                        "detectedAt",           Instant.now().toString()
                ));
    }
}
