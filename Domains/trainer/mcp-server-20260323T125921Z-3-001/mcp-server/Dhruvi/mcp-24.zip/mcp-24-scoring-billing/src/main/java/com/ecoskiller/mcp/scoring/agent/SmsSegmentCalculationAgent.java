package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-28: SMS_SEGMENT_CALCULATION_AGENT
 * Calculates the number of billable SMS segments for notification messages.
 * Handles GSM-7, Unicode (UCS-2), and EMS multi-part segment boundaries.
 * Used for billing reconciliation of SMS notifications.
 */
@Component
public class SmsSegmentCalculationAgent {

    @Tool(name = "sms_segment_calculate",
          description = "Calculate the number of SMS segments for a given message text and encoding.")
    public AgentResponse calculateSegments(
            @ToolParam(description = "Message text to calculate segments for") String messageText,
            @ToolParam(description = "Encoding: AUTO | GSM7 | UNICODE") String encoding,
            @ToolParam(description = "Sender country code (IN, US, GB, etc.)") String senderCountry) {

        boolean hasUnicode = !messageText.matches("[\\x00-\\x7F\\u00A3\\u00A5\\u00E8\\u00E9\\u00F9\\u00EC\\u00F2\\u00C7\\u000A\\u000D\\u0020-\\u007E]*");
        String effectiveEncoding = encoding.equals("AUTO") ? (hasUnicode ? "UNICODE" : "GSM7") : encoding;

        int charLimit1    = effectiveEncoding.equals("UNICODE") ? 70 : 160;
        int charLimitPart = effectiveEncoding.equals("UNICODE") ? 67 : 153;
        int len           = messageText.length();

        int segments = len <= charLimit1 ? 1 : (int) Math.ceil((double) len / charLimitPart);
        double costPerSegmentINR = senderCountry.equals("IN") ? 0.15 : 0.45;
        double totalCostINR      = segments * costPerSegmentINR;

        return AgentResponse.ok("SMS_SEGMENT_CALCULATION_AGENT",
                "SMS segments calculated: " + segments,
                Map.of(
                        "messageLength",      len,
                        "encoding",           effectiveEncoding,
                        "hasUnicode",         hasUnicode,
                        "segments",           segments,
                        "charLimit1Segment",  charLimit1,
                        "charLimitPerPart",   charLimitPart,
                        "senderCountry",      senderCountry,
                        "costPerSegmentINR",  costPerSegmentINR,
                        "totalCostINR",       Math.round(totalCostINR * 100.0) / 100.0,
                        "calculatedAt",       Instant.now().toString()
                ));
    }

    @Tool(name = "sms_bulk_cost_estimate",
          description = "Estimate the total SMS cost for a bulk notification campaign.")
    public AgentResponse bulkCostEstimate(
            @ToolParam(description = "Template message text") String templateText,
            @ToolParam(description = "Estimated number of recipients") int recipientCount,
            @ToolParam(description = "Sender country code") String senderCountry) {

        boolean hasUnicode = !templateText.matches("[\\x00-\\x7F]*");
        int charLimit1 = hasUnicode ? 70 : 160;
        int len        = templateText.length();
        int segments   = len <= charLimit1 ? 1 : (int) Math.ceil((double) len / (hasUnicode ? 67 : 153));
        double costPerSms = segments * (senderCountry.equals("IN") ? 0.15 : 0.45);
        double totalCost  = costPerSms * recipientCount;

        return AgentResponse.ok("SMS_SEGMENT_CALCULATION_AGENT",
                "Bulk SMS cost estimate: ₹" + Math.round(totalCost * 100.0) / 100.0,
                Map.of(
                        "recipientCount",  recipientCount,
                        "segmentsPerSms",  segments,
                        "costPerSmsINR",   Math.round(costPerSms * 100.0) / 100.0,
                        "totalCostINR",    Math.round(totalCost * 100.0) / 100.0,
                        "estimatedAt",     Instant.now().toString()
                ));
    }
}
