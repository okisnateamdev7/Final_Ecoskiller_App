package com.ecoskiller.mcp.scoring.agent;

import com.ecoskiller.mcp.scoring.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-27: TENANT_QUOTA_ENFORCEMENT_AGENT
 * Hard-enforces plan quotas for all metered resources.
 * Blocks operations when quotas are exhausted and manages
 * grace period, overage billing, and quota top-up flows.
 */
@Component
public class TenantQuotaEnforcementAgent {

    @Tool(name = "quota_enforce_check",
          description = "Hard-enforce quota check before a metered operation is allowed.")
    public AgentResponse enforceQuota(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Resource: CALL_MINUTES | STT_MINUTES | SCORING_UNITS | SESSIONS") String resource,
            @ToolParam(description = "Units requested for this operation") double unitsRequested,
            @ToolParam(description = "Current consumed units in billing period") double currentConsumed,
            @ToolParam(description = "Hard quota limit for this period") double hardLimit,
            @ToolParam(description = "Overage billing enabled for this tenant") boolean overageEnabled) {

        double remaining     = hardLimit - currentConsumed;
        boolean withinQuota  = remaining >= unitsRequested;
        boolean useOverage   = !withinQuota && overageEnabled;
        boolean allowed      = withinQuota || useOverage;

        return AgentResponse.ok("TENANT_QUOTA_ENFORCEMENT_AGENT",
                allowed ? "Quota check PASSED" : "Quota EXHAUSTED — operation BLOCKED",
                Map.of(
                        "tenantId",        tenantId,
                        "resource",        resource,
                        "unitsRequested",  unitsRequested,
                        "currentConsumed", currentConsumed,
                        "hardLimit",       hardLimit,
                        "remaining",       Math.max(0, remaining),
                        "allowed",         allowed,
                        "usingOverage",    useOverage,
                        "action",          allowed ? (useOverage ? "ALLOW_WITH_OVERAGE_CHARGE" : "ALLOW") : "BLOCK",
                        "checkedAt",       Instant.now().toString()
                ));
    }

    @Tool(name = "quota_topup_apply",
          description = "Apply a quota top-up purchase to a tenant's account mid-billing-cycle.")
    public AgentResponse applyTopUp(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Resource type") String resource,
            @ToolParam(description = "Top-up units purchased") double topUpUnits,
            @ToolParam(description = "Payment reference") String paymentRef) {

        return AgentResponse.ok("TENANT_QUOTA_ENFORCEMENT_AGENT",
                "Quota top-up applied for tenant " + tenantId,
                Map.of(
                        "tenantId",     tenantId,
                        "resource",     resource,
                        "topUpUnits",   topUpUnits,
                        "paymentRef",   paymentRef,
                        "newQuota",     "ORIGINAL_QUOTA + " + topUpUnits,
                        "appliedAt",    Instant.now().toString()
                ));
    }

    @Tool(name = "quota_reset_period",
          description = "Reset all metered quota counters for a tenant at the start of a new billing period.")
    public AgentResponse resetPeriod(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "New billing period start date (ISO-8601)") String periodStart,
            @ToolParam(description = "New billing period end date (ISO-8601)") String periodEnd) {

        return AgentResponse.ok("TENANT_QUOTA_ENFORCEMENT_AGENT",
                "Quota counters reset for tenant " + tenantId,
                Map.of(
                        "tenantId",    tenantId,
                        "periodStart", periodStart,
                        "periodEnd",   periodEnd,
                        "resetStatus", "COMPLETED",
                        "resources",   "CALL_MINUTES, STT_MINUTES, SCORING_UNITS, SESSIONS",
                        "resetAt",     Instant.now().toString()
                ));
    }
}
