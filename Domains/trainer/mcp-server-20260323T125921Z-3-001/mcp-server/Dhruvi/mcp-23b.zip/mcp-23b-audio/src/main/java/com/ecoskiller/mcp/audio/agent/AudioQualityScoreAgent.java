package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-03: AUDIO_QUALITY_SCORE_AGENT
 * Computes a composite audio quality score (0–100) from signal metrics:
 * SNR, MOS estimate, packet loss, jitter, and clipping ratio.
 */
@Component
public class AudioQualityScoreAgent {

    @Tool(name = "audio_quality_score",
          description = "Compute a composite audio quality score (0–100) from raw signal metrics.")
    public AgentResponse computeQualityScore(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Signal-to-Noise Ratio in dB") double snrDb,
            @ToolParam(description = "Estimated MOS (Mean Opinion Score) 1.0–5.0") double mosEstimate,
            @ToolParam(description = "Packet loss percentage 0–100") double packetLossPct,
            @ToolParam(description = "Jitter in milliseconds") double jitterMs,
            @ToolParam(description = "Clipping ratio 0.0–1.0 (fraction of clipped samples)") double clippingRatio) {

        // Weighted composite score calculation
        double snrScore      = Math.min(100, Math.max(0, (snrDb / 40.0) * 30));
        double mosScore      = ((mosEstimate - 1.0) / 4.0) * 30;
        double lossScore     = (1.0 - packetLossPct / 100.0) * 20;
        double jitterScore   = Math.max(0, (1.0 - jitterMs / 200.0)) * 10;
        double clippingScore = (1.0 - clippingRatio) * 10;

        double totalScore = snrScore + mosScore + lossScore + jitterScore + clippingScore;
        String grade = totalScore >= 85 ? "EXCELLENT"
                     : totalScore >= 70 ? "GOOD"
                     : totalScore >= 50 ? "FAIR"
                     : totalScore >= 30 ? "POOR"
                     : "UNUSABLE";

        return AgentResponse.ok("AUDIO_QUALITY_SCORE_AGENT",
                "Audio quality scored for session " + sessionId,
                Map.of(
                        "sessionId",       sessionId,
                        "qualityScore",    Math.round(totalScore * 10.0) / 10.0,
                        "grade",           grade,
                        "snrDb",           snrDb,
                        "mosEstimate",     mosEstimate,
                        "packetLossPct",   packetLossPct,
                        "jitterMs",        jitterMs,
                        "clippingRatio",   clippingRatio,
                        "sttRecommended",  totalScore >= 50,
                        "scoredAt",        Instant.now().toString()
                ));
    }

    @Tool(name = "audio_quality_threshold_check",
          description = "Check if an audio quality score meets the minimum STT processing threshold.")
    public AgentResponse checkThreshold(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Computed quality score 0–100") double qualityScore,
            @ToolParam(description = "Minimum acceptable score for STT (default 45)") double minScore) {

        boolean passes = qualityScore >= minScore;

        return AgentResponse.ok("AUDIO_QUALITY_SCORE_AGENT",
                "Quality threshold check: " + (passes ? "PASS" : "FAIL"),
                Map.of(
                        "sessionId",     sessionId,
                        "qualityScore",  qualityScore,
                        "minScore",      minScore,
                        "passes",        passes,
                        "action",        passes ? "PROCEED_TO_STT" : "FLAG_LOW_QUALITY",
                        "checkedAt",     Instant.now().toString()
                ));
    }
}
