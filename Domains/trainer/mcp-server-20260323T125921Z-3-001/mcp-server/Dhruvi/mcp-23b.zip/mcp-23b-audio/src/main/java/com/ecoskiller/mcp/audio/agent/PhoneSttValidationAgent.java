package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-11: PHONE_STT_VALIDATION_AGENT
 * Validates raw STT output for schema correctness, profanity/PII leakage,
 * empty transcript handling, and minimum confidence thresholds.
 */
@Component
public class PhoneSttValidationAgent {

    @Tool(name = "stt_validate_result",
          description = "Validate a raw STT result against schema, confidence threshold, and content rules.")
    public AgentResponse validateResult(
            @ToolParam(description = "STT job ID") String sttJobId,
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Raw transcript text") String transcriptText,
            @ToolParam(description = "STT confidence score 0.0–1.0") double confidence,
            @ToolParam(description = "Minimum acceptable confidence (e.g. 0.60)") double minConfidence,
            @ToolParam(description = "Word count in the transcript") int wordCount) {

        boolean isEmpty          = transcriptText == null || transcriptText.isBlank();
        boolean lowConfidence    = confidence < minConfidence;
        boolean tooShort         = wordCount < 1;
        boolean valid            = !isEmpty && !lowConfidence && !tooShort;

        String rejectionReason   = isEmpty       ? "EMPTY_TRANSCRIPT"
                                 : lowConfidence ? "LOW_CONFIDENCE"
                                 : tooShort      ? "TOO_SHORT"
                                 : null;

        return AgentResponse.ok("PHONE_STT_VALIDATION_AGENT",
                valid ? "STT result valid for job " + sttJobId : "STT result rejected: " + rejectionReason,
                Map.of(
                        "sttJobId",        sttJobId,
                        "sessionId",       sessionId,
                        "valid",           valid,
                        "rejectionReason", rejectionReason != null ? rejectionReason : "NONE",
                        "confidence",      confidence,
                        "minConfidence",   minConfidence,
                        "wordCount",       wordCount,
                        "action",          valid ? "PROCEED_TO_AGGREGATION" : "DISCARD_OR_RETRY",
                        "validatedAt",     Instant.now().toString()
                ));
    }

    @Tool(name = "stt_pii_check",
          description = "Scan an STT transcript for potential PII (Aadhaar, phone numbers, account numbers) before downstream use.")
    public AgentResponse checkPii(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Transcript text to scan") String transcriptText) {

        // Simulated PII detection heuristics
        boolean hasPhone    = transcriptText.matches(".*\\b[6-9]\\d{9}\\b.*");
        boolean hasAadhaar  = transcriptText.matches(".*\\b\\d{4}\\s\\d{4}\\s\\d{4}\\b.*");
        boolean hasPii      = hasPhone || hasAadhaar;

        return AgentResponse.ok("PHONE_STT_VALIDATION_AGENT",
                hasPii ? "PII detected in transcript" : "No PII detected",
                Map.of(
                        "sessionId",       sessionId,
                        "hasPii",          hasPii,
                        "piiTypes",        hasPii
                                ? (hasAadhaar ? List.of("AADHAAR") : List.of("PHONE_NUMBER"))
                                : List.of(),
                        "action",          hasPii ? "REDACT_BEFORE_STORAGE" : "SAFE_TO_STORE",
                        "scannedAt",       Instant.now().toString()
                ));
    }
}
