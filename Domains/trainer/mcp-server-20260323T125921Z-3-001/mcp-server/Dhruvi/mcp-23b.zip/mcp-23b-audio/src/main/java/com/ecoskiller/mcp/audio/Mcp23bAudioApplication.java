package com.ecoskiller.mcp.audio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mcp23bAudioApplication {
    public static void main(String[] args) {
        SpringApplication.run(Mcp23bAudioApplication.class, args);
    }
}
