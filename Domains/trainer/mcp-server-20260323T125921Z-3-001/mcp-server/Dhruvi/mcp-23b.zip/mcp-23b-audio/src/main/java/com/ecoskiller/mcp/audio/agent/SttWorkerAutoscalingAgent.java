package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-13: STT_WORKER_AUTOSCALING_AGENT
 * Evaluates STT worker pool utilization and emits scale-out / scale-in
 * recommendations. Integrates with Kubernetes HPA or custom autoscaler.
 */
@Component
public class SttWorkerAutoscalingAgent {

    @Tool(name = "stt_worker_scale_evaluate",
          description = "Evaluate current STT worker utilization and determine scale-out or scale-in action.")
    public AgentResponse evaluateScaling(
            @ToolParam(description = "Cluster ID") String clusterId,
            @ToolParam(description = "Current active worker count") int currentWorkers,
            @ToolParam(description = "Current CPU utilization across workers (0–100%)") double cpuUtilizationPct,
            @ToolParam(description = "Pending queue depth (utterances awaiting STT worker)") int pendingQueueDepth,
            @ToolParam(description = "Maximum allowed workers (cluster limit)") int maxWorkers,
            @ToolParam(description = "Minimum allowed workers (baseline)") int minWorkers) {

        boolean scaleOut = cpuUtilizationPct > 75 || pendingQueueDepth > 50;
        boolean scaleIn  = cpuUtilizationPct < 20 && pendingQueueDepth < 5;
        int recommendedWorkers = scaleOut ? Math.min(currentWorkers + 2, maxWorkers)
                               : scaleIn  ? Math.max(currentWorkers - 1, minWorkers)
                               : currentWorkers;

        String action = scaleOut ? "SCALE_OUT" : scaleIn ? "SCALE_IN" : "NO_CHANGE";

        return AgentResponse.ok("STT_WORKER_AUTOSCALING_AGENT",
                "Scaling evaluation for cluster " + clusterId + ": " + action,
                Map.of(
                        "clusterId",           clusterId,
                        "currentWorkers",      currentWorkers,
                        "recommendedWorkers",  recommendedWorkers,
                        "cpuUtilizationPct",   cpuUtilizationPct,
                        "pendingQueueDepth",   pendingQueueDepth,
                        "action",              action,
                        "scaleDelta",          recommendedWorkers - currentWorkers,
                        "evaluatedAt",         Instant.now().toString()
                ));
    }

    @Tool(name = "stt_worker_scale_apply",
          description = "Apply a scaling action to increase or decrease STT worker count in the cluster.")
    public AgentResponse applyScaling(
            @ToolParam(description = "Cluster ID") String clusterId,
            @ToolParam(description = "Scaling action: SCALE_OUT | SCALE_IN") String action,
            @ToolParam(description = "Target worker count") int targetWorkers) {

        return AgentResponse.ok("STT_WORKER_AUTOSCALING_AGENT",
                "Scaling action " + action + " applied on cluster " + clusterId,
                Map.of(
                        "clusterId",      clusterId,
                        "action",         action,
                        "targetWorkers",  targetWorkers,
                        "scaleStatus",    "APPLIED",
                        "estimatedReadySec", action.equals("SCALE_OUT") ? 45 : 30,
                        "appliedAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "stt_worker_pool_status",
          description = "Get the current status and utilization of the STT worker pool across all clusters.")
    public AgentResponse getPoolStatus() {

        return AgentResponse.ok("STT_WORKER_AUTOSCALING_AGENT",
                "STT worker pool status retrieved",
                Map.of(
                        "clusters", Map.of(
                                "CLUSTER-HI-IN", Map.of("workers", 6, "cpu", "68%", "queue", 12),
                                "CLUSTER-EN-IN", Map.of("workers", 4, "cpu", "45%", "queue", 5),
                                "CLUSTER-MR-IN", Map.of("workers", 2, "cpu", "30%", "queue", 2),
                                "CLUSTER-MULTI", Map.of("workers", 5, "cpu", "55%", "queue", 9)
                        ),
                        "totalWorkers", 17,
                        "checkedAt",    Instant.now().toString()
                ));
    }
}
