package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-01: AUDIO_BACKPRESSURE_CONTROL_AGENT
 * Monitors incoming audio stream queue depth and applies backpressure signals
 * to upstream producers to prevent buffer overflow and frame drop.
 */
@Component
public class AudioBackpressureControlAgent {

    @Tool(name = "audio_backpressure_check",
          description = "Evaluate current audio stream queue depth and determine if backpressure should be applied.")
    public AgentResponse checkBackpressure(
            @ToolParam(description = "Stream session ID") String sessionId,
            @ToolParam(description = "Current queue depth (number of buffered frames)") int queueDepth,
            @ToolParam(description = "Maximum allowed queue depth before backpressure") int maxQueueDepth) {

        boolean applyBackpressure = queueDepth >= (maxQueueDepth * 0.80);
        String pressureLevel = queueDepth >= maxQueueDepth ? "CRITICAL"
                             : queueDepth >= (maxQueueDepth * 0.80) ? "HIGH"
                             : queueDepth >= (maxQueueDepth * 0.50) ? "MEDIUM"
                             : "LOW";

        return AgentResponse.ok("AUDIO_BACKPRESSURE_CONTROL_AGENT",
                "Backpressure evaluated for session " + sessionId,
                Map.of(
                        "sessionId",          sessionId,
                        "queueDepth",         queueDepth,
                        "maxQueueDepth",      maxQueueDepth,
                        "pressureLevel",      pressureLevel,
                        "applyBackpressure",  applyBackpressure,
                        "action",             applyBackpressure ? "THROTTLE_UPSTREAM" : "ALLOW_FLOW",
                        "evaluatedAt",        Instant.now().toString()
                ));
    }

    @Tool(name = "audio_backpressure_signal",
          description = "Send a backpressure signal to the upstream audio producer to throttle or resume stream ingestion.")
    public AgentResponse sendBackpressureSignal(
            @ToolParam(description = "Stream session ID") String sessionId,
            @ToolParam(description = "Signal type: THROTTLE | PAUSE | RESUME") String signalType,
            @ToolParam(description = "Target producer endpoint or channel ID") String producerEndpoint) {

        return AgentResponse.ok("AUDIO_BACKPRESSURE_CONTROL_AGENT",
                "Backpressure signal " + signalType + " sent to producer",
                Map.of(
                        "sessionId",        sessionId,
                        "signalType",       signalType,
                        "producerEndpoint", producerEndpoint,
                        "signalStatus",     "DELIVERED",
                        "sentAt",           Instant.now().toString()
                ));
    }

    @Tool(name = "audio_queue_drain_status",
          description = "Check if the audio frame queue has drained to a safe level after backpressure was applied.")
    public AgentResponse checkDrainStatus(
            @ToolParam(description = "Stream session ID") String sessionId,
            @ToolParam(description = "Current queue depth after throttle") int currentDepth,
            @ToolParam(description = "Safe resume threshold") int resumeThreshold) {

        boolean safeToResume = currentDepth <= resumeThreshold;

        return AgentResponse.ok("AUDIO_BACKPRESSURE_CONTROL_AGENT",
                "Queue drain status checked for session " + sessionId,
                Map.of(
                        "sessionId",      sessionId,
                        "currentDepth",   currentDepth,
                        "resumeThreshold",resumeThreshold,
                        "safeToResume",   safeToResume,
                        "recommendation", safeToResume ? "SEND_RESUME_SIGNAL" : "MAINTAIN_THROTTLE",
                        "checkedAt",      Instant.now().toString()
                ));
    }
}
