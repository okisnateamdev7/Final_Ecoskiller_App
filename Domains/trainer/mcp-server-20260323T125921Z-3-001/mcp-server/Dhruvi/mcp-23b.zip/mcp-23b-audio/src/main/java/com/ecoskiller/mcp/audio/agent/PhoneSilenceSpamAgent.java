package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-07: PHONE_SILENCE_SPAM_AGENT
 * Detects prolonged silence spans and robocall / DTMF spam patterns
 * in phone audio streams. Flags sessions for early termination or spam tagging.
 */
@Component
public class PhoneSilenceSpamAgent {

    @Tool(name = "phone_silence_detect",
          description = "Detect prolonged silence in a phone session and determine if it warrants session termination.")
    public AgentResponse detectSilence(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Continuous silence duration in milliseconds") long silenceDurationMs,
            @ToolParam(description = "Silence threshold for warning in ms (e.g. 5000)") long warnThresholdMs,
            @ToolParam(description = "Silence threshold for termination in ms (e.g. 15000)") long terminateThresholdMs) {

        String action = silenceDurationMs >= terminateThresholdMs ? "TERMINATE_SESSION"
                      : silenceDurationMs >= warnThresholdMs      ? "WARN_CALLER"
                      : "CONTINUE";

        return AgentResponse.ok("PHONE_SILENCE_SPAM_AGENT",
                "Silence check: " + action + " for session " + sessionId,
                Map.of(
                        "sessionId",           sessionId,
                        "silenceDurationMs",   silenceDurationMs,
                        "warnThresholdMs",     warnThresholdMs,
                        "terminateThresholdMs",terminateThresholdMs,
                        "action",              action,
                        "detectedAt",          Instant.now().toString()
                ));
    }

    @Tool(name = "phone_spam_pattern_detect",
          description = "Detect robocall, DTMF spam, or synthetic voice patterns in a phone session.")
    public AgentResponse detectSpam(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Number of DTMF tones detected in the last 10 seconds") int dtmfCount10s,
            @ToolParam(description = "Whether synthetic TTS voice pattern was detected") boolean syntheticVoiceDetected,
            @ToolParam(description = "Whether the audio is a repeat of a stored robocall signature") boolean matchesRobocallSignature) {

        boolean isSpam    = dtmfCount10s > 8 || matchesRobocallSignature || syntheticVoiceDetected;
        String spamType   = matchesRobocallSignature ? "ROBOCALL"
                          : syntheticVoiceDetected   ? "SYNTHETIC_TTS"
                          : dtmfCount10s > 8         ? "DTMF_FLOOD"
                          : "CLEAN";

        return AgentResponse.ok("PHONE_SILENCE_SPAM_AGENT",
                "Spam detection result: " + spamType,
                Map.of(
                        "sessionId",                sessionId,
                        "isSpam",                   isSpam,
                        "spamType",                 spamType,
                        "dtmfCount10s",             dtmfCount10s,
                        "syntheticVoiceDetected",   syntheticVoiceDetected,
                        "matchesRobocallSignature",  matchesRobocallSignature,
                        "action",                   isSpam ? "FLAG_AND_TERMINATE" : "ALLOW",
                        "detectedAt",               Instant.now().toString()
                ));
    }
}
