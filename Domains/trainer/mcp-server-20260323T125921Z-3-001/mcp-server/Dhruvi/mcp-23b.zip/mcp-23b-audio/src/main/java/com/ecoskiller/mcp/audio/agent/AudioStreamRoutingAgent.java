package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-04: AUDIO_STREAM_ROUTING_AGENT
 * Routes incoming audio streams to the appropriate STT worker cluster
 * based on language hint, quality score, and worker load.
 */
@Component
public class AudioStreamRoutingAgent {

    @Tool(name = "audio_stream_route",
          description = "Route an audio stream session to the best available STT worker cluster.")
    public AgentResponse routeStream(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Detected or hinted language code (e.g. en-IN, hi-IN, mr-IN)") String languageCode,
            @ToolParam(description = "Audio quality score 0–100") double qualityScore,
            @ToolParam(description = "Caller region: NORTH | SOUTH | EAST | WEST | UNKNOWN") String callerRegion) {

        String cluster = resolveCluster(languageCode, callerRegion);
        String routeId = "RTE-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        return AgentResponse.ok("AUDIO_STREAM_ROUTING_AGENT",
                "Stream " + sessionId + " routed to cluster " + cluster,
                Map.of(
                        "routeId",        routeId,
                        "sessionId",      sessionId,
                        "languageCode",   languageCode,
                        "qualityScore",   qualityScore,
                        "callerRegion",   callerRegion,
                        "targetCluster",  cluster,
                        "routingPolicy",  "LANGUAGE_AFFINITY_LOAD_BALANCED",
                        "routedAt",       Instant.now().toString()
                ));
    }

    @Tool(name = "audio_stream_reroute",
          description = "Reroute a session to a fallback STT cluster when the primary cluster is unhealthy.")
    public AgentResponse rerouteStream(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Current (failed) cluster ID") String failedCluster,
            @ToolParam(description = "Reason for reroute: CLUSTER_DOWN | OVERLOAD | TIMEOUT") String rerouteReason) {

        String fallbackCluster = "CLUSTER-FALLBACK-" + failedCluster.replaceAll("[^A-Z0-9]", "");

        return AgentResponse.ok("AUDIO_STREAM_ROUTING_AGENT",
                "Session " + sessionId + " rerouted from " + failedCluster,
                Map.of(
                        "sessionId",       sessionId,
                        "failedCluster",   failedCluster,
                        "fallbackCluster", fallbackCluster,
                        "rerouteReason",   rerouteReason,
                        "reroutedAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "audio_stream_routing_health",
          description = "Check health and load of all STT routing clusters.")
    public AgentResponse routingHealth() {

        return AgentResponse.ok("AUDIO_STREAM_ROUTING_AGENT",
                "Stream routing cluster health checked",
                Map.of(
                        "clusters", Map.of(
                                "CLUSTER-HI-IN", Map.of("status", "UP", "load", "62%"),
                                "CLUSTER-EN-IN", Map.of("status", "UP", "load", "48%"),
                                "CLUSTER-MR-IN", Map.of("status", "UP", "load", "31%"),
                                "CLUSTER-MULTI", Map.of("status", "UP", "load", "55%"),
                                "CLUSTER-FALLBACK", Map.of("status", "UP", "load", "10%")
                        ),
                        "checkedAt", Instant.now().toString()
                ));
    }

    private String resolveCluster(String lang, String region) {
        if (lang.startsWith("hi")) return "CLUSTER-HI-IN";
        if (lang.startsWith("mr")) return "CLUSTER-MR-IN";
        if (lang.startsWith("en")) return "CLUSTER-EN-IN";
        return "CLUSTER-MULTI";
    }
}
