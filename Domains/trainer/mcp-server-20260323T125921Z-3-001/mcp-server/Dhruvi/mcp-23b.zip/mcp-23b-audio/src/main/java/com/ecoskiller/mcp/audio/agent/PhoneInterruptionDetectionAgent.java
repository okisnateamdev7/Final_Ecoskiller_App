package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-08: PHONE_INTERRUPTION_DETECTION_AGENT
 * Detects speaker overlaps, barge-ins, and interruption events
 * in duplex phone conversations. Emits interruption events for downstream
 * NLP context enrichment.
 */
@Component
public class PhoneInterruptionDetectionAgent {

    @Tool(name = "phone_interruption_detect",
          description = "Detect if a caller interruption or barge-in event occurred in a given audio window.")
    public AgentResponse detectInterruption(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Caller leg speaking: true if caller audio is active") boolean callerSpeaking,
            @ToolParam(description = "Agent leg speaking: true if agent audio is active") boolean agentSpeaking,
            @ToolParam(description = "Overlap duration in milliseconds (0 if no overlap)") long overlapDurationMs,
            @ToolParam(description = "Timestamp offset from call start (ms)") long timestampOffsetMs) {

        boolean isInterruption = callerSpeaking && agentSpeaking && overlapDurationMs > 0;
        String interruptType   = !isInterruption ? "NONE"
                               : overlapDurationMs > 1000 ? "SUSTAINED_OVERLAP"
                               : overlapDurationMs > 300  ? "BARGE_IN"
                               : "BRIEF_OVERLAP";

        String eventId = isInterruption
                ? "INT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase()
                : null;

        return AgentResponse.ok("PHONE_INTERRUPTION_DETECTION_AGENT",
                isInterruption ? "Interruption detected: " + interruptType : "No interruption detected",
                Map.of(
                        "sessionId",          sessionId,
                        "isInterruption",     isInterruption,
                        "interruptType",      interruptType,
                        "overlapDurationMs",  overlapDurationMs,
                        "timestampOffsetMs",  timestampOffsetMs,
                        "eventId",            eventId != null ? eventId : "N/A",
                        "callerSpeaking",     callerSpeaking,
                        "agentSpeaking",      agentSpeaking,
                        "detectedAt",         Instant.now().toString()
                ));
    }

    @Tool(name = "phone_interruption_summary",
          description = "Summarize all interruption events for a completed call session.")
    public AgentResponse summarizeInterruptions(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Total interruption count in the call") int totalInterruptions,
            @ToolParam(description = "Total overlap duration across all interruptions (ms)") long totalOverlapMs,
            @ToolParam(description = "Call duration in ms") long callDurationMs) {

        double interruptionRate = callDurationMs > 0
                ? (totalOverlapMs / (double) callDurationMs) * 100
                : 0.0;

        String conversationHealth = interruptionRate < 2 ? "SMOOTH"
                                  : interruptionRate < 8 ? "MODERATE_INTERRUPTIONS"
                                  : "HIGHLY_INTERRUPTED";

        return AgentResponse.ok("PHONE_INTERRUPTION_DETECTION_AGENT",
                "Interruption summary for session " + sessionId,
                Map.of(
                        "sessionId",           sessionId,
                        "totalInterruptions",  totalInterruptions,
                        "totalOverlapMs",      totalOverlapMs,
                        "callDurationMs",      callDurationMs,
                        "interruptionRatePct", Math.round(interruptionRate * 10.0) / 10.0,
                        "conversationHealth",  conversationHealth,
                        "summarizedAt",        Instant.now().toString()
                ));
    }
}
