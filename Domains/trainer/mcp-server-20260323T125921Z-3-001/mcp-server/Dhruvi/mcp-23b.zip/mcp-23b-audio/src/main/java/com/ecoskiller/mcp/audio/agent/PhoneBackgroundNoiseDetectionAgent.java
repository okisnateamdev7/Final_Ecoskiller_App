package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-06: PHONE_BACKGROUND_NOISE_DETECTION_AGENT
 * Classifies ambient noise type in phone call audio and estimates
 * its impact on STT accuracy. Supports noise suppression recommendations.
 */
@Component
public class PhoneBackgroundNoiseDetectionAgent {

    @Tool(name = "phone_noise_detect",
          description = "Detect and classify background noise type in a phone audio frame or segment.")
    public AgentResponse detectNoise(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Background noise energy in dBFS") double noiseEnergyDbfs,
            @ToolParam(description = "Dominant frequency of background noise in Hz") double dominantFreqHz,
            @ToolParam(description = "Signal-to-noise ratio in dB") double snrDb) {

        String noiseClass = classifyNoise(dominantFreqHz, noiseEnergyDbfs);
        String severity   = snrDb > 20 ? "LOW" : snrDb > 10 ? "MEDIUM" : snrDb > 3 ? "HIGH" : "SEVERE";
        boolean needsNoiseSuppression = snrDb < 15.0;

        return AgentResponse.ok("PHONE_BACKGROUND_NOISE_DETECTION_AGENT",
                "Background noise detected: " + noiseClass,
                Map.of(
                        "sessionId",             sessionId,
                        "noiseClass",            noiseClass,
                        "severity",              severity,
                        "noiseEnergyDbfs",       noiseEnergyDbfs,
                        "dominantFreqHz",        dominantFreqHz,
                        "snrDb",                 snrDb,
                        "needsNoiseSuppression", needsNoiseSuppression,
                        "sttImpact",             severity.equals("SEVERE") ? "HIGH_WER_RISK" : "ACCEPTABLE",
                        "detectedAt",            Instant.now().toString()
                ));
    }

    @Tool(name = "phone_noise_suppression_recommend",
          description = "Recommend a noise suppression strategy based on detected noise class and severity.")
    public AgentResponse recommendSuppression(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Noise class: CROWD | TRAFFIC | MUSIC | HVAC | ECHO | STATIC | CLEAN") String noiseClass,
            @ToolParam(description = "Severity: LOW | MEDIUM | HIGH | SEVERE") String severity) {

        String strategy = switch (noiseClass.toUpperCase()) {
            case "ECHO"    -> "ECHO_CANCELLATION_AEC";
            case "MUSIC"   -> "SPECTRAL_SUBTRACTION";
            case "CROWD"   -> "BEAMFORMING_MICROPHONE_FOCUS";
            case "STATIC"  -> "HIGH_PASS_FILTER";
            case "HVAC"    -> "STATIONARY_NOISE_SUPPRESSION";
            default        -> severity.equals("SEVERE") ? "RNN_DENOISER" : "WEBRTC_NS";
        };

        return AgentResponse.ok("PHONE_BACKGROUND_NOISE_DETECTION_AGENT",
                "Suppression strategy recommended: " + strategy,
                Map.of(
                        "sessionId",           sessionId,
                        "noiseClass",          noiseClass,
                        "severity",            severity,
                        "suppressionStrategy", strategy,
                        "applyImmediately",    severity.equals("HIGH") || severity.equals("SEVERE"),
                        "recommendedAt",       Instant.now().toString()
                ));
    }

    private String classifyNoise(double freqHz, double energyDbfs) {
        if (freqHz < 100)  return "HVAC";
        if (freqHz < 300)  return "TRAFFIC";
        if (freqHz < 1000) return "CROWD";
        if (freqHz < 4000) return "MUSIC";
        return energyDbfs > -30 ? "STATIC" : "CLEAN";
    }
}
