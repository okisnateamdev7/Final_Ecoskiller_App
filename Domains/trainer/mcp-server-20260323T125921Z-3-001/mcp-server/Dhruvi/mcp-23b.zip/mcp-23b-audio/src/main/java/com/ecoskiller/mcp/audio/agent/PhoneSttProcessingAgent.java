package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-10: PHONE_STT_PROCESSING_AGENT
 * Submits preprocessed audio frames to the configured STT engine and
 * returns raw transcript hypotheses with word-level timestamps.
 * Supports: Google STT, AWS Transcribe, Azure Speech, Whisper, Kaldi.
 */
@Component
public class PhoneSttProcessingAgent {

    @Tool(name = "stt_process_utterance",
          description = "Submit a preprocessed audio utterance to the STT engine and retrieve the raw transcript hypothesis.")
    public AgentResponse processUtterance(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Utterance ID") String utteranceId,
            @ToolParam(description = "STT engine: GOOGLE | AWS_TRANSCRIBE | AZURE_SPEECH | WHISPER | KALDI") String sttEngine,
            @ToolParam(description = "Language code (e.g. en-IN, hi-IN)") String languageCode,
            @ToolParam(description = "Audio duration of the utterance in ms") long durationMs,
            @ToolParam(description = "Enable word-level timestamps") boolean wordTimestamps) {

        String jobId = "STT-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase();
        double simulatedConfidence = 0.91;

        return AgentResponse.ok("PHONE_STT_PROCESSING_AGENT",
                "Utterance " + utteranceId + " submitted to " + sttEngine,
                Map.of(
                        "sessionId",        sessionId,
                        "utteranceId",      utteranceId,
                        "sttJobId",         jobId,
                        "sttEngine",        sttEngine,
                        "languageCode",     languageCode,
                        "durationMs",       durationMs,
                        "wordTimestamps",   wordTimestamps,
                        "jobStatus",        "PROCESSING",
                        "estimatedRttMs",   durationMs < 2000 ? 180 : 320,
                        "submittedAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "stt_result_fetch",
          description = "Fetch the completed STT result for a previously submitted job.")
    public AgentResponse fetchResult(
            @ToolParam(description = "STT job ID") String sttJobId,
            @ToolParam(description = "Session ID") String sessionId) {

        return AgentResponse.ok("PHONE_STT_PROCESSING_AGENT",
                "STT result fetched for job " + sttJobId,
                Map.of(
                        "sttJobId",         sttJobId,
                        "sessionId",        sessionId,
                        "jobStatus",        "COMPLETED",
                        "transcript",       "[TRANSCRIPT_PLACEHOLDER]",
                        "confidence",       0.91,
                        "wordCount",        12,
                        "processingTimeMs", 210,
                        "fetchedAt",        Instant.now().toString()
                ));
    }

    @Tool(name = "stt_stream_partial",
          description = "Retrieve partial (interim) STT results for a live streaming session.")
    public AgentResponse getPartialResult(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Current stream offset in ms") long streamOffsetMs) {

        return AgentResponse.ok("PHONE_STT_PROCESSING_AGENT",
                "Partial STT result at offset " + streamOffsetMs + "ms",
                Map.of(
                        "sessionId",       sessionId,
                        "streamOffsetMs",  streamOffsetMs,
                        "partialResult",   "[PARTIAL_TRANSCRIPT_PLACEHOLDER]",
                        "isFinal",         false,
                        "stability",       0.75,
                        "retrievedAt",     Instant.now().toString()
                ));
    }
}
