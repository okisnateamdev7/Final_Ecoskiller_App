package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-14: PHONE_CONFIDENCE_NORMALIZATION_AGENT
 * Normalizes raw confidence scores from different STT engines to a
 * unified 0.0–1.0 scale using engine-specific calibration curves.
 * Enables fair cross-engine confidence comparison.
 */
@Component
public class PhoneConfidenceNormalizationAgent {

    @Tool(name = "confidence_normalize",
          description = "Normalize a raw STT confidence score from a specific engine to a unified 0.0–1.0 scale.")
    public AgentResponse normalizeConfidence(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "STT engine: GOOGLE | AWS_TRANSCRIBE | AZURE_SPEECH | WHISPER | KALDI") String sttEngine,
            @ToolParam(description = "Raw confidence score from the STT engine") double rawConfidence,
            @ToolParam(description = "Language code (normalization curves may vary by language)") String languageCode) {

        double normalizedScore = applyCalibration(sttEngine, rawConfidence, languageCode);
        String calibrationCurve = sttEngine + "_" + languageCode.replace("-", "_").toUpperCase() + "_V1";

        return AgentResponse.ok("PHONE_CONFIDENCE_NORMALIZATION_AGENT",
                "Confidence normalized for " + sttEngine + " on session " + sessionId,
                Map.of(
                        "sessionId",         sessionId,
                        "sttEngine",         sttEngine,
                        "languageCode",      languageCode,
                        "rawConfidence",     rawConfidence,
                        "normalizedScore",   Math.round(normalizedScore * 1000.0) / 1000.0,
                        "calibrationCurve",  calibrationCurve,
                        "normalizedAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "confidence_calibration_update",
          description = "Update calibration parameters for an STT engine/language pair based on WER feedback.")
    public AgentResponse updateCalibration(
            @ToolParam(description = "STT engine") String sttEngine,
            @ToolParam(description = "Language code") String languageCode,
            @ToolParam(description = "Observed Word Error Rate from recent evaluation (0.0–1.0)") double observedWer,
            @ToolParam(description = "Sample size used for calibration update") int sampleSize) {

        double calibrationShift = observedWer > 0.20 ? -0.05 : observedWer < 0.05 ? 0.02 : 0.0;

        return AgentResponse.ok("PHONE_CONFIDENCE_NORMALIZATION_AGENT",
                "Calibration updated for " + sttEngine + "/" + languageCode,
                Map.of(
                        "sttEngine",         sttEngine,
                        "languageCode",      languageCode,
                        "observedWer",       observedWer,
                        "sampleSize",        sampleSize,
                        "calibrationShift",  calibrationShift,
                        "updatedAt",         Instant.now().toString()
                ));
    }

    private double applyCalibration(String engine, double raw, String lang) {
        // Engine-specific calibration offsets (simplified)
        double offset = switch (engine.toUpperCase()) {
            case "GOOGLE"        -> lang.startsWith("hi") ? 0.02 : 0.00;
            case "AWS_TRANSCRIBE"-> -0.03;
            case "AZURE_SPEECH"  -> 0.01;
            case "WHISPER"       -> lang.startsWith("hi") ? -0.05 : 0.03;
            case "KALDI"         -> -0.08;
            default              -> 0.0;
        };
        return Math.min(1.0, Math.max(0.0, raw + offset));
    }
}
