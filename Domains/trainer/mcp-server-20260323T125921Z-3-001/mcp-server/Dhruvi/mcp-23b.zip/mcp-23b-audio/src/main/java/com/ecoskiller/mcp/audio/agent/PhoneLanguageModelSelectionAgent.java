package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AGENT-15: PHONE_LANGUAGE_MODEL_SELECTION_AGENT
 * Selects the optimal STT language model for a session based on
 * detected language, domain context (education, medical, general),
 * and caller profile. Supports domain-adapted acoustic models.
 */
@Component
public class PhoneLanguageModelSelectionAgent {

    @Tool(name = "lm_select",
          description = "Select the best STT language model for a session based on language, domain, and quality constraints.")
    public AgentResponse selectModel(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Detected language code (e.g. en-IN, hi-IN, mr-IN)") String languageCode,
            @ToolParam(description = "Domain context: EDUCATION | MEDICAL | LEGAL | ECOMMERCE | GENERAL") String domain,
            @ToolParam(description = "Caller tier: PREMIUM | STANDARD | BASIC") String callerTier,
            @ToolParam(description = "Audio quality score 0–100") double qualityScore) {

        String selectedModel = resolveModel(languageCode, domain, callerTier, qualityScore);
        String modelVersion  = "v2.4.1";
        boolean domainAdapted = !domain.equals("GENERAL");

        return AgentResponse.ok("PHONE_LANGUAGE_MODEL_SELECTION_AGENT",
                "Language model selected: " + selectedModel,
                Map.of(
                        "sessionId",      sessionId,
                        "languageCode",   languageCode,
                        "domain",         domain,
                        "callerTier",     callerTier,
                        "qualityScore",   qualityScore,
                        "selectedModel",  selectedModel,
                        "modelVersion",   modelVersion,
                        "domainAdapted",  domainAdapted,
                        "fallbackModel",  "GENERAL_" + languageCode.replace("-", "_").toUpperCase(),
                        "selectedAt",     Instant.now().toString()
                ));
    }

    @Tool(name = "lm_fallback_select",
          description = "Select a fallback language model when the primary model fails or returns low confidence.")
    public AgentResponse selectFallback(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Primary model that failed") String primaryModel,
            @ToolParam(description = "Failure reason: LOW_CONFIDENCE | MODEL_UNAVAILABLE | TIMEOUT") String failureReason,
            @ToolParam(description = "Language code") String languageCode) {

        String fallbackModel = "GENERAL_" + languageCode.replace("-", "_").toUpperCase() + "_FALLBACK";

        return AgentResponse.ok("PHONE_LANGUAGE_MODEL_SELECTION_AGENT",
                "Fallback model selected: " + fallbackModel,
                Map.of(
                        "sessionId",     sessionId,
                        "primaryModel",  primaryModel,
                        "failureReason", failureReason,
                        "fallbackModel", fallbackModel,
                        "selectedAt",    Instant.now().toString()
                ));
    }

    @Tool(name = "lm_available_models",
          description = "List all available STT language models for a given language code.")
    public AgentResponse listModels(
            @ToolParam(description = "Language code to filter models") String languageCode) {

        List<Map<String, String>> models = List.of(
                Map.of("model", "GENERAL_" + languageCode.toUpperCase().replace("-","_"), "domain", "GENERAL",  "tier", "STANDARD"),
                Map.of("model", "EDU_" + languageCode.toUpperCase().replace("-","_"),     "domain", "EDUCATION","tier", "PREMIUM"),
                Map.of("model", "MED_" + languageCode.toUpperCase().replace("-","_"),     "domain", "MEDICAL",  "tier", "PREMIUM"),
                Map.of("model", "LEGAL_" + languageCode.toUpperCase().replace("-","_"),   "domain", "LEGAL",    "tier", "PREMIUM")
        );

        return AgentResponse.ok("PHONE_LANGUAGE_MODEL_SELECTION_AGENT",
                "Available models for language " + languageCode,
                Map.of(
                        "languageCode", languageCode,
                        "models",       models,
                        "retrievedAt",  Instant.now().toString()
                ));
    }

    private String resolveModel(String lang, String domain, String tier, double quality) {
        String langKey = lang.replace("-", "_").toUpperCase();
        if (tier.equals("BASIC") || quality < 40) return "GENERAL_" + langKey;
        return switch (domain.toUpperCase()) {
            case "EDUCATION" -> "EDU_" + langKey;
            case "MEDICAL"   -> "MED_" + langKey;
            case "LEGAL"     -> "LEGAL_" + langKey;
            default          -> "GENERAL_" + langKey;
        };
    }
}
