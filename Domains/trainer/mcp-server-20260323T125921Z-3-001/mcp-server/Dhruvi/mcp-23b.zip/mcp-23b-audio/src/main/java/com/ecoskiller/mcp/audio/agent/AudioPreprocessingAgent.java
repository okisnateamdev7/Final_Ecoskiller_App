package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-02: AUDIO_PREPROCESSING_AGENT
 * Applies preprocessing transforms to raw audio frames before STT:
 * resampling, normalization, VAD gating, and codec decode.
 */
@Component
public class AudioPreprocessingAgent {

    @Tool(name = "audio_preprocess_frame",
          description = "Apply preprocessing pipeline (resample, normalize, VAD gate) to a raw audio frame.")
    public AgentResponse preprocessFrame(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Frame sequence number") long frameSeq,
            @ToolParam(description = "Input sample rate in Hz (e.g. 8000, 16000, 44100)") int inputSampleRate,
            @ToolParam(description = "Target sample rate for STT (typically 16000)") int targetSampleRate,
            @ToolParam(description = "Input codec: PCM_16 | OPUS | G711_ULAW | G711_ALAW | AMR") String inputCodec,
            @ToolParam(description = "Detected audio energy level (RMS dB, e.g. -30.5)") double rmsDb) {

        boolean vadPass    = rmsDb > -45.0;
        boolean resampled  = inputSampleRate != targetSampleRate;
        String frameId     = "FRM-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        return AgentResponse.ok("AUDIO_PREPROCESSING_AGENT",
                "Frame " + frameSeq + " preprocessed for session " + sessionId,
                Map.of(
                        "frameId",          frameId,
                        "sessionId",        sessionId,
                        "frameSeq",         frameSeq,
                        "inputSampleRate",  inputSampleRate,
                        "targetSampleRate", targetSampleRate,
                        "inputCodec",       inputCodec,
                        "outputCodec",      "PCM_16",
                        "resampled",        resampled,
                        "rmsDb",            rmsDb,
                        "vadPass",          vadPass,
                        "frameStatus",      vadPass ? "QUEUED_FOR_STT" : "DROPPED_VAD",
                        "processedAt",      Instant.now().toString()
                ));
    }

    @Tool(name = "audio_normalize",
          description = "Apply gain normalization to bring audio to a target loudness level (LUFS).")
    public AgentResponse normalizeAudio(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Measured integrated loudness in LUFS") double measuredLufs,
            @ToolParam(description = "Target integrated loudness in LUFS (typically -23.0 for broadcast)") double targetLufs) {

        double gainDb = targetLufs - measuredLufs;

        return AgentResponse.ok("AUDIO_PREPROCESSING_AGENT",
                "Audio normalized for session " + sessionId,
                Map.of(
                        "sessionId",     sessionId,
                        "measuredLufs",  measuredLufs,
                        "targetLufs",    targetLufs,
                        "appliedGainDb", gainDb,
                        "normalizedAt",  Instant.now().toString()
                ));
    }

    @Tool(name = "audio_vad_config",
          description = "Configure Voice Activity Detection (VAD) sensitivity for a session.")
    public AgentResponse configureVad(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "VAD mode: AGGRESSIVE | NORMAL | GENTLE") String vadMode,
            @ToolParam(description = "Silence threshold in ms before frame is dropped") int silenceThresholdMs) {

        double energyThresholdDb = switch (vadMode.toUpperCase()) {
            case "AGGRESSIVE" -> -35.0;
            case "GENTLE"     -> -55.0;
            default           -> -45.0;
        };

        return AgentResponse.ok("AUDIO_PREPROCESSING_AGENT",
                "VAD configured for session " + sessionId,
                Map.of(
                        "sessionId",          sessionId,
                        "vadMode",            vadMode,
                        "silenceThresholdMs", silenceThresholdMs,
                        "energyThresholdDb",  energyThresholdDb,
                        "configuredAt",       Instant.now().toString()
                ));
    }
}
