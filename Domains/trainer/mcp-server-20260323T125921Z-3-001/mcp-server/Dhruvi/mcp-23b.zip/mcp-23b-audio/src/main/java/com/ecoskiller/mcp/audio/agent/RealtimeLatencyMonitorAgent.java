package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-09: REALTIME_LATENCY_MONITOR_AGENT
 * Measures and reports end-to-end STT pipeline latency in real-time.
 * Tracks: audio capture → preprocessing → STT → transcript delivery.
 * Raises latency alerts when SLOs are breached.
 */
@Component
public class RealtimeLatencyMonitorAgent {

    @Tool(name = "latency_record",
          description = "Record latency measurements for each stage of the STT pipeline for a given frame/utterance.")
    public AgentResponse recordLatency(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Utterance or frame ID") String utteranceId,
            @ToolParam(description = "Audio capture to preprocessing start latency (ms)") long captureToPreprocessMs,
            @ToolParam(description = "Preprocessing duration (ms)") long preprocessDurationMs,
            @ToolParam(description = "STT inference duration (ms)") long sttInferenceDurationMs,
            @ToolParam(description = "Transcript delivery latency (ms)") long deliveryLatencyMs) {

        long totalLatencyMs = captureToPreprocessMs + preprocessDurationMs
                            + sttInferenceDurationMs + deliveryLatencyMs;

        String sloStatus = totalLatencyMs <= 400  ? "WITHIN_SLO"
                         : totalLatencyMs <= 800  ? "SLO_WARNING"
                         : "SLO_BREACH";

        return AgentResponse.ok("REALTIME_LATENCY_MONITOR_AGENT",
                "Latency recorded for utterance " + utteranceId,
                Map.of(
                        "sessionId",                sessionId,
                        "utteranceId",              utteranceId,
                        "captureToPreprocessMs",    captureToPreprocessMs,
                        "preprocessDurationMs",     preprocessDurationMs,
                        "sttInferenceDurationMs",   sttInferenceDurationMs,
                        "deliveryLatencyMs",        deliveryLatencyMs,
                        "totalLatencyMs",           totalLatencyMs,
                        "sloStatus",                sloStatus,
                        "recordedAt",               Instant.now().toString()
                ));
    }

    @Tool(name = "latency_alert_check",
          description = "Check if the rolling average latency for a session exceeds SLO thresholds and generate an alert.")
    public AgentResponse checkLatencyAlert(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Rolling P95 latency in ms over last 60 seconds") long p95LatencyMs,
            @ToolParam(description = "SLO target for P95 latency in ms (e.g. 500)") long sloTargetMs) {

        boolean sloBreached = p95LatencyMs > sloTargetMs;
        double sloMarginPct = ((sloTargetMs - p95LatencyMs) / (double) sloTargetMs) * 100.0;

        return AgentResponse.ok("REALTIME_LATENCY_MONITOR_AGENT",
                sloBreached ? "LATENCY SLO BREACH on session " + sessionId : "Latency within SLO",
                Map.of(
                        "sessionId",      sessionId,
                        "p95LatencyMs",   p95LatencyMs,
                        "sloTargetMs",    sloTargetMs,
                        "sloBreached",    sloBreached,
                        "sloMarginPct",   Math.round(sloMarginPct * 10.0) / 10.0,
                        "alertSeverity",  sloBreached ? (p95LatencyMs > sloTargetMs * 2 ? "CRITICAL" : "WARNING") : "NONE",
                        "checkedAt",      Instant.now().toString()
                ));
    }
}
