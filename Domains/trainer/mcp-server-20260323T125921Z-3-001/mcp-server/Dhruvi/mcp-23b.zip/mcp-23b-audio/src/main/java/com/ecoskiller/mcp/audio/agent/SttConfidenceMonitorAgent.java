package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;

/**
 * AGENT-12: STT_CONFIDENCE_MONITOR_AGENT
 * Tracks STT confidence score trends over a session and across worker pool.
 * Triggers model reselection or worker reassignment when confidence degrades.
 */
@Component
public class SttConfidenceMonitorAgent {

    @Tool(name = "stt_confidence_record",
          description = "Record an STT confidence data point for rolling trend analysis.")
    public AgentResponse recordConfidence(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Utterance sequence number") int utteranceSeq,
            @ToolParam(description = "Confidence score 0.0–1.0") double confidence,
            @ToolParam(description = "STT engine used") String sttEngine,
            @ToolParam(description = "Language code") String languageCode) {

        String confidenceBand = confidence >= 0.90 ? "HIGH"
                              : confidence >= 0.70 ? "MEDIUM"
                              : confidence >= 0.50 ? "LOW"
                              : "VERY_LOW";

        return AgentResponse.ok("STT_CONFIDENCE_MONITOR_AGENT",
                "Confidence recorded for utterance " + utteranceSeq,
                Map.of(
                        "sessionId",      sessionId,
                        "utteranceSeq",   utteranceSeq,
                        "confidence",     confidence,
                        "confidenceBand", confidenceBand,
                        "sttEngine",      sttEngine,
                        "languageCode",   languageCode,
                        "recordedAt",     Instant.now().toString()
                ));
    }

    @Tool(name = "stt_confidence_trend_check",
          description = "Evaluate rolling confidence trend and recommend model reselection if degradation detected.")
    public AgentResponse checkTrend(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Rolling average confidence over last 10 utterances") double rollingAvgConfidence,
            @ToolParam(description = "Confidence degradation threshold to trigger model switch (e.g. 0.65)") double degradationThreshold,
            @ToolParam(description = "Current STT engine") String currentEngine) {

        boolean degraded        = rollingAvgConfidence < degradationThreshold;
        String recommendation   = !degraded ? "MAINTAIN_CURRENT_MODEL"
                                : currentEngine.equals("GOOGLE")      ? "SWITCH_TO_AZURE_SPEECH"
                                : currentEngine.equals("AWS_TRANSCRIBE") ? "SWITCH_TO_WHISPER"
                                : "SWITCH_TO_GOOGLE";

        return AgentResponse.ok("STT_CONFIDENCE_MONITOR_AGENT",
                degraded ? "Confidence degradation detected — recommending: " + recommendation
                         : "Confidence stable at " + rollingAvgConfidence,
                Map.of(
                        "sessionId",            sessionId,
                        "rollingAvgConfidence", rollingAvgConfidence,
                        "degradationThreshold", degradationThreshold,
                        "degraded",             degraded,
                        "currentEngine",        currentEngine,
                        "recommendation",       recommendation,
                        "checkedAt",            Instant.now().toString()
                ));
    }

    @Tool(name = "stt_confidence_session_summary",
          description = "Generate a confidence summary report for a completed call session.")
    public AgentResponse sessionSummary(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Total utterances processed") int totalUtterances,
            @ToolParam(description = "Average confidence across all utterances") double avgConfidence,
            @ToolParam(description = "Minimum confidence observed") double minConfidence,
            @ToolParam(description = "Number of utterances below acceptable threshold") int lowConfidenceCount) {

        double wer_risk = lowConfidenceCount / (double) Math.max(totalUtterances, 1) * 100;

        return AgentResponse.ok("STT_CONFIDENCE_MONITOR_AGENT",
                "Session confidence summary for " + sessionId,
                Map.of(
                        "sessionId",          sessionId,
                        "totalUtterances",    totalUtterances,
                        "avgConfidence",      avgConfidence,
                        "minConfidence",      minConfidence,
                        "lowConfidenceCount", lowConfidenceCount,
                        "werRiskPct",         Math.round(wer_risk * 10.0) / 10.0,
                        "qualityRating",      avgConfidence >= 0.85 ? "HIGH" : avgConfidence >= 0.70 ? "MEDIUM" : "LOW",
                        "summarizedAt",       Instant.now().toString()
                ));
    }
}
