package com.ecoskiller.mcp.audio.agent;

import com.ecoskiller.mcp.audio.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-18: TRANSCRIPT_TIMESTAMP_ALIGNMENT_AGENT
 * Aligns word-level transcript timestamps to wall-clock time (UTC ISO-8601)
 * using the call start epoch. Handles DST offsets and timezone normalization.
 */
@Component
public class TranscriptTimestampAlignmentAgent {

    @Tool(name = "transcript_timestamps_align",
          description = "Convert relative word-level timestamps (ms from call start) to absolute UTC wall-clock timestamps.")
    public AgentResponse alignTimestamps(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Call start epoch in milliseconds (UTC)") long callStartEpochMs,
            @ToolParam(description = "Relative word start offset from call start (ms)") long wordStartOffsetMs,
            @ToolParam(description = "Relative word end offset from call start (ms)") long wordEndOffsetMs,
            @ToolParam(description = "Word text") String wordText) {

        long absStartMs = callStartEpochMs + wordStartOffsetMs;
        long absEndMs   = callStartEpochMs + wordEndOffsetMs;
        String absStartIso = Instant.ofEpochMilli(absStartMs).toString();
        String absEndIso   = Instant.ofEpochMilli(absEndMs).toString();

        return AgentResponse.ok("TRANSCRIPT_TIMESTAMP_ALIGNMENT_AGENT",
                "Timestamps aligned for word: " + wordText,
                Map.of(
                        "sessionId",         sessionId,
                        "wordText",          wordText,
                        "relStartMs",        wordStartOffsetMs,
                        "relEndMs",          wordEndOffsetMs,
                        "absStartUtc",       absStartIso,
                        "absEndUtc",         absEndIso,
                        "durationMs",        wordEndOffsetMs - wordStartOffsetMs,
                        "alignedAt",         Instant.now().toString()
                ));
    }

    @Tool(name = "transcript_segment_align",
          description = "Align a full transcript segment (multiple utterances) to absolute UTC timestamps in bulk.")
    public AgentResponse alignSegment(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Segment ID") String segmentId,
            @ToolParam(description = "Call start epoch in ms (UTC)") long callStartEpochMs,
            @ToolParam(description = "Segment start offset from call start (ms)") long segmentStartOffsetMs,
            @ToolParam(description = "Segment end offset from call start (ms)") long segmentEndOffsetMs,
            @ToolParam(description = "Number of words in the segment") int wordCount) {

        String absStart = Instant.ofEpochMilli(callStartEpochMs + segmentStartOffsetMs).toString();
        String absEnd   = Instant.ofEpochMilli(callStartEpochMs + segmentEndOffsetMs).toString();

        return AgentResponse.ok("TRANSCRIPT_TIMESTAMP_ALIGNMENT_AGENT",
                "Segment " + segmentId + " timestamps aligned",
                Map.of(
                        "sessionId",     sessionId,
                        "segmentId",     segmentId,
                        "absStartUtc",   absStart,
                        "absEndUtc",     absEnd,
                        "durationMs",    segmentEndOffsetMs - segmentStartOffsetMs,
                        "wordCount",     wordCount,
                        "alignedAt",     Instant.now().toString()
                ));
    }
}
