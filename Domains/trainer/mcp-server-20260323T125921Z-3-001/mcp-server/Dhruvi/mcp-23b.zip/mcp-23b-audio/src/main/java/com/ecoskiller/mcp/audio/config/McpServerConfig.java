package com.ecoskiller.mcp.audio.config;

import com.ecoskiller.mcp.audio.agent.*;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Registers all 21 CAT-23b agents as MCP tools under the media namespace.
 */
@Configuration
public class McpServerConfig {

    @Bean
    public ToolCallbackProvider audioToolCallbacks(
            AudioBackpressureControlAgent     audioBackpressureControlAgent,
            AudioPreprocessingAgent           audioPreprocessingAgent,
            AudioQualityScoreAgent            audioQualityScoreAgent,
            AudioStreamRoutingAgent           audioStreamRoutingAgent,
            PhoneAudioReplayAlignmentAgent    phoneAudioReplayAlignmentAgent,
            PhoneBackgroundNoiseDetectionAgent phoneBackgroundNoiseDetectionAgent,
            PhoneSilenceSpamAgent             phoneSilenceSpamAgent,
            PhoneInterruptionDetectionAgent   phoneInterruptionDetectionAgent,
            RealtimeLatencyMonitorAgent       realtimeLatencyMonitorAgent,
            PhoneSttProcessingAgent           phoneSttProcessingAgent,
            PhoneSttValidationAgent           phoneSttValidationAgent,
            SttConfidenceMonitorAgent         sttConfidenceMonitorAgent,
            SttWorkerAutoscalingAgent         sttWorkerAutoscalingAgent,
            PhoneConfidenceNormalizationAgent phoneConfidenceNormalizationAgent,
            PhoneLanguageModelSelectionAgent  phoneLanguageModelSelectionAgent,
            LanguageDetectionAgent            languageDetectionAgent,
            TranscriptDriftCorrectionAgent    transcriptDriftCorrectionAgent,
            TranscriptTimestampAlignmentAgent transcriptTimestampAlignmentAgent,
            TranscriptAggregationAgent        transcriptAggregationAgent,
            TranscriptSchemaMigrationAgent    transcriptSchemaMigrationAgent,
            TranscriptVersioningAgent         transcriptVersioningAgent) {

        return MethodToolCallbackProvider.builder()
                .toolObjects(
                        audioBackpressureControlAgent,
                        audioPreprocessingAgent,
                        audioQualityScoreAgent,
                        audioStreamRoutingAgent,
                        phoneAudioReplayAlignmentAgent,
                        phoneBackgroundNoiseDetectionAgent,
                        phoneSilenceSpamAgent,
                        phoneInterruptionDetectionAgent,
                        realtimeLatencyMonitorAgent,
                        phoneSttProcessingAgent,
                        phoneSttValidationAgent,
                        sttConfidenceMonitorAgent,
                        sttWorkerAutoscalingAgent,
                        phoneConfidenceNormalizationAgent,
                        phoneLanguageModelSelectionAgent,
                        languageDetectionAgent,
                        transcriptDriftCorrectionAgent,
                        transcriptTimestampAlignmentAgent,
                        transcriptAggregationAgent,
                        transcriptSchemaMigrationAgent,
                        transcriptVersioningAgent
                )
                .build();
    }
}
