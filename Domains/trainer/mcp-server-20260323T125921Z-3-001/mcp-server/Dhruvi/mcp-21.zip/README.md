# mcp-22-antigravity

**Ecoskiller | CAT-22 — Policy Integrity & Human Override**  
MCP Server in Java | 10 Agents | Priority: HIGH

---

## Agents (10)

| # | Tool Name | Agent |
|---|-----------|-------|
| 1 | `data_lineage_provenance` | DATA_LINEAGE_PROVENANCE_AGENT |
| 2 | `data_minimization_policy` | DATA_MINIMIZATION_POLICY_AGENT |
| 3 | `feature_flag_rollout` | FEATURE_FLAG_ROLLOUT_AGENT |
| 4 | `offline_activity_sync` | OFFLINE_ACTIVITY_SYNC_AGENT |
| 5 | `parent_risk_explanation` | PARENT_RISK_EXPLANATION_AGENT |
| 6 | `placement_intervention` | PLACEMENT_INTERVENTION_AGENT |
| 7 | `policy_knowledge_drift_monitor` | POLICY_KNOWLEDGE_DRIFT_MONITOR_AGENT |
| 8 | `realtime_human_override` | REALTIME_HUMAN_OVERRIDE_AGENT |
| 9 | `safe_account_exit` | SAFE_ACCOUNT_EXIT_AGENT |
| 10 | `safety_escalation_router` | SAFETY_ESCALATION_ROUTER_AGENT |

---

## Requirements

- Java 11+
- Maven 3.8+

---

## Build

```bash
mvn package
```

This produces a fat jar at `target/mcp-22-antigravity-1.0.0.jar` with all dependencies included.

---

## Run the server

```bash
java -jar target/mcp-22-antigravity-1.0.0.jar
```

The server communicates via **stdin/stdout** using JSON-RPC 2.0 (MCP protocol).

---

## Connect to Claude Desktop

Edit `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "mcp-22-antigravity": {
      "command": "java",
      "args": ["-jar", "/absolute/path/to/mcp-22-antigravity/target/mcp-22-antigravity-1.0.0.jar"]
    }
  }
}
```

Replace `/absolute/path/to/` with the actual path on your machine.

---

## Run tests

```bash
mvn test                        # quick pass/fail
mvn test -Dverbose=true         # with full JSON output
```

---

## File Structure

```
mcp-22-antigravity/
├── pom.xml                                          ← Maven build file
├── claude_desktop_config.json                       ← Claude Desktop config snippet
├── README.md
├── src/
│   ├── main/java/com/ecoskiller/mcp/
│   │   └── McpServer.java                           ← Main MCP server (all 10 agents)
│   └── test/java/com/ecoskiller/mcp/
│       └── McpServerTest.java                       ← JUnit 5 tests for all agents
└── target/
    └── mcp-22-antigravity-1.0.0.jar                 ← Built fat jar (after mvn package)
```

---

## Protocol

- Transport: **stdio** (stdin/stdout)
- Format: **JSON-RPC 2.0**
- MCP Version: **2024-11-05**
- Methods: `initialize`, `tools/list`, `tools/call`, `ping`
