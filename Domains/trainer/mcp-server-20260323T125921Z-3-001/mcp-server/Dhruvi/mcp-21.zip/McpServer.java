package com.ecoskiller.mcp;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

/**
 * Ecoskiller | CAT-22 — Policy Integrity & Human Override
 * MCP Server in Java | 10 Agents | Priority: HIGH
 *
 * Transport: stdio (stdin/stdout)
 * Format: JSON-RPC 2.0
 * MCP Version: 2024-11-05
 */
public class McpServer {

    private static final ObjectMapper mapper = new ObjectMapper();
    private static final String MCP_VERSION = "2024-11-05";
    private static final String SERVER_NAME = "mcp-22-antigravity";
    private static final String SERVER_VERSION = "1.0.0";

    // ─── Agent Implementations ────────────────────────────────────────────────

    private static Map<String, Object> handleDataLineageProvenance(JsonNode params) {
        String datasetId = params.has("dataset_id") ? params.get("dataset_id").asText() : "unknown";
        Map<String, Object> result = new HashMap<>();
        result.put("agent", "DATA_LINEAGE_PROVENANCE_AGENT");
        result.put("dataset_id", datasetId);
        result.put("lineage_chain", new String[]{"ingestion", "transformation", "validation", "storage"});
        result.put("provenance_hash", "sha256:" + Integer.toHexString(datasetId.hashCode()));
        result.put("verified", true);
        result.put("status", "lineage_traced");
        return result;
    }

    private static Map<String, Object> handleDataMinimizationPolicy(JsonNode params) {
        String policyScope = params.has("scope") ? params.get("scope").asText() : "global";
        Map<String, Object> result = new HashMap<>();
        result.put("agent", "DATA_MINIMIZATION_POLICY_AGENT");
        result.put("scope", policyScope);
        result.put("fields_retained", new String[]{"user_id", "session_token", "created_at"});
        result.put("fields_purged", new String[]{"raw_input", "browser_fingerprint", "ip_address"});
        result.put("retention_days", 30);
        result.put("status", "policy_applied");
        return result;
    }

    private static Map<String, Object> handleFeatureFlagRollout(JsonNode params) {
        String featureKey = params.has("feature_key") ? params.get("feature_key").asText() : "unknown_feature";
        int rolloutPercent = params.has("rollout_percent") ? params.get("rollout_percent").asInt() : 0;
        Map<String, Object> result = new HashMap<>();
        result.put("agent", "FEATURE_FLAG_ROLLOUT_AGENT");
        result.put("feature_key", featureKey);
        result.put("rollout_percent", rolloutPercent);
        result.put("affected_users", rolloutPercent * 1000);
        result.put("canary_group", rolloutPercent < 10);
        result.put("status", "rollout_scheduled");
        return result;
    }

    private static Map<String, Object> handleOfflineActivitySync(JsonNode params) {
        String userId = params.has("user_id") ? params.get("user_id").asText() : "anonymous";
        Map<String, Object> result = new HashMap<>();
        result.put("agent", "OFFLINE_ACTIVITY_SYNC_AGENT");
        result.put("user_id", userId);
        result.put("queued_events", 14);
        result.put("synced_events", 14);
        result.put("conflict_resolution", "last_write_wins");
        result.put("last_sync_ts", System.currentTimeMillis());
        result.put("status", "sync_complete");
        return result;
    }

    private static Map<String, Object> handleParentRiskExplanation(JsonNode params) {
        String riskCode = params.has("risk_code") ? params.get("risk_code").asText() : "UNKNOWN";
        Map<String, Object> result = new HashMap<>();
        result.put("agent", "PARENT_RISK_EXPLANATION_AGENT");
        result.put("risk_code", riskCode);
        result.put("plain_language_summary", "Your child's activity showed a pattern that may require your attention.");
        result.put("severity", "medium");
        result.put("recommended_action", "Review session history and discuss with your child.");
        result.put("status", "explanation_generated");
        return result;
    }

    private static Map<String, Object> handlePlacementIntervention(JsonNode params) {
        String studentId = params.has("student_id") ? params.get("student_id").asText() : "unknown";
        Map<String, Object> result = new HashMap<>();
        result.put("agent", "PLACEMENT_INTERVENTION_AGENT");
        result.put("student_id", studentId);
        result.put("current_level", "Grade 5 — Advanced");
        result.put("recommended_intervention", "Supplemental support in algebra fundamentals");
        result.put("intervention_priority", "high");
        result.put("assigned_tutor_id", "TUTOR_4421");
        result.put("status", "intervention_scheduled");
        return result;
    }

    private static Map<String, Object> handlePolicyKnowledgeDriftMonitor(JsonNode params) {
        String policyId = params.has("policy_id") ? params.get("policy_id").asText() : "default";
        Map<String, Object> result = new HashMap<>();
        result.put("agent", "POLICY_KNOWLEDGE_DRIFT_MONITOR_AGENT");
        result.put("policy_id", policyId);
        result.put("baseline_version", "v3.1.0");
        result.put("current_version", "v3.4.2");
        result.put("drift_detected", true);
        result.put("drift_score", 0.23);
        result.put("flagged_clauses", new String[]{"clause_7b", "clause_12a"});
        result.put("status", "drift_report_generated");
        return result;
    }

    private static Map<String, Object> handleRealtimeHumanOverride(JsonNode params) {
        String sessionId = params.has("session_id") ? params.get("session_id").asText() : "unknown";
        String overrideReason = params.has("reason") ? params.get("reason").asText() : "manual_review";
        Map<String, Object> result = new HashMap<>();
        result.put("agent", "REALTIME_HUMAN_OVERRIDE_AGENT");
        result.put("session_id", sessionId);
        result.put("override_reason", overrideReason);
        result.put("override_applied", true);
        result.put("ai_decision_suspended", true);
        result.put("human_operator_id", "OPS_0091");
        result.put("override_ts", System.currentTimeMillis());
        result.put("status", "override_active");
        return result;
    }

    private static Map<String, Object> handleSafeAccountExit(JsonNode params) {
        String accountId = params.has("account_id") ? params.get("account_id").asText() : "unknown";
        Map<String, Object> result = new HashMap<>();
        result.put("agent", "SAFE_ACCOUNT_EXIT_AGENT");
        result.put("account_id", accountId);
        result.put("data_export_url", "https://exports.ecoskiller.com/" + accountId + "/data.zip");
        result.put("subscriptions_cancelled", true);
        result.put("data_deletion_scheduled_days", 30);
        result.put("confirmation_email_sent", true);
        result.put("status", "exit_initiated");
        return result;
    }

    private static Map<String, Object> handleSafetyEscalationRouter(JsonNode params) {
        String incidentType = params.has("incident_type") ? params.get("incident_type").asText() : "unknown";
        String severity = params.has("severity") ? params.get("severity").asText() : "low";
        Map<String, Object> result = new HashMap<>();
        result.put("agent", "SAFETY_ESCALATION_ROUTER_AGENT");
        result.put("incident_type", incidentType);
        result.put("severity", severity);
        result.put("routed_to", severity.equals("critical") ? "TRUST_AND_SAFETY_TEAM" : "SUPPORT_TIER_2");
        result.put("escalation_ticket", "ESC-" + (int)(Math.random() * 99999));
        result.put("estimated_response_minutes", severity.equals("critical") ? 5 : 60);
        result.put("status", "escalation_routed");
        return result;
    }

    // ─── Tool Dispatch ────────────────────────────────────────────────────────

    private static Object dispatchTool(String toolName, JsonNode params) throws Exception {
        switch (toolName) {
            case "data_lineage_provenance":       return handleDataLineageProvenance(params);
            case "data_minimization_policy":      return handleDataMinimizationPolicy(params);
            case "feature_flag_rollout":          return handleFeatureFlagRollout(params);
            case "offline_activity_sync":         return handleOfflineActivitySync(params);
            case "parent_risk_explanation":       return handleParentRiskExplanation(params);
            case "placement_intervention":        return handlePlacementIntervention(params);
            case "policy_knowledge_drift_monitor":return handlePolicyKnowledgeDriftMonitor(params);
            case "realtime_human_override":       return handleRealtimeHumanOverride(params);
            case "safe_account_exit":             return handleSafeAccountExit(params);
            case "safety_escalation_router":      return handleSafetyEscalationRouter(params);
            default:
                throw new IllegalArgumentException("Unknown tool: " + toolName);
        }
    }

    // ─── Tool Schema Builder ──────────────────────────────────────────────────

    private static ArrayNode buildToolsList() {
        ArrayNode tools = mapper.createArrayNode();

        Object[][] toolDefs = {
            {"data_lineage_provenance", "Trace full data lineage and provenance chain for a dataset",
                new String[]{"dataset_id"}, new String[]{"string"}},
            {"data_minimization_policy", "Apply data minimization policy, purging non-essential fields",
                new String[]{"scope"}, new String[]{"string"}},
            {"feature_flag_rollout", "Schedule and manage feature flag rollouts by percentage",
                new String[]{"feature_key", "rollout_percent"}, new String[]{"string", "integer"}},
            {"offline_activity_sync", "Sync queued offline user activity events back to the platform",
                new String[]{"user_id"}, new String[]{"string"}},
            {"parent_risk_explanation", "Generate plain-language risk explanations for parents",
                new String[]{"risk_code"}, new String[]{"string"}},
            {"placement_intervention", "Recommend and schedule academic placement interventions for students",
                new String[]{"student_id"}, new String[]{"string"}},
            {"policy_knowledge_drift_monitor", "Detect drift between baseline and current policy versions",
                new String[]{"policy_id"}, new String[]{"string"}},
            {"realtime_human_override", "Suspend AI decision-making and hand control to a human operator",
                new String[]{"session_id", "reason"}, new String[]{"string", "string"}},
            {"safe_account_exit", "Initiate a safe, compliant account exit with data export and deletion",
                new String[]{"account_id"}, new String[]{"string"}},
            {"safety_escalation_router", "Route safety incidents to the appropriate response team by severity",
                new String[]{"incident_type", "severity"}, new String[]{"string", "string"}},
        };

        for (Object[] def : toolDefs) {
            ObjectNode tool = mapper.createObjectNode();
            tool.put("name", (String) def[0]);
            tool.put("description", (String) def[1]);

            ObjectNode inputSchema = mapper.createObjectNode();
            inputSchema.put("type", "object");
            ObjectNode properties = mapper.createObjectNode();
            String[] paramNames = (String[]) def[2];
            String[] paramTypes = (String[]) def[3];
            for (int i = 0; i < paramNames.length; i++) {
                ObjectNode prop = mapper.createObjectNode();
                prop.put("type", paramTypes[i]);
                properties.set(paramNames[i], prop);
            }
            inputSchema.set("properties", properties);
            tool.set("inputSchema", inputSchema);
            tools.add(tool);
        }
        return tools;
    }

    // ─── JSON-RPC Response Builders ───────────────────────────────────────────

    private static ObjectNode successResponse(Object id, Object result) throws Exception {
        ObjectNode resp = mapper.createObjectNode();
        resp.put("jsonrpc", "2.0");
        if (id instanceof Integer) resp.put("id", (Integer) id);
        else if (id instanceof String) resp.put("id", (String) id);
        else resp.putNull("id");
        resp.set("result", mapper.valueToTree(result));
        return resp;
    }

    private static ObjectNode errorResponse(Object id, int code, String message) {
        ObjectNode resp = mapper.createObjectNode();
        resp.put("jsonrpc", "2.0");
        if (id instanceof Integer) resp.put("id", (Integer) id);
        else if (id instanceof String) resp.put("id", (String) id);
        else resp.putNull("id");
        ObjectNode error = mapper.createObjectNode();
        error.put("code", code);
        error.put("message", message);
        resp.set("error", error);
        return resp;
    }

    // ─── Request Handler ──────────────────────────────────────────────────────

    private static ObjectNode handleRequest(JsonNode request) throws Exception {
        Object id = null;
        if (request.has("id")) {
            JsonNode idNode = request.get("id");
            id = idNode.isInt() ? idNode.asInt() : idNode.asText();
        }

        String method = request.has("method") ? request.get("method").asText() : "";
        JsonNode params = request.has("params") ? request.get("params") : mapper.createObjectNode();

        switch (method) {
            case "initialize": {
                Map<String, Object> result = new HashMap<>();
                result.put("protocolVersion", MCP_VERSION);
                Map<String, Object> serverInfo = new HashMap<>();
                serverInfo.put("name", SERVER_NAME);
                serverInfo.put("version", SERVER_VERSION);
                result.put("serverInfo", serverInfo);
                Map<String, Object> capabilities = new HashMap<>();
                capabilities.put("tools", new HashMap<>());
                result.put("capabilities", capabilities);
                return successResponse(id, result);
            }

            case "ping": {
                return successResponse(id, new HashMap<>());
            }

            case "tools/list": {
                Map<String, Object> result = new HashMap<>();
                result.put("tools", buildToolsList());
                return successResponse(id, result);
            }

            case "tools/call": {
                String toolName = params.has("name") ? params.get("name").asText() : "";
                JsonNode toolArgs = params.has("arguments") ? params.get("arguments") : mapper.createObjectNode();
                try {
                    Object toolResult = dispatchTool(toolName, toolArgs);
                    Map<String, Object> result = new HashMap<>();
                    result.put("content", new Object[]{
                        Map.of("type", "text", "text", mapper.writeValueAsString(toolResult))
                    });
                    return successResponse(id, result);
                } catch (IllegalArgumentException e) {
                    return errorResponse(id, -32601, e.getMessage());
                }
            }

            default:
                return errorResponse(id, -32601, "Method not found: " + method);
        }
    }

    // ─── Main Loop ────────────────────────────────────────────────────────────

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter writer = new PrintWriter(System.out, true);

        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;
            try {
                JsonNode request = mapper.readTree(line);
                ObjectNode response = handleRequest(request);
                writer.println(mapper.writeValueAsString(response));
            } catch (Exception e) {
                ObjectNode errResp = errorResponse(null, -32700, "Parse error: " + e.getMessage());
                writer.println(mapper.writeValueAsString(errResp));
            }
        }
    }
}
