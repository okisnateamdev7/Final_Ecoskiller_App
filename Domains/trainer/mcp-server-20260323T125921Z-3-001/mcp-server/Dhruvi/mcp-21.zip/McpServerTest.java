package com.ecoskiller.mcp;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.io.*;
import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for CAT-22 MCP Server — all 10 Policy Integrity & Human Override agents.
 *
 * Run:  mvn test
 *       mvn test -Dverbose=true   (for full JSON output)
 */
class McpServerTest {

    private static final ObjectMapper mapper = new ObjectMapper();
    private static final boolean VERBOSE = Boolean.getBoolean("verbose");

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private JsonNode sendRequest(String json) throws Exception {
        // Pipe request into McpServer via stdin simulation
        InputStream originalIn = System.in;
        PrintStream originalOut = System.out;
        try {
            ByteArrayInputStream in = new ByteArrayInputStream((json + "\n").getBytes());
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            System.setIn(in);
            System.setOut(new PrintStream(out));
            McpServer.main(new String[]{});
            String response = out.toString().trim();
            if (VERBOSE) System.err.println("RESPONSE: " + response);
            return mapper.readTree(response);
        } finally {
            System.setIn(originalIn);
            System.setOut(originalOut);
        }
    }

    private JsonNode callTool(String toolName, String argsJson) throws Exception {
        String req = String.format(
            "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"tools/call\",\"params\":{\"name\":\"%s\",\"arguments\":%s}}",
            toolName, argsJson
        );
        JsonNode resp = sendRequest(req);
        assertNull(resp.get("error"), "Unexpected error: " + resp);
        JsonNode content = resp.get("result").get("content").get(0).get("text");
        return mapper.readTree(content.asText());
    }

    // ─── Protocol Tests ───────────────────────────────────────────────────────

    @Test
    void testInitialize() throws Exception {
        JsonNode resp = sendRequest(
            "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"initialize\",\"params\":{}}"
        );
        assertEquals("2.0", resp.get("jsonrpc").asText());
        assertEquals("2024-11-05", resp.get("result").get("protocolVersion").asText());
        assertEquals("mcp-22-antigravity", resp.get("result").get("serverInfo").get("name").asText());
        System.out.println("PASS  initialize");
    }

    @Test
    void testPing() throws Exception {
        JsonNode resp = sendRequest(
            "{\"jsonrpc\":\"2.0\",\"id\":2,\"method\":\"ping\",\"params\":{}}"
        );
        assertNull(resp.get("error"));
        System.out.println("PASS  ping");
    }

    @Test
    void testToolsList() throws Exception {
        JsonNode resp = sendRequest(
            "{\"jsonrpc\":\"2.0\",\"id\":3,\"method\":\"tools/list\",\"params\":{}}"
        );
        JsonNode tools = resp.get("result").get("tools");
        assertEquals(10, tools.size(), "Expected 10 tools");
        System.out.println("PASS  tools/list  (" + tools.size() + " tools)");
    }

    @Test
    void testUnknownMethod() throws Exception {
        JsonNode resp = sendRequest(
            "{\"jsonrpc\":\"2.0\",\"id\":4,\"method\":\"unknown/method\",\"params\":{}}"
        );
        assertNotNull(resp.get("error"));
        System.out.println("PASS  unknown_method → error returned correctly");
    }

    // ─── Agent Tests ──────────────────────────────────────────────────────────

    @Test
    void testDataLineageProvenance() throws Exception {
        JsonNode r = callTool("data_lineage_provenance", "{\"dataset_id\":\"DS-001\"}");
        assertEquals("DATA_LINEAGE_PROVENANCE_AGENT", r.get("agent").asText());
        assertEquals("lineage_traced", r.get("status").asText());
        assertTrue(r.get("verified").asBoolean());
        System.out.println("PASS  data_lineage_provenance");
    }

    @Test
    void testDataMinimizationPolicy() throws Exception {
        JsonNode r = callTool("data_minimization_policy", "{\"scope\":\"user_profiles\"}");
        assertEquals("DATA_MINIMIZATION_POLICY_AGENT", r.get("agent").asText());
        assertEquals("policy_applied", r.get("status").asText());
        assertTrue(r.get("retention_days").asInt() > 0);
        System.out.println("PASS  data_minimization_policy");
    }

    @Test
    void testFeatureFlagRollout() throws Exception {
        JsonNode r = callTool("feature_flag_rollout", "{\"feature_key\":\"new_dashboard\",\"rollout_percent\":5}");
        assertEquals("FEATURE_FLAG_ROLLOUT_AGENT", r.get("agent").asText());
        assertEquals("rollout_scheduled", r.get("status").asText());
        assertTrue(r.get("canary_group").asBoolean(), "5% rollout should be canary");
        System.out.println("PASS  feature_flag_rollout");
    }

    @Test
    void testOfflineActivitySync() throws Exception {
        JsonNode r = callTool("offline_activity_sync", "{\"user_id\":\"USR-8821\"}");
        assertEquals("OFFLINE_ACTIVITY_SYNC_AGENT", r.get("agent").asText());
        assertEquals("sync_complete", r.get("status").asText());
        assertEquals(r.get("queued_events").asInt(), r.get("synced_events").asInt());
        System.out.println("PASS  offline_activity_sync");
    }

    @Test
    void testParentRiskExplanation() throws Exception {
        JsonNode r = callTool("parent_risk_explanation", "{\"risk_code\":\"EXCESSIVE_SCREEN_TIME\"}");
        assertEquals("PARENT_RISK_EXPLANATION_AGENT", r.get("agent").asText());
        assertEquals("explanation_generated", r.get("status").asText());
        assertFalse(r.get("plain_language_summary").asText().isEmpty());
        System.out.println("PASS  parent_risk_explanation");
    }

    @Test
    void testPlacementIntervention() throws Exception {
        JsonNode r = callTool("placement_intervention", "{\"student_id\":\"STU-4422\"}");
        assertEquals("PLACEMENT_INTERVENTION_AGENT", r.get("agent").asText());
        assertEquals("intervention_scheduled", r.get("status").asText());
        assertFalse(r.get("assigned_tutor_id").asText().isEmpty());
        System.out.println("PASS  placement_intervention");
    }

    @Test
    void testPolicyKnowledgeDriftMonitor() throws Exception {
        JsonNode r = callTool("policy_knowledge_drift_monitor", "{\"policy_id\":\"GDPR-KIDS\"}");
        assertEquals("POLICY_KNOWLEDGE_DRIFT_MONITOR_AGENT", r.get("agent").asText());
        assertEquals("drift_report_generated", r.get("status").asText());
        assertTrue(r.get("drift_score").asDouble() >= 0.0);
        System.out.println("PASS  policy_knowledge_drift_monitor");
    }

    @Test
    void testRealtimeHumanOverride() throws Exception {
        JsonNode r = callTool("realtime_human_override", "{\"session_id\":\"SES-9910\",\"reason\":\"flagged_content\"}");
        assertEquals("REALTIME_HUMAN_OVERRIDE_AGENT", r.get("agent").asText());
        assertEquals("override_active", r.get("status").asText());
        assertTrue(r.get("ai_decision_suspended").asBoolean());
        System.out.println("PASS  realtime_human_override");
    }

    @Test
    void testSafeAccountExit() throws Exception {
        JsonNode r = callTool("safe_account_exit", "{\"account_id\":\"ACC-1234\"}");
        assertEquals("SAFE_ACCOUNT_EXIT_AGENT", r.get("agent").asText());
        assertEquals("exit_initiated", r.get("status").asText());
        assertTrue(r.get("confirmation_email_sent").asBoolean());
        System.out.println("PASS  safe_account_exit");
    }

    @Test
    void testSafetyEscalationRouter() throws Exception {
        JsonNode r = callTool("safety_escalation_router", "{\"incident_type\":\"bullying\",\"severity\":\"critical\"}");
        assertEquals("SAFETY_ESCALATION_ROUTER_AGENT", r.get("agent").asText());
        assertEquals("escalation_routed", r.get("status").asText());
        assertEquals("TRUST_AND_SAFETY_TEAM", r.get("routed_to").asText());
        System.out.println("PASS  safety_escalation_router");
    }

    @Test
    void testUnknownTool() throws Exception {
        String req = "{\"jsonrpc\":\"2.0\",\"id\":99,\"method\":\"tools/call\",\"params\":{\"name\":\"nonexistent_tool\",\"arguments\":{}}}";
        JsonNode resp = sendRequest(req);
        assertNotNull(resp.get("error"), "Expected error for unknown tool");
        System.out.println("PASS  unknown_tool → error returned correctly");
    }
}
