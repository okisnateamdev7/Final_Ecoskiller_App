#!/usr/bin/env bash
# Quick test runner — delegates to test_agents.py
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
if [ ! -f "target/mcp-18-core-control.jar" ]; then
  echo "JAR not found. Run ./build.sh first."
  exit 1
fi
python3 test_agents.py "$@"
