package com.ecoskiller.mcp;

import com.ecoskiller.mcp.agents.*;
import com.ecoskiller.mcp.json.Json;
import com.ecoskiller.mcp.json.Json.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  EcoSkiller | CAT-18 — Governance & Core Control            ║
 * ║  MCP Server · Java 11+ · Zero external dependencies        ║
 * ║  Transport : stdio (stdin/stdout)                           ║
 * ║  Protocol  : JSON-RPC 2.0 · MCP 2024-11-05                 ║
 * ║  Agents    : 5 (TEST_SCORING, PSCA, IBDA, EMBEDDING, ATEX) ║
 * ╚══════════════════════════════════════════════════════════════╝
 */
public class McpServer {

    private static final String MCP_VERSION   = "2024-11-05";
    private static final String SERVER_NAME   = "mcp-18-core-control";
    private static final String SERVER_VERSION = "1.0.0";

    private final Map<String, AgentHandler> agents = new LinkedHashMap<>();

    public McpServer() {
        register(new TestScoringAgent());
        register(new PscaAgent());
        register(new IbdaAgent());
        register(new EmbeddingIndexAgent());
        register(new ActiveTestExecutionAgent());
    }

    private void register(AgentHandler a) { agents.put(a.toolName(), a); }

    // ── Main loop ────────────────────────────────────────────────────────────

    public void run() throws IOException {
        BufferedReader in  = new BufferedReader(
                new InputStreamReader(System.in, StandardCharsets.UTF_8));
        PrintWriter    out = new PrintWriter(
                new OutputStreamWriter(System.out, StandardCharsets.UTF_8), true);
        String line;
        while ((line = in.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;
            String response = dispatch(line);
            if (response != null) out.println(response);
        }
    }

    // ── Dispatcher ───────────────────────────────────────────────────────────

    private String dispatch(String raw) {
        JNode root;
        try {
            root = Json.parse(raw);
        } catch (Exception e) {
            return errorResp(Json.NULL, -32700, "Parse error: " + e.getMessage());
        }
        if (!root.isObj()) return errorResp(Json.NULL, -32600, "Invalid Request");

        JObject req    = root.asObj();
        JNode   idNode = req.has("id") ? req.get("id") : Json.NULL;
        String  method = req.str("method", "");

        if (method.isEmpty()) return errorResp(idNode, -32600, "Invalid Request: missing method");

        switch (method) {
            case "initialize":               return handleInitialize(idNode);
            case "tools/list":               return handleToolsList(idNode);
            case "tools/call":               return handleToolsCall(idNode, req);
            case "ping":                     return okResp(idNode, Json.obj());
            case "notifications/initialized": return null;  // notification — no response
            default:                         return errorResp(idNode, -32601, "Method not found: " + method);
        }
    }

    // ── initialize ───────────────────────────────────────────────────────────

    private String handleInitialize(JNode id) {
        JObject res = Json.obj()
            .put("protocolVersion", MCP_VERSION)
            .put("serverInfo", Json.obj()
                .put("name",    SERVER_NAME)
                .put("version", SERVER_VERSION))
            .put("capabilities", Json.obj()
                .put("tools", Json.obj()));
        return okResp(id, res);
    }

    // ── tools/list ───────────────────────────────────────────────────────────

    private String handleToolsList(JNode id) {
        JArray tools = Json.arr();
        for (AgentHandler a : agents.values()) tools.add(a.toolSchema());
        return okResp(id, Json.obj().put("tools", tools));
    }

    // ── tools/call ───────────────────────────────────────────────────────────

    private String handleToolsCall(JNode id, JObject req) {
        JObject params   = req.has("params")  && req.get("params").isObj()
                           ? req.get("params").asObj() : Json.obj();
        String  toolName = params.str("name", "");
        if (toolName.isEmpty()) return errorResp(id, -32602, "Invalid params: missing tool name");

        AgentHandler agent = agents.get(toolName);
        if (agent == null) return errorResp(id, -32602, "Unknown tool: " + toolName);

        JObject args = params.has("arguments") && params.get("arguments").isObj()
                       ? params.get("arguments").asObj() : Json.obj();
        try {
            JObject payload   = agent.call(args);
            JArray  contents  = Json.arr().add(
                Json.obj().put("type", "text").put("text", payload.toString()));
            return okResp(id, Json.obj().put("content", contents));
        } catch (Exception e) {
            return errorResp(id, -32603, "Agent error: " + e.getMessage());
        }
    }

    // ── JSON-RPC helpers ─────────────────────────────────────────────────────

    private String okResp(JNode id, JObject result) {
        return Json.obj()
            .put("jsonrpc", "2.0")
            .put("id", id)
            .put("result", result)
            .toString();
    }

    private String errorResp(JNode id, int code, String message) {
        return Json.obj()
            .put("jsonrpc", "2.0")
            .put("id", id)
            .put("error", Json.obj()
                .put("code",    (long) code)
                .put("message", message))
            .toString();
    }

    // ── Entry point ──────────────────────────────────────────────────────────

    public static void main(String[] args) throws IOException {
        // Suppress all stderr so only clean JSON-RPC goes to stdout
        System.setErr(new PrintStream(OutputStream.nullOutputStream()));
        new McpServer().run();
    }
}
