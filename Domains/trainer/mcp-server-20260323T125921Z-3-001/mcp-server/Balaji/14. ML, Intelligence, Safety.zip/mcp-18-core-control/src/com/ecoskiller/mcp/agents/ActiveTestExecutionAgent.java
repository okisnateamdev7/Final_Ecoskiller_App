package com.ecoskiller.mcp.agents;

import com.ecoskiller.mcp.AgentHandler;
import com.ecoskiller.mcp.json.Json;
import com.ecoskiller.mcp.json.Json.*;
import java.time.Instant;
import java.util.Random;

/**
 * AGENT 22 — ACTIVE_TEST_EXECUTION_AGENT_COMPLETE
 *
 * Orchestrates the full lifecycle of a live test session.
 *
 * Actions supported:
 *   create_session    — initialise, configure timers, allocate live WS
 *   deliver_question  — push next adaptive question to student
 *   submit_answer     — record student answer, return receipt
 *   get_status        — live session health, rank, progress
 *   pause_session     — freeze timer, issue resume token
 *   resume_session    — unfreeze timer from pause point
 *   close_session     — finalise, compute score, issue certificate signal
 *   emit_proctor_signal — log proctoring event, optionally flag session
 */
public class ActiveTestExecutionAgent implements AgentHandler {

    private static final String[] Q_TYPES  = {"MCQ","open_ended","true_false","numerical","diagram"};
    private static final String[] SUBJECTS = {"Mathematics","Physics","Chemistry","Biology",
                                               "Reasoning","English","Computer Science"};

    @Override public String toolName() { return "active_test_execution"; }

    @Override
    public JObject toolSchema() {
        return Json.obj()
            .put("name",        toolName())
            .put("description",
                "ACTIVE_TEST_EXECUTION_AGENT_COMPLETE — Orchestrates live test session execution. " +
                "Actions: create_session, deliver_question, submit_answer, get_status, " +
                "pause_session, resume_session, close_session, emit_proctor_signal. " +
                "Manages timers, answer windows, live leaderboard updates, and proctoring events.")
            .put("inputSchema", Json.obj()
                .put("type", "object")
                .put("required", Json.arr().add("action"))
                .put("properties", Json.obj()
                    .put("action",           propEnum("Execution action to perform",
                                                 "create_session","deliver_question","submit_answer",
                                                 "get_status","pause_session","resume_session",
                                                 "close_session","emit_proctor_signal"))
                    .put("session_id",       prop("string", "Active test session ID"))
                    .put("student_id",       prop("string", "Student identifier"))
                    .put("test_id",          prop("string", "Test definition identifier"))
                    .put("question_index",   prop("number", "Zero-based question index to deliver"))
                    .put("answer",           prop("string", "Student submitted answer text"))
                    .put("duration_minutes", prop("number", "Session duration in minutes (create_session)"))
                    .put("proctor_event",    propEnum("Proctoring event type",
                                                 "tab_switch","face_missing","noise_detected",
                                                 "copy_detected","multiple_faces","phone_detected"))
                    .put("resume_token",     prop("string", "Token issued at pause, required to resume"))
                ));
    }

    @Override
    public JObject call(JObject args) {
        String action    = args.str("action",     "get_status");
        String sessionId = args.str("session_id", "SES-" + System.currentTimeMillis());
        String studentId = args.str("student_id", "STU-000");
        String testId    = args.str("test_id",    "TEST-000");

        Random rng = new Random(sessionId.hashCode() ^ studentId.hashCode());

        JObject result = Json.obj()
            .put("agent",      "ACTIVE_TEST_EXECUTION_AGENT_COMPLETE")
            .put("action",     action)
            .put("session_id", sessionId)
            .put("student_id", studentId)
            .put("timestamp",  Instant.now().toString());

        switch (action) {
            case "create_session":     create(args,   result, rng, testId);   break;
            case "deliver_question":   deliver(args,  result, rng);           break;
            case "submit_answer":      submit(args,   result, rng);           break;
            case "get_status":         status(result, rng);                   break;
            case "pause_session":      pause(result,  sessionId);             break;
            case "resume_session":     resume(result, args);                  break;
            case "close_session":      close(result,  rng, sessionId);        break;
            case "emit_proctor_signal":proctor(args,  result, rng);           break;
            default:                   result.put("status","unknown_action"); break;
        }

        return result;
    }

    // ── Action handlers ───────────────────────────────────────────────────

    private void create(JObject args, JObject r, Random rng, String testId) {
        int  dur    = args.num("duration_minutes", 60);
        long totQ   = 10 + rng.nextInt(20);
        r.put("status",            "session_created")
         .put("test_id",           testId)
         .put("duration_minutes",  (long) dur)
         .put("total_questions",   totQ)
         .put("start_time",        Instant.now().toString())
         .put("end_time",          Instant.now().plusSeconds(dur * 60L).toString())
         .put("live_ws_url",       "wss://test-exec.ecoskiller.ai/session/" + r.str("session_id",""))
         .put("leaderboard_url",   "https://live.ecoskiller.ai/leaderboard/" + testId)
         .put("proctor_enabled",   true)
         .put("leaderboard_live",  true)
         .put("subject",           SUBJECTS[rng.nextInt(SUBJECTS.length)]);
    }

    private void deliver(JObject args, JObject r, Random rng) {
        int idx = args.num("question_index", 0);
        r.put("status",       "question_delivered")
         .put("q_index",      (long) idx)
         .put("q_type",       Q_TYPES[rng.nextInt(Q_TYPES.length)])
         .put("q_text",       "Question " + (idx + 1) + ": " + SUBJECTS[rng.nextInt(SUBJECTS.length)]
                              + " — adaptive question for session " + r.str("session_id",""))
         .put("time_limit_s", (long)(30 + rng.nextInt(90)))
         .put("difficulty",   Json.round3(0.25 + rng.nextDouble() * 0.70))
         .put("marks",        (long)(1 + rng.nextInt(5)))
         .put("hint_available", rng.nextDouble() > 0.5);
    }

    private void submit(JObject args, JObject r, Random rng) {
        String ans = args.str("answer", "");
        r.put("status",             "answer_recorded")
         .put("answer_length",      (long) ans.length())
         .put("recorded",           true)
         .put("evaluation_pending", true)
         .put("answer_hash",        Integer.toHexString(ans.hashCode()))
         .put("server_received_at", Instant.now().toString())
         .put("latency_ms",         (long)(rng.nextInt(30) + 5));
    }

    private void status(JObject r, Random rng) {
        int answered = rng.nextInt(15);
        r.put("status",               "active")
         .put("questions_answered",   (long) answered)
         .put("questions_remaining",  (long)(20 - answered))
         .put("elapsed_minutes",      (long)(answered * 2 + rng.nextInt(5)))
         .put("current_rank",         (long)(1 + rng.nextInt(500)))
         .put("current_score",        Json.round2(answered * 5.5 + rng.nextDouble() * 10))
         .put("connection_quality",   rng.nextDouble() > 0.1 ? "good" : "degraded")
         .put("proctor_alerts",       (long)(rng.nextDouble() < 0.08 ? 1 : 0))
         .put("heartbeat",            Instant.now().toString());
    }

    private void pause(JObject r, String sessionId) {
        r.put("status",       "paused")
         .put("paused_at",    Instant.now().toString())
         .put("resume_token", "RT-" + Integer.toHexString(sessionId.hashCode()));
    }

    private void resume(JObject r, JObject args) {
        r.put("status",      "resumed")
         .put("resumed_at",  Instant.now().toString())
         .put("token_valid", args.has("resume_token") && !args.str("resume_token","").isEmpty());
    }

    private void close(JObject r, Random rng, String sessionId) {
        double finalScore = Json.round2(40 + rng.nextDouble() * 55);
        r.put("status",               "closed")
         .put("closed_at",            Instant.now().toString())
         .put("final_score",          finalScore)
         .put("grade",                finalScore >= 85 ? "A+" : finalScore >= 70 ? "A"
                                      : finalScore >= 55 ? "B" : "C")
         .put("time_taken_minutes",   (long)(30 + rng.nextInt(30)))
         .put("certificate_eligible", finalScore >= 60)
         .put("report_url",           "https://reports.ecoskiller.ai/session/" + sessionId)
         .put("certificate_url",      finalScore >= 60
                                      ? "https://certs.ecoskiller.ai/" + sessionId : null);
    }

    private void proctor(JObject args, JObject r, Random rng) {
        String evt      = args.str("proctor_event", "generic_event");
        boolean critical= evt.contains("copy") || evt.contains("face") || evt.contains("phone");
        String  severity= critical ? "HIGH" : "MEDIUM";
        r.put("status",          "proctor_signal_logged")
         .put("event_type",      evt)
         .put("severity",        severity)
         .put("event_id",        "PE-" + (100000 + rng.nextInt(899999)))
         .put("action_taken",    critical ? "warning_issued" : "logged_only")
         .put("auto_flag",       critical)
         .put("session_status",  critical ? "flagged" : "active")
         .put("evidence_stored", true);
    }

    private static JObject prop(String type, String desc) {
        return Json.obj().put("type", type).put("description", desc);
    }
    private static JObject propEnum(String desc, String... vals) {
        JArray e = Json.arr(); for (String v : vals) e.add(v);
        return Json.obj().put("type","string").put("description", desc).put("enum", e);
    }
}
