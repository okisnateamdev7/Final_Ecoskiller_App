package com.ecoskiller.mcp.json;

import java.util.*;

/**
 * Minimal zero-dependency JSON builder + parser for MCP stdio protocol.
 *
 * Builder  : Json.obj(), Json.arr(), Json.val(), .put(), .add()
 * Parser   : Json.parse(String) → JNode
 * Serialise: node.toString()
 */
public final class Json {

    /* ─────────────────────────────────────────────────────────────────────
       Node types
       ───────────────────────────────────────────────────────────────────── */

    public interface JNode {
        default JObject asObj()     { return (JObject) this; }
        default JArray  asArr()     { return (JArray)  this; }
        default String  strVal()    { return ((JStr)   this).value; }
        default boolean boolVal()   { return ((JBool)  this).value; }
        default double  numVal()    { return ((JNum)   this).value; }
        default boolean isNull()    { return this instanceof JNull; }
        default boolean isObj()     { return this instanceof JObject; }
        default boolean isArr()     { return this instanceof JArray; }
        default boolean isStr()     { return this instanceof JStr; }
        default boolean isNum()     { return this instanceof JNum; }
        default boolean isBool()    { return this instanceof JBool; }
        String toString();
    }

    /* Object */
    public static final class JObject implements JNode {
        private final LinkedHashMap<String,JNode> map = new LinkedHashMap<>();

        public JObject put(String k, JNode v)   { map.put(k, v != null ? v : NULL); return this; }
        public JObject put(String k, String v)  { return put(k, v == null ? NULL : new JStr(v)); }
        public JObject put(String k, long v)    { return put(k, new JNum(v)); }
        public JObject put(String k, double v)  { return put(k, new JNum(v)); }
        public JObject put(String k, boolean v) { return put(k, v ? TRUE : FALSE); }

        public boolean has(String k)            { return map.containsKey(k); }
        public JNode   get(String k)            { return map.getOrDefault(k, NULL); }
        public String  str(String k, String d)  { JNode n=map.get(k); return n instanceof JStr  ? ((JStr)n).value : d; }
        public int     num(String k, int d)     { JNode n=map.get(k); return n instanceof JNum  ? (int)((JNum)n).value : d; }
        public double  dbl(String k, double d)  { JNode n=map.get(k); return n instanceof JNum  ? ((JNum)n).value : d; }
        public boolean bool(String k, boolean d){ JNode n=map.get(k); return n instanceof JBool ? ((JBool)n).value : d; }
        public Set<String> keys()               { return map.keySet(); }

        @Override public String toString() {
            StringBuilder sb = new StringBuilder("{");
            boolean first = true;
            for (Map.Entry<String,JNode> e : map.entrySet()) {
                if (!first) sb.append(','); first = false;
                sb.append('"').append(escStr(e.getKey())).append("\":").append(e.getValue());
            }
            return sb.append('}').toString();
        }
    }

    /* Array */
    public static final class JArray implements JNode {
        private final List<JNode> list = new ArrayList<>();

        public JArray add(JNode v)   { list.add(v != null ? v : NULL); return this; }
        public JArray add(String v)  { return add(v == null ? NULL : new JStr(v)); }
        public JArray add(long v)    { return add(new JNum(v)); }
        public JArray add(double v)  { return add(new JNum(v)); }
        public JArray add(boolean v) { return add(v ? TRUE : FALSE); }
        public int    size()         { return list.size(); }
        public JNode  get(int i)     { return list.get(i); }
        public List<JNode> items()   { return Collections.unmodifiableList(list); }

        @Override public String toString() {
            StringBuilder sb = new StringBuilder("[");
            for (int i=0;i<list.size();i++) { if(i>0)sb.append(','); sb.append(list.get(i)); }
            return sb.append(']').toString();
        }
    }

    public static final class JStr  implements JNode { public final String  value; JStr(String v){value=v;} @Override public String toString(){return "\""+escStr(value)+"\"";} }
    public static final class JNum  implements JNode { public final double  value; JNum(double v){value=v;}
        @Override public String toString() {
            if (value == Math.floor(value) && !Double.isInfinite(value) && Math.abs(value) < 1e15) return String.valueOf((long)value);
            return String.valueOf(value);
        }
    }
    public static final class JBool implements JNode { public final boolean value; JBool(boolean v){value=v;} @Override public String toString(){return value?"true":"false";} }
    public static final class JNull implements JNode { @Override public String toString(){return "null";} }

    /* Constants */
    public static final JNull  NULL  = new JNull();
    public static final JBool  TRUE  = new JBool(true);
    public static final JBool  FALSE = new JBool(false);

    /* Factories */
    public static JObject obj()              { return new JObject(); }
    public static JArray  arr()              { return new JArray();  }
    public static JNode   val(String v)      { return v==null ? NULL : new JStr(v); }
    public static JNode   val(long v)        { return new JNum(v); }
    public static JNode   val(double v)      { return new JNum(v); }
    public static JNode   val(boolean v)     { return v ? TRUE : FALSE; }

    /* ─────────────────────────────────────────────────────────────────────
       Parser
       ───────────────────────────────────────────────────────────────────── */

    public static JNode parse(String s) {
        if (s==null||s.isBlank()) return NULL;
        return new Parser(s.trim()).parseValue();
    }

    private static final class Parser {
        private final String s;
        private int pos = 0;
        Parser(String s){ this.s=s; }

        JNode parseValue() {
            skipWS();
            if (pos>=s.length()) return NULL;
            char c = s.charAt(pos);
            switch(c) {
                case '{': return parseObject();
                case '[': return parseArray();
                case '"': return parseString();
                case 't': pos+=4; return TRUE;
                case 'f': pos+=5; return FALSE;
                case 'n': pos+=4; return NULL;
                default:  return parseNumber();
            }
        }

        JObject parseObject() {
            JObject o = new JObject();
            pos++; // '{'
            skipWS();
            if (peek()=='}') { pos++; return o; }
            while (pos<s.length()) {
                skipWS();
                String key = ((JStr)parseString()).value;
                skipWS();
                if (peek()==':') pos++;
                skipWS();
                JNode val = parseValue();
                o.put(key, val);
                skipWS();
                if (peek()==',') { pos++; } else { break; }
            }
            skipWS();
            if (peek()=='}') pos++;
            return o;
        }

        JArray parseArray() {
            JArray a = new JArray();
            pos++; // '['
            skipWS();
            if (peek()==']') { pos++; return a; }
            while (pos<s.length()) {
                skipWS();
                a.add(parseValue());
                skipWS();
                if (peek()==',') { pos++; } else { break; }
            }
            skipWS();
            if (peek()==']') pos++;
            return a;
        }

        JStr parseString() {
            pos++; // '"'
            StringBuilder sb = new StringBuilder();
            while (pos<s.length()) {
                char c = s.charAt(pos++);
                if (c=='"') break;
                if (c=='\\' && pos<s.length()) {
                    char e = s.charAt(pos++);
                    switch(e) {
                        case '"': sb.append('"'); break;
                        case '\\': sb.append('\\'); break;
                        case '/':  sb.append('/');  break;
                        case 'n':  sb.append('\n'); break;
                        case 'r':  sb.append('\r'); break;
                        case 't':  sb.append('\t'); break;
                        case 'b':  sb.append('\b'); break;
                        case 'f':  sb.append('\f'); break;
                        case 'u':
                            if (pos+4<=s.length()) {
                                sb.append((char)Integer.parseInt(s.substring(pos,pos+4),16)); pos+=4;
                            }
                            break;
                        default: sb.append(e);
                    }
                } else { sb.append(c); }
            }
            return new JStr(sb.toString());
        }

        JNum parseNumber() {
            int start = pos;
            if (pos<s.length()&&s.charAt(pos)=='-') pos++;
            while (pos<s.length()&&(Character.isDigit(s.charAt(pos))||s.charAt(pos)=='.'
                   ||s.charAt(pos)=='e'||s.charAt(pos)=='E'||s.charAt(pos)=='+'||s.charAt(pos)=='-')) pos++;
            try { return new JNum(Double.parseDouble(s.substring(start,pos))); }
            catch(NumberFormatException e){ return new JNum(0); }
        }

        void skipWS() { while(pos<s.length()&&Character.isWhitespace(s.charAt(pos)))pos++; }
        char peek()   { return pos<s.length()?s.charAt(pos):0; }
    }

    /* ─────────────────────────────────────────────────────────────────────
       Utilities
       ───────────────────────────────────────────────────────────────────── */

    public static String escStr(String s) {
        if (s==null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch(c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                case '\t': sb.append("\\t");  break;
                default:   sb.append(c);
            }
        }
        return sb.toString();
    }

    public static double round2(double v) { return Math.round(v*100.0)/100.0; }
    public static double round3(double v) { return Math.round(v*1000.0)/1000.0; }
    public static double round4(double v) { return Math.round(v*10000.0)/10000.0; }
}
