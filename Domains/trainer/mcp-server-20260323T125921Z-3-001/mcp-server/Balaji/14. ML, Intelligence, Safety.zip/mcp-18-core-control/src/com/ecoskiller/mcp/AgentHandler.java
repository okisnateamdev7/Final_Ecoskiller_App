package com.ecoskiller.mcp;

import com.ecoskiller.mcp.json.Json.JObject;
import com.ecoskiller.mcp.json.Json.JNode;

/**
 * Contract every CAT-18 agent must implement.
 */
public interface AgentHandler {
    /** MCP tool name used in tools/list and tools/call */
    String toolName();

    /** Full JSON Schema descriptor returned in tools/list */
    JObject toolSchema();

    /** Execute with the given arguments object; return result payload */
    JObject call(JObject args) throws Exception;
}
