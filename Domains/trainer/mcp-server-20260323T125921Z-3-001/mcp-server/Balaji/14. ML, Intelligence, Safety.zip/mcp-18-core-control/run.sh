#!/usr/bin/env bash
ROOT="$(cd "$(dirname "$0")" && pwd)"
JAR="$ROOT/target/mcp-18-core-control.jar"
if [ ! -f "$JAR" ]; then echo "JAR not found. Run ./build.sh first."; exit 1; fi
java -jar "$JAR"
