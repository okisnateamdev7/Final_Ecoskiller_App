#!/usr/bin/env python3
"""
EcoSkiller MCP-18 — Test runner
Usage: python3 test_agents.py [--verbose]
"""
import subprocess, json, sys

JAR  = "target/mcp-18-core-control.jar"
CMD  = ["java", "-jar", JAR]
VERB = "--verbose" in sys.argv

passed = failed = 0

TESTS = [
    ("initialize",
     {"jsonrpc":"2.0","id":0,"method":"initialize","params":{}}),
    ("tools/list",
     {"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}),
    ("ping",
     {"jsonrpc":"2.0","id":2,"method":"ping","params":{}}),
    ("test_scoring — standard + anomaly",
     {"jsonrpc":"2.0","id":3,"method":"tools/call","params":{
       "name":"test_scoring","arguments":{
         "session_id":"SES-001","student_id":"STU-101","responses":[],
         "rubric":"standard","cohort_id":"BATCH-2024","flag_anomalies":True}}}),
    ("test_scoring — advanced rubric",
     {"jsonrpc":"2.0","id":4,"method":"tools/call","params":{
       "name":"test_scoring","arguments":{
         "session_id":"SES-002","student_id":"STU-202","responses":[],
         "rubric":"advanced","flag_anomalies":False}}}),
    ("psca_compliance — all policies + escalate",
     {"jsonrpc":"2.0","id":5,"method":"tools/call","params":{
       "name":"psca_compliance","arguments":{
         "audit_id":"AUD-001","entity_type":"user","entity_id":"USR-404",
         "action":"data_export","policy_set":"all","tenant_id":"SCHOOL-01",
         "escalate_on_violation":True}}}),
    ("psca_compliance — gdpr only",
     {"jsonrpc":"2.0","id":6,"method":"tools/call","params":{
       "name":"psca_compliance","arguments":{
         "audit_id":"AUD-002","entity_type":"content","entity_id":"CNT-77",
         "action":"content_publish","policy_set":"gdpr"}}}),
    ("ibda_assessment — adaptive math + realtime",
     {"jsonrpc":"2.0","id":7,"method":"tools/call","params":{
       "name":"ibda_assessment","arguments":{
         "assessment_id":"IBDA-555","student_id":"STU-303",
         "subject":"math","target_level":"adaptive",
         "question_count":8,"real_time_adjust":True,"time_pressure":True}}}),
    ("ibda_assessment — advanced reasoning",
     {"jsonrpc":"2.0","id":8,"method":"tools/call","params":{
       "name":"ibda_assessment","arguments":{
         "assessment_id":"IBDA-556","student_id":"STU-404",
         "subject":"reasoning","target_level":"advanced","question_count":5}}}),
    ("embedding_index — ingest",
     {"jsonrpc":"2.0","id":9,"method":"tools/call","params":{
       "name":"embedding_index","arguments":{
         "operation":"ingest","namespace":"test-bank","content_id":"CNT-100",
         "content_text":"Newton laws of motion describe force and acceleration",
         "model":"ecoskiller-v2","content_type":"question"}}}),
    ("embedding_index — search top-4",
     {"jsonrpc":"2.0","id":10,"method":"tools/call","params":{
       "name":"embedding_index","arguments":{
         "operation":"search","namespace":"test-bank",
         "query_text":"laws of motion force acceleration",
         "top_k":4,"score_threshold":0.75}}}),
    ("embedding_index — delete",
     {"jsonrpc":"2.0","id":11,"method":"tools/call","params":{
       "name":"embedding_index","arguments":{
         "operation":"delete","namespace":"test-bank","content_id":"CNT-100"}}}),
    ("embedding_index — health_check",
     {"jsonrpc":"2.0","id":12,"method":"tools/call","params":{
       "name":"embedding_index","arguments":{
         "operation":"health_check","namespace":"test-bank","dimension":768}}}),
    ("active_test — create_session",
     {"jsonrpc":"2.0","id":13,"method":"tools/call","params":{
       "name":"active_test_execution","arguments":{
         "action":"create_session","session_id":"LIVE-001",
         "student_id":"STU-505","test_id":"MATH-ADV","duration_minutes":45}}}),
    ("active_test — deliver_question q0",
     {"jsonrpc":"2.0","id":14,"method":"tools/call","params":{
       "name":"active_test_execution","arguments":{
         "action":"deliver_question","session_id":"LIVE-001","question_index":0}}}),
    ("active_test — submit_answer",
     {"jsonrpc":"2.0","id":15,"method":"tools/call","params":{
       "name":"active_test_execution","arguments":{
         "action":"submit_answer","session_id":"LIVE-001",
         "answer":"F=ma (Newtons second law)"}}}),
    ("active_test — get_status",
     {"jsonrpc":"2.0","id":16,"method":"tools/call","params":{
       "name":"active_test_execution","arguments":{
         "action":"get_status","session_id":"LIVE-001"}}}),
    ("active_test — pause_session",
     {"jsonrpc":"2.0","id":17,"method":"tools/call","params":{
       "name":"active_test_execution","arguments":{
         "action":"pause_session","session_id":"LIVE-001"}}}),
    ("active_test — resume_session",
     {"jsonrpc":"2.0","id":18,"method":"tools/call","params":{
       "name":"active_test_execution","arguments":{
         "action":"resume_session","session_id":"LIVE-001",
         "resume_token":"RT-deadbeef"}}}),
    ("active_test — emit_proctor_signal face_missing",
     {"jsonrpc":"2.0","id":19,"method":"tools/call","params":{
       "name":"active_test_execution","arguments":{
         "action":"emit_proctor_signal","session_id":"LIVE-001",
         "proctor_event":"face_missing"}}}),
    ("active_test — emit_proctor_signal tab_switch",
     {"jsonrpc":"2.0","id":20,"method":"tools/call","params":{
       "name":"active_test_execution","arguments":{
         "action":"emit_proctor_signal","session_id":"LIVE-001",
         "proctor_event":"tab_switch"}}}),
    ("active_test — close_session",
     {"jsonrpc":"2.0","id":21,"method":"tools/call","params":{
       "name":"active_test_execution","arguments":{
         "action":"close_session","session_id":"LIVE-001"}}}),
    ("unknown method → error response",
     {"jsonrpc":"2.0","id":99,"method":"unknown/method","params":{}}),
]

print("=" * 60)
print(" EcoSkiller MCP-18 — CAT-18 Agent Test Suite (Python)")
print("=" * 60)

for label, payload in TESTS:
    raw = json.dumps(payload)
    try:
        proc = subprocess.run(CMD, input=raw, capture_output=True, text=True, timeout=10)
        out  = proc.stdout.strip()
        resp = json.loads(out)
        # "unknown method" test expects an error, not a result
        if "unknown method" in label:
            ok = "error" in resp
        else:
            ok = "result" in resp
        if ok:
            print(f"  [PASS] {label}")
            passed += 1
            if VERB:
                print("  ←", json.dumps(resp, indent=4))
        else:
            print(f"  [FAIL] {label}")
            print(f"         → {out[:200]}")
            failed += 1
    except Exception as e:
        print(f"  [FAIL] {label}  ← exception: {e}")
        failed += 1

print()
print("=" * 60)
print(f" Results: {passed} passed, {failed} failed")
print("=" * 60)
sys.exit(0 if failed == 0 else 1)
