# mcp-18-core-control

**EcoSkiller | CAT-18 — Governance & Core Control**  
MCP Server in **Java** | 5 Agents | Category: ML, Intelligence & Safety | Priority: **HIGH**  
Zero external dependencies — runs on any **Java 11+** JRE

---

## Agents (5)

| # | Tool Name | Agent |
|---|-----------|-------|
| 18 | `test_scoring` | TEST_SCORING_AGENT_COMPLETE |
| 19 | `psca_compliance` | PSCA_COMPLETE_SPECIFICATION_v1.0.0 |
| 20 | `ibda_assessment` | IBDA_COMPLETE_SEALED_SPECIFICATION |
| 21 | `embedding_index` | EMBEDDING_INDEX_AGENT_COMPLETE |
| 22 | `active_test_execution` | ACTIVE_TEST_EXECUTION_AGENT_COMPLETE |

---

## Agent Reference

### 18 · `test_scoring` — TEST_SCORING_AGENT_COMPLETE
Scores submitted test responses via multi-dimensional rubrics (accuracy, depth,
originality, coherence). Normalises raw scores against cohort percentiles, optionally
runs anomaly detection, and emits a structured score report for downstream ML pipelines.

**Key inputs:** `session_id`, `student_id`, `responses[]`, `rubric` (standard/advanced/creativity/stem),
`cohort_id`, `flag_anomalies`

---

### 19 · `psca_compliance` — PSCA_COMPLETE_SPECIFICATION_v1.0.0
Platform Safety & Compliance Auditor. Validates events against GDPR, COPPA, ISO 27001,
and internal policies. Generates immutable append-only audit trails and routes violations
to escalation workflows with SLA tracking.

**Key inputs:** `audit_id`, `entity_type`, `entity_id`, `action`, `policy_set` (gdpr/coppa/iso27001/all),
`escalate_on_violation`

---

### 20 · `ibda_assessment` — IBDA_COMPLETE_SEALED_SPECIFICATION
Intelligence-Based Dynamic Assessment. Profiles students across 7 cognitive dimensions
(logical, linguistic, spatial, creative, kinesthetic, interpersonal, musical), generates
personalised adaptive question blueprints, and optionally emits real-time difficulty
adjustment signals to the live test engine.

**Key inputs:** `assessment_id`, `student_id`, `subject`, `target_level` (beginner/intermediate/advanced/adaptive),
`question_count`, `real_time_adjust`, `time_pressure`

---

### 21 · `embedding_index` — EMBEDDING_INDEX_AGENT_COMPLETE
Full vector-embedding lifecycle manager. Four operations:

| Operation | Purpose |
|-----------|---------|
| `ingest` | Tokenise text, generate embedding, upsert to vector store |
| `search` | Cosine-similarity top-k nearest-neighbour retrieval |
| `delete` | Remove vector by content ID |
| `health_check` | Index stats, shard status, p50/p99 latency |

**Key inputs:** `operation`, `namespace`, `content_id`, `content_text`, `query_text`,
`top_k`, `score_threshold`, `model` (mini-lm/ada-002/ecoskiller-v2/ecoskiller-v3)

---

### 22 · `active_test_execution` — ACTIVE_TEST_EXECUTION_AGENT_COMPLETE
Full lifecycle orchestration for live test sessions. Eight actions:

| Action | Purpose |
|--------|---------|
| `create_session` | Initialise session, allocate live WebSocket, configure timer |
| `deliver_question` | Push adaptive question to student |
| `submit_answer` | Record answer with receipt and hash |
| `get_status` | Live rank, progress, connection quality, heartbeat |
| `pause_session` | Freeze timer, issue resume token |
| `resume_session` | Unfreeze timer from pause point |
| `close_session` | Finalise score, grade, certificate signal |
| `emit_proctor_signal` | Log proctoring event (tab_switch, face_missing, copy_detected …) |

---

## Requirements

- **Java 11+** (JRE is sufficient to run; JDK required to build from source)
- No Maven, no Gradle, no external libraries

---

## Quick Start

### A — Run pre-built JAR (recommended)

```bash
java -jar target/mcp-18-core-control.jar
```

### B — Build from source then run

```bash
./build.sh
java -jar target/mcp-18-core-control.jar
```

### C — Manual build (if build.sh is unavailable)

```bash
find src -name "*.java" | xargs javac -d target/classes
printf "Manifest-Version: 1.0\nMain-Class: com.ecoskiller.mcp.McpServer\n" \
    > target/META-INF/MANIFEST.MF
jar cfm target/mcp-18-core-control.jar target/META-INF/MANIFEST.MF \
    -C target/classes .
java -jar target/mcp-18-core-control.jar
```

The server reads JSON-RPC 2.0 from **stdin** and writes responses to **stdout**.

---

## Connect to Claude Desktop

Edit the config file:
- **macOS/Linux:** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "mcp-18-core-control": {
      "command": "java",
      "args": ["-jar", "/absolute/path/to/mcp-18-core-control/target/mcp-18-core-control.jar"]
    }
  }
}
```

---

## Run Tests

```bash
./test_agents.sh             # 23 tests — quick pass/fail
./test_agents.sh --verbose   # with full JSON response output
python3 test_agents.py       # direct Python runner
```

---

## File Structure

```
mcp-18-core-control/
├── src/
│   └── com/ecoskiller/mcp/
│       ├── McpServer.java                      ← MCP server + JSON-RPC router
│       ├── AgentHandler.java                   ← Agent interface
│       ├── json/
│       │   └── Json.java                       ← Zero-dep JSON builder + parser
│       └── agents/
│           ├── TestScoringAgent.java           ← Agent 18: TEST_SCORING
│           ├── PscaAgent.java                  ← Agent 19: PSCA
│           ├── IbdaAgent.java                  ← Agent 20: IBDA
│           ├── EmbeddingIndexAgent.java        ← Agent 21: EMBEDDING_INDEX
│           └── ActiveTestExecutionAgent.java   ← Agent 22: ACTIVE_TEST_EXECUTION
├── target/
│   └── mcp-18-core-control.jar                 ← Pre-built fat JAR (Java 21)
├── build.sh                                    ← Build from source (javac + jar)
├── run.sh                                      ← Run the server
├── test_agents.py                              ← Python test runner (23 tests)
├── test_agents.sh                              ← Shell wrapper for test_agents.py
├── claude_desktop_config.json                  ← Claude Desktop config snippet
└── README.md
```

---

## Protocol

| Property | Value |
|---|---|
| Transport | stdio (stdin / stdout) |
| Format | JSON-RPC 2.0 |
| MCP Version | 2024-11-05 |
| Methods | `initialize`, `tools/list`, `tools/call`, `ping`, `notifications/initialized` |
| Java Version | 11+ |
| Dependencies | **None** — pure Java stdlib only |

---

## Example JSON-RPC Calls

**Initialize**
```json
{"jsonrpc":"2.0","id":0,"method":"initialize","params":{}}
```

**Score a Test**
```json
{
  "jsonrpc":"2.0","id":1,"method":"tools/call",
  "params":{
    "name":"test_scoring",
    "arguments":{
      "session_id":"SES-2024-001","student_id":"STU-5050",
      "responses":[],"rubric":"advanced",
      "cohort_id":"BATCH-JUN-2024","flag_anomalies":true
    }
  }
}
```

**Embedding Search**
```json
{
  "jsonrpc":"2.0","id":2,"method":"tools/call",
  "params":{
    "name":"embedding_index",
    "arguments":{
      "operation":"search","namespace":"skill-content",
      "query_text":"quadratic formula factorisation",
      "top_k":5,"score_threshold":0.80
    }
  }
}
```

**Create Live Test Session**
```json
{
  "jsonrpc":"2.0","id":3,"method":"tools/call",
  "params":{
    "name":"active_test_execution",
    "arguments":{
      "action":"create_session","session_id":"LIVE-2024-042",
      "student_id":"STU-707","test_id":"PHYSICS-ADVANCED",
      "duration_minutes":60
    }
  }
}
```
