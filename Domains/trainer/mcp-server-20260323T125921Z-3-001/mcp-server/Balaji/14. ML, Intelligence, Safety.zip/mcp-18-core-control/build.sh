#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  EcoSkiller MCP-18 — Build Script
#  Requires: Java 11+  (no Maven, no external deps)
# ─────────────────────────────────────────────────────────────
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC_DIR="$ROOT/src"
OUT_DIR="$ROOT/target/classes"
JAR="$ROOT/target/mcp-18-core-control.jar"

echo "[1/4] Cleaning previous build..."
rm -rf "$ROOT/target"
mkdir -p "$OUT_DIR"

echo "[2/4] Compiling Java sources..."
find "$SRC_DIR" -name "*.java" | xargs javac -d "$OUT_DIR"

echo "[3/4] Creating MANIFEST..."
mkdir -p "$ROOT/target/META-INF"
printf "Manifest-Version: 1.0\nMain-Class: com.ecoskiller.mcp.McpServer\n" \
    > "$ROOT/target/META-INF/MANIFEST.MF"

echo "[4/4] Packaging fat JAR..."
jar cfm "$JAR" "$ROOT/target/META-INF/MANIFEST.MF" -C "$OUT_DIR" .

SIZE=$(du -sh "$JAR" | cut -f1)
echo ""
echo "  ✓ Build complete → $JAR  ($SIZE)"
echo "  Run: java -jar target/mcp-18-core-control.jar"
