package com.ecoskiller.mlsafety.agents;

import com.ecoskiller.mlsafety.models.*;
import com.fasterxml.jackson.databind.node.*;
import java.util.List;

// ═══════════════════════════════════════════════════════════════════════════
// Agent 11 — INTELLIGENCE_BIAS_DETECTION_AGENT
// Detects demographic and algorithmic bias in intelligence scoring models.
// ═══════════════════════════════════════════════════════════════════════════
class IntelligenceBiasDetectionAgent extends BaseAgent {
    @Override public String getName() { return "INTELLIGENCE_BIAS_DETECTION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_run_bias_audit",
                "Run a full bias audit across demographic groups for an intelligence model.",
                schema("model_name","audit_scope","tenant_id")),
            new McpTool("mlsafety_get_bias_report",
                "Get the detailed bias audit report with fairness metrics.",
                schema("audit_id","tenant_id")),
            new McpTool("mlsafety_apply_bias_correction",
                "Apply a bias correction strategy to the model scoring pipeline.",
                schema("model_name","correction_method","audit_id","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch(t) {
            case "mlsafety_run_bias_audit" -> {
                ObjectNode d = mapper.createObjectNode(); String auditId="audit-"+System.currentTimeMillis();
                d.put("audit_id",     auditId); d.put("model_name",a.path("model_name").asText());
                d.put("groups_tested", 6); d.put("disparate_impact_found",false);
                d.put("max_group_delta",2.1); d.put("threshold",5.0); d.put("result","FAIR");
                yield AgentResponse.success(getName(), d, "Bias audit: FAIR (max group delta=2.1%, threshold=5%).");
            }
            case "mlsafety_get_bias_report" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode groups = mapper.createArrayNode();
                String[][] grps = {{"gender_male","81.2","0.0"},{"gender_female","80.4","-0.8"},
                                   {"urban","81.8","+0.6"},{"rural","79.7","-1.5"}};
                for(String[] g:grps){ObjectNode gr=mapper.createObjectNode();gr.put("group",g[0]);gr.put("avg_score",g[1]);gr.put("delta_from_mean",g[2]);groups.add(gr);}
                d.set("group_metrics",groups); d.put("audit_id",a.path("audit_id").asText()); d.put("overall_fairness","PASS");
                yield AgentResponse.success(getName(), d, "Bias report: all groups within fairness threshold.");
            }
            case "mlsafety_apply_bias_correction" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("model_name",        a.path("model_name").asText());
                d.put("correction_method", a.path("correction_method").asText("reweighting"));
                d.put("applied",           true); d.put("max_delta_after",0.9); d.put("improvement","76% bias reduction");
                yield AgentResponse.success(getName(), d, "Bias correction applied (76% reduction).");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 12 — IBDA_COMPLETE_SEALED_SPECIFICATION_AGENT
// Manages the IBDA (Intelligence Bias Detection Algorithm) sealed specification.
// ═══════════════════════════════════════════════════════════════════════════
class IbdaCompleteSpecificationAgent extends BaseAgent {
    @Override public String getName() { return "IBDA_COMPLETE_SEALED_SPECIFICATION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_get_ibda_spec",
                "Retrieve the sealed IBDA specification with cryptographic hash.",
                schema("spec_version","tenant_id")),
            new McpTool("mlsafety_verify_ibda_integrity",
                "Verify the integrity of the IBDA specification using its hash.",
                schema("spec_version","expected_hash","tenant_id")),
            new McpTool("mlsafety_seal_ibda_spec",
                "Seal a new IBDA specification version with cryptographic signature.",
                schema("spec_content_hash","author","approval_id","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch(t) {
            case "mlsafety_get_ibda_spec" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("version",    a.path("spec_version").asText("v1.4")); d.put("sealed",true);
                d.put("hash",       "sha256:a1b2c3d4e5f6a7b8c9d0e1f2"); d.put("sealed_by","Ecoskiller-Safety-Board");
                d.put("sections",   8); d.put("tampered",false); d.put("status","ACTIVE");
                yield AgentResponse.success(getName(), d, "IBDA spec v1.4 retrieved and integrity confirmed.");
            }
            case "mlsafety_verify_ibda_integrity" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("version",        a.path("spec_version").asText("v1.4"));
                d.put("provided_hash",  a.path("expected_hash").asText());
                d.put("stored_hash",    "sha256:a1b2c3d4e5f6a7b8c9d0e1f2"); d.put("match",true); d.put("tampered",false);
                yield AgentResponse.success(getName(), d, "IBDA specification integrity verified: INTACT.");
            }
            case "mlsafety_seal_ibda_spec" -> {
                ObjectNode d = mapper.createObjectNode(); String sealId="seal-"+System.currentTimeMillis();
                d.put("seal_id",      sealId); d.put("new_version","v1.5");
                d.put("sealed_at",    System.currentTimeMillis()); d.put("author",a.path("author").asText());
                d.put("immutable",    true); d.put("approval_id",a.path("approval_id").asText());
                yield AgentResponse.success(getName(), d, "IBDA spec sealed as v1.5 — immutable.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 13 — HIDDEN_TALENT_DETECTION_AGENT
// Identifies hidden or latent talent signals not captured by standard assessment.
// ═══════════════════════════════════════════════════════════════════════════
class HiddenTalentDetectionAgent extends BaseAgent {
    @Override public String getName() { return "HIDDEN_TALENT_DETECTION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_detect_hidden_talent",
                "Scan for hidden talent signals in a student or worker's behavioral data.",
                schema("entity_id","entity_type","data_window_days","tenant_id")),
            new McpTool("mlsafety_get_talent_signal_report",
                "Get a full report of detected hidden talent signals.",
                schema("entity_id","tenant_id")),
            new McpTool("mlsafety_recommend_talent_pathway",
                "Recommend development pathways based on detected hidden talents.",
                schema("entity_id","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch(t) {
            case "mlsafety_detect_hidden_talent" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",       a.path("entity_id").asText());
                d.put("signals_found",   3); d.put("top_signal","Advanced pattern synthesis in unstructured tasks");
                d.put("hidden_score",    78); d.put("rank_within_cohort","Top 12%");
                d.put("confidence",      0.84); d.put("model_version","htd-v2");
                yield AgentResponse.success(getName(), d, "3 hidden talent signals detected. Top 12% of cohort.");
            }
            case "mlsafety_get_talent_signal_report" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode signals = mapper.createArrayNode();
                String[][] sigs = {{"Spatial reasoning under noise","HIGH","84%"},
                                   {"Cross-domain problem bridging","MEDIUM","71%"},
                                   {"Rapid schema formation","HIGH","88%"}};
                for(String[] s:sigs){ObjectNode sig=mapper.createObjectNode();sig.put("signal",s[0]);sig.put("strength",s[1]);sig.put("confidence",s[2]);signals.add(sig);}
                d.set("signals",signals); d.put("entity_id",a.path("entity_id").asText());
                yield AgentResponse.success(getName(), d, "3 hidden talent signals in report.");
            }
            case "mlsafety_recommend_talent_pathway" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode paths = mapper.createArrayNode();
                for(String p:new String[]{"Competitive Programming","Research & Innovation Track","Advanced STEM Fellowship"})
                    paths.add(p);
                d.set("pathways",paths); d.put("entity_id",a.path("entity_id").asText()); d.put("confidence",0.82);
                yield AgentResponse.success(getName(), d, "3 development pathways recommended.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 14 — FEATURE_EXTRACTION_AGENT
// Extracts ML features from raw student/worker data for model input.
// ═══════════════════════════════════════════════════════════════════════════
class FeatureExtractionAgent extends BaseAgent {
    @Override public String getName() { return "FEATURE_EXTRACTION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_extract_features",
                "Extract ML feature vector from raw entity data.",
                schema("entity_id","entity_type","feature_set","tenant_id")),
            new McpTool("mlsafety_get_feature_store_entry",
                "Retrieve a stored feature vector for an entity from the feature store.",
                schema("entity_id","feature_version","tenant_id")),
            new McpTool("mlsafety_run_feature_pipeline",
                "Run the full feature extraction pipeline for a batch of entities.",
                schema("entity_type","batch_id","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch(t) {
            case "mlsafety_extract_features" -> {
                ObjectNode d = mapper.createObjectNode(); ObjectNode vector = mapper.createObjectNode();
                vector.put("xp_normalized",0.87); vector.put("streak_length",14); vector.put("session_frequency",4.2);
                vector.put("avg_score",81.4); vector.put("peer_interactions",28); vector.put("completion_rate",0.91);
                d.set("feature_vector",vector); d.put("entity_id",a.path("entity_id").asText());
                d.put("features_extracted",6); d.put("feature_version","fv-v3");
                yield AgentResponse.success(getName(), d, "6 features extracted (fv-v3).");
            }
            case "mlsafety_get_feature_store_entry" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",      a.path("entity_id").asText());
                d.put("feature_version",a.path("feature_version").asText("fv-v3"));
                d.put("features",       6); d.put("cached",true);
                d.put("stored_at",      "2026-03-04T18:00:00Z"); d.put("ttl_hours",24);
                yield AgentResponse.success(getName(), d, "Feature store entry retrieved (cached).");
            }
            case "mlsafety_run_feature_pipeline" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("batch_id",        a.path("batch_id").asText()); d.put("entity_type",a.path("entity_type").asText());
                d.put("entities_processed",4820); d.put("features_per_entity",6);
                d.put("pipeline_version","fp-v2"); d.put("duration_seconds",34); d.put("status","COMPLETE");
                yield AgentResponse.success(getName(), d, "Feature pipeline: 4820 entities, 6 features each.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 15 — EMBEDDING_INDEX_AGENT
// Manages vector embeddings and similarity search for skill/intelligence data.
// ═══════════════════════════════════════════════════════════════════════════
class EmbeddingIndexAgent extends BaseAgent {
    @Override public String getName() { return "EMBEDDING_INDEX_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_upsert_embedding",
                "Upsert a vector embedding for an entity into the embedding index.",
                schema("entity_id","entity_type","embedding_vector","model_id","tenant_id")),
            new McpTool("mlsafety_similarity_search",
                "Find the top-K most similar entities to a query using vector similarity.",
                schema("query_entity_id","entity_type","top_k","tenant_id")),
            new McpTool("mlsafety_get_embedding_index_stats",
                "Get statistics about the embedding index.",
                schema("tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch(t) {
            case "mlsafety_upsert_embedding" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",    a.path("entity_id").asText()); d.put("entity_type",a.path("entity_type").asText());
                d.put("upserted",     true); d.put("dimensions",384); d.put("model_id",a.path("model_id").asText("emb-v2"));
                d.put("index_updated",true);
                yield AgentResponse.success(getName(), d, "Embedding upserted (384-dim).");
            }
            case "mlsafety_similarity_search" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode results = mapper.createArrayNode();
                String[] ids = {"USR-007","USR-041","USR-103","USR-209","USR-314"};
                double[] sims = {0.97,0.93,0.89,0.86,0.82};
                for(int i=0;i<ids.length;i++){ObjectNode r=mapper.createObjectNode();r.put("entity_id",ids[i]);r.put("similarity",sims[i]);r.put("rank",i+1);results.add(r);}
                d.set("results",results); d.put("query_entity",a.path("query_entity_id").asText()); d.put("top_k",5);
                yield AgentResponse.success(getName(), d, "Top-5 similar entities found (best=0.97).");
            }
            case "mlsafety_get_embedding_index_stats" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("total_vectors",   48_200); d.put("dimensions",384); d.put("model_id","emb-v2");
                d.put("index_size_mb",   187); d.put("last_updated","2026-03-05T06:00:00Z");
                d.put("search_latency_p95_ms",12);
                yield AgentResponse.success(getName(), d, "Embedding index: 48,200 vectors, 384-dim.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 16 — CONTENT_MODERATION_AGENT
// Moderates user-generated content for policy violations and harmful material.
// ═══════════════════════════════════════════════════════════════════════════
class ContentModerationAgent extends BaseAgent {
    @Override public String getName() { return "CONTENT_MODERATION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_moderate_content",
                "Moderate a content item for policy violations, hate speech, or harmful material.",
                schema("content_id","content_type","content_text","tenant_id")),
            new McpTool("mlsafety_get_moderation_queue",
                "Get items currently in the moderation review queue.",
                schema("tenant_id","status","limit")),
            new McpTool("mlsafety_resolve_moderation_case",
                "Resolve a moderation case with APPROVE, REJECT, or ESCALATE.",
                schema("case_id","decision","reviewer_id","notes","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch(t) {
            case "mlsafety_moderate_content" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("content_id",    a.path("content_id").asText()); d.put("verdict","APPROVED");
                d.put("violation_score",4); d.put("hate_speech",false); d.put("harmful",false);
                d.put("spam",          false); d.put("confidence",0.98); d.put("model_version","mod-v3");
                yield AgentResponse.success(getName(), d, "Content moderated: APPROVED (violation_score=4/100).");
            }
            case "mlsafety_get_moderation_queue" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode queue = mapper.createArrayNode();
                for(int i=1;i<=3;i++){ObjectNode item=mapper.createObjectNode();item.put("case_id","MOD-00"+i);item.put("content_type","comment");item.put("violation_score",72+i*3);item.put("priority","HIGH");queue.add(item);}
                d.set("queue",queue); d.put("total_pending",3); d.put("avg_wait_minutes",12);
                yield AgentResponse.success(getName(), d, "Moderation queue: 3 items pending.");
            }
            case "mlsafety_resolve_moderation_case" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("case_id",    a.path("case_id").asText()); d.put("decision",a.path("decision").asText("REJECT"));
                d.put("resolved",   true); d.put("content_action","REMOVED"); d.put("notified_author",true);
                d.put("resolved_by",a.path("reviewer_id").asText());
                yield AgentResponse.success(getName(), d, "Moderation case resolved: " + a.path("decision").asText("REJECT"));
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 17 — CHILD_SAFETY_MONITOR_AGENT
// Monitors platform activity for child safety violations and risk signals.
// ═══════════════════════════════════════════════════════════════════════════
class ChildSafetyMonitorAgent extends BaseAgent {
    @Override public String getName() { return "CHILD_SAFETY_MONITOR_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_run_child_safety_scan",
                "Run a child safety scan on a session, message thread, or content item.",
                schema("scan_target_id","scan_type","tenant_id")),
            new McpTool("mlsafety_get_child_safety_alerts",
                "Get open child safety alerts for a tenant.",
                schema("tenant_id","severity","limit")),
            new McpTool("mlsafety_escalate_child_safety_case",
                "Escalate a detected child safety risk to the safety response team.",
                schema("alert_id","evidence","escalation_level","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch(t) {
            case "mlsafety_run_child_safety_scan" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("scan_target_id", a.path("scan_target_id").asText()); d.put("scan_type",a.path("scan_type").asText("message_thread"));
                d.put("risk_detected",  false); d.put("signals_checked",28); d.put("risk_score",3);
                d.put("verdict",        "SAFE"); d.put("model_version","csm-v2");
                yield AgentResponse.success(getName(), d, "Child safety scan: SAFE (risk_score=3/100).");
            }
            case "mlsafety_get_child_safety_alerts" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode alerts = mapper.createArrayNode();
                d.set("alerts",alerts); d.put("total_open",0); d.put("tenant_id",a.path("tenant_id").asText());
                d.put("status","ALL_CLEAR");
                yield AgentResponse.success(getName(), d, "Child safety: 0 open alerts. Status: ALL_CLEAR.");
            }
            case "mlsafety_escalate_child_safety_case" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("alert_id",    a.path("alert_id").asText()); d.put("escalated",true);
                d.put("case_id",    "CS-"+System.currentTimeMillis()); d.put("level",a.path("escalation_level").asText("CRITICAL"));
                d.put("team_notified","child-safety@ecoskiller.com"); d.put("response_sla_hours",1);
                yield AgentResponse.success(getName(), d, "Child safety case escalated. SLA: 1h response.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 18 — CAREER_PREDICTION_AGENT
// Predicts career trajectories and role-fit based on skills and intelligence.
// ═══════════════════════════════════════════════════════════════════════════
class CareerPredictionAgent extends BaseAgent {
    @Override public String getName() { return "CAREER_PREDICTION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_predict_career_trajectory",
                "Predict the most likely career trajectory for a student or worker.",
                schema("entity_id","horizon_years","tenant_id")),
            new McpTool("mlsafety_get_role_fit_scores",
                "Get fit scores for a set of target roles based on the entity's profile.",
                schema("entity_id","role_ids_csv","tenant_id")),
            new McpTool("mlsafety_generate_career_roadmap",
                "Generate a personalized career roadmap with milestones.",
                schema("entity_id","target_role","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch(t) {
            case "mlsafety_predict_career_trajectory" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",      a.path("entity_id").asText());
                d.put("horizon_years",  a.path("horizon_years").asInt(5));
                d.put("top_trajectory", "Senior Software Engineer → Tech Lead");
                d.put("probability",    0.74); d.put("alt_trajectory","Data Scientist");
                d.put("alt_probability",0.61); d.put("model_version","career-v3");
                yield AgentResponse.success(getName(), d, "Career trajectory predicted: Sr. Engineer→Tech Lead (74%).");
            }
            case "mlsafety_get_role_fit_scores" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode scores = mapper.createArrayNode();
                String[][] roles = {{"SWE-L4","Backend Engineer","88.4"},{"PM-L3","Product Manager","71.2"},{"DS-L3","Data Scientist","79.6"}};
                for(String[] r:roles){ObjectNode score=mapper.createObjectNode();score.put("role_id",r[0]);score.put("role_name",r[1]);score.put("fit_score",r[2]);scores.add(score);}
                d.set("role_scores",scores); d.put("entity_id",a.path("entity_id").asText());
                yield AgentResponse.success(getName(), d, "Role fit scores: top match=Backend Engineer (88.4%).");
            }
            case "mlsafety_generate_career_roadmap" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode milestones = mapper.createArrayNode();
                String[][] ms = {{"6 months","Complete System Design course"},{"1 year","Lead a backend module"},{"2 years","Pass L4 promotion review"},{"3 years","Mentor junior engineers"}};
                for(String[] m:ms){ObjectNode mi=mapper.createObjectNode();mi.put("timeline",m[0]);mi.put("milestone",m[1]);milestones.add(mi);}
                d.set("milestones",milestones); d.put("target_role",a.path("target_role").asText());
                d.put("entity_id",a.path("entity_id").asText()); d.put("estimated_years",3);
                yield AgentResponse.success(getName(), d, "Career roadmap: 4 milestones, ~3 years.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 19 — ACTIVE_TEST_EXECUTION_AGENT
// Manages live test execution sessions with proctoring and anti-cheat.
// ═══════════════════════════════════════════════════════════════════════════
class ActiveTestExecutionAgent extends BaseAgent {
    @Override public String getName() { return "ACTIVE_TEST_EXECUTION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_start_test_session",
                "Initialize and start a proctored test session for a candidate.",
                schema("test_id","candidate_id","proctoring_level","tenant_id")),
            new McpTool("mlsafety_submit_test_answer",
                "Submit an answer for a question during an active test session.",
                schema("session_id","question_id","answer","time_taken_sec","tenant_id")),
            new McpTool("mlsafety_end_test_session",
                "End a test session, trigger scoring, and generate the result.",
                schema("session_id","submitted_by","tenant_id")),
            new McpTool("mlsafety_get_proctoring_alerts",
                "Get anti-cheat proctoring alerts raised during a test session.",
                schema("session_id","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch(t) {
            case "mlsafety_start_test_session" -> {
                String sid = "sess-"+System.currentTimeMillis(); ObjectNode d = mapper.createObjectNode();
                d.put("session_id",  sid); d.put("test_id",a.path("test_id").asText());
                d.put("candidate_id",a.path("candidate_id").asText()); d.put("proctoring",a.path("proctoring_level").asText("STANDARD"));
                d.put("questions",   30); d.put("time_limit_min",60); d.put("status","ACTIVE");
                d.put("started_at",  System.currentTimeMillis());
                yield AgentResponse.success(getName(), d, "Test session started: " + sid + " (30Q, 60min).");
            }
            case "mlsafety_submit_test_answer" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("session_id",  a.path("session_id").asText()); d.put("question_id",a.path("question_id").asText());
                d.put("recorded",    true); d.put("time_taken_sec",a.path("time_taken_sec").asInt(45));
                d.put("answer_hash", "sha256:"+Integer.toHexString(a.path("answer").asText().hashCode()));
                yield AgentResponse.success(getName(), d, "Answer recorded (tamper-proof hash stored).");
            }
            case "mlsafety_end_test_session" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("session_id",  a.path("session_id").asText()); d.put("status","SUBMITTED");
                d.put("answers_submitted",30); d.put("scoring_queued",true);
                d.put("result_eta_seconds",15); d.put("proctoring_alerts",0);
                yield AgentResponse.success(getName(), d, "Test session submitted. Scoring queued (ETA 15s).");
            }
            case "mlsafety_get_proctoring_alerts" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode alerts = mapper.createArrayNode();
                d.set("alerts",alerts); d.put("session_id",a.path("session_id").asText());
                d.put("total_alerts",0); d.put("verdict","NO_VIOLATIONS"); d.put("integrity_score",100);
                yield AgentResponse.success(getName(), d, "Proctoring: NO_VIOLATIONS (integrity=100%).");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}
