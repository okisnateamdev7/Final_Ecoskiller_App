package com.ecoskiller.enterprise.server;

import com.ecoskiller.enterprise.agents.*;
import com.ecoskiller.enterprise.models.AgentResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Ecoskiller Enterprise MCP Server — Unit Tests (18 Agents)")
class EnterpriseMcpServerTest {

    private EnterpriseMcpServer server;
    @BeforeEach void setUp() { server = new EnterpriseMcpServer(); }

    @Test @DisplayName("initialize → mcp-13-enterprise")
    void testInit() {
        String r = callMethod("initialize","{}");
        assertTrue(r.contains("mcp-13-enterprise")); assertFalse(r.contains("\"error\""));
    }
    @Test @DisplayName("18 agents registered")
    void testCount() { assertEquals(18, server.registry.count()); }
    @Test @DisplayName("tools/list contains all agent tools")
    void testToolsList() {
        String r = callMethod("tools/list","{}");
        assertTrue(r.contains("enterprise_predict_work_reliability"));
        assertTrue(r.contains("enterprise_detect_sync_conflicts"));
        assertTrue(r.contains("enterprise_extract_skills_from_text"));
        assertTrue(r.contains("enterprise_benchmark_organization"));
        assertTrue(r.contains("enterprise_calculate_hiring_roi"));
        assertTrue(r.contains("enterprise_compute_productivity_index"));
        assertTrue(r.contains("enterprise_compute_reputation"));
        assertTrue(r.contains("enterprise_validate_migration"));
        assertTrue(r.contains("enterprise_detect_fraud_pattern"));
        assertTrue(r.contains("enterprise_detect_fake_profile"));
        assertTrue(r.contains("enterprise_analyze_excel_file"));
        assertTrue(r.contains("enterprise_normalize_dataset"));
        assertTrue(r.contains("enterprise_classify_certificate"));
        assertTrue(r.contains("enterprise_run_shortlisting"));
        assertTrue(r.contains("enterprise_predict_attrition_risk"));
        assertTrue(r.contains("enterprise_map_performance_metrics"));
        assertTrue(r.contains("enterprise_classify_data_quality"));
        assertTrue(r.contains("enterprise_auto_map_fields"));
    }
    @Test @DisplayName("unknown method → -32601")
    void testUnknownMethod() { assertTrue(callMethod("fake","{}").contains("-32601")); }
    @Test @DisplayName("malformed JSON → -32700")
    void testMalformed()     { assertTrue(server.handleMessage("{bad}").contains("-32700")); }

    // Agent tests
    @Test void testWorkReliability() {
        assertTrue(callTool("enterprise_predict_work_reliability",
            "{\"worker_id\":\"W1\",\"task_completion_rate\":\"0.90\",\"tenant_id\":\"T1\"}")
            .contains("reliability_score"));
    }
    @Test void testBatchReliability() {
        assertTrue(callTool("enterprise_batch_reliability_scan",
            "{\"department_id\":\"D1\",\"tenant_id\":\"T1\",\"threshold\":\"70\"}")
            .contains("workers_scanned"));
    }
    @Test void testSyncConflicts() {
        assertTrue(callTool("enterprise_detect_sync_conflicts",
            "{\"sync_job_id\":\"JOB-1\",\"source_system\":\"SAP\",\"target_system\":\"ERP\",\"tenant_id\":\"T1\"}")
            .contains("\"conflicts_found\":14"));
    }
    @Test void testSkillExtraction() {
        assertTrue(callTool("enterprise_extract_skills_from_text",
            "{\"text_content\":\"...\",\"source_type\":\"resume\",\"entity_id\":\"E1\",\"tenant_id\":\"T1\"}")
            .contains("Python"));
    }
    @Test void testSkillCompare() {
        assertTrue(callTool("enterprise_compare_skill_vectors",
            "{\"candidate_id\":\"C1\",\"job_id\":\"J1\",\"tenant_id\":\"T1\"}")
            .contains("STRONG_MATCH"));
    }
    @Test void testBenchmark() {
        String r = callTool("enterprise_benchmark_organization",
            "{\"org_id\":\"ORG-1\",\"industry\":\"EdTech\",\"size_band\":\"M\",\"metric\":\"skill_coverage\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("percentile")); assertTrue(r.contains("B+"));
    }
    @Test void testHiringROI() {
        assertTrue(callTool("enterprise_calculate_hiring_roi",
            "{\"hire_id\":\"H1\",\"cost_inr\":\"150000\",\"ramp_months\":\"3\",\"role\":\"SWE\",\"tenant_id\":\"T1\"}")
            .contains("roi_multiplier"));
    }
    @Test void testProductivityIndex() {
        assertTrue(callTool("enterprise_compute_productivity_index",
            "{\"entity_id\":\"E1\",\"entity_type\":\"employee\",\"period\":\"2026-02\",\"tenant_id\":\"T1\"}")
            .contains("\"productivity_index\":81.7"));
    }
    @Test void testReputation() {
        assertTrue(callTool("enterprise_compute_reputation",
            "{\"entity_id\":\"W1\",\"entity_type\":\"worker\",\"tenant_id\":\"T1\"}")
            .contains("\"reputation_score\":862"));
    }
    @Test void testMigrationValidation() {
        assertTrue(callTool("enterprise_validate_migration",
            "{\"migration_id\":\"MIG-1\",\"source\":\"legacy\",\"target\":\"erp\",\"tenant_id\":\"T1\"}")
            .contains("99.94"));
    }
    @Test void testFraudDetection() {
        assertTrue(callTool("enterprise_detect_fraud_pattern",
            "{\"entity_id\":\"E1\",\"entity_type\":\"transaction\",\"event_data\":\"{}\",\"tenant_id\":\"T1\"}")
            .contains("CLEAR"));
    }
    @Test void testFakeProfile() {
        assertTrue(callTool("enterprise_detect_fake_profile",
            "{\"profile_id\":\"P1\",\"profile_type\":\"worker\",\"tenant_id\":\"T1\"}")
            .contains("AUTHENTIC"));
    }
    @Test void testBatchFakeScan() {
        assertTrue(callTool("enterprise_batch_fake_scan",
            "{\"tenant_id\":\"T1\",\"cohort_type\":\"student\",\"flag_threshold\":\"50\"}")
            .contains("confirmed_fake"));
    }
    @Test void testExcelAnalysis() {
        String r = callTool("enterprise_analyze_excel_file",
            "{\"file_id\":\"F1\",\"sheet_name\":\"Sheet1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("quality_score")); assertTrue(r.contains("91.4"));
    }
    @Test void testExcelAnomalies() {
        assertTrue(callTool("enterprise_detect_excel_anomalies",
            "{\"file_id\":\"F1\",\"column\":\"salary\",\"method\":\"IQR\",\"tenant_id\":\"T1\"}")
            .contains("\"outliers\":4"));
    }
    @Test void testNormalization() {
        assertTrue(callTool("enterprise_normalize_dataset",
            "{\"dataset_id\":\"D1\",\"source_format\":\"CSV\",\"target_schema\":\"ecoskiller-v4\",\"tenant_id\":\"T1\"}")
            .contains("COMPLETE"));
    }
    @Test void testCertificateClassify() {
        assertTrue(callTool("enterprise_classify_certificate",
            "{\"certificate_id\":\"CERT-1\",\"file_url\":\"https://...\",\"issuer\":\"IIT\",\"tenant_id\":\"T1\"}")
            .contains("AUTHENTIC"));
    }
    @Test void testShortlisting() {
        assertTrue(callTool("enterprise_run_shortlisting",
            "{\"job_id\":\"J1\",\"pool_size\":\"150\",\"shortlist_target\":\"15\",\"criteria_json\":\"{}\",\"tenant_id\":\"T1\"}")
            .contains("\"shortlisted\":15"));
    }
    @Test void testAttritionRisk() {
        assertTrue(callTool("enterprise_predict_attrition_risk",
            "{\"employee_id\":\"E1\",\"tenure_months\":\"24\",\"satisfaction_score\":\"72\",\"tenant_id\":\"T1\"}")
            .contains("attrition_risk_pct"));
    }
    @Test void testAttritionHeatmap() {
        assertTrue(callTool("enterprise_get_attrition_heatmap",
            "{\"org_id\":\"ORG-1\",\"tenant_id\":\"T1\"}")
            .contains("Support"));
    }
    @Test void testMetricMapper() {
        assertTrue(callTool("enterprise_map_performance_metrics",
            "{\"source_system\":\"SAP-HR\",\"metric_payload\":\"{}\",\"entity_id\":\"E1\",\"tenant_id\":\"T1\"}")
            .contains("\"metrics_mapped\":8"));
    }
    @Test void testDataCleaning() {
        assertTrue(callTool("enterprise_classify_data_quality",
            "{\"dataset_id\":\"D1\",\"tenant_id\":\"T1\"}")
            .contains("\"quality_score\":87.3"));
    }
    @Test void testAiFieldMapping() {
        String r = callTool("enterprise_auto_map_fields",
            "{\"source_schema_json\":\"{}\",\"target_schema\":\"ecoskiller-v4\",\"confidence_threshold\":\"0.80\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"fields_mapped\":12")); assertTrue(r.contains("afm-v3.1"));
    }
    @Test void testMappingConfidence() {
        assertTrue(callTool("enterprise_get_mapping_confidence_report",
            "{\"mapping_job_id\":\"fmap-1\",\"tenant_id\":\"T1\"}")
            .contains("MANUAL_REVIEW"));
    }
    @Test void testUnknownTool() {
        assertTrue(callTool("enterprise_nonexistent","{}").contains("-32602"));
    }

    private String callMethod(String method, String params) {
        return server.handleMessage("{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\""+method+"\",\"params\":"+params+"}");
    }
    private String callTool(String name, String args) {
        return server.handleMessage("{\"jsonrpc\":\"2.0\",\"id\":99,\"method\":\"tools/call\",\"params\":{\"name\":\""+name+"\",\"arguments\":"+args+"}}");
    }
}
