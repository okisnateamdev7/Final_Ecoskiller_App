package com.ecoskiller.enterprise.server;

import com.ecoskiller.enterprise.agents.*;
import com.ecoskiller.enterprise.models.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.*;

import java.io.*;
import java.util.logging.*;

/**
 * Ecoskiller Enterprise MCP Server
 * CAT-13 — Enterprise Optimization + Trust Infrastructure
 * MCP Server: mcp-13-enterprise  |  Namespace: core
 *
 * Agents (18):
 *   1.  WORK_RELIABILITY_MODEL_AGENT
 *   2.  SYNC_CONFLICT_RESOLVER_AGENT
 *   3.  STRUCTURED_SKILL_EXTRACTION_MODEL_AGENT
 *   4.  CORPORATE_BENCHMARK_MODEL_AGENT
 *   5.  HIRING_ROI_MODEL_AGENT
 *   6.  PRODUCTIVITY_INDEX_MODEL_AGENT
 *   7.  REPUTATION_SCORE_ENGINE_AGENT
 *   8.  MIGRATION_VALIDATION_ENGINE_AGENT
 *   9.  FRAUD_PATTERN_DETECTION_MODEL_AGENT
 *  10.  FAKE_PROFILE_DETECTION_MODEL_AGENT
 *  11.  EXCEL_PATTERN_DETECTION_MODEL_AGENT
 *  12.  DATA_NORMALIZATION_ENGINE_AGENT
 *  13.  CERTIFICATE_AUTHENTICITY_CLASSIFIER_AGENT
 *  14.  AUTOMATED_SHORTLISTING_ENGINE_AGENT
 *  15.  ATTRITION_RISK_MODEL_AGENT
 *  16.  PERFORMANCE_METRIC_MAPPER_AGENT
 *  17.  DATA_CLEANING_CLASSIFIER_AGENT
 *  18.  AI_FIELD_MAPPING_MODEL_AGENT
 */
public class EnterpriseMcpServer {

    static final String SERVER_NAME    = "mcp-13-enterprise";
    static final String SERVER_VERSION = "1.0.0";
    static final String NAMESPACE      = "core";

    private static final Logger LOGGER = Logger.getLogger(EnterpriseMcpServer.class.getName());
    private final ObjectMapper  mapper   = new ObjectMapper();
    final         AgentRegistry registry = new AgentRegistry();

    public EnterpriseMcpServer() { registerAllAgents(); }

    private void registerAllAgents() {
        // Group 1: Reliability, Sync, Skills, Benchmark, ROI, Productivity
        registry.register(new WorkReliabilityModelAgent());
        registry.register(new SyncConflictResolverAgent());
        registry.register(new StructuredSkillExtractionModelAgent());
        registry.register(new CorporateBenchmarkModelAgent());
        registry.register(new HiringRoiModelAgent());
        registry.register(new ProductivityIndexModelAgent());
        // Group 2: Reputation, Migration, Fraud, Fake, Excel, Normalization
        registry.register(new ReputationScoreEngineAgent());
        registry.register(new MigrationValidationEngineAgent());
        registry.register(new FraudPatternDetectionModelAgent());
        registry.register(new FakeProfileDetectionModelAgent());
        registry.register(new ExcelPatternDetectionModelAgent());
        registry.register(new DataNormalizationEngineAgent());
        // Group 3: Certificate, Shortlisting, Attrition, MetricMapper, Cleaning, FieldMapping
        registry.register(new CertificateAuthenticityClassifierAgent());
        registry.register(new AutomatedShortlistingEngineAgent());
        registry.register(new AttritionRiskModelAgent());
        registry.register(new PerformanceMetricMapperAgent());
        registry.register(new DataCleaningClassifierAgent());
        registry.register(new AiFieldMappingModelAgent());
        LOGGER.info("[" + SERVER_NAME + "] Registered " + registry.count() + "/18 agents.");
    }

    // ── MCP stdio loop ────────────────────────────────────────────────────

    public void run() throws Exception {
        LOGGER.info("[" + SERVER_NAME + "] Starting on stdio transport...");
        var in  = new BufferedReader(new InputStreamReader(System.in));
        var out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)), true);
        String line;
        while ((line = in.readLine()) != null) {
            line = line.trim(); if (line.isEmpty()) continue;
            String resp = handleMessage(line); if (resp != null) out.println(resp);
        }
    }

    // ── Dispatch ─────────────────────────────────────────────────────────

    String handleMessage(String raw) {
        try {
            ObjectNode req = (ObjectNode) mapper.readTree(raw);
            String method  = req.path("method").asText("");
            Object id      = req.has("id") ? req.get("id") : null;
            return switch (method) {
                case "initialize"     -> handleInitialize(id);
                case "tools/list"     -> handleToolsList(id);
                case "tools/call"     -> handleToolCall(req, id);
                case "resources/list" -> buildResult(id, mapper.createObjectNode().set("resources", mapper.createArrayNode()));
                case "prompts/list"   -> buildResult(id, mapper.createObjectNode().set("prompts",   mapper.createArrayNode()));
                case "ping"           -> buildResult(id, mapper.createObjectNode());
                default               -> buildError(id, -32601, "Method not found: " + method);
            };
        } catch (Exception e) { return buildError(null, -32700, "Parse error: " + e.getMessage()); }
    }

    private String handleInitialize(Object id) {
        ObjectNode r = mapper.createObjectNode(); r.put("protocolVersion","2024-11-05");
        ObjectNode info = mapper.createObjectNode(); info.put("name",SERVER_NAME); info.put("version",SERVER_VERSION);
        r.set("serverInfo", info);
        ObjectNode caps = mapper.createObjectNode();
        caps.set("tools",     mapper.createObjectNode().put("listChanged",false));
        caps.set("resources", mapper.createObjectNode().put("subscribe",false));
        caps.set("prompts",   mapper.createObjectNode().put("listChanged",false));
        r.set("capabilities", caps); return buildResult(id, r);
    }

    private String handleToolsList(Object id) {
        ArrayNode tools = mapper.createArrayNode();
        for (BaseAgent agent : registry.all())
            for (McpTool tool : agent.getTools()) tools.add(tool.toJson(mapper));
        ObjectNode r = mapper.createObjectNode(); r.set("tools", tools); return buildResult(id, r);
    }

    private String handleToolCall(ObjectNode req, Object id) {
        try {
            ObjectNode params   = (ObjectNode) req.path("params");
            String     toolName = params.path("name").asText("");
            ObjectNode args     = params.has("arguments") ? (ObjectNode) params.get("arguments") : mapper.createObjectNode();
            for (BaseAgent agent : registry.all())
                for (McpTool tool : agent.getTools())
                    if (tool.getName().equals(toolName)) return buildToolResult(id, agent.execute(toolName, args));
            return buildError(id, -32602, "Tool not found: " + toolName);
        } catch (Exception e) { return buildError(id, -32603, "Tool error: " + e.getMessage()); }
    }

    // ── JSON-RPC helpers ──────────────────────────────────────────────────

    private String buildResult(Object id, ObjectNode result) {
        ObjectNode r = mapper.createObjectNode(); r.put("jsonrpc","2.0"); setId(r,id); r.set("result",result); return r.toString();
    }
    private String buildToolResult(Object id, AgentResponse ar) {
        ObjectNode r = mapper.createObjectNode(); r.put("jsonrpc","2.0"); setId(r,id);
        ObjectNode result = mapper.createObjectNode(); ArrayNode content = mapper.createArrayNode();
        ObjectNode text = mapper.createObjectNode(); text.put("type","text"); text.put("text", ar.toJson(mapper)); content.add(text);
        result.set("content",content); result.put("isError", ar.isError()); r.set("result",result); return r.toString();
    }
    private String buildError(Object id, int code, String msg) {
        ObjectNode r = mapper.createObjectNode(); r.put("jsonrpc","2.0"); setId(r,id);
        ObjectNode err = mapper.createObjectNode(); err.put("code",code); err.put("message",msg);
        r.set("error",err); return r.toString();
    }
    private void setId(ObjectNode r, Object id) {
        if (id instanceof Integer i) r.put("id",i); else if (id instanceof String s) r.put("id",s); else r.putNull("id");
    }

    public static void main(String[] args) throws Exception {
        LogManager.getLogManager().reset();
        Logger root = Logger.getLogger(""); Handler h = new StreamHandler(System.err, new SimpleFormatter());
        h.setLevel(Level.ALL); root.addHandler(h); root.setLevel(Level.INFO);
        new EnterpriseMcpServer().run();
    }
}
