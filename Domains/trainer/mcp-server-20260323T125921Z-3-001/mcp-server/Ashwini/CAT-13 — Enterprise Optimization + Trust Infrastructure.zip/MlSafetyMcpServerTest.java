package com.ecoskiller.mlsafety.server;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Ecoskiller ML Safety MCP Server — Unit Tests (19 Agents)")
class MlSafetyMcpServerTest {

    private MlSafetyMcpServer server;
    @BeforeEach void setUp() { server = new MlSafetyMcpServer(); }

    @Test @DisplayName("initialize → mcp-14-ml-safety")
    void testInit() {
        assertTrue(call("initialize","{}").contains("mcp-14-ml-safety"));
    }
    @Test @DisplayName("19 agents registered")
    void testCount() { assertEquals(19, server.registry.count()); }

    @Test @DisplayName("tools/list contains all 19 agents' tools")
    void testToolsList() {
        String r = call("tools/list","{}");
        assertTrue(r.contains("mlsafety_score_test_submission"));
        assertTrue(r.contains("mlsafety_get_psca_spec"));
        assertTrue(r.contains("mlsafety_list_model_versions"));
        assertTrue(r.contains("mlsafety_trigger_training_run"));
        assertTrue(r.contains("mlsafety_get_model_health"));
        assertTrue(r.contains("mlsafety_score_intelligence"));
        assertTrue(r.contains("mlsafety_override_intelligence_score"));
        assertTrue(r.contains("mlsafety_explain_intelligence_score"));
        assertTrue(r.contains("mlsafety_get_intelligence_timeline"));
        assertTrue(r.contains("mlsafety_run_calibration"));
        assertTrue(r.contains("mlsafety_run_bias_audit"));
        assertTrue(r.contains("mlsafety_get_ibda_spec"));
        assertTrue(r.contains("mlsafety_detect_hidden_talent"));
        assertTrue(r.contains("mlsafety_extract_features"));
        assertTrue(r.contains("mlsafety_upsert_embedding"));
        assertTrue(r.contains("mlsafety_moderate_content"));
        assertTrue(r.contains("mlsafety_run_child_safety_scan"));
        assertTrue(r.contains("mlsafety_predict_career_trajectory"));
        assertTrue(r.contains("mlsafety_start_test_session"));
    }

    // Agent tests
    @Test void testScoreTest() {
        String r = tool("mlsafety_score_test_submission",
            "{\"submission_id\":\"S1\",\"test_id\":\"T1\",\"answer_key_id\":\"AK1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"score\":84")); assertTrue(r.contains("ts-v3"));
    }
    @Test void testPscaValidation() {
        assertTrue(tool("mlsafety_validate_against_psca",
            "{\"content_id\":\"C1\",\"content_type\":\"video\",\"spec_version\":\"v2.4\",\"tenant_id\":\"T1\"}")
            .contains("COMPLIANT"));
    }
    @Test void testModelVersions() {
        assertTrue(tool("mlsafety_list_model_versions",
            "{\"model_name\":\"intelligence-scorer\",\"tenant_id\":\"T1\"}")
            .contains("PRODUCTION"));
    }
    @Test void testModelPromotion() {
        assertTrue(tool("mlsafety_promote_model_version",
            "{\"model_name\":\"intel\",\"version\":\"v3.3-rc\",\"approver_id\":\"USR-1\",\"tenant_id\":\"T1\"}")
            .contains("PRODUCTION"));
    }
    @Test void testTrainingRun() {
        assertTrue(tool("mlsafety_trigger_training_run",
            "{\"model_name\":\"intel\",\"dataset_id\":\"DS-1\",\"hyperparams_json\":\"{}\",\"tenant_id\":\"T1\"}")
            .contains("QUEUED"));
    }
    @Test void testModelHealth() {
        assertTrue(tool("mlsafety_get_model_health",
            "{\"model_name\":\"intel\",\"version\":\"v3.2\",\"tenant_id\":\"T1\"}")
            .contains("HEALTHY"));
    }
    @Test void testDriftDetection() {
        assertTrue(tool("mlsafety_detect_data_drift",
            "{\"model_name\":\"intel\",\"window_hours\":\"24\",\"tenant_id\":\"T1\"}")
            .contains("STABLE"));
    }
    @Test void testIntelligenceScore() {
        String r = tool("mlsafety_score_intelligence",
            "{\"entity_id\":\"E1\",\"assessment_id\":\"A1\",\"raw_responses_json\":\"{}\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"composite_iq\":79")); assertTrue(r.contains("intel-v4"));
    }
    @Test void testIntelligenceOverride() {
        assertTrue(tool("mlsafety_override_intelligence_score",
            "{\"entity_id\":\"E1\",\"dimension\":\"spatial\",\"new_score\":\"78\",\"justification\":\"Manual review\",\"reviewer_id\":\"R1\",\"tenant_id\":\"T1\"}")
            .contains("audit_logged"));
    }
    @Test void testExplainability() {
        assertTrue(tool("mlsafety_explain_intelligence_score",
            "{\"entity_id\":\"E1\",\"dimension\":\"logical\",\"audience\":\"teacher\",\"tenant_id\":\"T1\"}")
            .contains("explanation"));
    }
    @Test void testFeatureImportance() {
        assertTrue(tool("mlsafety_get_feature_importance",
            "{\"entity_id\":\"E1\",\"dimension\":\"logical\",\"tenant_id\":\"T1\"}")
            .contains("Pattern recognition"));
    }
    @Test void testIntelligenceTimeline() {
        String r = tool("mlsafety_get_intelligence_timeline",
            "{\"entity_id\":\"E1\",\"dimension\":\"logical\",\"months\":\"7\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("IMPROVING")); assertTrue(r.contains("+12"));
    }
    @Test void testTrajectoryPrediction() {
        assertTrue(tool("mlsafety_predict_intelligence_trajectory",
            "{\"entity_id\":\"E1\",\"forecast_months\":\"6\",\"tenant_id\":\"T1\"}")
            .contains("STEADY_GROWTH"));
    }
    @Test void testCalibration() {
        assertTrue(tool("mlsafety_run_calibration",
            "{\"model_name\":\"intel\",\"normative_dataset_id\":\"ND-1\",\"dimension\":\"all\",\"tenant_id\":\"T1\"}")
            .contains("68.4"));
    }
    @Test void testBiasAudit() {
        assertTrue(tool("mlsafety_run_bias_audit",
            "{\"model_name\":\"intel\",\"audit_scope\":\"all\",\"tenant_id\":\"T1\"}")
            .contains("FAIR"));
    }
    @Test void testBiasCorrection() {
        assertTrue(tool("mlsafety_apply_bias_correction",
            "{\"model_name\":\"intel\",\"correction_method\":\"reweighting\",\"audit_id\":\"A1\",\"tenant_id\":\"T1\"}")
            .contains("76%"));
    }
    @Test void testIbdaSpec() {
        assertTrue(tool("mlsafety_get_ibda_spec",
            "{\"spec_version\":\"v1.4\",\"tenant_id\":\"T1\"}")
            .contains("sha256"));
    }
    @Test void testIbdaIntegrity() {
        assertTrue(tool("mlsafety_verify_ibda_integrity",
            "{\"spec_version\":\"v1.4\",\"expected_hash\":\"sha256:a1b2\",\"tenant_id\":\"T1\"}")
            .contains("INTACT"));
    }
    @Test void testHiddenTalent() {
        assertTrue(tool("mlsafety_detect_hidden_talent",
            "{\"entity_id\":\"E1\",\"entity_type\":\"student\",\"data_window_days\":\"90\",\"tenant_id\":\"T1\"}")
            .contains("Top 12%"));
    }
    @Test void testTalentPathways() {
        assertTrue(tool("mlsafety_recommend_talent_pathway",
            "{\"entity_id\":\"E1\",\"tenant_id\":\"T1\"}")
            .contains("Competitive Programming"));
    }
    @Test void testFeatureExtraction() {
        assertTrue(tool("mlsafety_extract_features",
            "{\"entity_id\":\"E1\",\"entity_type\":\"student\",\"feature_set\":\"default\",\"tenant_id\":\"T1\"}")
            .contains("\"features_extracted\":6"));
    }
    @Test void testEmbeddingUpsert() {
        assertTrue(tool("mlsafety_upsert_embedding",
            "{\"entity_id\":\"E1\",\"entity_type\":\"student\",\"embedding_vector\":\"[]\",\"model_id\":\"emb-v2\",\"tenant_id\":\"T1\"}")
            .contains("\"dimensions\":384"));
    }
    @Test void testSimilaritySearch() {
        assertTrue(tool("mlsafety_similarity_search",
            "{\"query_entity_id\":\"E1\",\"entity_type\":\"student\",\"top_k\":\"5\",\"tenant_id\":\"T1\"}")
            .contains("0.97"));
    }
    @Test void testContentModeration() {
        assertTrue(tool("mlsafety_moderate_content",
            "{\"content_id\":\"C1\",\"content_type\":\"comment\",\"content_text\":\"hello\",\"tenant_id\":\"T1\"}")
            .contains("APPROVED"));
    }
    @Test void testChildSafetyScan() {
        assertTrue(tool("mlsafety_run_child_safety_scan",
            "{\"scan_target_id\":\"MSG-1\",\"scan_type\":\"message_thread\",\"tenant_id\":\"T1\"}")
            .contains("SAFE"));
    }
    @Test void testChildSafetyAlerts() {
        assertTrue(tool("mlsafety_get_child_safety_alerts",
            "{\"tenant_id\":\"T1\",\"severity\":\"all\",\"limit\":\"10\"}")
            .contains("ALL_CLEAR"));
    }
    @Test void testCareerTrajectory() {
        assertTrue(tool("mlsafety_predict_career_trajectory",
            "{\"entity_id\":\"E1\",\"horizon_years\":\"5\",\"tenant_id\":\"T1\"}")
            .contains("Tech Lead"));
    }
    @Test void testRoleFit() {
        assertTrue(tool("mlsafety_get_role_fit_scores",
            "{\"entity_id\":\"E1\",\"role_ids_csv\":\"SWE-L4,PM-L3\",\"tenant_id\":\"T1\"}")
            .contains("88.4"));
    }
    @Test void testStartTestSession() {
        String r = tool("mlsafety_start_test_session",
            "{\"test_id\":\"TST-1\",\"candidate_id\":\"C1\",\"proctoring_level\":\"STANDARD\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"status\":\"ACTIVE\"")); assertTrue(r.contains("\"questions\":30"));
    }
    @Test void testEndTestSession() {
        assertTrue(tool("mlsafety_end_test_session",
            "{\"session_id\":\"sess-1\",\"submitted_by\":\"C1\",\"tenant_id\":\"T1\"}")
            .contains("SUBMITTED"));
    }
    @Test void testProctoringAlerts() {
        assertTrue(tool("mlsafety_get_proctoring_alerts",
            "{\"session_id\":\"sess-1\",\"tenant_id\":\"T1\"}")
            .contains("NO_VIOLATIONS"));
    }
    @Test void testUnknownTool() {
        assertTrue(tool("mlsafety_fake","{}").contains("-32602"));
    }

    private String call(String m, String p) {
        return server.handleMessage("{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\""+m+"\",\"params\":"+p+"}");
    }
    private String tool(String name, String args) {
        return server.handleMessage("{\"jsonrpc\":\"2.0\",\"id\":99,\"method\":\"tools/call\",\"params\":{\"name\":\""+name+"\",\"arguments\":"+args+"}}");
    }
}
