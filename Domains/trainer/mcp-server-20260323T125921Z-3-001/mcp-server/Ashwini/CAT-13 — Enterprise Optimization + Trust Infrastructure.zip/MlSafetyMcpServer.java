package com.ecoskiller.mlsafety.server;

import com.ecoskiller.mlsafety.agents.*;
import com.ecoskiller.mlsafety.models.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.*;

import java.io.*;
import java.util.logging.*;

/**
 * Ecoskiller ML Safety MCP Server
 * CAT-14 — ML, Intelligence & Safety
 * MCP Server: mcp-14-ml-safety  |  Namespace: ml
 *
 * Agents (19):
 *   1.  TEST_SCORING_AGENT
 *   2.  PSCA_COMPLETE_SPECIFICATION_AGENT
 *   3.  MODEL_VERSIONING_AGENT
 *   4.  MODEL_TRAINING_PIPELINE_AGENT
 *   5.  MODEL_MONITORING_AGENT
 *   6.  INTELLIGENCE_SCORING_ML_AGENT
 *   7.  INTELLIGENCE_OVERRIDE_AGENT
 *   8.  INTELLIGENCE_EXPLAINABILITY_AGENT
 *   9.  INTELLIGENCE_EVOLUTION_AGENT
 *  10.  INTELLIGENCE_CALIBRATION_AGENT
 *  11.  INTELLIGENCE_BIAS_DETECTION_AGENT
 *  12.  IBDA_COMPLETE_SEALED_SPECIFICATION_AGENT
 *  13.  HIDDEN_TALENT_DETECTION_AGENT
 *  14.  FEATURE_EXTRACTION_AGENT
 *  15.  EMBEDDING_INDEX_AGENT
 *  16.  CONTENT_MODERATION_AGENT
 *  17.  CHILD_SAFETY_MONITOR_AGENT
 *  18.  CAREER_PREDICTION_AGENT
 *  19.  ACTIVE_TEST_EXECUTION_AGENT
 */
public class MlSafetyMcpServer {

    static final String SERVER_NAME    = "mcp-14-ml-safety";
    static final String SERVER_VERSION = "1.0.0";
    static final String NAMESPACE      = "ml";

    private static final Logger LOGGER = Logger.getLogger(MlSafetyMcpServer.class.getName());
    private final ObjectMapper  mapper   = new ObjectMapper();
    final         AgentRegistry registry = new AgentRegistry();

    public MlSafetyMcpServer() { registerAllAgents(); }

    private void registerAllAgents() {
        // Group 1: Scoring, PSCA, Versioning, Training, Monitoring, Intelligence×5
        registry.register(new TestScoringAgent());
        registry.register(new PscaCompleteSpecificationAgent());
        registry.register(new ModelVersioningAgent());
        registry.register(new ModelTrainingPipelineAgent());
        registry.register(new ModelMonitoringAgent());
        registry.register(new IntelligenceScoringMlAgent());
        registry.register(new IntelligenceOverrideAgent());
        registry.register(new IntelligenceExplainabilityAgent());
        registry.register(new IntelligenceEvolutionAgent());
        registry.register(new IntelligenceCalibrationAgent());
        // Group 2: Bias, IBDA, HiddenTalent, Features, Embeddings, Moderation, ChildSafety, Career, ActiveTest
        registry.register(new IntelligenceBiasDetectionAgent());
        registry.register(new IbdaCompleteSpecificationAgent());
        registry.register(new HiddenTalentDetectionAgent());
        registry.register(new FeatureExtractionAgent());
        registry.register(new EmbeddingIndexAgent());
        registry.register(new ContentModerationAgent());
        registry.register(new ChildSafetyMonitorAgent());
        registry.register(new CareerPredictionAgent());
        registry.register(new ActiveTestExecutionAgent());
        LOGGER.info("[" + SERVER_NAME + "] Registered " + registry.count() + "/19 agents.");
    }

    public void run() throws Exception {
        LOGGER.info("[" + SERVER_NAME + "] Starting on stdio transport...");
        var in  = new BufferedReader(new InputStreamReader(System.in));
        var out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)), true);
        String line;
        while ((line = in.readLine()) != null) {
            line = line.trim(); if (line.isEmpty()) continue;
            String resp = handleMessage(line); if (resp != null) out.println(resp);
        }
    }

    String handleMessage(String raw) {
        try {
            ObjectNode req = (ObjectNode) mapper.readTree(raw);
            String method  = req.path("method").asText("");
            Object id      = req.has("id") ? req.get("id") : null;
            return switch (method) {
                case "initialize"     -> handleInitialize(id);
                case "tools/list"     -> handleToolsList(id);
                case "tools/call"     -> handleToolCall(req, id);
                case "resources/list" -> buildResult(id, mapper.createObjectNode().set("resources", mapper.createArrayNode()));
                case "prompts/list"   -> buildResult(id, mapper.createObjectNode().set("prompts",   mapper.createArrayNode()));
                case "ping"           -> buildResult(id, mapper.createObjectNode());
                default               -> buildError(id, -32601, "Method not found: " + method);
            };
        } catch (Exception e) { return buildError(null, -32700, "Parse error: " + e.getMessage()); }
    }

    private String handleInitialize(Object id) {
        ObjectNode r = mapper.createObjectNode(); r.put("protocolVersion","2024-11-05");
        ObjectNode info = mapper.createObjectNode(); info.put("name",SERVER_NAME); info.put("version",SERVER_VERSION); r.set("serverInfo",info);
        ObjectNode caps = mapper.createObjectNode();
        caps.set("tools",     mapper.createObjectNode().put("listChanged",false));
        caps.set("resources", mapper.createObjectNode().put("subscribe",false));
        caps.set("prompts",   mapper.createObjectNode().put("listChanged",false));
        r.set("capabilities",caps); return buildResult(id,r);
    }
    private String handleToolsList(Object id) {
        ArrayNode tools = mapper.createArrayNode();
        for (BaseAgent agent : registry.all()) for (McpTool tool : agent.getTools()) tools.add(tool.toJson(mapper));
        ObjectNode r = mapper.createObjectNode(); r.set("tools",tools); return buildResult(id,r);
    }
    private String handleToolCall(ObjectNode req, Object id) {
        try {
            ObjectNode params = (ObjectNode) req.path("params");
            String toolName   = params.path("name").asText("");
            ObjectNode args   = params.has("arguments") ? (ObjectNode) params.get("arguments") : mapper.createObjectNode();
            for (BaseAgent agent : registry.all()) for (McpTool tool : agent.getTools())
                if (tool.getName().equals(toolName)) return buildToolResult(id, agent.execute(toolName, args));
            return buildError(id, -32602, "Tool not found: " + toolName);
        } catch (Exception e) { return buildError(id, -32603, "Tool error: " + e.getMessage()); }
    }

    private String buildResult(Object id, ObjectNode result) {
        ObjectNode r = mapper.createObjectNode(); r.put("jsonrpc","2.0"); setId(r,id); r.set("result",result); return r.toString();
    }
    private String buildToolResult(Object id, AgentResponse ar) {
        ObjectNode r = mapper.createObjectNode(); r.put("jsonrpc","2.0"); setId(r,id);
        ObjectNode result = mapper.createObjectNode(); ArrayNode content = mapper.createArrayNode();
        ObjectNode text = mapper.createObjectNode(); text.put("type","text"); text.put("text",ar.toJson(mapper)); content.add(text);
        result.set("content",content); result.put("isError",ar.isError()); r.set("result",result); return r.toString();
    }
    private String buildError(Object id, int code, String msg) {
        ObjectNode r = mapper.createObjectNode(); r.put("jsonrpc","2.0"); setId(r,id);
        ObjectNode err = mapper.createObjectNode(); err.put("code",code); err.put("message",msg); r.set("error",err); return r.toString();
    }
    private void setId(ObjectNode r, Object id) {
        if (id instanceof Integer i) r.put("id",i); else if (id instanceof String s) r.put("id",s); else r.putNull("id");
    }

    public static void main(String[] args) throws Exception {
        LogManager.getLogManager().reset();
        Logger root = Logger.getLogger(""); Handler h = new StreamHandler(System.err, new SimpleFormatter());
        h.setLevel(Level.ALL); root.addHandler(h); root.setLevel(Level.INFO);
        new MlSafetyMcpServer().run();
    }
}
