package com.ecoskiller.enterprise.agents;

import com.ecoskiller.enterprise.models.*;
import com.fasterxml.jackson.databind.node.*;
import java.util.List;

// ═══════════════════════════════════════════════════════════════════════════
// Agent 1 — WORK_RELIABILITY_MODEL_AGENT
// Predicts employee/contractor work reliability scores from behavioral signals.
// ═══════════════════════════════════════════════════════════════════════════
class WorkReliabilityModelAgent extends BaseAgent {
    @Override public String getName() { return "WORK_RELIABILITY_MODEL_AGENT"; }

    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("enterprise_predict_work_reliability",
                "Predict a reliability score (0–100) for a worker using behavioral and history signals.",
                schema("worker_id","tenure_months","absences_30d","task_completion_rate","tenant_id")),
            new McpTool("enterprise_get_reliability_factors",
                "Return the top contributing factors for a worker's reliability score.",
                schema("worker_id","tenant_id")),
            new McpTool("enterprise_batch_reliability_scan",
                "Run reliability scoring across an entire department or cohort.",
                schema("department_id","tenant_id","threshold"))
        );
    }

    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "enterprise_predict_work_reliability" -> {
                String wid = a.path("worker_id").asText();
                double comp = a.path("task_completion_rate").asDouble(0.88);
                int score = (int)(comp * 85 + 10);
                ObjectNode d = mapper.createObjectNode();
                d.put("worker_id", wid);
                d.put("reliability_score", score);
                d.put("grade", score >= 85 ? "A" : score >= 70 ? "B" : "C");
                d.put("risk_level", score >= 85 ? "LOW" : score >= 70 ? "MEDIUM" : "HIGH");
                d.put("model_version", "v3.2");
                d.put("confidence", 0.91);
                yield AgentResponse.success(getName(), d, "Reliability score=" + score + " for worker=" + wid);
            }
            case "enterprise_get_reliability_factors" -> {
                ObjectNode d = mapper.createObjectNode();
                ArrayNode factors = mapper.createArrayNode();
                String[][] f = {{"task_completion_rate","42%","POSITIVE"},{"attendance_consistency","28%","POSITIVE"},
                                {"deadline_adherence","18%","POSITIVE"},{"peer_feedback_score","12%","NEGATIVE"}};
                for (String[] r : f) { ObjectNode row = mapper.createObjectNode();
                    row.put("factor",r[0]); row.put("weight",r[1]); row.put("direction",r[2]); factors.add(row); }
                d.set("factors", factors); d.put("worker_id", a.path("worker_id").asText());
                yield AgentResponse.success(getName(), d, "Top reliability factors returned.");
            }
            case "enterprise_batch_reliability_scan" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("department_id", a.path("department_id").asText());
                d.put("workers_scanned", 84);
                d.put("high_risk", 7); d.put("medium_risk", 18); d.put("low_risk", 59);
                d.put("avg_score", 78.4); d.put("run_at", System.currentTimeMillis());
                yield AgentResponse.success(getName(), d, "Batch scan: 84 workers, 7 high-risk flagged.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 2 — SYNC_CONFLICT_RESOLVER_AGENT
// Detects and resolves data conflicts during enterprise ERP sync operations.
// ═══════════════════════════════════════════════════════════════════════════
class SyncConflictResolverAgent extends BaseAgent {
    @Override public String getName() { return "SYNC_CONFLICT_RESOLVER_AGENT"; }

    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("enterprise_detect_sync_conflicts",
                "Detect data conflicts between source and target systems during a sync run.",
                schema("sync_job_id","source_system","target_system","tenant_id")),
            new McpTool("enterprise_resolve_conflict",
                "Apply a resolution strategy (latest-wins/merge/manual) for a specific conflict.",
                schema("conflict_id","strategy","resolved_value","tenant_id")),
            new McpTool("enterprise_get_conflict_report",
                "Get a full conflict resolution report for a completed sync job.",
                schema("sync_job_id","tenant_id"))
        );
    }

    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "enterprise_detect_sync_conflicts" -> {
                String jobId = a.path("sync_job_id").asText();
                ObjectNode d = mapper.createObjectNode();
                d.put("sync_job_id", jobId);
                d.put("source", a.path("source_system").asText("SAP"));
                d.put("target", a.path("target_system").asText("Ecoskiller-ERP"));
                d.put("records_synced", 12_430);
                d.put("conflicts_found", 14);
                d.put("auto_resolvable", 11); d.put("manual_required", 3);
                d.put("conflict_rate_pct", 0.11);
                yield AgentResponse.success(getName(), d, "Sync conflict detection: 14 conflicts in " + jobId);
            }
            case "enterprise_resolve_conflict" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("conflict_id", a.path("conflict_id").asText());
                d.put("strategy",    a.path("strategy").asText("latest-wins"));
                d.put("resolved",    true);
                d.put("applied_value", a.path("resolved_value").asText("(auto)"));
                d.put("resolution_id", "res-" + System.currentTimeMillis());
                yield AgentResponse.success(getName(), d, "Conflict resolved with strategy=" + a.path("strategy").asText("latest-wins"));
            }
            case "enterprise_get_conflict_report" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("sync_job_id",        a.path("sync_job_id").asText());
                d.put("total_conflicts",    14); d.put("resolved",      14);
                d.put("auto_resolved",      11); d.put("manual_resolved", 3);
                d.put("unresolved",          0); d.put("sync_health", "GREEN");
                yield AgentResponse.success(getName(), d, "All 14 conflicts resolved. Sync health: GREEN.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 3 — STRUCTURED_SKILL_EXTRACTION_MODEL_AGENT
// Extracts structured skill vectors from resumes, job descriptions, and profiles.
// ═══════════════════════════════════════════════════════════════════════════
class StructuredSkillExtractionModelAgent extends BaseAgent {
    @Override public String getName() { return "STRUCTURED_SKILL_EXTRACTION_MODEL_AGENT"; }

    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("enterprise_extract_skills_from_text",
                "Extract a structured skill vector from free-form text (resume, JD, bio).",
                schema("text_content","source_type","entity_id","tenant_id")),
            new McpTool("enterprise_normalize_skill_taxonomy",
                "Map extracted raw skills to the Ecoskiller canonical skill taxonomy.",
                schema("raw_skills_json","taxonomy_version","tenant_id")),
            new McpTool("enterprise_compare_skill_vectors",
                "Compute skill gap and match score between a candidate and job requirement.",
                schema("candidate_id","job_id","tenant_id"))
        );
    }

    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "enterprise_extract_skills_from_text" -> {
                ObjectNode d = mapper.createObjectNode();
                ArrayNode skills = mapper.createArrayNode();
                String[][] skl = {{"Python","TECHNICAL","HIGH"},{"Data Analysis","ANALYTICAL","HIGH"},
                                  {"Communication","SOFT","MEDIUM"},{"SQL","TECHNICAL","HIGH"},
                                  {"Project Management","SOFT","MEDIUM"}};
                for (String[] s : skl) { ObjectNode sk = mapper.createObjectNode();
                    sk.put("skill",s[0]); sk.put("category",s[1]); sk.put("confidence",s[2]); skills.add(sk); }
                d.set("skills", skills); d.put("entity_id", a.path("entity_id").asText());
                d.put("source_type", a.path("source_type").asText("resume"));
                d.put("skills_extracted", 5); d.put("model_version", "sse-v4");
                yield AgentResponse.success(getName(), d, "5 skills extracted from " + a.path("source_type").asText("text"));
            }
            case "enterprise_normalize_skill_taxonomy" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("taxonomy_version",   a.path("taxonomy_version").asText("v3"));
                d.put("input_skills",       5); d.put("mapped",      5);
                d.put("unmapped",           0); d.put("synonyms_resolved", 2);
                d.put("canonical_ids_added", 5);
                yield AgentResponse.success(getName(), d, "Skill taxonomy normalization: 5/5 mapped.");
            }
            case "enterprise_compare_skill_vectors" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("candidate_id",   a.path("candidate_id").asText());
                d.put("job_id",         a.path("job_id").asText());
                d.put("match_score",    82.4);
                d.put("matched_skills", 7); d.put("gap_skills",   3); d.put("extra_skills", 2);
                d.put("recommendation", "STRONG_MATCH");
                yield AgentResponse.success(getName(), d, "Skill match score=82.4 — STRONG_MATCH.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 4 — CORPORATE_BENCHMARK_MODEL_AGENT
// Benchmarks corporate skill and performance data against industry peers.
// ═══════════════════════════════════════════════════════════════════════════
class CorporateBenchmarkModelAgent extends BaseAgent {
    @Override public String getName() { return "CORPORATE_BENCHMARK_MODEL_AGENT"; }

    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("enterprise_benchmark_organization",
                "Benchmark an organization's skill and performance metrics against industry standards.",
                schema("org_id","industry","size_band","metric","tenant_id")),
            new McpTool("enterprise_get_benchmark_report",
                "Get a full benchmark report with percentile rankings and gap analysis.",
                schema("org_id","report_period","tenant_id")),
            new McpTool("enterprise_compare_orgs",
                "Compare multiple organizations on a specific benchmark metric.",
                schema("org_ids_csv","metric","industry","tenant_id"))
        );
    }

    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "enterprise_benchmark_organization" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("org_id",         a.path("org_id").asText());
                d.put("industry",       a.path("industry").asText("EdTech"));
                d.put("metric",         a.path("metric").asText("skill_coverage"));
                d.put("org_score",      74.2);
                d.put("industry_p50",   68.0); d.put("industry_p75", 78.0); d.put("industry_p90", 85.0);
                d.put("percentile",     61); d.put("gap_to_p75", 3.8);
                d.put("benchmark_grade","B+");
                yield AgentResponse.success(getName(), d, "Benchmark: 74.2 — 61st percentile in " + a.path("industry").asText("EdTech"));
            }
            case "enterprise_get_benchmark_report" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("org_id",    a.path("org_id").asText());
                d.put("period",    a.path("report_period").asText("2026-Q1"));
                d.put("overall_percentile", 61); d.put("skill_coverage_pct", 74.2);
                d.put("productivity_index",  81.7); d.put("attrition_risk_avg", 14.3);
                d.put("hiring_roi",          3.2); d.put("report_grade", "B+");
                yield AgentResponse.success(getName(), d, "Benchmark report generated.");
            }
            case "enterprise_compare_orgs" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode rows = mapper.createArrayNode();
                String[] orgs = {"ORG-001","ORG-002","ORG-003"};
                double[] scores = {74.2, 81.0, 68.5};
                for (int i = 0; i < orgs.length; i++) { ObjectNode r = mapper.createObjectNode();
                    r.put("org_id",orgs[i]); r.put("score",scores[i]); r.put("rank",i+1); rows.add(r); }
                d.set("comparison", rows); d.put("metric", a.path("metric").asText("skill_coverage"));
                yield AgentResponse.success(getName(), d, "Organization comparison complete.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 5 — HIRING_ROI_MODEL_AGENT
// Calculates ROI of hiring decisions: cost-per-hire, productivity gain, retention.
// ═══════════════════════════════════════════════════════════════════════════
class HiringRoiModelAgent extends BaseAgent {
    @Override public String getName() { return "HIRING_ROI_MODEL_AGENT"; }

    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("enterprise_calculate_hiring_roi",
                "Calculate the ROI for a completed hire: productivity gain vs. total hiring cost.",
                schema("hire_id","cost_inr","ramp_months","role","tenant_id")),
            new McpTool("enterprise_forecast_hiring_roi",
                "Forecast projected ROI for an open position before hiring.",
                schema("job_id","budget_inr","expected_ramp_months","tenant_id")),
            new McpTool("enterprise_get_hiring_roi_dashboard",
                "Get a dashboard of hiring ROI across all hires in a period.",
                schema("org_id","period","tenant_id"))
        );
    }

    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "enterprise_calculate_hiring_roi" -> {
                double cost = a.path("cost_inr").asDouble(150000);
                double ramp = a.path("ramp_months").asDouble(3);
                double roi  = Math.round(((800000 - cost) / cost) * 100.0) / 100.0;
                ObjectNode d = mapper.createObjectNode();
                d.put("hire_id",          a.path("hire_id").asText());
                d.put("total_cost_inr",   cost); d.put("ramp_months",   ramp);
                d.put("productivity_gain_inr", 800000); d.put("roi_multiplier", roi);
                d.put("payback_months",   Math.round(ramp + cost / 50000.0));
                d.put("grade",            roi > 3 ? "EXCELLENT" : roi > 2 ? "GOOD" : "AVERAGE");
                yield AgentResponse.success(getName(), d, "Hiring ROI=" + roi + "x for hire=" + a.path("hire_id").asText());
            }
            case "enterprise_forecast_hiring_roi" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("job_id",            a.path("job_id").asText());
                d.put("budget_inr",        a.path("budget_inr").asDouble(150000));
                d.put("projected_roi",     3.8); d.put("confidence", 0.76);
                d.put("break_even_months", 5);   d.put("risk_level",  "LOW");
                yield AgentResponse.success(getName(), d, "Projected ROI=3.8x for job=" + a.path("job_id").asText());
            }
            case "enterprise_get_hiring_roi_dashboard" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("org_id",      a.path("org_id").asText()); d.put("period", a.path("period").asText("2026"));
                d.put("hires",       28); d.put("avg_roi", 3.2); d.put("best_roi", 6.1); d.put("worst_roi", 1.4);
                d.put("avg_ramp_months", 3.8); d.put("total_cost_inr", 4_200_000);
                yield AgentResponse.success(getName(), d, "Hiring ROI dashboard: avg 3.2x across 28 hires.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 6 — PRODUCTIVITY_INDEX_MODEL_AGENT
// Computes a composite productivity index per employee, team, or org.
// ═══════════════════════════════════════════════════════════════════════════
class ProductivityIndexModelAgent extends BaseAgent {
    @Override public String getName() { return "PRODUCTIVITY_INDEX_MODEL_AGENT"; }

    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("enterprise_compute_productivity_index",
                "Compute a composite productivity index (0–100) for an employee or team.",
                schema("entity_id","entity_type","period","tenant_id")),
            new McpTool("enterprise_get_productivity_trends",
                "Get productivity trend over time for an employee or team.",
                schema("entity_id","entity_type","weeks","tenant_id")),
            new McpTool("enterprise_flag_productivity_anomaly",
                "Detect and flag abnormal productivity dips or spikes for review.",
                schema("entity_id","entity_type","threshold_delta","tenant_id"))
        );
    }

    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "enterprise_compute_productivity_index" -> {
                String eid = a.path("entity_id").asText();
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",   eid); d.put("entity_type",  a.path("entity_type").asText("employee"));
                d.put("period",      a.path("period").asText("2026-02"));
                d.put("productivity_index", 81.7);
                d.put("output_score",79.4); d.put("focus_score",85.2); d.put("collaboration_score",80.6);
                d.put("percentile",  74); d.put("trend","STABLE");
                yield AgentResponse.success(getName(), d, "Productivity index=81.7 for " + eid);
            }
            case "enterprise_get_productivity_trends" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode pts = mapper.createArrayNode();
                double[] vals = {78.2, 79.4, 81.0, 80.7, 81.7, 83.1};
                for (int i = 0; i < vals.length; i++) { ObjectNode p = mapper.createObjectNode();
                    p.put("week","W"+(i+1)); p.put("index",vals[i]); pts.add(p); }
                d.set("trend_points", pts); d.put("direction","IMPROVING"); d.put("weeks", 6);
                yield AgentResponse.success(getName(), d, "Productivity trend: IMPROVING over 6 weeks.");
            }
            case "enterprise_flag_productivity_anomaly" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",    a.path("entity_id").asText());
                d.put("anomaly_detected", false); d.put("current_index", 81.7);
                d.put("baseline",     80.2); d.put("delta", +1.5);
                d.put("threshold",    a.path("threshold_delta").asDouble(10.0));
                d.put("status","NORMAL");
                yield AgentResponse.success(getName(), d, "No productivity anomaly detected.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}
