package com.ecoskiller.mlsafety.agents;

import com.ecoskiller.mlsafety.models.*;
import com.fasterxml.jackson.databind.node.*;
import java.util.List;

/**
 * MODEL_MONITORING_AGENT
 * Monitors live ML models for performance degradation, data drift,
 * latency spikes, and accuracy drops. Fires alerts and triggers retraining.
 */
public class ModelMonitoringAgent extends BaseAgent {

    @Override public String getName() { return "MODEL_MONITORING_AGENT"; }

    @Override
    public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_get_model_health",
                "Get real-time health metrics for an active ML model in production.",
                schema("model_name","version","tenant_id")),
            new McpTool("mlsafety_detect_data_drift",
                "Detect feature or label drift in model inputs using PSI and KS tests.",
                schema("model_name","window_hours","tenant_id")),
            new McpTool("mlsafety_get_alert_log",
                "Get monitoring alerts triggered for a model in a time window.",
                schema("model_name","hours","severity","tenant_id")),
            new McpTool("mlsafety_set_alert_threshold",
                "Configure alert thresholds for accuracy, latency, or drift for a model.",
                schema("model_name","metric","threshold","action","tenant_id")),
            new McpTool("mlsafety_trigger_retraining_alert",
                "Manually flag a model for scheduled retraining due to degradation.",
                schema("model_name","reason","priority","tenant_id"))
        );
    }

    @Override
    public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "mlsafety_get_model_health" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("model_name",          a.path("model_name").asText());
                d.put("version",             a.path("version").asText("v3.2"));
                d.put("status",              "HEALTHY"); d.put("accuracy_live", 96.1);
                d.put("accuracy_baseline",   96.2); d.put("accuracy_delta", -0.1);
                d.put("p50_latency_ms",      42); d.put("p95_latency_ms",  84); d.put("p99_latency_ms", 142);
                d.put("throughput_rps",      320); d.put("error_rate_pct",  0.04);
                d.put("drift_detected",      false); d.put("uptime_pct",    99.97);
                d.put("last_checked",        System.currentTimeMillis());
                yield AgentResponse.success(getName(), d, "Model HEALTHY — accuracy=96.1%, p95=84ms.");
            }
            case "mlsafety_detect_data_drift" -> {
                int window = a.path("window_hours").asInt(24);
                ObjectNode d = mapper.createObjectNode();
                d.put("model_name",      a.path("model_name").asText());
                d.put("window_hours",    window); d.put("drift_detected",  false);
                d.put("features_checked",18); d.put("features_drifted", 0);
                d.put("psi_max",         0.04); d.put("psi_threshold",   0.20);
                d.put("ks_pvalue_min",   0.38); d.put("status",          "STABLE");
                yield AgentResponse.success(getName(), d, "No drift (PSI_max=0.04 < threshold 0.20, " + window + "h window).");
            }
            case "mlsafety_get_alert_log" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode alerts = mapper.createArrayNode();
                d.set("alerts", alerts); d.put("model_name", a.path("model_name").asText());
                d.put("hours",   a.path("hours").asInt(24)); d.put("total_alerts", 0); d.put("status","CLEAN");
                yield AgentResponse.success(getName(), d, "No alerts in last " + a.path("hours").asInt(24) + "h — CLEAN.");
            }
            case "mlsafety_set_alert_threshold" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("model_name", a.path("model_name").asText()); d.put("metric",    a.path("metric").asText());
                d.put("threshold",  a.path("threshold").asText()); d.put("action",     a.path("action").asText("ALERT"));
                d.put("saved",      true); d.put("config_id", uid("alert-cfg"));
                yield AgentResponse.success(getName(), d, "Alert threshold saved for " + a.path("metric").asText());
            }
            case "mlsafety_trigger_retraining_alert" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("model_name",    a.path("model_name").asText());
                d.put("priority",      a.path("priority").asText("HIGH"));
                d.put("reason",        a.path("reason").asText());
                d.put("retrain_id",    uid("retrain")); d.put("scheduled",true);
                d.put("eta_days",      3);
                yield AgentResponse.success(getName(), d, "Model flagged for retraining (priority=" + a.path("priority").asText("HIGH") + ").");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}
