package com.ecoskiller.mlsafety.agents;

import com.ecoskiller.mlsafety.models.*;
import com.fasterxml.jackson.databind.node.*;
import java.util.List;

// ═══════════════════════════════════════════════════════════════════════════
// Agent 16 — CONTENT_MODERATION_AGENT
// Moderates user-generated content for policy violations, hate speech,
// spam, and harmful material using a multi-layer ML pipeline.
// ═══════════════════════════════════════════════════════════════════════════
class ContentModerationAgent extends BaseAgent {
    @Override public String getName() { return "CONTENT_MODERATION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_moderate_content",
                "Moderate a content item for policy violations, hate speech, spam, or harmful material.",
                schema("content_id","content_type","content_text","context","tenant_id")),
            new McpTool("mlsafety_get_moderation_queue",
                "Get items in the moderation review queue for human review.",
                schema("tenant_id","status","priority","limit")),
            new McpTool("mlsafety_resolve_case",
                "Resolve a moderation case: APPROVE, REJECT, or ESCALATE.",
                schema("case_id","decision","reviewer_id","notes","tenant_id")),
            new McpTool("mlsafety_get_moderation_stats",
                "Get moderation statistics for a tenant in a period.",
                schema("tenant_id","period")),
            new McpTool("mlsafety_bulk_moderate",
                "Submit a batch of content items for parallel moderation.",
                schema("content_ids_csv","content_type","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "mlsafety_moderate_content" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("content_id",     a.path("content_id").asText());
                d.put("content_type",   a.path("content_type").asText());
                d.put("verdict",        "APPROVED"); d.put("violation_score",4);
                d.put("hate_speech",    false); d.put("harmful",false); d.put("spam",false);
                d.put("adult_content",  false); d.put("confidence",0.98);
                d.put("model_version",  "mod-v3.1"); d.put("latency_ms",18);
                yield AgentResponse.success(getName(), d, "APPROVED — violation_score=4/100, confidence=98%.");
            }
            case "mlsafety_get_moderation_queue" -> {
                ArrayNode queue = mapper.createArrayNode();
                for (int i = 1; i <= 3; i++) { ObjectNode item = mapper.createObjectNode();
                    item.put("case_id","MOD-00"+i); item.put("content_type","comment");
                    item.put("violation_score",72+i*3); item.put("priority","HIGH");
                    item.put("wait_minutes",8+i*4); queue.add(item); }
                ObjectNode d = mapper.createObjectNode(); d.set("queue",queue);
                d.put("total_pending",3); d.put("avg_wait_minutes",14); d.put("sla_breach_count",0);
                yield AgentResponse.success(getName(), d, "Moderation queue: 3 items, avg wait=14min, 0 SLA breaches.");
            }
            case "mlsafety_resolve_case" -> {
                String dec = a.path("decision").asText("REJECT"); ObjectNode d = mapper.createObjectNode();
                d.put("case_id",    a.path("case_id").asText()); d.put("decision",dec);
                d.put("resolved",   true); d.put("action",dec.equals("APPROVE")?"PUBLISHED":"REMOVED");
                d.put("notified_author",true); d.put("resolved_by",a.path("reviewer_id").asText());
                d.put("resolved_at",System.currentTimeMillis());
                yield AgentResponse.success(getName(), d, "Case " + a.path("case_id").asText() + " → " + dec);
            }
            case "mlsafety_get_moderation_stats" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("period",        a.path("period").asText("7d")); d.put("total_reviewed",4_280);
                d.put("approved",      4_107); d.put("rejected",147); d.put("escalated",26);
                d.put("auto_approved", 3_980); d.put("human_reviewed",300); d.put("rejection_rate_pct",3.4);
                d.put("avg_latency_ms",19);
                yield AgentResponse.success(getName(), d, "Moderation stats: 4280 reviewed, 3.4% rejection rate.");
            }
            case "mlsafety_bulk_moderate" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("content_type",  a.path("content_type").asText()); d.put("submitted",50);
                d.put("queued",        50); d.put("batch_id",uid("bulk-mod")); d.put("est_seconds",22);
                yield AgentResponse.success(getName(), d, "50 items queued for bulk moderation (~22s).");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 17 — CHILD_SAFETY_MONITOR_AGENT
// Monitors platform activity for child safety risks.
// CRITICAL AGENT: SLA = 1-hour response on any HIGH-severity alert.
// ═══════════════════════════════════════════════════════════════════════════
class ChildSafetyMonitorAgent extends BaseAgent {
    @Override public String getName() { return "CHILD_SAFETY_MONITOR_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_run_child_safety_scan",
                "Run a child safety scan on a session, message thread, or content item.",
                schema("scan_target_id","scan_type","tenant_id")),
            new McpTool("mlsafety_get_safety_alerts",
                "Get open child safety alerts for a tenant.",
                schema("tenant_id","severity","limit")),
            new McpTool("mlsafety_escalate_safety_case",
                "Escalate a child safety risk to the safety response team (SLA: 1h).",
                schema("alert_id","evidence_json","escalation_level","tenant_id")),
            new McpTool("mlsafety_get_safety_dashboard",
                "Get a real-time child safety health dashboard for a tenant.",
                schema("tenant_id")),
            new McpTool("mlsafety_audit_contact_patterns",
                "Audit adult-to-minor contact patterns for grooming risk signals.",
                schema("adult_id","minor_id","days","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "mlsafety_run_child_safety_scan" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("scan_target_id", a.path("scan_target_id").asText());
                d.put("scan_type",      a.path("scan_type").asText("message_thread"));
                d.put("risk_detected",  false); d.put("signals_checked",34);
                d.put("risk_score",     3); d.put("verdict","SAFE");
                d.put("model_version",  "csm-v2.1"); d.put("latency_ms",24);
                yield AgentResponse.success(getName(), d, "Child safety scan: SAFE (risk_score=3/100).");
            }
            case "mlsafety_get_safety_alerts" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode alerts = mapper.createArrayNode();
                d.set("alerts",alerts); d.put("total_open",0);
                d.put("tenant_id",a.path("tenant_id").asText()); d.put("status","ALL_CLEAR");
                d.put("last_checked",System.currentTimeMillis());
                yield AgentResponse.success(getName(), d, "Child safety: 0 open alerts — ALL_CLEAR.");
            }
            case "mlsafety_escalate_safety_case" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("alert_id",       a.path("alert_id").asText()); d.put("escalated",true);
                d.put("case_id",        uid("CS")); d.put("level",a.path("escalation_level").asText("CRITICAL"));
                d.put("team_notified",  "child-safety@ecoskiller.com");
                d.put("response_sla_hr",1); d.put("law_enforcement_loop",false);
                d.put("escalated_at",   System.currentTimeMillis());
                yield AgentResponse.success(getName(), d, "ESCALATED to child safety team — SLA: 1h response.");
            }
            case "mlsafety_get_safety_dashboard" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("tenant_id",          a.path("tenant_id").asText());
                d.put("scans_today",         2_840); d.put("scans_flagged_today",0);
                d.put("open_alerts",         0); d.put("resolved_last_7d",0);
                d.put("avg_scan_latency_ms", 22); d.put("overall_status","ALL_CLEAR");
                d.put("last_incident",       "None in last 90 days");
                yield AgentResponse.success(getName(), d, "Safety dashboard: ALL_CLEAR — 2840 scans today, 0 flagged.");
            }
            case "mlsafety_audit_contact_patterns" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("adult_id",       a.path("adult_id").asText()); d.put("minor_id",a.path("minor_id").asText());
                d.put("days",           a.path("days").asInt(30)); d.put("risk_score",2);
                d.put("grooming_signals",0); d.put("contact_frequency","Normal (4/week)");
                d.put("context",        "Teacher-student academic interaction"); d.put("verdict","NORMAL");
                yield AgentResponse.success(getName(), d, "Contact pattern audit: NORMAL — no grooming signals.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}
