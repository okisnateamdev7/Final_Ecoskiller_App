package com.ecoskiller.mlsafety.server;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive unit tests for mcp-14-ml-safety.
 * Covers all 19 agents and their tools, plus protocol-level tests.
 * 50+ assertions across protocol, agent routing, and tool logic.
 */
@DisplayName("mcp-14-ml-safety — Comprehensive Unit Tests (19 Agents)")
class MlSafetyMcpServerTest {

    private MlSafetyMcpServer server;

    @BeforeEach void setUp() { server = new MlSafetyMcpServer(); }

    // ═══════════════════════════════════════════════════════════════════════
    // Protocol-level tests
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("initialize returns correct server name and protocol")
    void testInitialize() {
        String r = method("initialize", "{}");
        assertTrue(r.contains("mcp-14-ml-safety"));
        assertTrue(r.contains("2024-11-05"));
        assertTrue(r.contains("\"agents\":19"));
        assertFalse(r.contains("\"error\""));
    }

    @Test @DisplayName("19 agents registered in registry")
    void testAgentCount() { assertEquals(19, server.registry.count()); }

    @Test @DisplayName("tools/list exposes tools from all 19 agents")
    void testToolsList() {
        String r = method("tools/list", "{}");
        // spot-check one tool from each agent
        assertTrue(r.contains("mlsafety_score_submission"));       // 1
        assertTrue(r.contains("mlsafety_get_psca_spec"));          // 2
        assertTrue(r.contains("mlsafety_list_model_versions"));     // 3
        assertTrue(r.contains("mlsafety_trigger_training"));        // 4
        assertTrue(r.contains("mlsafety_get_model_health"));        // 5
        assertTrue(r.contains("mlsafety_score_intelligence"));      // 6
        assertTrue(r.contains("mlsafety_override_dimension"));      // 7
        assertTrue(r.contains("mlsafety_explain_score"));           // 8
        assertTrue(r.contains("mlsafety_get_intelligence_timeline")); // 9
        assertTrue(r.contains("mlsafety_run_calibration"));         // 10
        assertTrue(r.contains("mlsafety_run_bias_audit"));          // 11
        assertTrue(r.contains("mlsafety_get_ibda_spec"));           // 12
        assertTrue(r.contains("mlsafety_detect_hidden_talent"));    // 13
        assertTrue(r.contains("mlsafety_extract_features"));        // 14
        assertTrue(r.contains("mlsafety_upsert_embedding"));        // 15
        assertTrue(r.contains("mlsafety_moderate_content"));        // 16
        assertTrue(r.contains("mlsafety_run_child_safety_scan"));   // 17
        assertTrue(r.contains("mlsafety_predict_career"));          // 18
        assertTrue(r.contains("mlsafety_start_session"));           // 19
    }

    @Test @DisplayName("ping returns empty result object")
    void testPing() {
        String r = method("ping", "{}");
        assertTrue(r.contains("\"result\""));
        assertFalse(r.contains("\"error\""));
    }

    @Test @DisplayName("unknown method returns -32601")
    void testUnknownMethod() { assertTrue(method("nonexistent", "{}").contains("-32601")); }

    @Test @DisplayName("malformed JSON returns -32700")
    void testMalformedJson() { assertTrue(server.handleMessage("{not json}").contains("-32700")); }

    @Test @DisplayName("unknown tool returns -32602")
    void testUnknownTool()   { assertTrue(tool("mlsafety_does_not_exist", "{}").contains("-32602")); }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 1 — TEST_SCORING_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 1: score_submission returns score and grade")
    void testScoreSubmission() {
        String r = tool("mlsafety_score_submission",
            "{\"submission_id\":\"S1\",\"test_id\":\"T1\",\"test_type\":\"MCQ\",\"answer_key_id\":\"AK1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"score\":84"));
        assertTrue(r.contains("\"grade\":\"B+\""));
        assertTrue(r.contains("ts-v3.2"));
        assertTrue(r.contains("xp_earned"));
    }

    @Test @DisplayName("Agent 1: score override is audited")
    void testScoreOverride() {
        String r = tool("mlsafety_override_score",
            "{\"submission_id\":\"S1\",\"new_score\":\"91\",\"justification\":\"Remark\",\"reviewer_id\":\"R1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"new_score\":91"));
        assertTrue(r.contains("\"audit_logged\":true"));
    }

    @Test @DisplayName("Agent 1: batch_score queues submissions")
    void testBatchScore() {
        String r = tool("mlsafety_batch_score",
            "{\"test_id\":\"T1\",\"session_id\":\"SES1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"queued\":47"));
        assertTrue(r.contains("QUEUED"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 2 — PSCA_COMPLETE_SPECIFICATION_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 2: get_psca_spec returns version and section count")
    void testGetPscaSpec() {
        String r = tool("mlsafety_get_psca_spec",
            "{\"spec_type\":\"content_moderation\",\"version\":\"v2.4\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"sections\":12"));
        assertTrue(r.contains("ACTIVE"));
    }

    @Test @DisplayName("Agent 2: validate_against_psca returns COMPLIANT")
    void testValidatePsca() {
        String r = tool("mlsafety_validate_against_psca",
            "{\"content_id\":\"C1\",\"content_type\":\"video\",\"spec_version\":\"v2.4\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"compliant\":true"));
        assertTrue(r.contains("\"violations\":0"));
    }

    @Test @DisplayName("Agent 2: diff shows 3 changed sections")
    void testDiffPsca() {
        String r = tool("mlsafety_diff_psca_versions",
            "{\"spec_type\":\"content_moderation\",\"version_a\":\"v2.3\",\"version_b\":\"v2.4\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"sections_changed\":3"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 3 — MODEL_VERSIONING_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 3: list_model_versions shows production version")
    void testListVersions() {
        String r = tool("mlsafety_list_model_versions",
            "{\"model_name\":\"intelligence-scorer\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("PRODUCTION"));
        assertTrue(r.contains("\"production_version\":\"v3.2\""));
    }

    @Test @DisplayName("Agent 3: promote includes rollback window")
    void testPromoteModel() {
        String r = tool("mlsafety_promote_model",
            "{\"model_name\":\"intel\",\"version\":\"v3.3-rc\",\"canary_pct\":\"10\",\"approver_id\":\"USR-1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"promoted_to\":\"PRODUCTION\""));
        assertTrue(r.contains("\"rollback_window_hr\":24"));
    }

    @Test @DisplayName("Agent 3: rollback reroutes traffic")
    void testRollbackModel() {
        String r = tool("mlsafety_rollback_model",
            "{\"model_name\":\"intel\",\"reason\":\"accuracy drop\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"traffic_rerouted\":true"));
        assertTrue(r.contains("v3.2"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 4 — MODEL_TRAINING_PIPELINE_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 4: trigger_training returns job in QUEUED state")
    void testTriggerTraining() {
        String r = tool("mlsafety_trigger_training",
            "{\"model_name\":\"intel\",\"dataset_id\":\"DS-1\",\"hyperparams_json\":\"{}\",\"gpu_profile\":\"A100x2\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("QUEUED"));
        assertTrue(r.contains("A100x2"));
    }

    @Test @DisplayName("Agent 4: get_training_status shows epoch progress")
    void testTrainingStatus() {
        String r = tool("mlsafety_get_training_status",
            "{\"job_id\":\"train-001\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"epoch_current\":8"));
        assertTrue(r.contains("\"epoch_total\":12"));
        assertTrue(r.contains("RUNNING"));
    }

    @Test @DisplayName("Agent 4: cancel saves checkpoint")
    void testCancelTraining() {
        String r = tool("mlsafety_cancel_training",
            "{\"job_id\":\"train-001\",\"reason\":\"urgent\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"checkpoint_saved\":true"));
        assertTrue(r.contains("\"cancelled\":true"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 5 — MODEL_MONITORING_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 5: get_model_health returns HEALTHY status")
    void testModelHealth() {
        String r = tool("mlsafety_get_model_health",
            "{\"model_name\":\"intel\",\"version\":\"v3.2\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"status\":\"HEALTHY\""));
        assertTrue(r.contains("\"p95_latency_ms\":84"));
    }

    @Test @DisplayName("Agent 5: detect_data_drift shows PSI below threshold")
    void testDriftDetection() {
        String r = tool("mlsafety_detect_data_drift",
            "{\"model_name\":\"intel\",\"window_hours\":\"24\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"drift_detected\":false"));
        assertTrue(r.contains("\"status\":\"STABLE\""));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 6 — INTELLIGENCE_SCORING_ML_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 6: score_intelligence returns 9 dimensions + composite")
    void testIntelligenceScore() {
        String r = tool("mlsafety_score_intelligence",
            "{\"entity_id\":\"E1\",\"assessment_id\":\"A1\",\"raw_responses_json\":\"{}\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"composite_iq\":78"));
        assertTrue(r.contains("\"interpersonal\":92"));
        assertTrue(r.contains("intel-v4"));
    }

    @Test @DisplayName("Agent 6: compare_profiles shows leader per dimension")
    void testCompareProfiles() {
        String r = tool("mlsafety_compare_intelligence_profiles",
            "{\"entity_id_a\":\"E1\",\"entity_id_b\":\"E2\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"entity_a_composite\":78"));
        assertTrue(r.contains("leader"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 7 — INTELLIGENCE_OVERRIDE_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 7: override dimension is audited")
    void testOverrideDimension() {
        String r = tool("mlsafety_override_dimension",
            "{\"entity_id\":\"E1\",\"dimension\":\"spatial\",\"new_score\":\"80\",\"justification\":\"retest\",\"reviewer_id\":\"R1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"audit_logged\":true"));
        assertTrue(r.contains("\"new_score\":80"));
    }

    @Test @DisplayName("Agent 7: bulk_override covers 84 entities")
    void testBulkOverride() {
        String r = tool("mlsafety_bulk_override",
            "{\"cohort_id\":\"C1\",\"dimension\":\"logical\",\"adjustment_delta\":\"3\",\"reason\":\"admin error\",\"approver_id\":\"A1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"entities_updated\":84"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 8 — INTELLIGENCE_EXPLAINABILITY_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 8: explain_score includes narrative explanation")
    void testExplainScore() {
        String r = tool("mlsafety_explain_score",
            "{\"entity_id\":\"E1\",\"dimension\":\"logical\",\"audience\":\"teacher\",\"language\":\"en\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("explanation"));
        assertTrue(r.contains("\"score\":84"));
    }

    @Test @DisplayName("Agent 8: feature_importance uses SHAP")
    void testFeatureImportance() {
        String r = tool("mlsafety_get_feature_importance",
            "{\"entity_id\":\"E1\",\"dimension\":\"logical\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("Pattern recognition speed"));
        assertTrue(r.contains("\"method\":\"SHAP\""));
    }

    @Test @DisplayName("Agent 8: parent_report generates PDF URL")
    void testParentReport() {
        String r = tool("mlsafety_generate_parent_report",
            "{\"student_id\":\"S1\",\"language\":\"en\",\"include_recommendations\":\"true\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("report_url"));
        assertTrue(r.contains("\"pages\":4"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 9 — INTELLIGENCE_EVOLUTION_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 9: timeline shows IMPROVING trend")
    void testIntelligenceTimeline() {
        String r = tool("mlsafety_get_intelligence_timeline",
            "{\"entity_id\":\"E1\",\"dimension\":\"logical\",\"months\":\"7\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"trend\":\"IMPROVING\""));
        assertTrue(r.contains("\"+12\"") || r.contains("delta_total"));
    }

    @Test @DisplayName("Agent 9: predict trajectory 78→84 over 6 months")
    void testPredictTrajectory() {
        String r = tool("mlsafety_predict_trajectory",
            "{\"entity_id\":\"E1\",\"forecast_months\":\"6\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"current_composite\":78"));
        assertTrue(r.contains("\"predicted_composite\":84"));
        assertTrue(r.contains("STEADY_GROWTH"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 10 — INTELLIGENCE_CALIBRATION_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 10: calibration reduces error 3.8→1.2")
    void testCalibration() {
        String r = tool("mlsafety_run_calibration",
            "{\"model_name\":\"intel\",\"normative_dataset_id\":\"ND-1\",\"dimension\":\"all\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"error_before\":3.8"));
        assertTrue(r.contains("\"error_after\":1.2"));
        assertTrue(r.contains("68.4"));
    }

    @Test @DisplayName("Agent 10: validate_calibration recommends APPROVE")
    void testValidateCalibration() {
        String r = tool("mlsafety_validate_calibration",
            "{\"calibration_job_id\":\"cal-1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("APPROVE_FOR_PRODUCTION"));
        assertTrue(r.contains("\"ks_passed\":true"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 11 — INTELLIGENCE_BIAS_DETECTION_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 11: bias_audit returns FAIR verdict")
    void testBiasAudit() {
        String r = tool("mlsafety_run_bias_audit",
            "{\"model_name\":\"intel\",\"audit_scope\":\"all\",\"demographics_csv\":\"gender,region\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"result\":\"FAIR\""));
        assertTrue(r.contains("\"max_group_delta\":2.1"));
    }

    @Test @DisplayName("Agent 11: bias correction achieves 76% reduction")
    void testBiasCorrection() {
        String r = tool("mlsafety_apply_bias_correction",
            "{\"model_name\":\"intel\",\"correction_method\":\"reweighting\",\"audit_id\":\"A1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("76% bias reduction"));
        assertTrue(r.contains("\"-0.1%\""));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 12 — IBDA_COMPLETE_SEALED_SPECIFICATION_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 12: get_ibda_spec has sha256 hash and sealed=true")
    void testGetIbdaSpec() {
        String r = tool("mlsafety_get_ibda_spec",
            "{\"spec_version\":\"v1.4\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("sha256:"));
        assertTrue(r.contains("\"sealed\":true"));
        assertTrue(r.contains("\"tampered\":false"));
    }

    @Test @DisplayName("Agent 12: verify integrity returns INTACT")
    void testVerifyIbda() {
        String r = tool("mlsafety_verify_ibda_integrity",
            "{\"spec_version\":\"v1.4\",\"expected_hash\":\"sha256:a1b2\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"integrity\":\"INTACT\""));
        assertTrue(r.contains("\"tampered\":false"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 13 — HIDDEN_TALENT_DETECTION_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 13: detect 3 signals, top 12% cohort")
    void testHiddenTalent() {
        String r = tool("mlsafety_detect_hidden_talent",
            "{\"entity_id\":\"E1\",\"entity_type\":\"student\",\"data_window_days\":\"90\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"signals_found\":3"));
        assertTrue(r.contains("Top 12%"));
    }

    @Test @DisplayName("Agent 13: batch scan finds 28 in 320 (8.75%)")
    void testBatchTalentScan() {
        String r = tool("mlsafety_batch_talent_scan",
            "{\"scope\":\"school\",\"scope_id\":\"SCH-1\",\"threshold\":\"0.75\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"hidden_talent_detected\":28"));
        assertTrue(r.contains("8.75"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 14 — FEATURE_EXTRACTION_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 14: extract 8 features at fv-v3")
    void testExtractFeatures() {
        String r = tool("mlsafety_extract_features",
            "{\"entity_id\":\"E1\",\"entity_type\":\"student\",\"feature_set\":\"default\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"features_extracted\":8"));
        assertTrue(r.contains("fv-v3"));
        assertTrue(r.contains("\"dim\":384"));
    }

    @Test @DisplayName("Agent 14: pipeline processes 4820 entities")
    void testFeaturePipeline() {
        String r = tool("mlsafety_run_feature_pipeline",
            "{\"entity_type\":\"student\",\"batch_id\":\"B1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"entities_processed\":4820"));
        assertTrue(r.contains("COMPLETE"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 15 — EMBEDDING_INDEX_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 15: upsert embedding is 384-dim")
    void testUpsertEmbedding() {
        String r = tool("mlsafety_upsert_embedding",
            "{\"entity_id\":\"E1\",\"entity_type\":\"student\",\"embedding_json\":\"[]\",\"model_id\":\"emb-v2\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"dimensions\":384"));
        assertTrue(r.contains("\"upserted\":true"));
    }

    @Test @DisplayName("Agent 15: similarity search returns top-5 with latency")
    void testSimilaritySearch() {
        String r = tool("mlsafety_similarity_search",
            "{\"query_entity_id\":\"E1\",\"entity_type\":\"student\",\"top_k\":\"5\",\"filter_json\":\"{}\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("0.972"));
        assertTrue(r.contains("\"top_k\":5"));
        assertTrue(r.contains("latency_ms"));
    }

    @Test @DisplayName("Agent 15: index stats shows 48200 vectors")
    void testIndexStats() {
        String r = tool("mlsafety_get_index_stats", "{\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("48200") || r.contains("48_200"));
        assertTrue(r.contains("\"dimensions\":384"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 16 — CONTENT_MODERATION_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 16: moderate clean content → APPROVED")
    void testModerateApproved() {
        String r = tool("mlsafety_moderate_content",
            "{\"content_id\":\"C1\",\"content_type\":\"comment\",\"content_text\":\"Great lesson!\",\"context\":\"classroom\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"verdict\":\"APPROVED\""));
        assertTrue(r.contains("\"hate_speech\":false"));
        assertTrue(r.contains("0.98"));
    }

    @Test @DisplayName("Agent 16: queue shows 3 items pending")
    void testModerationQueue() {
        String r = tool("mlsafety_get_moderation_queue",
            "{\"tenant_id\":\"T1\",\"status\":\"PENDING\",\"priority\":\"HIGH\",\"limit\":\"10\"}");
        assertTrue(r.contains("\"total_pending\":3"));
        assertTrue(r.contains("\"sla_breach_count\":0"));
    }

    @Test @DisplayName("Agent 16: resolve case to REJECT removes content")
    void testResolveCase() {
        String r = tool("mlsafety_resolve_case",
            "{\"case_id\":\"MOD-001\",\"decision\":\"REJECT\",\"reviewer_id\":\"R1\",\"notes\":\"Policy violation\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"action\":\"REMOVED\""));
        assertTrue(r.contains("\"resolved\":true"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 17 — CHILD_SAFETY_MONITOR_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 17: safety scan returns SAFE verdict")
    void testChildSafetyScan() {
        String r = tool("mlsafety_run_child_safety_scan",
            "{\"scan_target_id\":\"MSG-1\",\"scan_type\":\"message_thread\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"verdict\":\"SAFE\""));
        assertTrue(r.contains("\"risk_detected\":false"));
    }

    @Test @DisplayName("Agent 17: alerts dashboard shows ALL_CLEAR")
    void testSafetyAlerts() {
        String r = tool("mlsafety_get_safety_alerts",
            "{\"tenant_id\":\"T1\",\"severity\":\"all\",\"limit\":\"10\"}");
        assertTrue(r.contains("ALL_CLEAR"));
        assertTrue(r.contains("\"total_open\":0"));
    }

    @Test @DisplayName("Agent 17: escalate sets 1h SLA")
    void testEscalateSafetyCase() {
        String r = tool("mlsafety_escalate_safety_case",
            "{\"alert_id\":\"A1\",\"evidence_json\":\"{}\",\"escalation_level\":\"CRITICAL\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"response_sla_hr\":1"));
        assertTrue(r.contains("\"escalated\":true"));
    }

    @Test @DisplayName("Agent 17: contact pattern audit returns NORMAL")
    void testContactAudit() {
        String r = tool("mlsafety_audit_contact_patterns",
            "{\"adult_id\":\"T1\",\"minor_id\":\"S1\",\"days\":\"30\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"verdict\":\"NORMAL\""));
        assertTrue(r.contains("\"grooming_signals\":0"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 18 — CAREER_PREDICTION_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 18: predict_career returns top trajectory with probability")
    void testCareerPrediction() {
        String r = tool("mlsafety_predict_career",
            "{\"entity_id\":\"E1\",\"horizon_years\":\"5\",\"context\":\"student\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("Tech Lead"));
        assertTrue(r.contains("0.74"));
    }

    @Test @DisplayName("Agent 18: role_fit tops at Backend Engineer 88.4%")
    void testRoleFit() {
        String r = tool("mlsafety_get_role_fit",
            "{\"entity_id\":\"E1\",\"role_ids_csv\":\"SWE-L4,DS-L3,PM-L3\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("88.4"));
        assertTrue(r.contains("Backend Engineer"));
    }

    @Test @DisplayName("Agent 18: roadmap has 4 milestones")
    void testCareerRoadmap() {
        String r = tool("mlsafety_generate_roadmap",
            "{\"entity_id\":\"E1\",\"target_role\":\"Tech Lead\",\"timeline_years\":\"3\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"milestone_count\":4"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Agent 19 — ACTIVE_TEST_EXECUTION_AGENT
    // ═══════════════════════════════════════════════════════════════════════

    @Test @DisplayName("Agent 19: start_session creates 30Q/60min session")
    void testStartSession() {
        String r = tool("mlsafety_start_session",
            "{\"test_id\":\"T1\",\"candidate_id\":\"C1\",\"proctoring_level\":\"STANDARD\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"questions\":30"));
        assertTrue(r.contains("\"time_limit_min\":60"));
        assertTrue(r.contains("\"status\":\"ACTIVE\""));
    }

    @Test @DisplayName("Agent 19: submit_answer stores tamper-proof hash")
    void testSubmitAnswer() {
        String r = tool("mlsafety_submit_answer",
            "{\"session_id\":\"sess-1\",\"question_id\":\"Q7\",\"answer\":\"B\",\"time_taken_sec\":\"45\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"recorded\":true"));
        assertTrue(r.contains("sha256:"));
    }

    @Test @DisplayName("Agent 19: end_session is SUBMITTED with integrity=100")
    void testEndSession() {
        String r = tool("mlsafety_end_session",
            "{\"session_id\":\"sess-1\",\"submitted_by\":\"C1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"status\":\"SUBMITTED\""));
        assertTrue(r.contains("\"integrity_score\":100"));
        assertTrue(r.contains("\"scoring_queued\":true"));
    }

    @Test @DisplayName("Agent 19: proctoring alerts shows NO_VIOLATIONS")
    void testProctoringAlerts() {
        String r = tool("mlsafety_get_proctoring_alerts",
            "{\"session_id\":\"sess-1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("NO_VIOLATIONS"));
        assertTrue(r.contains("\"total_alerts\":0"));
    }

    @Test @DisplayName("Agent 19: session analytics reports avg 82s per question")
    void testSessionAnalytics() {
        String r = tool("mlsafety_get_session_analytics",
            "{\"session_id\":\"sess-1\",\"tenant_id\":\"T1\"}");
        assertTrue(r.contains("\"avg_time_per_q_sec\":82"));
        assertTrue(r.contains("confidence_trend"));
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Helpers
    // ═══════════════════════════════════════════════════════════════════════

    private String method(String m, String params) {
        return server.handleMessage(
            "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"" + m + "\",\"params\":" + params + "}");
    }

    private String tool(String name, String args) {
        return server.handleMessage(
            "{\"jsonrpc\":\"2.0\",\"id\":99,\"method\":\"tools/call\"," +
            "\"params\":{\"name\":\"" + name + "\",\"arguments\":" + args + "}}");
    }
}
