package com.ecoskiller.mlsafety.agents;

import com.ecoskiller.mlsafety.models.*;
import com.fasterxml.jackson.databind.node.*;
import java.util.List;

/**
 * MODEL_TRAINING_PIPELINE_AGENT
 * Orchestrates ML model training: dataset prep, hyperparameter config,
 * GPU allocation, run monitoring, and checkpoint management.
 */
public class ModelTrainingPipelineAgent extends BaseAgent {

    @Override public String getName() { return "MODEL_TRAINING_PIPELINE_AGENT"; }

    @Override
    public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_trigger_training",
                "Trigger a new training run with specified dataset and hyperparameters.",
                schema("model_name","dataset_id","hyperparams_json","gpu_profile","tenant_id")),
            new McpTool("mlsafety_get_training_status",
                "Get the current status, epoch progress, and metrics of an active training run.",
                schema("job_id","tenant_id")),
            new McpTool("mlsafety_list_training_runs",
                "List recent training runs for a model with their final metrics.",
                schema("model_name","limit","tenant_id")),
            new McpTool("mlsafety_cancel_training",
                "Cancel an in-progress training run and save a checkpoint.",
                schema("job_id","reason","tenant_id")),
            new McpTool("mlsafety_resume_from_checkpoint",
                "Resume a cancelled or interrupted training run from its last checkpoint.",
                schema("job_id","checkpoint_epoch","tenant_id"))
        );
    }

    @Override
    public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "mlsafety_trigger_training" -> {
                String jobId = uid("train");
                ObjectNode d = mapper.createObjectNode();
                d.put("job_id",         jobId); d.put("model_name", a.path("model_name").asText());
                d.put("dataset_id",     a.path("dataset_id").asText());
                d.put("gpu_profile",    a.path("gpu_profile").asText("A100x2"));
                d.put("status",         "QUEUED"); d.put("estimated_hours", 4.5);
                d.put("epochs",         12); d.put("queued_at", System.currentTimeMillis());
                yield AgentResponse.success(getName(), d, "Training job queued: " + jobId + " (~4.5h on A100x2).");
            }
            case "mlsafety_get_training_status" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("job_id",          a.path("job_id").asText()); d.put("status", "RUNNING");
                d.put("epoch_current",   8); d.put("epoch_total", 12);
                d.put("progress_pct",    66.7); d.put("current_loss", 0.142);
                d.put("current_accuracy", 95.4); d.put("best_accuracy", 95.8);
                d.put("eta_minutes",     48); d.put("gpu_utilization_pct", 94);
                yield AgentResponse.success(getName(), d, "Training 66.7% complete — epoch 8/12, ETA 48 min.");
            }
            case "mlsafety_list_training_runs" -> {
                ArrayNode runs = mapper.createArrayNode();
                String[][] rd = {
                    {"train-001","COMPLETE","96.2","4.4h","2026-01-15"},
                    {"train-002","FAILED",  "—",   "1.2h","2026-02-01"},
                    {"train-003","RUNNING", "95.4","—",   "2026-03-05"}
                };
                for (String[] r : rd) {
                    ObjectNode row = mapper.createObjectNode();
                    row.put("job_id",r[0]); row.put("status",r[1]); row.put("accuracy",r[2]);
                    row.put("duration",r[3]); row.put("started",r[4]); runs.add(row);
                }
                ObjectNode d = mapper.createObjectNode(); d.set("runs", runs); d.put("total", 3);
                yield AgentResponse.success(getName(), d, "3 training runs listed.");
            }
            case "mlsafety_cancel_training" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("job_id",         a.path("job_id").asText()); d.put("cancelled", true);
                d.put("reason",         a.path("reason").asText()); d.put("checkpoint_saved", true);
                d.put("checkpoint_epoch",8); d.put("checkpoint_id", uid("ckpt"));
                yield AgentResponse.success(getName(), d, "Training cancelled. Checkpoint saved at epoch 8.");
            }
            case "mlsafety_resume_from_checkpoint" -> {
                String newJobId = uid("train-resume");
                ObjectNode d = mapper.createObjectNode();
                d.put("original_job_id", a.path("job_id").asText()); d.put("new_job_id", newJobId);
                d.put("resuming_epoch", a.path("checkpoint_epoch").asInt(8));
                d.put("status", "QUEUED"); d.put("estimated_hours_remaining", 1.8);
                yield AgentResponse.success(getName(), d, "Resumed from epoch " + a.path("checkpoint_epoch").asInt(8) + " → " + newJobId);
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}
