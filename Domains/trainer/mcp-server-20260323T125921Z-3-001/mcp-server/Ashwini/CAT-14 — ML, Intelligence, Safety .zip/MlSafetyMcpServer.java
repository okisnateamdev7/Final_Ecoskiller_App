package com.ecoskiller.mlsafety.server;

import com.ecoskiller.mlsafety.agents.*;
import com.ecoskiller.mlsafety.models.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.*;

import java.io.*;
import java.util.logging.*;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  Ecoskiller ML Safety MCP Server                                     ║
 * ║  CAT-14 — ML, Intelligence & Safety                                  ║
 * ║  MCP Server ID : mcp-14-ml-safety                                    ║
 * ║  Namespace     : ml                                                   ║
 * ║  Protocol      : MCP 2024-11-05 / JSON-RPC 2.0 / stdio               ║
 * ║  Agents        : 19                                                   ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 *
 * Agent roster:
 *   1.  TEST_SCORING_AGENT                       (TestScoringAgent)
 *   2.  PSCA_COMPLETE_SPECIFICATION_AGENT        (PscaSpecificationAgent)
 *   3.  MODEL_VERSIONING_AGENT                   (ModelVersioningAgent)
 *   4.  MODEL_TRAINING_PIPELINE_AGENT            (ModelTrainingPipelineAgent)
 *   5.  MODEL_MONITORING_AGENT                   (ModelMonitoringAgent)
 *   6.  INTELLIGENCE_SCORING_ML_AGENT            (IntelligenceScoringMlAgent)
 *   7.  INTELLIGENCE_OVERRIDE_AGENT              (IntelligenceOverrideAgent)
 *   8.  INTELLIGENCE_EXPLAINABILITY_AGENT        (IntelligenceExplainabilityAgent)
 *   9.  INTELLIGENCE_EVOLUTION_AGENT             (IntelligenceEvolutionAgent)
 *  10.  INTELLIGENCE_CALIBRATION_AGENT           (IntelligenceCalibrationAgent)
 *  11.  INTELLIGENCE_BIAS_DETECTION_AGENT        (IntelligenceBiasDetectionAgent)
 *  12.  IBDA_COMPLETE_SEALED_SPECIFICATION_AGENT (IbdaSpecificationAgent)
 *  13.  HIDDEN_TALENT_DETECTION_AGENT            (HiddenTalentDetectionAgent)
 *  14.  FEATURE_EXTRACTION_AGENT                 (FeatureExtractionAgent)
 *  15.  EMBEDDING_INDEX_AGENT                    (EmbeddingIndexAgent)
 *  16.  CONTENT_MODERATION_AGENT                 (ContentModerationAgent)
 *  17.  CHILD_SAFETY_MONITOR_AGENT               (ChildSafetyMonitorAgent)
 *  18.  CAREER_PREDICTION_AGENT                  (CareerPredictionAgent)
 *  19.  ACTIVE_TEST_EXECUTION_AGENT              (ActiveTestExecutionAgent)
 */
public class MlSafetyMcpServer {

    public  static final String SERVER_NAME    = "mcp-14-ml-safety";
    public  static final String SERVER_VERSION = "1.0.0";
    private static final String PROTOCOL_VER   = "2024-11-05";
    private static final String NAMESPACE       = "ml";

    private static final Logger LOGGER = Logger.getLogger(MlSafetyMcpServer.class.getName());

    private final ObjectMapper  mapper   = new ObjectMapper();
    final         AgentRegistry registry = new AgentRegistry();

    // ── Constructor: register all 19 agents ───────────────────────────────

    public MlSafetyMcpServer() {
        // CAT-14 agents — registration order matches spec table
        registry.register(new TestScoringAgent());            //  1
        registry.register(new PscaSpecificationAgent());      //  2
        registry.register(new ModelVersioningAgent());        //  3
        registry.register(new ModelTrainingPipelineAgent());  //  4
        registry.register(new ModelMonitoringAgent());        //  5
        registry.register(new IntelligenceScoringMlAgent()); //  6
        registry.register(new IntelligenceOverrideAgent());   //  7
        registry.register(new IntelligenceExplainabilityAgent()); //  8
        registry.register(new IntelligenceEvolutionAgent()); //  9
        registry.register(new IntelligenceCalibrationAgent()); // 10
        registry.register(new IntelligenceBiasDetectionAgent()); // 11
        registry.register(new IbdaSpecificationAgent());      // 12
        registry.register(new HiddenTalentDetectionAgent());  // 13
        registry.register(new FeatureExtractionAgent());      // 14
        registry.register(new EmbeddingIndexAgent());         // 15
        registry.register(new ContentModerationAgent());      // 16
        registry.register(new ChildSafetyMonitorAgent());     // 17
        registry.register(new CareerPredictionAgent());       // 18
        registry.register(new ActiveTestExecutionAgent());    // 19

        LOGGER.info("[" + SERVER_NAME + "] Registered " + registry.count() + "/19 agents.");
    }

    // ── MCP stdio transport loop ───────────────────────────────────────────

    public void run() throws Exception {
        LOGGER.info("[" + SERVER_NAME + "] v" + SERVER_VERSION + " starting on stdio transport...");
        BufferedReader in  = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter    out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)), true);
        String line;
        while ((line = in.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;
            String response = handleMessage(line);
            if (response != null) out.println(response);
        }
    }

    // ── Message dispatch ──────────────────────────────────────────────────

    String handleMessage(String rawJson) {
        try {
            ObjectNode req = (ObjectNode) mapper.readTree(rawJson);
            String method  = req.path("method").asText("");
            Object id      = req.has("id") ? req.get("id") : null;

            return switch (method) {
                case "initialize"     -> handleInitialize(id);
                case "tools/list"     -> handleToolsList(id);
                case "tools/call"     -> handleToolCall(req, id);
                case "resources/list" -> buildResult(id, mapper.createObjectNode().set("resources", mapper.createArrayNode()));
                case "prompts/list"   -> buildResult(id, mapper.createObjectNode().set("prompts",   mapper.createArrayNode()));
                case "ping"           -> buildResult(id, mapper.createObjectNode());
                default               -> buildError(id, -32601, "Method not found: " + method);
            };
        } catch (Exception e) {
            return buildError(null, -32700, "Parse error: " + e.getMessage());
        }
    }

    // ── Handlers ──────────────────────────────────────────────────────────

    private String handleInitialize(Object id) {
        ObjectNode result = mapper.createObjectNode();
        result.put("protocolVersion", PROTOCOL_VER);

        ObjectNode serverInfo = mapper.createObjectNode();
        serverInfo.put("name",      SERVER_NAME);
        serverInfo.put("version",   SERVER_VERSION);
        serverInfo.put("namespace", NAMESPACE);
        serverInfo.put("agents",    registry.count());
        result.set("serverInfo", serverInfo);

        ObjectNode caps = mapper.createObjectNode();
        caps.set("tools",     mapper.createObjectNode().put("listChanged", false));
        caps.set("resources", mapper.createObjectNode().put("subscribe",   false));
        caps.set("prompts",   mapper.createObjectNode().put("listChanged", false));
        result.set("capabilities", caps);

        return buildResult(id, result);
    }

    private String handleToolsList(Object id) {
        ArrayNode tools = mapper.createArrayNode();
        for (BaseAgent agent : registry.all())
            for (McpTool tool : agent.getTools())
                tools.add(tool.toJson(mapper));

        ObjectNode result = mapper.createObjectNode();
        result.set("tools", tools);
        result.put("count", tools.size());
        return buildResult(id, result);
    }

    private String handleToolCall(ObjectNode req, Object id) {
        try {
            ObjectNode params   = (ObjectNode) req.path("params");
            String     toolName = params.path("name").asText("");
            ObjectNode args     = params.has("arguments")
                ? (ObjectNode) params.get("arguments")
                : mapper.createObjectNode();

            for (BaseAgent agent : registry.all())
                for (McpTool tool : agent.getTools())
                    if (tool.getName().equals(toolName))
                        return buildToolResult(id, agent.execute(toolName, args));

            return buildError(id, -32602, "Tool not found: " + toolName);
        } catch (Exception e) {
            return buildError(id, -32603, "Tool execution error: " + e.getMessage());
        }
    }

    // ── JSON-RPC response builders ────────────────────────────────────────

    private String buildResult(Object id, ObjectNode result) {
        ObjectNode resp = mapper.createObjectNode();
        resp.put("jsonrpc", "2.0");
        setId(resp, id);
        resp.set("result", result);
        return resp.toString();
    }

    private String buildToolResult(Object id, AgentResponse agentResp) {
        ObjectNode resp   = mapper.createObjectNode();
        resp.put("jsonrpc", "2.0");
        setId(resp, id);

        ObjectNode result  = mapper.createObjectNode();
        ArrayNode  content = mapper.createArrayNode();
        ObjectNode text    = mapper.createObjectNode();
        text.put("type", "text");
        text.put("text", agentResp.toJson(mapper));
        content.add(text);
        result.set("content",  content);
        result.put("isError",  agentResp.isError());
        resp.set("result", result);
        return resp.toString();
    }

    private String buildError(Object id, int code, String message) {
        ObjectNode resp  = mapper.createObjectNode();
        resp.put("jsonrpc", "2.0");
        setId(resp, id);
        ObjectNode error = mapper.createObjectNode();
        error.put("code",    code);
        error.put("message", message);
        resp.set("error", error);
        return resp.toString();
    }

    private void setId(ObjectNode resp, Object id) {
        if (id instanceof Integer i)    resp.put("id", i);
        else if (id instanceof String s) resp.put("id", s);
        else                             resp.putNull("id");
    }

    // ── Entry point ───────────────────────────────────────────────────────

    public static void main(String[] args) throws Exception {
        LogManager.getLogManager().reset();
        Logger root = Logger.getLogger("");
        Handler handler = new StreamHandler(System.err, new SimpleFormatter());
        handler.setLevel(Level.ALL);
        root.addHandler(handler);
        root.setLevel(Level.INFO);
        new MlSafetyMcpServer().run();
    }
}
