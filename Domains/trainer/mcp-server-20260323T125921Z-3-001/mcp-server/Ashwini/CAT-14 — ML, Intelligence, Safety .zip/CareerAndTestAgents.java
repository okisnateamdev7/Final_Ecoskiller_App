package com.ecoskiller.mlsafety.agents;

import com.ecoskiller.mlsafety.models.*;
import com.fasterxml.jackson.databind.node.*;
import java.util.List;

// ═══════════════════════════════════════════════════════════════════════════
// Agent 18 — CAREER_PREDICTION_AGENT
// Predicts career trajectories and role-fit using intelligence + skill profiles.
// Generates personalized roadmaps with milestone planning.
// ═══════════════════════════════════════════════════════════════════════════
class CareerPredictionAgent extends BaseAgent {
    @Override public String getName() { return "CAREER_PREDICTION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_predict_career",
                "Predict the most likely career trajectory for a student or worker.",
                schema("entity_id","horizon_years","context","tenant_id")),
            new McpTool("mlsafety_get_role_fit",
                "Get fit scores for a set of target roles based on the entity's full profile.",
                schema("entity_id","role_ids_csv","tenant_id")),
            new McpTool("mlsafety_generate_roadmap",
                "Generate a personalised career roadmap with time-boxed milestones.",
                schema("entity_id","target_role","timeline_years","tenant_id")),
            new McpTool("mlsafety_get_career_market_alignment",
                "Assess how well an entity's profile aligns with current job market demand.",
                schema("entity_id","market","tenant_id")),
            new McpTool("mlsafety_compare_career_trajectories",
                "Compare two entities' predicted career trajectories.",
                schema("entity_id_a","entity_id_b","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "mlsafety_predict_career" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",         a.path("entity_id").asText());
                d.put("horizon_years",     a.path("horizon_years").asInt(5));
                d.put("top_trajectory",    "Senior Software Engineer → Tech Lead → Engineering Manager");
                d.put("probability",       0.74); d.put("alt_trajectory","Data Scientist → ML Engineer");
                d.put("alt_probability",   0.61); d.put("third_trajectory","Product Manager");
                d.put("third_probability", 0.48); d.put("model_version","career-v3");
                d.put("confidence",        0.82);
                yield AgentResponse.success(getName(), d, "Career trajectory: SWE→Tech Lead (74%) — 3 scenarios modelled.");
            }
            case "mlsafety_get_role_fit" -> {
                ArrayNode scores = mapper.createArrayNode();
                String[][] roles = {{"SWE-L4","Backend Engineer","88.4","STRONG"},
                                    {"DS-L3","Data Scientist","79.6","GOOD"},
                                    {"PM-L3","Product Manager","71.2","MODERATE"},
                                    {"ML-L3","ML Engineer","82.1","STRONG"}};
                for (String[] r : roles) { ObjectNode row = mapper.createObjectNode();
                    row.put("role_id",r[0]); row.put("role_name",r[1]); row.put("fit_score",r[2]); row.put("band",r[3]); scores.add(row); }
                ObjectNode d = mapper.createObjectNode(); d.set("roles",scores);
                d.put("entity_id",a.path("entity_id").asText()); d.put("top_fit","Backend Engineer (88.4%)");
                yield AgentResponse.success(getName(), d, "Role fit: Backend Engineer tops at 88.4%.");
            }
            case "mlsafety_generate_roadmap" -> {
                ArrayNode milestones = mapper.createArrayNode();
                String[][] ms = {{"6 months","Complete System Design course + DSA refresh"},
                                 {"1 year","Lead a backend module end-to-end"},
                                 {"2 years","Pass L4 promotion review; mentor 1 junior"},
                                 {"3 years","Drive a team of 3; own a product area"}};
                for (String[] m : ms) { ObjectNode mi = mapper.createObjectNode(); mi.put("timeline",m[0]); mi.put("milestone",m[1]); milestones.add(mi); }
                ObjectNode d = mapper.createObjectNode(); d.set("milestones",milestones);
                d.put("target_role",a.path("target_role").asText()); d.put("timeline_years",a.path("timeline_years").asInt(3));
                d.put("entity_id",a.path("entity_id").asText()); d.put("milestone_count",4);
                yield AgentResponse.success(getName(), d, "Career roadmap: 4 milestones over " + a.path("timeline_years").asInt(3) + " years.");
            }
            case "mlsafety_get_career_market_alignment" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",        a.path("entity_id").asText());
                d.put("market",           a.path("market").asText("IN-Bangalore"));
                d.put("alignment_score",  84.2); d.put("in_demand_skills_match",7);
                d.put("gap_skills",       "Cloud (AWS/GCP), Kubernetes");
                d.put("market_demand",    "HIGH for SWE profiles"); d.put("salary_percentile",72);
                yield AgentResponse.success(getName(), d, "Market alignment: 84.2% in " + a.path("market").asText("IN-Bangalore"));
            }
            case "mlsafety_compare_career_trajectories" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_a",           a.path("entity_id_a").asText()); d.put("entity_b",a.path("entity_id_b").asText());
                d.put("a_top_trajectory",   "SWE → Tech Lead"); d.put("a_probability",0.74);
                d.put("b_top_trajectory",   "Data Scientist → ML Lead"); d.put("b_probability",0.69);
                d.put("divergence_year",    2); d.put("market_advantage","A (higher demand role)");
                yield AgentResponse.success(getName(), d, "Trajectory comparison: A=SWE→TL (74%), B=DS→ML (69%).");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 19 — ACTIVE_TEST_EXECUTION_AGENT
// Manages live proctored test sessions with anti-cheat, answer submission,
// real-time monitoring, and integrity scoring.
// ═══════════════════════════════════════════════════════════════════════════
class ActiveTestExecutionAgent extends BaseAgent {
    @Override public String getName() { return "ACTIVE_TEST_EXECUTION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_start_session",
                "Initialise and start a proctored test session for a candidate.",
                schema("test_id","candidate_id","proctoring_level","tenant_id")),
            new McpTool("mlsafety_submit_answer",
                "Submit a single question answer during an active session.",
                schema("session_id","question_id","answer","time_taken_sec","tenant_id")),
            new McpTool("mlsafety_end_session",
                "End a test session, trigger scoring pipeline, and generate result.",
                schema("session_id","submitted_by","tenant_id")),
            new McpTool("mlsafety_get_proctoring_alerts",
                "Get anti-cheat proctoring alerts from a completed or live session.",
                schema("session_id","tenant_id")),
            new McpTool("mlsafety_get_session_analytics",
                "Get per-session analytics: time per question, answer confidence, behaviour.",
                schema("session_id","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "mlsafety_start_session" -> {
                String sid = uid("sess"); ObjectNode d = mapper.createObjectNode();
                d.put("session_id",   sid); d.put("test_id",a.path("test_id").asText());
                d.put("candidate_id", a.path("candidate_id").asText());
                d.put("proctoring",   a.path("proctoring_level").asText("STANDARD"));
                d.put("questions",    30); d.put("time_limit_min",60);
                d.put("status",       "ACTIVE"); d.put("started_at",System.currentTimeMillis());
                d.put("webcam",       true); d.put("tab_lock",true);
                yield AgentResponse.success(getName(), d, "Session " + sid + " started — 30Q, 60min, STANDARD proctoring.");
            }
            case "mlsafety_submit_answer" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("session_id",   a.path("session_id").asText());
                d.put("question_id",  a.path("question_id").asText());
                d.put("recorded",     true); d.put("time_taken_sec",a.path("time_taken_sec").asInt(45));
                d.put("answer_hash",  "sha256:" + Integer.toHexString(a.path("answer").asText().hashCode()));
                d.put("sequence_no",  7); d.put("flagged",false);
                yield AgentResponse.success(getName(), d, "Answer recorded (tamper-proof hash stored).");
            }
            case "mlsafety_end_session" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("session_id",        a.path("session_id").asText()); d.put("status","SUBMITTED");
                d.put("answers_recorded",  30); d.put("scoring_queued",true);
                d.put("score_eta_seconds", 15); d.put("integrity_score",100);
                d.put("proctoring_alerts", 0); d.put("submitted_at",System.currentTimeMillis());
                yield AgentResponse.success(getName(), d, "Session submitted — scoring queued (ETA 15s), integrity=100%.");
            }
            case "mlsafety_get_proctoring_alerts" -> {
                ObjectNode d = mapper.createObjectNode(); ArrayNode alerts = mapper.createArrayNode();
                d.set("alerts",alerts); d.put("session_id",a.path("session_id").asText());
                d.put("total_alerts",  0); d.put("verdict","NO_VIOLATIONS");
                d.put("integrity_score",100); d.put("tab_switches",0); d.put("face_not_visible",0);
                yield AgentResponse.success(getName(), d, "Proctoring: NO_VIOLATIONS — integrity=100%.");
            }
            case "mlsafety_get_session_analytics" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("session_id",        a.path("session_id").asText()); d.put("questions",30);
                d.put("avg_time_per_q_sec",82); d.put("fastest_q_sec",14); d.put("slowest_q_sec",184);
                d.put("revisited_count",   4); d.put("skipped_count",0);
                d.put("confidence_trend",  "HIGH at start, dropped at Q18-22");
                d.put("total_time_min",    41);
                yield AgentResponse.success(getName(), d, "Session analytics: avg 82s/question, 41 min total.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}
