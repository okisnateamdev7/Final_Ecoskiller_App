package com.ecoskiller.mlsafety.agents;

import com.ecoskiller.mlsafety.models.*;
import com.fasterxml.jackson.databind.node.*;
import java.util.List;

// ═══════════════════════════════════════════════════════════════════════════
// Agent 7 — INTELLIGENCE_OVERRIDE_AGENT
// Authorised override of ML intelligence dimension scores with full audit trail.
// ═══════════════════════════════════════════════════════════════════════════
class IntelligenceOverrideAgent extends BaseAgent {
    @Override public String getName() { return "INTELLIGENCE_OVERRIDE_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_override_dimension",
                "Override a specific intelligence dimension score with audited justification.",
                schema("entity_id","dimension","new_score","justification","reviewer_id","tenant_id")),
            new McpTool("mlsafety_get_override_history",
                "Get the complete override history for an entity.",
                schema("entity_id","days","tenant_id")),
            new McpTool("mlsafety_revert_override",
                "Revert an override and restore the ML-computed score.",
                schema("entity_id","override_id","tenant_id")),
            new McpTool("mlsafety_bulk_override",
                "Apply the same dimension adjustment to a cohort (e.g. test administration error).",
                schema("cohort_id","dimension","adjustment_delta","reason","approver_id","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "mlsafety_override_dimension" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",    a.path("entity_id").asText());
                d.put("dimension",    a.path("dimension").asText());
                d.put("ml_score",     71); d.put("new_score",   a.path("new_score").asInt(78));
                d.put("delta",        a.path("new_score").asInt(78) - 71);
                d.put("justification",a.path("justification").asText());
                d.put("override_id",  uid("ov")); d.put("audit_logged", true);
                yield AgentResponse.success(getName(), d, "Dimension '" + a.path("dimension").asText() + "' overridden with audit.");
            }
            case "mlsafety_get_override_history" -> {
                ArrayNode hist = mapper.createArrayNode();
                ObjectNode ov = mapper.createObjectNode(); ov.put("override_id","ov-001");
                ov.put("dimension","spatial"); ov.put("from",71); ov.put("to",78); ov.put("date","2026-02-15");
                ov.put("reviewer","reviewer-01"); hist.add(ov);
                ObjectNode d = mapper.createObjectNode(); d.set("overrides",hist); d.put("total",1);
                yield AgentResponse.success(getName(), d, "1 override in history.");
            }
            case "mlsafety_revert_override" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("override_id",   a.path("override_id").asText()); d.put("reverted",  true);
                d.put("restored_score",71); d.put("revert_id",uid("rv")); d.put("audit_logged",true);
                yield AgentResponse.success(getName(), d, "Override reverted. ML score (71) restored.");
            }
            case "mlsafety_bulk_override" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("cohort_id",   a.path("cohort_id").asText()); d.put("dimension",a.path("dimension").asText());
                d.put("adjustment",  a.path("adjustment_delta").asInt(0));
                d.put("entities_updated",84); d.put("bulk_id",uid("bulk-ov")); d.put("audit_logged",true);
                yield AgentResponse.success(getName(), d, "Bulk override applied to 84 entities.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 8 — INTELLIGENCE_EXPLAINABILITY_AGENT
// Generates human-readable, audience-appropriate explanations for intelligence scoring.
// ═══════════════════════════════════════════════════════════════════════════
class IntelligenceExplainabilityAgent extends BaseAgent {
    @Override public String getName() { return "INTELLIGENCE_EXPLAINABILITY_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_explain_score",
                "Generate a human-readable explanation for an intelligence dimension score.",
                schema("entity_id","dimension","audience","language","tenant_id")),
            new McpTool("mlsafety_get_feature_importance",
                "Return the top features that drove an intelligence scoring decision (SHAP).",
                schema("entity_id","dimension","tenant_id")),
            new McpTool("mlsafety_generate_parent_report",
                "Generate a parent-friendly PDF intelligence report for a student.",
                schema("student_id","language","include_recommendations","tenant_id")),
            new McpTool("mlsafety_generate_teacher_insights",
                "Generate actionable classroom insights for a teacher based on class intelligence profiles.",
                schema("teacher_id","class_id","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "mlsafety_explain_score" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",  a.path("entity_id").asText());
                d.put("dimension",  a.path("dimension").asText("logical"));
                d.put("score",      84); d.put("audience", a.path("audience").asText("teacher"));
                d.put("explanation","This student demonstrates strong pattern recognition and abstract reasoning. "
                    + "They scored in the 84th percentile, excelling particularly in sequential logic tasks. "
                    + "Consider challenging them with advanced problem-solving activities.");
                d.put("confidence", 0.92);
                yield AgentResponse.success(getName(), d, "Explanation generated for " + a.path("dimension").asText("logical"));
            }
            case "mlsafety_get_feature_importance" -> {
                ArrayNode features = mapper.createArrayNode();
                String[][] f = {{"Pattern recognition speed","31%","POSITIVE"},
                                {"Abstract reasoning accuracy","27%","POSITIVE"},
                                {"Sequential logic score","22%","POSITIVE"},
                                {"Working memory tasks","20%","POSITIVE"}};
                for (String[] fi : f) { ObjectNode row = mapper.createObjectNode();
                    row.put("feature",fi[0]); row.put("importance",fi[1]); row.put("direction",fi[2]); features.add(row); }
                ObjectNode d = mapper.createObjectNode(); d.set("features",features);
                d.put("dimension",a.path("dimension").asText("logical")); d.put("method","SHAP");
                yield AgentResponse.success(getName(), d, "SHAP feature importance: 4 features (top=pattern recognition 31%).");
            }
            case "mlsafety_generate_parent_report" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("student_id",   a.path("student_id").asText()); d.put("language",a.path("language").asText("en"));
                d.put("pages",         4); d.put("include_recommendations",a.path("include_recommendations").asBoolean(true));
                d.put("report_url",   "https://cdn.ecoskiller.com/reports/intel-" + a.path("student_id").asText() + ".pdf");
                d.put("generated_at", System.currentTimeMillis());
                yield AgentResponse.success(getName(), d, "Parent report generated (4 pages).");
            }
            case "mlsafety_generate_teacher_insights" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("teacher_id",  a.path("teacher_id").asText()); d.put("class_id",a.path("class_id").asText());
                d.put("students",    32); d.put("class_strengths","Interpersonal, Kinesthetic");
                d.put("class_gaps",  "Spatial reasoning, Musical"); d.put("suggested_activities","Group projects, Physical learning stations");
                d.put("report_url",  "https://cdn.ecoskiller.com/reports/class-" + a.path("class_id").asText() + ".pdf");
                yield AgentResponse.success(getName(), d, "Teacher insights generated for 32 students.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 9 — INTELLIGENCE_EVOLUTION_AGENT
// Tracks intelligence score changes over time and detects growth patterns.
// ═══════════════════════════════════════════════════════════════════════════
class IntelligenceEvolutionAgent extends BaseAgent {
    @Override public String getName() { return "INTELLIGENCE_EVOLUTION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_get_intelligence_timeline",
                "Get the intelligence score evolution timeline for an entity.",
                schema("entity_id","dimension","months","tenant_id")),
            new McpTool("mlsafety_predict_trajectory",
                "Predict future intelligence growth trajectory based on current trends.",
                schema("entity_id","forecast_months","tenant_id")),
            new McpTool("mlsafety_detect_growth_anomaly",
                "Detect anomalous jumps or drops in intelligence score evolution.",
                schema("entity_id","dimension","tenant_id")),
            new McpTool("mlsafety_get_cohort_growth_report",
                "Get a growth report comparing an entity to their cohort over time.",
                schema("entity_id","cohort_id","months","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "mlsafety_get_intelligence_timeline" -> {
                ArrayNode pts = mapper.createArrayNode();
                int[] scores  = {72,74,75,77,79,81,84};
                String[] months = {"Sep","Oct","Nov","Dec","Jan","Feb","Mar"};
                for (int i = 0; i < scores.length; i++) {
                    ObjectNode p = mapper.createObjectNode(); p.put("month",months[i]); p.put("score",scores[i]); pts.add(p);
                }
                ObjectNode d = mapper.createObjectNode(); d.set("timeline",pts);
                d.put("dimension",a.path("dimension").asText("logical"));
                d.put("trend","IMPROVING"); d.put("delta_total",+12); d.put("velocity_per_month",1.8);
                yield AgentResponse.success(getName(), d, "Timeline: +12 pts over 7 months (IMPROVING, 1.8/mo).");
            }
            case "mlsafety_predict_trajectory" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",           a.path("entity_id").asText());
                d.put("current_composite",    78); d.put("forecast_months",a.path("forecast_months").asInt(6));
                d.put("predicted_composite",  84); d.put("growth_per_month",1.0);
                d.put("confidence",           0.74); d.put("scenario","STEADY_GROWTH");
                d.put("optimistic_forecast",  87); d.put("pessimistic_forecast",81);
                yield AgentResponse.success(getName(), d, "Trajectory: 78→84 in 6 months (steady growth, confidence=74%).");
            }
            case "mlsafety_detect_growth_anomaly" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",        a.path("entity_id").asText()); d.put("dimension",a.path("dimension").asText("logical"));
                d.put("anomaly_detected",  false); d.put("current_velocity",+1.8);
                d.put("expected_velocity", +1.5); d.put("delta_velocity",+0.3);
                d.put("status",           "NORMAL");
                yield AgentResponse.success(getName(), d, "No growth anomaly detected — velocity within expected range.");
            }
            case "mlsafety_get_cohort_growth_report" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("entity_id",          a.path("entity_id").asText());
                d.put("cohort_id",          a.path("cohort_id").asText()); d.put("months",a.path("months").asInt(6));
                d.put("entity_growth",      +12); d.put("cohort_avg_growth",+8);
                d.put("entity_percentile",  78); d.put("outpacing_cohort",true);
                yield AgentResponse.success(getName(), d, "Entity grew +12 vs cohort avg +8 (78th percentile).");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Agent 10 — INTELLIGENCE_CALIBRATION_AGENT
// Calibrates intelligence models against normative population data.
// Reduces calibration error and ensures demographic fairness.
// ═══════════════════════════════════════════════════════════════════════════
class IntelligenceCalibrationAgent extends BaseAgent {
    @Override public String getName() { return "INTELLIGENCE_CALIBRATION_AGENT"; }
    @Override public List<McpTool> getTools() {
        return List.of(
            new McpTool("mlsafety_run_calibration",
                "Run a calibration pass aligning intelligence scores with normative population data.",
                schema("model_name","normative_dataset_id","dimension","tenant_id")),
            new McpTool("mlsafety_get_calibration_status",
                "Get calibration health and last-run details for an intelligence model.",
                schema("model_name","tenant_id")),
            new McpTool("mlsafety_validate_calibration",
                "Validate calibration output quality (KS test, bias check) before committing.",
                schema("calibration_job_id","tenant_id")),
            new McpTool("mlsafety_get_calibration_history",
                "Get calibration run history for a model including error progression.",
                schema("model_name","runs","tenant_id"))
        );
    }
    @Override public AgentResponse execute(String t, ObjectNode a) {
        return switch (t) {
            case "mlsafety_run_calibration" -> {
                String jobId = uid("cal"); ObjectNode d = mapper.createObjectNode();
                d.put("job_id",jobId); d.put("model_name",a.path("model_name").asText());
                d.put("dimension",a.path("dimension").asText("all")); d.put("normative_n",84_000);
                d.put("error_before",3.8); d.put("error_after",1.2); d.put("improvement_pct",68.4); d.put("status","COMPLETE");
                yield AgentResponse.success(getName(), d, "Calibration: error 3.8→1.2 (68% improvement). Job=" + jobId);
            }
            case "mlsafety_get_calibration_status" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("model_name",   a.path("model_name").asText()); d.put("calibrated",true);
                d.put("last_run",     "2026-01-15"); d.put("calibration_error",1.2);
                d.put("normative_n",  84_000); d.put("status","HEALTHY"); d.put("next_scheduled","2026-04-15");
                yield AgentResponse.success(getName(), d, "Calibration HEALTHY — error=1.2 (last: 2026-01-15).");
            }
            case "mlsafety_validate_calibration" -> {
                ObjectNode d = mapper.createObjectNode();
                d.put("job_id",        a.path("calibration_job_id").asText());
                d.put("valid",         true); d.put("ks_pvalue",0.42); d.put("ks_passed",true);
                d.put("bias_detected", false); d.put("demographic_parity",0.98);
                d.put("recommendation","APPROVE_FOR_PRODUCTION");
                yield AgentResponse.success(getName(), d, "Calibration validated: APPROVE_FOR_PRODUCTION.");
            }
            case "mlsafety_get_calibration_history" -> {
                ArrayNode runs = mapper.createArrayNode();
                String[][] hist = {{"2026-01-15","1.2","COMPLETE"},{"2025-10-10","2.1","COMPLETE"},{"2025-07-05","3.8","COMPLETE"}};
                for (String[] r : hist) { ObjectNode row = mapper.createObjectNode();
                    row.put("date",r[0]); row.put("error",r[1]); row.put("status",r[2]); runs.add(row); }
                ObjectNode d = mapper.createObjectNode(); d.set("history",runs); d.put("trend","IMPROVING");
                yield AgentResponse.success(getName(), d, "Calibration history: error improving 3.8→2.1→1.2.");
            }
            default -> AgentResponse.error(getName(), "Unknown tool: " + t);
        };
    }
}
