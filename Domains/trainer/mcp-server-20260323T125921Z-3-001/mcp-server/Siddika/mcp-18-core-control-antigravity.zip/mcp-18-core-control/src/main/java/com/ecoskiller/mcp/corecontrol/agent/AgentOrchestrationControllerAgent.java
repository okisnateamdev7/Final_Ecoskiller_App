package com.ecoskiller.mcp.corecontrol.agent;

import com.ecoskiller.mcp.corecontrol.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-01: AGENT_ORCHESTRATION_CONTROLLER_AGENT
 * Master controller: routes tasks to correct agents,
 * manages agent lifecycle, handles inter-agent communication.
 */
@Component
public class AgentOrchestrationControllerAgent {

    @Tool(name = "agent_task_route",
          description = "Route an incoming task to the correct agent based on task type and priority.")
    public AgentResponse routeTask(
            @ToolParam(description = "Task ID") String taskId,
            @ToolParam(description = "Task type: ROYALTY_CALC | AUDIT | COMPLIANCE | SKILL_VERIFY | DOJO") String taskType,
            @ToolParam(description = "Priority: CRITICAL | HIGH | MEDIUM | LOW") String priority,
            @ToolParam(description = "Tenant ID") String tenantId) {

        String assignedAgent = switch (taskType.toUpperCase()) {
            case "ROYALTY_CALC"  -> "mcp-17-royalty::ROYALTY_CALCULATION_AGENT";
            case "AUDIT"         -> "mcp-18-core-control::AUDIT_VERIFICATION_AGENT";
            case "COMPLIANCE"    -> "mcp-02-governance::AUDIT_COMPLIANCE_AGENT";
            case "SKILL_VERIFY"  -> "mcp-18-core-control::SKILL_VERIFICATION_PROOF_AGENT";
            case "DOJO"          -> "mcp-18-core-control::DOJO_SESSION_ORCHESTRATION_AGENT";
            default              -> "mcp-01-platform::ECOSKILLER_ANTIGRAVITY_API_AGENT";
        };

        return AgentResponse.ok("AGENT_ORCHESTRATION_CONTROLLER_AGENT",
                "Task " + taskId + " routed to " + assignedAgent,
                Map.of(
                        "taskId",            taskId,
                        "taskType",          taskType,
                        "priority",          priority,
                        "tenantId",          tenantId,
                        "assignedAgent",     assignedAgent,
                        "routingId",         "ROUTE-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(),
                        "estimatedStartMs",  priority.equals("CRITICAL") ? 100 : 500,
                        "status",            "QUEUED"
                ));
    }

    @Tool(name = "agent_lifecycle_status",
          description = "Get current lifecycle status of all active agents across MCP servers.")
    public AgentResponse lifecycleStatus(
            @ToolParam(description = "MCP server filter e.g. mcp-17-royalty or ALL") String mcpFilter) {

        return AgentResponse.ok("AGENT_ORCHESTRATION_CONTROLLER_AGENT",
                "Agent lifecycle status for filter: " + mcpFilter,
                Map.of(
                        "filter",       mcpFilter,
                        "totalAgents",  461,
                        "active",       438,
                        "idle",         20,
                        "failed",       3,
                        "byServer", Map.of(
                                "mcp-17-royalty",      Map.of("total",18,"active",17,"idle",1,"failed",0),
                                "mcp-18-core-control", Map.of("total",11,"active",11,"idle",0,"failed",0),
                                "mcp-09-intelligence", Map.of("total",19,"active",18,"idle",0,"failed",1)
                        ),
                        "checkedAt", Instant.now().toString()
                ));
    }

    @Tool(name = "agent_restart",
          description = "Restart a failed or stuck agent.")
    public AgentResponse restartAgent(
            @ToolParam(description = "Agent name to restart") String agentName,
            @ToolParam(description = "MCP server it belongs to") String mcpServer,
            @ToolParam(description = "Restart reason") String reason) {

        return AgentResponse.ok("AGENT_ORCHESTRATION_CONTROLLER_AGENT",
                "Restart initiated for agent " + agentName,
                Map.of(
                        "agentName",          agentName,
                        "mcpServer",          mcpServer,
                        "reason",             reason,
                        "restartId",          "RST-" + System.currentTimeMillis(),
                        "status",             "RESTARTING",
                        "estimatedReadySec",  15
                ));
    }

    @Tool(name = "agent_inter_communicate",
          description = "Send a message or data payload from one agent to another.")
    public AgentResponse interCommunicate(
            @ToolParam(description = "Source agent name") String fromAgent,
            @ToolParam(description = "Target agent name") String toAgent,
            @ToolParam(description = "Message type: REQUEST | RESPONSE | EVENT | ALERT") String messageType,
            @ToolParam(description = "Payload JSON string") String payload) {

        return AgentResponse.ok("AGENT_ORCHESTRATION_CONTROLLER_AGENT",
                "Message delivered from " + fromAgent + " to " + toAgent,
                Map.of(
                        "messageId",   "MSG-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase(),
                        "fromAgent",   fromAgent,
                        "toAgent",     toAgent,
                        "messageType", messageType,
                        "status",      "DELIVERED",
                        "deliveredAt", Instant.now().toString()
                ));
    }
}
