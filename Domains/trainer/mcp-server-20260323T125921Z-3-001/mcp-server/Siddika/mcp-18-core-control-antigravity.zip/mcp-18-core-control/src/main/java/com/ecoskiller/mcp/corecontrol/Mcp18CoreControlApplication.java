package com.ecoskiller.mcp.corecontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Ecoskiller MCP-18 — Governance & Core Control
 * MCP Server: mcp-18-core-control | Port: 8018
 * CAT-18 | 11 Agents | 30+ Tools
 */
@SpringBootApplication
public class Mcp18CoreControlApplication {

    public static void main(String[] args) {
        SpringApplication.run(Mcp18CoreControlApplication.class, args);
    }
}
