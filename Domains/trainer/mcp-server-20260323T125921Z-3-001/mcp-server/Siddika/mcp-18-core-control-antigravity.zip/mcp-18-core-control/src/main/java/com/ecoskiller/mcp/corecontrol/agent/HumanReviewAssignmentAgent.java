package com.ecoskiller.mcp.corecontrol.agent;

import com.ecoskiller.mcp.corecontrol.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-08: HUMAN_REVIEW_ASSIGNMENT_AGENT
 * Routes flagged decisions, anomalies, and disputes
 * to human reviewers with SLA tracking.
 */
@Component
public class HumanReviewAssignmentAgent {

    @Tool(name = "review_assign",
          description = "Assign a flagged item to a human reviewer with SLA.")
    public AgentResponse assign(
            @ToolParam(description = "Item ID to review") String itemId,
            @ToolParam(description = "Item type: DECISION | ANOMALY | DISPUTE | KYC | CONTENT") String itemType,
            @ToolParam(description = "Priority: URGENT | HIGH | NORMAL") String priority,
            @ToolParam(description = "Context / reason for review") String context) {

        int slaHours = switch (priority.toUpperCase()) {
            case "URGENT" -> 4;
            case "HIGH"   -> 24;
            default       -> 72;
        };

        return AgentResponse.ok("HUMAN_REVIEW_ASSIGNMENT_AGENT",
                "Review assigned for item " + itemId,
                Map.of(
                        "reviewId",    "REV-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(),
                        "itemId",      itemId,
                        "itemType",    itemType,
                        "priority",    priority,
                        "context",     context,
                        "assignedTo",  "reviewer-team-" + (Math.abs(itemType.hashCode()) % 3 + 1),
                        "slaHours",    slaHours,
                        "dueBy",       Instant.now().plus(slaHours, ChronoUnit.HOURS).toString(),
                        "status",      "PENDING"
                ));
    }

    @Tool(name = "review_complete",
          description = "Mark a human review as completed with outcome.")
    public AgentResponse complete(
            @ToolParam(description = "Review ID") String reviewId,
            @ToolParam(description = "Reviewer user ID") String reviewerId,
            @ToolParam(description = "Outcome: APPROVED | REJECTED | ESCALATED | NEEDS_MORE_INFO") String outcome,
            @ToolParam(description = "Reviewer notes") String notes) {

        return AgentResponse.ok("HUMAN_REVIEW_ASSIGNMENT_AGENT",
                "Review " + reviewId + " completed: " + outcome,
                Map.of(
                        "reviewId",    reviewId,
                        "reviewerId",  reviewerId,
                        "outcome",     outcome,
                        "notes",       notes,
                        "completedAt", Instant.now().toString(),
                        "nextAction",  outcome.equals("ESCALATED") ? "SENIOR_REVIEW_QUEUED" : "CLOSED"
                ));
    }

    @Tool(name = "review_queue_status",
          description = "Get current status and metrics of the human review queue.")
    public AgentResponse queueStatus() {

        return AgentResponse.ok("HUMAN_REVIEW_ASSIGNMENT_AGENT",
                "Review queue status",
                Map.of(
                        "totalPending",          14,
                        "urgent",                2,
                        "high",                  5,
                        "normal",                7,
                        "avgResolutionHours",    18,
                        "slaBreachedCount",      1,
                        "oldestPendingHours",    31
                ));
    }
}
