package com.ecoskiller.mcp.corecontrol.agent;

import com.ecoskiller.mcp.corecontrol.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-07: DOJO_SESSION_ORCHESTRATION_AGENT
 * Orchestrates real-time Dojo skill sessions:
 * scheduling, participant management, live scoring pipeline.
 */
@Component
public class DojoSessionOrchestrationAgent {

    @Tool(name = "dojo_session_create",
          description = "Create and initialize a new Dojo skill session.")
    public AgentResponse createSession(
            @ToolParam(description = "Session name") String name,
            @ToolParam(description = "Skill category e.g. Coding, Chess, Robotics") String skillCategory,
            @ToolParam(description = "Max participants") int maxParticipants,
            @ToolParam(description = "Duration minutes") int durationMinutes,
            @ToolParam(description = "Organizer user ID") String organizerId) {

        String sessionId = "DOJO-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        return AgentResponse.ok("DOJO_SESSION_ORCHESTRATION_AGENT",
                "Dojo session '" + name + "' created",
                Map.of(
                        "sessionId",       sessionId,
                        "name",            name,
                        "skillCategory",   skillCategory,
                        "maxParticipants", maxParticipants,
                        "durationMinutes", durationMinutes,
                        "organizerId",     organizerId,
                        "status",          "SCHEDULED",
                        "joinUrl",         "https://dojo.ecoskiller.com/session/" + sessionId,
                        "startsAt",        Instant.now().plus(30, ChronoUnit.MINUTES).toString()
                ));
    }

    @Tool(name = "dojo_session_start",
          description = "Start a scheduled Dojo session and activate the live scoring pipeline.")
    public AgentResponse startSession(
            @ToolParam(description = "Session ID") String sessionId) {

        return AgentResponse.ok("DOJO_SESSION_ORCHESTRATION_AGENT",
                "Dojo session " + sessionId + " is now LIVE",
                Map.of(
                        "sessionId",       sessionId,
                        "status",          "LIVE",
                        "startedAt",       Instant.now().toString(),
                        "scoringPipeline", "ACTIVE",
                        "leaderboardUrl",  "https://dojo.ecoskiller.com/leaderboard/" + sessionId
                ));
    }

    @Tool(name = "dojo_session_end",
          description = "End a Dojo session, finalize scores, and trigger certificate + royalty pipelines.")
    public AgentResponse endSession(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "Total participants who completed") int completed) {

        return AgentResponse.ok("DOJO_SESSION_ORCHESTRATION_AGENT",
                "Dojo session " + sessionId + " ended",
                Map.of(
                        "sessionId",               sessionId,
                        "status",                  "COMPLETED",
                        "participantsCompleted",   completed,
                        "endedAt",                 Instant.now().toString(),
                        "certificatesQueued",       completed,
                        "royaltyPipelineTriggered", true,
                        "reportAvailableIn",        "15 minutes"
                ));
    }

    @Tool(name = "dojo_participant_register",
          description = "Register a participant for a Dojo session.")
    public AgentResponse registerParticipant(
            @ToolParam(description = "Session ID") String sessionId,
            @ToolParam(description = "User ID") String userId,
            @ToolParam(description = "Skill level: BEGINNER | INTERMEDIATE | ADVANCED") String skillLevel) {

        return AgentResponse.ok("DOJO_SESSION_ORCHESTRATION_AGENT",
                "Participant " + userId + " registered for session " + sessionId,
                Map.of(
                        "sessionId",       sessionId,
                        "userId",          userId,
                        "skillLevel",      skillLevel,
                        "registrationId",  "REG-" + System.currentTimeMillis(),
                        "status",          "CONFIRMED"
                ));
    }
}
