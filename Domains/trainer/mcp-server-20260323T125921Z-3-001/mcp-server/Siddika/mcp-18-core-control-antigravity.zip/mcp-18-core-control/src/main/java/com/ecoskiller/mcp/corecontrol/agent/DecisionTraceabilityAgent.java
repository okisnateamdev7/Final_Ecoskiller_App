package com.ecoskiller.mcp.corecontrol.agent;

import com.ecoskiller.mcp.corecontrol.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-06: DECISION_TRACEABILITY_AGENT
 * Records WHY every AI/system decision was made.
 * Supports explainability, dispute resolution, and compliance audits.
 */
@Component
public class DecisionTraceabilityAgent {

    @Tool(name = "decision_record",
          description = "Record an AI or system decision with full rationale and inputs.")
    public AgentResponse recordDecision(
            @ToolParam(description = "Decision ID") String decisionId,
            @ToolParam(description = "Decision type: ROYALTY | SKILL_SCORE | COMPETITION_RANK | ELIGIBILITY") String type,
            @ToolParam(description = "Entity affected: user ID or contract ID") String entityId,
            @ToolParam(description = "Decision outcome") String outcome,
            @ToolParam(description = "Agent name that made the decision") String agentName) {

        return AgentResponse.ok("DECISION_TRACEABILITY_AGENT",
                "Decision recorded: " + decisionId,
                Map.of(
                        "decisionId", decisionId,
                        "type",       type,
                        "entityId",   entityId,
                        "outcome",    outcome,
                        "agentName",  agentName,
                        "traceId",    "TRC-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase(),
                        "recorded",   true,
                        "timestamp",  Instant.now().toString()
                ));
    }

    @Tool(name = "decision_explain",
          description = "Generate human-readable explanation for a recorded decision.")
    public AgentResponse explainDecision(
            @ToolParam(description = "Decision ID to explain") String decisionId,
            @ToolParam(description = "Audience: USER | ADMIN | AUDITOR | LEGAL") String audience) {

        return AgentResponse.ok("DECISION_TRACEABILITY_AGENT",
                "Explanation generated for decision " + decisionId,
                Map.of(
                        "decisionId",      decisionId,
                        "audience",        audience,
                        "explanation",     "Royalty rate 55% assigned based on creator tier GOLD, " +
                                           "revenue type COURSE_SALE, and platform policy v2.1 (Jan 2025).",
                        "inputFactors",    List.of("creator_tier=GOLD","revenue_type=COURSE_SALE","policy_version=2.1"),
                        "confidenceScore", 0.97,
                        "explainedAt",     Instant.now().toString()
                ));
    }

    @Tool(name = "decision_dispute_raise",
          description = "Raise a dispute against an AI decision for human review.")
    public AgentResponse raiseDispute(
            @ToolParam(description = "Decision ID to dispute") String decisionId,
            @ToolParam(description = "Disputing user ID") String userId,
            @ToolParam(description = "Dispute reason") String reason) {

        return AgentResponse.ok("DECISION_TRACEABILITY_AGENT",
                "Dispute raised for decision " + decisionId,
                Map.of(
                        "disputeId",   "DISP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(),
                        "decisionId",  decisionId,
                        "userId",      userId,
                        "reason",      reason,
                        "status",      "PENDING_HUMAN_REVIEW",
                        "assignedTo",  "HUMAN_REVIEW_ASSIGNMENT_AGENT",
                        "slaHours",    48
                ));
    }
}
