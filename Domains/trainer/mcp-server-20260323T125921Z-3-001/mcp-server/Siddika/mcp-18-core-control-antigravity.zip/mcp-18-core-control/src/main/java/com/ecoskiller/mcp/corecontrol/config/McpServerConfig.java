package com.ecoskiller.mcp.corecontrol.config;

import com.ecoskiller.mcp.corecontrol.agent.*;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Registers all 11 CAT-18 agents as MCP tools.
 */
@Configuration
public class McpServerConfig {

    @Bean
    public ToolCallbackProvider coreControlToolCallbacks(
            AgentOrchestrationControllerAgent    agentOrchestrationControllerAgent,
            AnomalyBehaviorDetectionAgent        anomalyBehaviorDetectionAgent,
            ApiRateLimitEnforcementCompleteAgent apiRateLimitEnforcementCompleteAgent,
            ApiRateLimitEnforcementAgent         apiRateLimitEnforcementAgent,
            AuditVerificationAgent               auditVerificationAgent,
            DecisionTraceabilityAgent            decisionTraceabilityAgent,
            DojoSessionOrchestrationAgent        dojoSessionOrchestrationAgent,
            HumanReviewAssignmentAgent           humanReviewAssignmentAgent,
            IntelligenceConfidenceIntervalAgent  intelligenceConfidenceIntervalAgent,
            SkillVerificationProofAgent          skillVerificationProofAgent,
            SystemIntegrityAttestationAgent      systemIntegrityAttestationAgent) {

        return MethodToolCallbackProvider.builder()
                .toolObjects(
                        agentOrchestrationControllerAgent,
                        anomalyBehaviorDetectionAgent,
                        apiRateLimitEnforcementCompleteAgent,
                        apiRateLimitEnforcementAgent,
                        auditVerificationAgent,
                        decisionTraceabilityAgent,
                        dojoSessionOrchestrationAgent,
                        humanReviewAssignmentAgent,
                        intelligenceConfidenceIntervalAgent,
                        skillVerificationProofAgent,
                        systemIntegrityAttestationAgent
                )
                .build();
    }
}
