package com.ecoskiller.mcp.corecontrol.agent;

import com.ecoskiller.mcp.corecontrol.model.AgentResponse;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * AGENT-02: ANOMALY_BEHAVIOR_DETECTION_AGENT
 * Detects abnormal patterns in API usage, user behavior,
 * agent responses, and financial transactions.
 */
@Component
public class AnomalyBehaviorDetectionAgent {

    @Tool(name = "anomaly_detect",
          description = "Detect anomalous behavior for a user, agent, or transaction in a time window.")
    public AgentResponse detect(
            @ToolParam(description = "Entity ID: user ID, agent name, or transaction ID") String entityId,
            @ToolParam(description = "Entity type: USER | AGENT | TRANSACTION | API_KEY") String entityType,
            @ToolParam(description = "Time window minutes") int windowMinutes) {

        double anomalyScore = 18.4; // simulated
        boolean isAnomaly   = anomalyScore > 30;

        return AgentResponse.ok("ANOMALY_BEHAVIOR_DETECTION_AGENT",
                "Anomaly detection completed for " + entityId,
                Map.of(
                        "entityId",          entityId,
                        "entityType",        entityType,
                        "windowMinutes",     windowMinutes,
                        "anomalyScore",      anomalyScore,
                        "isAnomaly",         isAnomaly,
                        "severity",          isAnomaly ? "HIGH" : "NORMAL",
                        "detectedPatterns",  isAnomaly
                                ? List.of("UNUSUAL_REQUEST_RATE", "OFF_HOURS_ACTIVITY")
                                : List.of(),
                        "recommendedAction", isAnomaly ? "ESCALATE_TO_HUMAN_REVIEW" : "NONE",
                        "analyzedAt",        Instant.now().toString()
                ));
    }

    @Tool(name = "anomaly_pattern_register",
          description = "Register a new anomaly detection pattern into the rule engine.")
    public AgentResponse registerPattern(
            @ToolParam(description = "Pattern name") String patternName,
            @ToolParam(description = "Pattern description") String description,
            @ToolParam(description = "Detection threshold value") double threshold,
            @ToolParam(description = "Severity: LOW | MEDIUM | HIGH | CRITICAL") String severity) {

        return AgentResponse.ok("ANOMALY_BEHAVIOR_DETECTION_AGENT",
                "Anomaly pattern '" + patternName + "' registered",
                Map.of(
                        "patternId",   "PAT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(),
                        "patternName", patternName,
                        "description", description,
                        "threshold",   threshold,
                        "severity",    severity,
                        "status",      "ACTIVE"
                ));
    }

    @Tool(name = "anomaly_report_get",
          description = "Get anomaly detection report for a tenant in a given period.")
    public AgentResponse getReport(
            @ToolParam(description = "Tenant ID") String tenantId,
            @ToolParam(description = "Period: TODAY | THIS_WEEK | THIS_MONTH") String period) {

        return AgentResponse.ok("ANOMALY_BEHAVIOR_DETECTION_AGENT",
                "Anomaly report for " + tenantId + " — " + period,
                Map.of(
                        "tenantId",            tenantId,
                        "period",              period,
                        "totalEventsScanned",  48320,
                        "anomaliesDetected",   7,
                        "criticalAnomalies",   1,
                        "highAnomalies",       2,
                        "resolved",            5,
                        "pending",             2
                ));
    }
}
