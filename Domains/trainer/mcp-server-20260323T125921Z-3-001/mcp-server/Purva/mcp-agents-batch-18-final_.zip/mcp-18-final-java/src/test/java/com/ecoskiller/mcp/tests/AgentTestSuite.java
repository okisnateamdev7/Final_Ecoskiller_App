package com.ecoskiller.mcp.tests;

import com.ecoskiller.mcp.agents.GenericAgent;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class AgentTestSuite {
    private static final ObjectMapper mapper = new ObjectMapper();

    public static void main(String[] args) {
        System.out.println("🧪 Testing CAT-18 FINAL Server (100+ Agents)...\n");
        testSampleAgents();
    }

    private static void testSampleAgents() {
        String[] agentNames = {
            "CLICKHOUSE_METRIC",
            "ERP_GO_REPORT",
            "MULTI_ENV",
            "USER_REGISTRATION",
            "SCORE_BIAS",
            "TENANT_BOUNDARY",
            "CALL_COST",
            "SPATIAL_PATTERN",
            "OPEN_RESPONSE",
            "CREATIVITY_DIVERGENCE",
            "SKILL_DISCOVERY",
            "SKILL_SIMILARITY",
            "SKILL_MATCHING",
            "COMPETITION_BRACKET",
            "LEADERBOARD_MGMT",
            "ACHIEVEMENT_BADGES"
        };

        System.out.println("Testing sample agents from each category:\n");
        int passed = 0;
        int failed = 0;

        for (int i = 0; i < agentNames.length; i++) {
            String agentName = agentNames[i];
            GenericAgent agent = new GenericAgent(agentName, "Test agent");
            String testName = String.format("[%d/16] %s", i + 1, agentName);
            
            try {
                ObjectNode testArgs = JsonNodeFactory.instance.objectNode();
                testArgs.put("test_param", "test_value");
                
                JsonNode result = agent.execute(agentName, testArgs);
                
                if (result != null && result.has("status")) {
                    System.out.println("✅ " + testName);
                    passed++;
                } else {
                    System.out.println("❌ " + testName + " - Invalid response");
                    failed++;
                }
            } catch (Exception e) {
                System.out.println("❌ " + testName + " - " + e.getMessage());
                failed++;
            }
        }

        System.out.println("\n" + "=".repeat(70));
        System.out.println("Sample Test Results: " + passed + " passed, " + failed + " failed");
        System.out.println("Total Agents in CAT-18 FINAL: 100+");
        System.out.println("Categories: 8 (Governance, Core Control, Skills & Competition)");
        System.out.println("=".repeat(70));
    }
}
