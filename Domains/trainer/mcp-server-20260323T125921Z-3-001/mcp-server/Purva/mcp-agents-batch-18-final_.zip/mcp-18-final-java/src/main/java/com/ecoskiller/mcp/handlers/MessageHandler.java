package com.ecoskiller.mcp.handlers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ecoskiller.mcp.agents.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class MessageHandler {
    private static final Logger logger = LoggerFactory.getLogger(MessageHandler.class);
    private static final ObjectMapper mapper = new ObjectMapper();
    
    private final Map<String, Agent> agents;
    private final ToolRegistry toolRegistry;

    public MessageHandler() {
        this.agents = new HashMap<>();
        this.toolRegistry = new ToolRegistry();
        initializeAgents();
    }

    private void initializeAgents() {
        // CAT-18 FINAL: Complete System with Governance, Core Control, Skills & Competition
        // 8 Categories x 12-13 agents each = 100+ agents
        
        // Category 1: Analytics & ERP (13 agents)
        registerAgent("clickhouse_metric_normalization", new GenericAgent("CLICKHOUSE_METRIC", "ClickHouse metrics"));
        registerAgent("erp_go_report_integration", new GenericAgent("ERP_GO_REPORT", "ERP reporting"));
        registerAgent("phone_feature_vector_emission", new GenericAgent("PHONE_FEATURE_VEC", "Feature vectors"));
        registerAgent("attendance_behavior_analytics", new GenericAgent("ATTENDANCE_BEHAVIOR", "Attendance analysis"));
        registerAgent("enrollment_analytics", new GenericAgent("ENROLLMENT_ANALYTICS", "Enrollment metrics"));
        registerAgent("analytics_connect", new GenericAgent("ANALYTICS_CONNECT", "Analytics integration"));
        registerAgent("data_warehouse_analytics", new GenericAgent("DATA_WAREHOUSE", "Data warehouse ops"));
        registerAgent("reporting_engine", new GenericAgent("REPORTING_ENGINE", "Report generation"));
        registerAgent("skill_mapping_analytics", new GenericAgent("SKILL_MAPPING", "Skill mapping"));
        registerAgent("competition_analytics", new GenericAgent("COMPETITION_ANALYTICS", "Competition stats"));
        registerAgent("performance_benchmarking", new GenericAgent("PERFORMANCE_BENCH", "Performance metrics"));
        registerAgent("trend_analysis_engine", new GenericAgent("TREND_ANALYSIS", "Trend analysis"));
        registerAgent("predictive_modeling", new GenericAgent("PREDICTIVE_MODEL", "Predictive analysis"));
        
        // Category 2: DevOps & Environment (13 agents)
        registerAgent("multi_environment_config", new GenericAgent("MULTI_ENV", "Environment config"));
        registerAgent("phone_backup_restore", new GenericAgent("BACKUP_RESTORE", "Backup/restore"));
        registerAgent("phone_end_to_end_trace", new GenericAgent("E2E_TRACE", "Tracing"));
        registerAgent("phone_external_webhook", new GenericAgent("WEBHOOKS", "Webhooks"));
        registerAgent("phone_infra_health", new GenericAgent("INFRA_HEALTH", "Health checks"));
        registerAgent("phone_monitoring_clock", new GenericAgent("MONITORING", "Monitoring"));
        registerAgent("cross_node_time_drift", new GenericAgent("TIME_SYNC", "Time sync"));
        registerAgent("model_governance_registry", new GenericAgent("MODEL_GOVERNANCE", "Model governance"));
        registerAgent("deployment_orchestration", new GenericAgent("DEPLOY_ORCH", "Deployment"));
        registerAgent("resource_optimization", new GenericAgent("RESOURCE_OPT", "Resource optimization"));
        registerAgent("load_balancing_config", new GenericAgent("LOAD_BALANCE", "Load balancing"));
        registerAgent("disaster_recovery_plan", new GenericAgent("DISASTER_RECOVERY", "Disaster recovery"));
        registerAgent("infrastructure_scaling", new GenericAgent("INFRA_SCALING", "Auto-scaling"));
        
        // Category 3: Organizer & Network Management (13 agents)
        registerAgent("user_registration", new GenericAgent("USER_REGISTRATION", "User registration"));
        registerAgent("kyc_verification", new GenericAgent("KYC_VERIFY", "KYC verification"));
        registerAgent("coordinator_onboarding", new GenericAgent("COORDINATOR_ONBOARD", "Coordinator setup"));
        registerAgent("master_organizer_onboarding", new GenericAgent("MASTER_ORGANIZER", "Master organizer"));
        registerAgent("rural_block_onboarding", new GenericAgent("RURAL_BLOCK", "Rural blocks"));
        registerAgent("role_assignment", new GenericAgent("ROLE_ASSIGN", "Role management"));
        registerAgent("household_id_linking", new GenericAgent("HOUSEHOLD_LINK", "Household linking"));
        registerAgent("society_mapping", new GenericAgent("SOCIETY_MAP", "Society mapping"));
        registerAgent("resource_allocation", new GenericAgent("RESOURCE_ALLOC", "Resource alloc"));
        registerAgent("network_management", new GenericAgent("NETWORK_MGMT", "Network mgmt"));
        registerAgent("skill_community_building", new GenericAgent("SKILL_COMMUNITY", "Skill communities"));
        registerAgent("peer_networking_engine", new GenericAgent("PEER_NETWORK", "Peer networking"));
        registerAgent("collaboration_platform", new GenericAgent("COLLABORATION", "Collaboration"));
        
        // Category 4: Scoring & Fairness (13 agents)
        registerAgent("score_bias_audit", new GenericAgent("SCORE_BIAS", "Bias auditing"));
        registerAgent("scoring_model_deprecation", new GenericAgent("MODEL_DEPRECATION", "Model deprecation"));
        registerAgent("phone_score_dispute", new GenericAgent("SCORE_DISPUTE", "Score disputes"));
        registerAgent("phone_scoring_sanitizer", new GenericAgent("SCORING_SANITIZE", "Input sanitization"));
        registerAgent("phone_speaking_time", new GenericAgent("SPEAKING_TIME", "Speaking time"));
        registerAgent("phone_min_participation", new GenericAgent("MIN_PARTICIPATION", "Minimum participation"));
        registerAgent("offline_go_to_dojo_sync", new GenericAgent("OFFLINE_SYNC", "Offline sync"));
        registerAgent("phone_ai_explainability", new GenericAgent("AI_EXPLAINABILITY", "AI explanation"));
        registerAgent("phone_behavior_analytics", new GenericAgent("BEHAVIOR_ANALYTICS", "Behavior analysis"));
        registerAgent("phone_participation_reputation", new GenericAgent("PARTICIPATION_REP", "Reputation"));
        registerAgent("cross_session_behavior", new GenericAgent("CROSS_SESSION", "Session behavior"));
        registerAgent("skill_assessment_fairness", new GenericAgent("SKILL_FAIRNESS", "Skill fairness"));
        registerAgent("competition_ranking_engine", new GenericAgent("COMPETITION_RANK", "Competition ranking"));
        
        // Category 5: Security & Compliance (14 agents)
        registerAgent("phone_tenant_boundary", new GenericAgent("TENANT_BOUNDARY", "Tenant isolation"));
        registerAgent("phone_domain_isolation", new GenericAgent("DOMAIN_ISOLATION", "Domain isolation"));
        registerAgent("tenant_audio_isolation", new GenericAgent("AUDIO_ISOLATION", "Audio isolation"));
        registerAgent("tenant_transcript_encryption", new GenericAgent("TRANSCRIPT_ENC", "Encryption"));
        registerAgent("phone_permission_matrix", new GenericAgent("PERMISSIONS", "Permissions"));
        registerAgent("phone_role_escalation", new GenericAgent("ROLE_ESCALATION", "Role escalation"));
        registerAgent("phone_feature_gating", new GenericAgent("FEATURE_GATING", "Feature gating"));
        registerAgent("phone_participant_identity", new GenericAgent("PARTICIPANT_ID", "Identity"));
        registerAgent("short_lived_token_revocation", new GenericAgent("TOKEN_MGMT", "Token mgmt"));
        registerAgent("human_override_audit", new GenericAgent("OVERRIDE_AUDIT", "Override audit"));
        registerAgent("phone_bot_detection", new GenericAgent("BOT_DETECTION", "Bot detection"));
        registerAgent("phone_transparency_notification", new GenericAgent("TRANSPARENCY", "Transparency"));
        registerAgent("media_session_security", new GenericAgent("SESSION_SECURITY", "Session security"));
        registerAgent("voice_impersonation_detection", new GenericAgent("IMPERSONATION", "Impersonation"));
        
        // Category 6: Billing & Quota (12 agents)
        registerAgent("call_cost_calculation", new GenericAgent("CALL_COST", "Cost calculation"));
        registerAgent("call_rate_limit", new GenericAgent("RATE_LIMIT", "Rate limiting"));
        registerAgent("high_usage_alert", new GenericAgent("USAGE_ALERT", "Usage alerts"));
        registerAgent("tenant_quota_enforcement", new GenericAgent("QUOTA_ENFORCE", "Quota enforcement"));
        registerAgent("sms_segment_calculation", new GenericAgent("SMS_CALC", "SMS calc"));
        registerAgent("telecom_usage_reconciliation", new GenericAgent("RECONCILIATION", "Reconciliation"));
        registerAgent("phone_resource_quota", new GenericAgent("RESOURCE_QUOTA", "Resource quota"));
        registerAgent("skill_credit_system", new GenericAgent("SKILL_CREDIT", "Skill credits"));
        registerAgent("competition_prize_management", new GenericAgent("COMPETITION_PRIZE", "Prize mgmt"));
        registerAgent("revenue_sharing_engine", new GenericAgent("REVENUE_SHARING", "Revenue sharing"));
        registerAgent("pricing_strategy_optimizer", new GenericAgent("PRICING_STRATEGY", "Pricing"));
        registerAgent("cost_allocation_engine", new GenericAgent("COST_ALLOC", "Cost allocation"));
        
        // Category 7: Core Intelligence Architect (19 agents)
        registerAgent("spatial_pattern_model", new GenericAgent("SPATIAL_PATTERN", "Spatial analysis"));
        registerAgent("reflective_depth_analyzer", new GenericAgent("REFLECTIVE_DEPTH", "Depth analysis"));
        registerAgent("population_percentile_engine", new GenericAgent("POPULATION_PERCENTILE", "Percentile calc"));
        registerAgent("open_response_evaluation", new GenericAgent("OPEN_RESPONSE", "Response eval"));
        registerAgent("naturalistic_classification", new GenericAgent("NATURALISTIC_CLASS", "Classification"));
        registerAgent("musical_frequency_model", new GenericAgent("MUSICAL_FREQUENCY", "Frequency analysis"));
        registerAgent("logical_scoring_model", new GenericAgent("LOGICAL_SCORING", "Logic scoring"));
        registerAgent("linguistic_structural_analyzer", new GenericAgent("LINGUISTIC_ANALYSIS", "Language analysis"));
        registerAgent("learning_velocity_model", new GenericAgent("LEARNING_VELOCITY", "Learning velocity"));
        registerAgent("kinesthetic_motion_model", new GenericAgent("KINESTHETIC_MOTION", "Motion analysis"));
        registerAgent("intrapersonal_behavioral_model", new GenericAgent("INTRAPERSONAL", "Behavior model"));
        registerAgent("interpersonal_graph_model", new GenericAgent("INTERPERSONAL_GRAPH", "Graph model"));
        registerAgent("intelligence_report_generator", new GenericAgent("INTELLIGENCE_REPORT", "Report gen"));
        registerAgent("intelligence_growth_timeseries", new GenericAgent("INTELLIGENCE_GROWTH", "Growth analysis"));
        registerAgent("entrepreneurial_risk_model", new GenericAgent("ENTREPRENEURIAL_RISK", "Risk model"));
        registerAgent("debate_quality_analyzer", new GenericAgent("DEBATE_QUALITY", "Debate analysis"));
        registerAgent("creativity_divergence_agent", new GenericAgent("CREATIVITY_DIVERGENCE", "Creativity analysis"));
        registerAgent("cognitive_stability_index", new GenericAgent("COGNITIVE_STABILITY", "Stability index"));
        registerAgent("ai_collaboration_efficiency", new GenericAgent("AI_COLLABORATION", "Collaboration"));
        
        // Category 8: Skills & Competition Core (13 agents) - NEW
        registerAgent("skill_discovery_engine", new GenericAgent("SKILL_DISCOVERY", "Skill discovery"));
        registerAgent("skill_proficiency_assessment", new GenericAgent("SKILL_PROFICIENCY", "Proficiency assessment"));
        registerAgent("skill_development_roadmap", new GenericAgent("SKILL_ROADMAP", "Development roadmap"));
        registerAgent("skill_matching_algorithm", new GenericAgent("SKILL_MATCHING", "Skill matching"));
        registerAgent("skill_similarity_embedding_agent", new GenericAgent("SKILL_SIMILARITY", "Similarity embedding"));
        registerAgent("skill_gap_analysis", new GenericAgent("SKILL_GAP", "Gap analysis"));
        registerAgent("competition_bracket_generator", new GenericAgent("COMPETITION_BRACKET", "Bracket generation"));
        registerAgent("competition_scoring_algorithm", new GenericAgent("COMPETITION_SCORING", "Competition scoring"));
        registerAgent("leaderboard_management", new GenericAgent("LEADERBOARD_MGMT", "Leaderboard management"));
        registerAgent("tournament_orchestrator", new GenericAgent("TOURNAMENT_ORCH", "Tournament orchestration"));
        registerAgent("prize_distribution_engine", new GenericAgent("PRIZE_DISTRIBUTION", "Prize distribution"));
        registerAgent("achievement_badge_system", new GenericAgent("ACHIEVEMENT_BADGES", "Achievement badges"));
        registerAgent("gamification_analytics", new GenericAgent("GAMIFICATION_ANALYTICS", "Gamification analytics"));
        
        logger.info("✅ Initialized {} agents for CAT-18 FINAL", agents.size());
    }

    private void registerAgent(String toolName, Agent agent) {
        agents.put(toolName, agent);
    }

    public JsonNode handle(JsonNode request) {
        try {
            String method = request.path("method").asText();
            Object id = request.path("id").isMissingNode() ? null : request.path("id").asText();
            JsonNode params = request.path("params");

            logger.debug("📩 Request - method: {}, agents available: {}", method, agents.size());

            return switch (method) {
                case "initialize" -> handleInitialize(id);
                case "tools/list" -> handleToolsList(id);
                case "tools/call" -> handleToolCall(id, params);
                case "ping" -> handlePing(id);
                default -> buildErrorResponse(id, -32601, "Method not found");
            };
        } catch (Exception e) {
            logger.error("❌ Handler error: {}", e.getMessage());
            return buildErrorResponse(null, -32603, "Internal error");
        }
    }

    private JsonNode handleInitialize(Object id) {
        ObjectNode result = JsonNodeFactory.instance.objectNode();
        
        ObjectNode serverInfo = JsonNodeFactory.instance.objectNode();
        serverInfo.put("name", "mcp-18-final");
        serverInfo.put("version", "1.0.0");
        serverInfo.put("description", "EcoSkiller CAT-18 Final — Governance, Core Control, Skills & Competition");
        serverInfo.put("total_agents", agents.size());
        serverInfo.put("categories", 8);
        
        result.set("serverInfo", serverInfo);
        
        ObjectNode protocolVersion = JsonNodeFactory.instance.objectNode();
        protocolVersion.put("version", "2024-11-05");
        result.set("protocolVersion", protocolVersion);
        
        result.set("capabilities", JsonNodeFactory.instance.objectNode());
        
        return buildResponse(id, result);
    }

    private JsonNode handleToolsList(Object id) {
        return buildResponse(id, toolRegistry.getToolsList(agents.size()));
    }

    private JsonNode handleToolCall(Object id, JsonNode params) {
        String toolName = params.path("name").asText();
        JsonNode arguments = params.path("arguments");

        logger.info("🔨 Calling tool: {}", toolName);

        Agent agent = agents.get(toolName);

        if (agent == null) {
            return buildErrorResponse(id, -32602, "Unknown tool: " + toolName);
        }

        try {
            JsonNode result = agent.execute(toolName, arguments);
            return buildResponse(id, result);
        } catch (Exception e) {
            logger.error("❌ Agent execution failed: {}", e.getMessage());
            return buildErrorResponse(id, -32603, "Agent execution error: " + e.getMessage());
        }
    }

    private JsonNode handlePing(Object id) {
        ObjectNode result = JsonNodeFactory.instance.objectNode();
        result.put("status", "alive");
        result.put("agents_available", agents.size());
        result.put("timestamp", System.currentTimeMillis());
        return buildResponse(id, result);
    }

    private JsonNode buildResponse(Object id, JsonNode result) {
        ObjectNode response = JsonNodeFactory.instance.objectNode();
        response.put("jsonrpc", "2.0");
        response.set("result", result);
        
        if (id != null) {
            response.put("id", id.toString());
        }
        
        return response;
    }

    private JsonNode buildErrorResponse(Object id, int code, String message) {
        ObjectNode response = JsonNodeFactory.instance.objectNode();
        response.put("jsonrpc", "2.0");
        
        ObjectNode errorNode = JsonNodeFactory.instance.objectNode();
        errorNode.put("code", code);
        errorNode.put("message", message);
        
        response.set("error", errorNode);
        
        if (id != null) {
            response.put("id", id.toString());
        }
        
        return response;
    }
}
