package com.ecoskiller.mcp.handlers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class ToolRegistry {
    
    public JsonNode getToolsList(int totalAgents) {
        ArrayNode tools = JsonNodeFactory.instance.arrayNode();
        
        // Analytics & ERP (13)
        addTools(tools, new String[][]{
            {"clickhouse_metric_normalization", "CLICKHOUSE_METRIC", "Normalize ClickHouse metrics"},
            {"erp_go_report_integration", "ERP_GO_REPORT", "Integrate ERP Go reports"},
            {"phone_feature_vector_emission", "PHONE_FEATURE_VEC", "Emit feature vectors"},
            {"attendance_behavior_analytics", "ATTENDANCE_BEHAVIOR", "Analyze attendance behavior"},
            {"enrollment_analytics", "ENROLLMENT_ANALYTICS", "Analyze enrollment data"},
            {"analytics_connect", "ANALYTICS_CONNECT", "Connect analytics platforms"},
            {"data_warehouse_analytics", "DATA_WAREHOUSE", "Data warehouse analytics"},
            {"reporting_engine", "REPORTING_ENGINE", "Generate reports"},
            {"skill_mapping_analytics", "SKILL_MAPPING", "Map and analyze skills"},
            {"competition_analytics", "COMPETITION_ANALYTICS", "Analyze competition data"},
            {"performance_benchmarking", "PERFORMANCE_BENCH", "Performance benchmarking"},
            {"trend_analysis_engine", "TREND_ANALYSIS", "Analyze trends"},
            {"predictive_modeling", "PREDICTIVE_MODEL", "Predictive modeling"}
        }, "Analytics");
        
        // DevOps & Environment (13)
        addTools(tools, new String[][]{
            {"multi_environment_config", "MULTI_ENV", "Multi-environment config"},
            {"phone_backup_restore", "BACKUP_RESTORE", "Backup and restore"},
            {"phone_end_to_end_trace", "E2E_TRACE", "End-to-end tracing"},
            {"phone_external_webhook", "WEBHOOKS", "External webhooks"},
            {"phone_infra_health", "INFRA_HEALTH", "Infrastructure health"},
            {"phone_monitoring_clock", "MONITORING", "Monitoring and clock"},
            {"cross_node_time_drift", "TIME_SYNC", "Cross-node time sync"},
            {"model_governance_registry", "MODEL_GOVERNANCE", "Model governance"},
            {"deployment_orchestration", "DEPLOY_ORCH", "Deployment orchestration"},
            {"resource_optimization", "RESOURCE_OPT", "Resource optimization"},
            {"load_balancing_config", "LOAD_BALANCE", "Load balancing"},
            {"disaster_recovery_plan", "DISASTER_RECOVERY", "Disaster recovery"},
            {"infrastructure_scaling", "INFRA_SCALING", "Infrastructure scaling"}
        }, "DevOps");
        
        // Network Management (13)
        addTools(tools, new String[][]{
            {"user_registration", "USER_REGISTRATION", "User registration"},
            {"kyc_verification", "KYC_VERIFY", "KYC verification"},
            {"coordinator_onboarding", "COORDINATOR_ONBOARD", "Coordinator onboarding"},
            {"master_organizer_onboarding", "MASTER_ORGANIZER", "Master organizer setup"},
            {"rural_block_onboarding", "RURAL_BLOCK", "Rural block setup"},
            {"role_assignment", "ROLE_ASSIGN", "Role assignment"},
            {"household_id_linking", "HOUSEHOLD_LINK", "Household ID linking"},
            {"society_mapping", "SOCIETY_MAP", "Society mapping"},
            {"resource_allocation", "RESOURCE_ALLOC", "Resource allocation"},
            {"network_management", "NETWORK_MGMT", "Network management"},
            {"skill_community_building", "SKILL_COMMUNITY", "Skill communities"},
            {"peer_networking_engine", "PEER_NETWORK", "Peer networking"},
            {"collaboration_platform", "COLLABORATION", "Collaboration platform"}
        }, "Network");
        
        // Scoring & Fairness (13)
        addTools(tools, new String[][]{
            {"score_bias_audit", "SCORE_BIAS", "Score bias auditing"},
            {"scoring_model_deprecation", "MODEL_DEPRECATION", "Model deprecation"},
            {"phone_score_dispute", "SCORE_DISPUTE", "Score disputes"},
            {"phone_scoring_sanitizer", "SCORING_SANITIZE", "Input sanitization"},
            {"phone_speaking_time", "SPEAKING_TIME", "Speaking time metrics"},
            {"phone_min_participation", "MIN_PARTICIPATION", "Minimum participation"},
            {"offline_go_to_dojo_sync", "OFFLINE_SYNC", "Offline sync"},
            {"phone_ai_explainability", "AI_EXPLAINABILITY", "AI explainability"},
            {"phone_behavior_analytics", "BEHAVIOR_ANALYTICS", "Behavior analytics"},
            {"phone_participation_reputation", "PARTICIPATION_REP", "Reputation management"},
            {"cross_session_behavior", "CROSS_SESSION", "Cross-session behavior"},
            {"skill_assessment_fairness", "SKILL_FAIRNESS", "Skill assessment fairness"},
            {"competition_ranking_engine", "COMPETITION_RANK", "Competition ranking"}
        }, "Scoring");
        
        // Security & Compliance (14)
        addTools(tools, new String[][]{
            {"phone_tenant_boundary", "TENANT_BOUNDARY", "Tenant isolation"},
            {"phone_domain_isolation", "DOMAIN_ISOLATION", "Domain isolation"},
            {"tenant_audio_isolation", "AUDIO_ISOLATION", "Audio isolation"},
            {"tenant_transcript_encryption", "TRANSCRIPT_ENC", "Encryption"},
            {"phone_permission_matrix", "PERMISSIONS", "Permission matrix"},
            {"phone_role_escalation", "ROLE_ESCALATION", "Role escalation"},
            {"phone_feature_gating", "FEATURE_GATING", "Feature gating"},
            {"phone_participant_identity", "PARTICIPANT_ID", "Identity management"},
            {"short_lived_token_revocation", "TOKEN_MGMT", "Token management"},
            {"human_override_audit", "OVERRIDE_AUDIT", "Override audit"},
            {"phone_bot_detection", "BOT_DETECTION", "Bot detection"},
            {"phone_transparency_notification", "TRANSPARENCY", "Transparency"},
            {"media_session_security", "SESSION_SECURITY", "Session security"},
            {"voice_impersonation_detection", "IMPERSONATION", "Impersonation detection"}
        }, "Security");
        
        // Billing & Quota (12)
        addTools(tools, new String[][]{
            {"call_cost_calculation", "CALL_COST", "Cost calculation"},
            {"call_rate_limit", "RATE_LIMIT", "Rate limiting"},
            {"high_usage_alert", "USAGE_ALERT", "Usage alerts"},
            {"tenant_quota_enforcement", "QUOTA_ENFORCE", "Quota enforcement"},
            {"sms_segment_calculation", "SMS_CALC", "SMS calculation"},
            {"telecom_usage_reconciliation", "RECONCILIATION", "Reconciliation"},
            {"phone_resource_quota", "RESOURCE_QUOTA", "Resource quota"},
            {"skill_credit_system", "SKILL_CREDIT", "Skill credits"},
            {"competition_prize_management", "COMPETITION_PRIZE", "Prize management"},
            {"revenue_sharing_engine", "REVENUE_SHARING", "Revenue sharing"},
            {"pricing_strategy_optimizer", "PRICING_STRATEGY", "Pricing strategy"},
            {"cost_allocation_engine", "COST_ALLOC", "Cost allocation"}
        }, "Billing");
        
        // Core Intelligence (19)
        addTools(tools, new String[][]{
            {"spatial_pattern_model", "SPATIAL_PATTERN", "Spatial pattern analysis"},
            {"reflective_depth_analyzer", "REFLECTIVE_DEPTH", "Reflective depth analysis"},
            {"population_percentile_engine", "POPULATION_PERCENTILE", "Population percentiles"},
            {"open_response_evaluation", "OPEN_RESPONSE", "Open response evaluation"},
            {"naturalistic_classification", "NATURALISTIC_CLASS", "Naturalistic classification"},
            {"musical_frequency_model", "MUSICAL_FREQUENCY", "Musical frequency analysis"},
            {"logical_scoring_model", "LOGICAL_SCORING", "Logical scoring"},
            {"linguistic_structural_analyzer", "LINGUISTIC_ANALYSIS", "Linguistic analysis"},
            {"learning_velocity_model", "LEARNING_VELOCITY", "Learning velocity"},
            {"kinesthetic_motion_model", "KINESTHETIC_MOTION", "Kinesthetic motion"},
            {"intrapersonal_behavioral_model", "INTRAPERSONAL", "Intrapersonal behavior"},
            {"interpersonal_graph_model", "INTERPERSONAL_GRAPH", "Interpersonal graph"},
            {"intelligence_report_generator", "INTELLIGENCE_REPORT", "Intelligence reports"},
            {"intelligence_growth_timeseries", "INTELLIGENCE_GROWTH", "Growth time series"},
            {"entrepreneurial_risk_model", "ENTREPRENEURIAL_RISK", "Entrepreneurial risk"},
            {"debate_quality_analyzer", "DEBATE_QUALITY", "Debate quality analysis"},
            {"creativity_divergence_agent", "CREATIVITY_DIVERGENCE", "Creativity & divergence"},
            {"cognitive_stability_index", "COGNITIVE_STABILITY", "Cognitive stability"},
            {"ai_collaboration_efficiency", "AI_COLLABORATION", "AI collaboration"}
        }, "Intelligence");
        
        // Skills & Competition (13) - NEW
        addTools(tools, new String[][]{
            {"skill_discovery_engine", "SKILL_DISCOVERY", "Discover and catalog skills"},
            {"skill_proficiency_assessment", "SKILL_PROFICIENCY", "Assess skill proficiency"},
            {"skill_development_roadmap", "SKILL_ROADMAP", "Create skill development roadmap"},
            {"skill_matching_algorithm", "SKILL_MATCHING", "Match skills with opportunities"},
            {"skill_similarity_embedding_agent", "SKILL_SIMILARITY", "Skill similarity embedding"},
            {"skill_gap_analysis", "SKILL_GAP", "Analyze skill gaps"},
            {"competition_bracket_generator", "COMPETITION_BRACKET", "Generate competition brackets"},
            {"competition_scoring_algorithm", "COMPETITION_SCORING", "Score competition results"},
            {"leaderboard_management", "LEADERBOARD_MGMT", "Manage leaderboards"},
            {"tournament_orchestrator", "TOURNAMENT_ORCH", "Orchestrate tournaments"},
            {"prize_distribution_engine", "PRIZE_DISTRIBUTION", "Distribute prizes"},
            {"achievement_badge_system", "ACHIEVEMENT_BADGES", "Award achievement badges"},
            {"gamification_analytics", "GAMIFICATION_ANALYTICS", "Gamification analytics"}
        }, "Skills");
        
        return tools;
    }

    private void addTools(ArrayNode tools, String[][] toolsData, String category) {
        for (String[] toolData : toolsData) {
            ObjectNode tool = JsonNodeFactory.instance.objectNode();
            tool.put("name", toolData[0]);
            tool.put("description", toolData[2]);
            tool.put("inputSchema", createInputSchema(new String[]{"parameters"}));
            
            ObjectNode meta = JsonNodeFactory.instance.objectNode();
            meta.put("agent", toolData[1]);
            meta.put("category", "CAT-18");
            meta.put("subcategory", category);
            meta.put("priority", "HIGH");
            tool.set("_meta", meta);
            
            tools.add(tool);
        }
    }

    private ObjectNode createInputSchema(String[] properties) {
        ObjectNode schema = JsonNodeFactory.instance.objectNode();
        schema.put("type", "object");
        
        ObjectNode props = JsonNodeFactory.instance.objectNode();
        for (String prop : properties) {
            ObjectNode propDef = JsonNodeFactory.instance.objectNode();
            propDef.put("type", "string");
            propDef.put("description", "Parameter: " + prop);
            props.set(prop, propDef);
        }
        
        schema.set("properties", props);
        schema.put("required", JsonNodeFactory.instance.arrayNode());
        
        return schema;
    }
}
